module AbsNumCongr : SafetyInterfaces.AbsNumType
