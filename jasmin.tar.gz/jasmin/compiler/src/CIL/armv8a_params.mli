(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_params
open Arch_utils
open Arm_common
open Armv8a_decl
open Armv8a_extra
open Armv8a_instr_decl
open Armv8a_lowering
open Armv8a_params_core
open Armv8a_stack_zeroization
open Asm_gen
open Compiler_util
open Constant_prop
open Eqtype
open Expr
open Fexpr
open Lea
open Linearization
open Lowering
open Memory_model
open Operators
open Seq
open Shift_kind
open Slh_lowering
open Sopn
open Ssrbool
open Ssrfun
open Ssrnat
open Stack_alloc_params
open Stack_zeroization
open Type
open Utils0
open Var0
open Word0
open Word_ssrZ
open Wsize

val to_opn :
  (register, empty, empty, rflag, condt) arch_toIdent -> ((lexpr
  list * (register, empty, empty, rflag, condt, armv8a_asm_op)
  asm_op_t') * rexpr list) -> (lexpr list * armv8a_extended_op sopn) * rexpr
  list

val coq_ARMv8AFopn_mov :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  (lexpr list * armv8a_extended_op sopn) * rexpr list

val coq_ARMv8AFopn_addi :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  coq_Z -> (lexpr list * armv8a_extended_op sopn) * rexpr list

val coq_ARMv8AFopn_subi :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  coq_Z -> (lexpr list * armv8a_extended_op sopn) * rexpr list

val coq_ARMv8AFopn_align :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  wsize -> (lexpr list * armv8a_extended_op sopn) * rexpr list

val coq_ARMv8AFopn_smart_addi :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list

val coq_ARMv8AFopn_smart_subi :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list

val coq_ARMv8AFopn_smart_addi_tmp :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list

val coq_ARMv8AFopn_smart_subi_tmp :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
  coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list

val armv8a_mov_ofs :
  (register, empty, empty, rflag, condt) arch_toIdent -> lval -> assgn_tag ->
  mov_kind -> pexpr -> pexpr -> (register, empty, empty, rflag, condt,
  armv8a_asm_op, armv8a_extra_op) extended_op instr_r option

val armv8a_immediate :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> coq_Z ->
  ((register, empty, empty, rflag, condt, armv8a_asm_op) asm_op_t',
  armv8a_extra_op) extended_op_gen instr_r

val armv8a_swap :
  (register, empty, empty, rflag, condt) arch_toIdent -> assgn_tag -> var_i
  -> var_i -> var_i -> var_i -> ((register, empty, empty, rflag, condt,
  armv8a_asm_op) asm_op_t', armv8a_extra_op) extended_op_gen instr_r

val armv8a_saparams :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
  stack_alloc_params

val armv8a_allocate_stack_frame :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i
  option -> coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list)
  list

val armv8a_free_stack_frame :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i
  option -> coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list)
  list

val armv8a_set_up_sp_register :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> coq_Z ->
  wsize -> var_i -> var_i -> ((lexpr list * (register, empty, empty, rflag,
  condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn) * rexpr list) list

val armv8a_tmp :
  (register, empty, empty, rflag, condt) arch_toIdent -> Ident.Ident.ident

val armv8a_tmp2 :
  (register, empty, empty, rflag, condt) arch_toIdent -> Ident.Ident.ident

val armv8a_lmove :
  (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> var_i ->
  var_i -> (lexpr list * armv8a_extended_op sopn) * rexpr list

val armv8a_check_ws : Equality.sort -> bool

val armv8a_lstore :
  (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> var_i ->
  coq_Z -> var_i -> (lexpr list * armv8a_extended_op sopn) * rexpr list

val armv8a_lload :
  (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> var_i ->
  var_i -> coq_Z -> (lexpr list * armv8a_extended_op sopn) * rexpr list

val armv8a_lloads :
  (register, empty, empty, rflag, condt) arch_toIdent -> var_i ->
  (Var.var * coq_Z) list -> coq_Z -> ((lexpr list * (register, empty, empty,
  rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn) * rexpr
  list) list

val armv8a_liparams :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
  linearization_params

val armv8a_fvars_correct :
  (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars -> progT
  -> (register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
  extended_op fun_decl list -> bool

val armv8a_loparams :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
  lowering_params

val armv8a_shparams :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op sh_params

val condt_of_rflag : rflag -> condt

val condt_not : condt -> condt

val condt_and : condt -> condt -> condt option

val condt_or : condt -> condt -> condt option

val is_rflags_GE : rflag -> rflag -> bool

val assemble_cond :
  (register, empty, empty, rflag, condt) arch_toIdent -> instr_info -> fexpr
  -> condt cexec

val is_valid_address :
  (register, empty, empty, rflag, condt) reg_address -> bool

val armv8a_agparams :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) asm_gen_params

val armv8a_szparams :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
  stack_zeroization_params

val armv8a_is_move_op :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op asm_op_t
  -> bool

val armv8a_params :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) architecture_params
