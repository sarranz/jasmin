(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open ListDef
open Nat0
open Zpower
open Arch_decl
open EqbOK
open Eqb_core_defs
open Eqtype
open Memory_model
open Sem_type
open Seq
open Sha256
open Sopn
open Ssrbool
open Ssrnat
open Tuple
open Type
open Utils0
open Waes
open Word0
open Word
open Word_ssrZ
open Wsize
open X86_decl

type __ = Obj.t

type x86_op =
| MOV of wsize
| MOVSX of wsize * wsize
| MOVZX of wsize * wsize
| CMOVcc of wsize
| XCHG of wsize
| ADD of wsize
| SUB of wsize
| MUL of wsize
| IMUL of wsize
| IMULr of wsize
| IMULri of wsize
| DIV of wsize
| IDIV of wsize
| CQO of wsize
| ADC of wsize
| SBB of wsize
| NEG of wsize
| INC of wsize
| DEC of wsize
| LZCNT of wsize
| TZCNT of wsize
| BSR of wsize
| SETcc
| BT of wsize
| CLC
| STC
| LEA of wsize
| TEST of wsize
| CMP of wsize
| AND of wsize
| ANDN of wsize
| OR of wsize
| XOR of wsize
| NOT of wsize
| ROR of wsize
| ROL of wsize
| RCR of wsize
| RCL of wsize
| SHL of wsize
| SHR of wsize
| SAL of wsize
| SAR of wsize
| SHLD of wsize
| SHRD of wsize
| RORX of wsize
| SARX of wsize
| SHRX of wsize
| SHLX of wsize
| MULX_lo_hi of wsize
| ADCX of wsize
| ADOX of wsize
| BSWAP of wsize
| POPCNT of wsize
| BTR of wsize
| BTS of wsize
| PEXT of wsize
| PDEP of wsize
| MOVX of wsize
| POR
| PADD of velem * wsize
| MOVD of wsize
| MOVV of wsize
| VMOV of wsize
| VMOVDQA of wsize
| VMOVDQU of wsize
| VPMOVSX of velem * wsize * velem * wsize
| VPMOVZX of velem * wsize * velem * wsize
| VPAND of wsize
| VPANDN of wsize
| VPOR of wsize
| VPXOR of wsize
| VPADD of velem * wsize
| VPSUB of velem * wsize
| VPAVG of velem * wsize
| VPMULL of velem * wsize
| VPMULH of wsize
| VPMULHU of wsize
| VPMULHRS of wsize
| VPMUL of wsize
| VPMULU of wsize
| VPEXTR of wsize
| VPINSR of velem
| VPSLL of velem * wsize
| VPSRL of velem * wsize
| VPSRA of velem * wsize
| VPSLLV of velem * wsize
| VPSRLV of velem * wsize
| VPSLLDQ of wsize
| VPSRLDQ of wsize
| VPSHUFB of wsize
| VPSHUFD of wsize
| VPSHUFHW of wsize
| VPSHUFLW of wsize
| VPBLEND of velem * wsize
| BLENDV of velem * wsize
| VPACKUS of velem * wsize
| VPACKSS of velem * wsize
| VSHUFPS of wsize
| VPBROADCAST of velem * wsize
| VMOVSHDUP of wsize
| VMOVSLDUP of wsize
| VPALIGNR of wsize
| VBROADCASTI128
| VPUNPCKH of velem * wsize
| VPUNPCKL of velem * wsize
| VEXTRACTI128
| VINSERTI128
| VPERM2I128
| VPERMD
| VPERMQ
| MOVEMASK of velem * wsize
| VPCMPEQ of velem * wsize
| VPCMPGT of velem * wsize
| VPSIGN of velem * wsize
| VPMADDUBSW of wsize
| VPMADDWD of wsize
| VMOVLPD
| VMOVHPD
| VPMINU of velem * wsize
| VPMINS of velem * wsize
| VPMAXU of velem * wsize
| VPMAXS of velem * wsize
| VPABS of velem * wsize
| VPTEST of wsize
| CLFLUSH
| PREFETCHT0
| PREFETCHT1
| PREFETCHT2
| PREFETCHNTA
| LFENCE
| MFENCE
| SFENCE
| RDTSC of wsize
| RDTSCP of wsize
| AESDEC
| VAESDEC of wsize
| AESDECLAST
| VAESDECLAST of wsize
| AESENC
| VAESENC of wsize
| AESENCLAST
| VAESENCLAST of wsize
| AESIMC
| VAESIMC
| AESKEYGENASSIST
| VAESKEYGENASSIST
| PCLMULQDQ
| VPCLMULQDQ of wsize
| SHA256RNDS2
| SHA256MSG1
| SHA256MSG2

val x86_op_rect :
  (wsize -> 'a1) -> (wsize -> wsize -> 'a1) -> (wsize -> wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1)
  -> 'a1 -> 'a1 -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> 'a1 -> (velem -> wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (velem -> wsize -> velem -> wsize -> 'a1) -> (velem -> wsize -> velem ->
  wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (velem -> 'a1) -> (velem -> wsize -> 'a1) -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (velem -> wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize ->
  'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (velem -> wsize -> 'a1) -> (wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize ->
  'a1) -> (velem -> wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1
  -> 'a1 -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> 'a1 -> (wsize
  -> 'a1) -> 'a1 -> (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> x86_op -> 'a1

val x86_op_rec :
  (wsize -> 'a1) -> (wsize -> wsize -> 'a1) -> (wsize -> wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1)
  -> 'a1 -> 'a1 -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> 'a1 -> (velem -> wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (velem -> wsize -> velem -> wsize -> 'a1) -> (velem -> wsize -> velem ->
  wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) ->
  (wsize -> 'a1) -> (velem -> 'a1) -> (velem -> wsize -> 'a1) -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (velem -> wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize ->
  'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (velem -> wsize -> 'a1) -> (wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize ->
  'a1) -> (velem -> wsize -> 'a1) -> (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1
  -> 'a1 -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem ->
  wsize -> 'a1) -> (velem -> wsize -> 'a1) -> (velem -> wsize -> 'a1) ->
  (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> 'a1 -> (wsize
  -> 'a1) -> 'a1 -> (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> x86_op -> 'a1

type is_x86_op =
| Coq_is_MOV of wsize * is_wsize
| Coq_is_MOVSX of wsize * is_wsize * wsize * is_wsize
| Coq_is_MOVZX of wsize * is_wsize * wsize * is_wsize
| Coq_is_CMOVcc of wsize * is_wsize
| Coq_is_XCHG of wsize * is_wsize
| Coq_is_ADD of wsize * is_wsize
| Coq_is_SUB of wsize * is_wsize
| Coq_is_MUL of wsize * is_wsize
| Coq_is_IMUL of wsize * is_wsize
| Coq_is_IMULr of wsize * is_wsize
| Coq_is_IMULri of wsize * is_wsize
| Coq_is_DIV of wsize * is_wsize
| Coq_is_IDIV of wsize * is_wsize
| Coq_is_CQO of wsize * is_wsize
| Coq_is_ADC of wsize * is_wsize
| Coq_is_SBB of wsize * is_wsize
| Coq_is_NEG of wsize * is_wsize
| Coq_is_INC of wsize * is_wsize
| Coq_is_DEC of wsize * is_wsize
| Coq_is_LZCNT of wsize * is_wsize
| Coq_is_TZCNT of wsize * is_wsize
| Coq_is_BSR of wsize * is_wsize
| Coq_is_SETcc
| Coq_is_BT of wsize * is_wsize
| Coq_is_CLC
| Coq_is_STC
| Coq_is_LEA of wsize * is_wsize
| Coq_is_TEST of wsize * is_wsize
| Coq_is_CMP of wsize * is_wsize
| Coq_is_AND of wsize * is_wsize
| Coq_is_ANDN of wsize * is_wsize
| Coq_is_OR of wsize * is_wsize
| Coq_is_XOR of wsize * is_wsize
| Coq_is_NOT of wsize * is_wsize
| Coq_is_ROR of wsize * is_wsize
| Coq_is_ROL of wsize * is_wsize
| Coq_is_RCR of wsize * is_wsize
| Coq_is_RCL of wsize * is_wsize
| Coq_is_SHL of wsize * is_wsize
| Coq_is_SHR of wsize * is_wsize
| Coq_is_SAL of wsize * is_wsize
| Coq_is_SAR of wsize * is_wsize
| Coq_is_SHLD of wsize * is_wsize
| Coq_is_SHRD of wsize * is_wsize
| Coq_is_RORX of wsize * is_wsize
| Coq_is_SARX of wsize * is_wsize
| Coq_is_SHRX of wsize * is_wsize
| Coq_is_SHLX of wsize * is_wsize
| Coq_is_MULX_lo_hi of wsize * is_wsize
| Coq_is_ADCX of wsize * is_wsize
| Coq_is_ADOX of wsize * is_wsize
| Coq_is_BSWAP of wsize * is_wsize
| Coq_is_POPCNT of wsize * is_wsize
| Coq_is_BTR of wsize * is_wsize
| Coq_is_BTS of wsize * is_wsize
| Coq_is_PEXT of wsize * is_wsize
| Coq_is_PDEP of wsize * is_wsize
| Coq_is_MOVX of wsize * is_wsize
| Coq_is_POR
| Coq_is_PADD of velem * is_velem * wsize * is_wsize
| Coq_is_MOVD of wsize * is_wsize
| Coq_is_MOVV of wsize * is_wsize
| Coq_is_VMOV of wsize * is_wsize
| Coq_is_VMOVDQA of wsize * is_wsize
| Coq_is_VMOVDQU of wsize * is_wsize
| Coq_is_VPMOVSX of velem * is_velem * wsize * is_wsize * velem * is_velem
   * wsize * is_wsize
| Coq_is_VPMOVZX of velem * is_velem * wsize * is_wsize * velem * is_velem
   * wsize * is_wsize
| Coq_is_VPAND of wsize * is_wsize
| Coq_is_VPANDN of wsize * is_wsize
| Coq_is_VPOR of wsize * is_wsize
| Coq_is_VPXOR of wsize * is_wsize
| Coq_is_VPADD of velem * is_velem * wsize * is_wsize
| Coq_is_VPSUB of velem * is_velem * wsize * is_wsize
| Coq_is_VPAVG of velem * is_velem * wsize * is_wsize
| Coq_is_VPMULL of velem * is_velem * wsize * is_wsize
| Coq_is_VPMULH of wsize * is_wsize
| Coq_is_VPMULHU of wsize * is_wsize
| Coq_is_VPMULHRS of wsize * is_wsize
| Coq_is_VPMUL of wsize * is_wsize
| Coq_is_VPMULU of wsize * is_wsize
| Coq_is_VPEXTR of wsize * is_wsize
| Coq_is_VPINSR of velem * is_velem
| Coq_is_VPSLL of velem * is_velem * wsize * is_wsize
| Coq_is_VPSRL of velem * is_velem * wsize * is_wsize
| Coq_is_VPSRA of velem * is_velem * wsize * is_wsize
| Coq_is_VPSLLV of velem * is_velem * wsize * is_wsize
| Coq_is_VPSRLV of velem * is_velem * wsize * is_wsize
| Coq_is_VPSLLDQ of wsize * is_wsize
| Coq_is_VPSRLDQ of wsize * is_wsize
| Coq_is_VPSHUFB of wsize * is_wsize
| Coq_is_VPSHUFD of wsize * is_wsize
| Coq_is_VPSHUFHW of wsize * is_wsize
| Coq_is_VPSHUFLW of wsize * is_wsize
| Coq_is_VPBLEND of velem * is_velem * wsize * is_wsize
| Coq_is_BLENDV of velem * is_velem * wsize * is_wsize
| Coq_is_VPACKUS of velem * is_velem * wsize * is_wsize
| Coq_is_VPACKSS of velem * is_velem * wsize * is_wsize
| Coq_is_VSHUFPS of wsize * is_wsize
| Coq_is_VPBROADCAST of velem * is_velem * wsize * is_wsize
| Coq_is_VMOVSHDUP of wsize * is_wsize
| Coq_is_VMOVSLDUP of wsize * is_wsize
| Coq_is_VPALIGNR of wsize * is_wsize
| Coq_is_VBROADCASTI128
| Coq_is_VPUNPCKH of velem * is_velem * wsize * is_wsize
| Coq_is_VPUNPCKL of velem * is_velem * wsize * is_wsize
| Coq_is_VEXTRACTI128
| Coq_is_VINSERTI128
| Coq_is_VPERM2I128
| Coq_is_VPERMD
| Coq_is_VPERMQ
| Coq_is_MOVEMASK of velem * is_velem * wsize * is_wsize
| Coq_is_VPCMPEQ of velem * is_velem * wsize * is_wsize
| Coq_is_VPCMPGT of velem * is_velem * wsize * is_wsize
| Coq_is_VPSIGN of velem * is_velem * wsize * is_wsize
| Coq_is_VPMADDUBSW of wsize * is_wsize
| Coq_is_VPMADDWD of wsize * is_wsize
| Coq_is_VMOVLPD
| Coq_is_VMOVHPD
| Coq_is_VPMINU of velem * is_velem * wsize * is_wsize
| Coq_is_VPMINS of velem * is_velem * wsize * is_wsize
| Coq_is_VPMAXU of velem * is_velem * wsize * is_wsize
| Coq_is_VPMAXS of velem * is_velem * wsize * is_wsize
| Coq_is_VPABS of velem * is_velem * wsize * is_wsize
| Coq_is_VPTEST of wsize * is_wsize
| Coq_is_CLFLUSH
| Coq_is_PREFETCHT0
| Coq_is_PREFETCHT1
| Coq_is_PREFETCHT2
| Coq_is_PREFETCHNTA
| Coq_is_LFENCE
| Coq_is_MFENCE
| Coq_is_SFENCE
| Coq_is_RDTSC of wsize * is_wsize
| Coq_is_RDTSCP of wsize * is_wsize
| Coq_is_AESDEC
| Coq_is_VAESDEC of wsize * is_wsize
| Coq_is_AESDECLAST
| Coq_is_VAESDECLAST of wsize * is_wsize
| Coq_is_AESENC
| Coq_is_VAESENC of wsize * is_wsize
| Coq_is_AESENCLAST
| Coq_is_VAESENCLAST of wsize * is_wsize
| Coq_is_AESIMC
| Coq_is_VAESIMC
| Coq_is_AESKEYGENASSIST
| Coq_is_VAESKEYGENASSIST
| Coq_is_PCLMULQDQ
| Coq_is_VPCLMULQDQ of wsize * is_wsize
| Coq_is_SHA256RNDS2
| Coq_is_SHA256MSG1
| Coq_is_SHA256MSG2

val is_x86_op_rect :
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  'a1 -> 'a1 -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> 'a1 -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> velem -> is_velem -> wsize -> is_wsize
  -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> 'a1 -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) -> 'a1 ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) -> 'a1 ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize ->
  is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> x86_op -> is_x86_op -> 'a1

val is_x86_op_rec :
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  'a1 -> 'a1 -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> 'a1 -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> velem -> is_velem -> wsize -> is_wsize
  -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> 'a1 -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) -> 'a1 ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) -> 'a1 ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize ->
  is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> x86_op -> is_x86_op -> 'a1

val x86_op_tag : x86_op -> positive

val is_x86_op_inhab : x86_op -> is_x86_op

val is_x86_op_functor : x86_op -> is_x86_op -> is_x86_op

type box_x86_op_MOV =
  wsize
  (* singleton inductive, whose constructor was Box_x86_op_MOV *)

val coq_Box_x86_op_MOV_0 : box_x86_op_MOV -> wsize

type box_x86_op_MOVSX = { coq_Box_x86_op_MOVSX_0 : wsize;
                          coq_Box_x86_op_MOVSX_1 : wsize }

val coq_Box_x86_op_MOVSX_0 : box_x86_op_MOVSX -> wsize

val coq_Box_x86_op_MOVSX_1 : box_x86_op_MOVSX -> wsize

type box_x86_op_SETcc =
| Box_x86_op_SETcc

type box_x86_op_PADD = { coq_Box_x86_op_PADD_0 : velem;
                         coq_Box_x86_op_PADD_1 : wsize }

val coq_Box_x86_op_PADD_0 : box_x86_op_PADD -> velem

val coq_Box_x86_op_PADD_1 : box_x86_op_PADD -> wsize

type box_x86_op_VPMOVSX = { coq_Box_x86_op_VPMOVSX_0 : velem;
                            coq_Box_x86_op_VPMOVSX_1 : wsize;
                            coq_Box_x86_op_VPMOVSX_2 : velem;
                            coq_Box_x86_op_VPMOVSX_3 : wsize }

val coq_Box_x86_op_VPMOVSX_0 : box_x86_op_VPMOVSX -> velem

val coq_Box_x86_op_VPMOVSX_1 : box_x86_op_VPMOVSX -> wsize

val coq_Box_x86_op_VPMOVSX_2 : box_x86_op_VPMOVSX -> velem

val coq_Box_x86_op_VPMOVSX_3 : box_x86_op_VPMOVSX -> wsize

type box_x86_op_VPINSR =
  velem
  (* singleton inductive, whose constructor was Box_x86_op_VPINSR *)

val coq_Box_x86_op_VPINSR_0 : box_x86_op_VPINSR -> velem

type x86_op_fields_t = __

val x86_op_fields : x86_op -> x86_op_fields_t

val x86_op_construct : positive -> x86_op_fields_t -> x86_op option

val x86_op_induction :
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  'a1 -> 'a1 -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize
  -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> 'a1 -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> velem -> is_velem -> wsize -> is_wsize
  -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (velem
  -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize ->
  'a1) -> 'a1 -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize ->
  'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (wsize ->
  is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> (velem ->
  is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem -> wsize ->
  is_wsize -> 'a1) -> (velem -> is_velem -> wsize -> is_wsize -> 'a1) ->
  (velem -> is_velem -> wsize -> is_wsize -> 'a1) -> (velem -> is_velem ->
  wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) -> 'a1 ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) -> 'a1 ->
  (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize ->
  is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> x86_op -> is_x86_op -> 'a1

val x86_op_eqb_fields :
  (x86_op -> x86_op -> bool) -> positive -> x86_op_fields_t ->
  x86_op_fields_t -> bool

val x86_op_eqb : x86_op -> x86_op -> bool

val x86_op_eqb_OK : x86_op -> x86_op -> reflect

val x86_op_eqb_OK_sumbool : x86_op -> x86_op -> bool

val coq_HB_unnamed_factory_1 : x86_op Coq_hasDecEq.axioms_

val x86_instr_decl_x86_op__canonical__eqtype_Equality : Equality.coq_type

val b_ty : ltype list

val b4_ty : ltype list

val b5_ty : ltype list

val bw_ty : wsize -> ltype list

val bw2_ty : wsize -> ltype list

val b2w_ty : wsize -> ltype list

val b4w_ty : wsize -> ltype list

val b5w_ty : wsize -> ltype list

val b5w2_ty : wsize -> ltype list

val w_ty : wsize -> ltype list

val w2_ty : wsize -> wsize -> ltype list

val w3_ty : wsize -> ltype list

val w8_ty : ltype list

val w128_ty : ltype list

val w256_ty : ltype list

val w2b_ty : wsize -> wsize -> ltype list

val ww8_ty : wsize -> ltype list

val ww8b_ty : wsize -> ltype list

val w2w8_ty : wsize -> ltype list

val w128w8_ty : ltype list

val w128ww8_ty : wsize -> ltype list

val w256w8_ty : ltype list

val w256w128w8_ty : ltype list

val w256x2w8_ty : ltype list

val coq_SF_of_word : wsize -> Word0.word -> bool

val coq_PF_of_word : wsize -> Word0.word -> bool

val coq_ZF_of_word : wsize -> Word0.word -> bool

val rflags_of_bwop : wsize -> Word0.word -> sem_tuple

val rflags_of_aluop : wsize -> Word0.word -> coq_Z -> coq_Z -> sem_tuple

val rflags_of_mul : bool -> sem_tuple

val rflags_of_div : sem_tuple

val rflags_of_andn : wsize -> Word0.word -> sem_tuple

val rflags_None_w : wsize -> sem_ot -> sem_tuple

val rflags_of_aluop_nocf : wsize -> Word0.word -> coq_Z -> sem_tuple

val flags_w : __ list -> ltuple -> wsize -> Word0.word -> ltuple

val flags_w2 : __ list -> ltuple -> wsize -> sem_tuple -> ltuple

val rflags_of_aluop_w : wsize -> Word0.word -> coq_Z -> coq_Z -> ltuple

val rflags_of_aluop_nocf_w : wsize -> Word0.word -> coq_Z -> ltuple

val rflags_of_bwop_w : wsize -> Word0.word -> ltuple

val prim_8_64 : (wsize -> 'a1) -> 'a1 prim_constructor

val prim_16_64 : (wsize -> 'a1) -> 'a1 prim_constructor

val prim_32_64 : (wsize -> 'a1) -> 'a1 prim_constructor

val prim_128_256 : (wsize -> 'a1) -> 'a1 prim_constructor

val prim_movsx : (wsize -> wsize -> x86_op) -> x86_op prim_constructor

val prim_movzx : (wsize -> wsize -> x86_op) -> x86_op prim_constructor

val prim_vv :
  (velem -> wsize -> velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_range :
  prim_x86_suffix list -> (velem -> wsize -> x86_op) -> x86_op
  prim_constructor

val primV : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_8_16 : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_8_32 : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_16 : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_16_32 : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_16_64 : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_32_64 : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primV_128 : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primMMX : (velem -> wsize -> x86_op) -> x86_op prim_constructor

val primSV_8_32 :
  (signedness -> velem -> wsize -> x86_op) -> x86_op prim_constructor

val primX : (wsize -> wsize -> x86_op) -> x86_op prim_constructor

val implicit_flags :
  (register, register_ext, xmm_register, rflag, condt) Arch_decl.arg_desc list

val implicit_flags_noCF :
  (register, register_ext, xmm_register, rflag, condt) Arch_decl.arg_desc list

val implicit_OF_CF_SF_PF :
  (register, register_ext, xmm_register, rflag, condt) Arch_decl.arg_desc list

val iCF :
  (register, register_ext, xmm_register, rflag, condt) Arch_decl.arg_desc

val reg_msb_flag : wsize -> msb_flag

val max_32 : wsize -> wsize

val map_sz :
  wsize -> (register, register_ext, xmm_register, rflag, condt) asm_args ->
  (wsize * (register, register_ext, xmm_register, rflag, condt) asm_arg) list

val pp_name :
  string -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  asm_args -> (register, register_ext, xmm_register, rflag, condt) pp_asm_op

val pp_name_ty :
  string -> wsize list -> (register, register_ext, xmm_register, rflag,
  condt) asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val pp_iname :
  string -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  asm_args -> (register, register_ext, xmm_register, rflag, condt) pp_asm_op

val pp_viname_long :
  string -> velem -> wsize -> (register, register_ext, xmm_register, rflag,
  condt) asm_args -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val pp_viname :
  string -> velem -> wsize -> (register, register_ext, xmm_register, rflag,
  condt) asm_args -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val pp_viname_ww_128 :
  string -> velem -> wsize -> (register, register_ext, xmm_register, rflag,
  condt) asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val pp_iname_w_8 :
  string -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val pp_iname_ww_8 :
  string -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val get_ct :
  (register, register_ext, xmm_register, rflag, condt) asm_arg list ->
  (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op_ext * (register, register_ext, xmm_register, rflag, condt)
  asm_arg list

val pp_ct :
  string -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val pp_cqo :
  wsize -> (register, register_ext, xmm_register, rflag, condt) asm_args ->
  (register, register_ext, xmm_register, rflag, condt) pp_asm_op

val c : (register, register_ext, xmm_register, rflag, condt) arg_kind list

val r : (register, register_ext, xmm_register, rflag, condt) arg_kind list

val rx : (register, register_ext, xmm_register, rflag, condt) arg_kind list

val m :
  bool -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val i :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val rm :
  bool -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val rxm :
  bool -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val rmi :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val ri :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val m_r :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list

val r_rm_false :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list

val r_rm :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list

val r_rmi :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list

val m_ri :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list

val xmm : (register, register_ext, xmm_register, rflag, condt) arg_kind list

val xmmm :
  bool -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val xmmmi :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list

val xmm_xmmm :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list

val xmmm_xmm :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list

val xmm_xmm_xmmm :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list

val xmm_xmm_xmmmi :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list

val x86_MOV : wsize -> Word0.word -> Word0.word

val check_mov :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val coq_Ox86_MOV_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_movx :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val pp_movd :
  string -> Equality.sort -> (register, register_ext, xmm_register, rflag,
  condt) asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val x86_MOVX : wsize -> Word0.word -> Word0.word

val coq_Ox86_MOVX_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_por :
  (register, register_ext, xmm_register, rflag, condt) i_args_kinds

val x86_POR :
  (register, register_ext, xmm_register, rflag, condt) wreg -> (register,
  register_ext, xmm_register, rflag, condt) wreg -> (register, register_ext,
  xmm_register, rflag, condt) wreg

val coq_Ox86_POR_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val check_padd :
  (register, register_ext, xmm_register, rflag, condt) i_args_kinds

val coq_Ox86_PADD_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_movsx :
  wsize -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  arg_kind list list list

val pp_movsx :
  Equality.sort -> Equality.sort -> (register, register_ext, xmm_register,
  rflag, condt) asm_arg list -> (register, register_ext, xmm_register, rflag,
  condt) pp_asm_op

val size_MOVSX : wsize -> wsize -> bool

val x86_MOVSX : wsize -> wsize -> Word0.word -> sem_tuple

val coq_Ox86_MOVSX_instr :
  (wsize -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val pp_movzx :
  wsize -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val size_MOVZX : wsize -> wsize -> bool

val x86_MOVZX : wsize -> wsize -> Word0.word -> sem_tuple

val coq_Ox86_MOVZX_instr :
  (wsize -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_xchg :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list list

val x86_XCHG : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_XCHG_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val c_r_rm :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list

val x86_CMOVcc : wsize -> bool -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_CMOVcc_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_add :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_ADD : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_ADD_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_SUB : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_SUB_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_mul :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_MUL : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_MUL_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_IMUL_overflow : wsize -> Word0.word -> Word0.word -> bool

val x86_IMUL : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_IMUL_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_IMULt : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_IMULr_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_IMULri_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_DIV :
  wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple exec

val coq_Ox86_DIV_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_IDIV :
  wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple exec

val coq_Ox86_IDIV_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_CQO : wsize -> Word0.word -> Word0.word

val coq_Ox86_CQO_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val add_carry : wsize -> coq_Z -> coq_Z -> coq_Z -> Word0.word

val x86_ADC : wsize -> Word0.word -> Word0.word -> bool -> sem_tuple

val coq_Ox86_ADC_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val sub_borrow : wsize -> coq_Z -> coq_Z -> coq_Z -> Word0.word

val x86_SBB : wsize -> Word0.word -> Word0.word -> bool -> sem_tuple

val coq_Ox86_SBB_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_adcx :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_ADCX : wsize -> Word0.word -> Word0.word -> bool -> sem_tuple

val coq_Ox86_ADCX_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_ADOX_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_mulx :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list list

val x86_MULX_lo_hi : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_MULX_lo_hi_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_neg :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_NEG : wsize -> Word0.word -> sem_tuple

val coq_Ox86_NEG_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_INC : wsize -> Word0.word -> sem_tuple

val coq_Ox86_INC_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_DEC : wsize -> Word0.word -> sem_tuple

val coq_Ox86_DEC_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_LZCNT : wsize -> Word0.word -> sem_tuple

val coq_Ox86_LZCNT_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_TZCNT : wsize -> Word0.word -> sem_tuple

val coq_Ox86_TZCNT_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_BSR : wsize -> Word0.word -> sem_tuple exec

val coq_Ox86_BSR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_setcc :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list list

val x86_SETcc : bool -> sem_tuple

val coq_Ox86_SETcc_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val check_bt :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_BT : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_BT_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_CLC : sem_tuple

val coq_Ox86_CLC_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_STC : sem_tuple

val coq_Ox86_STC_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val check_lea :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_LEA : wsize -> Word0.word -> sem_tuple

val coq_Ox86_LEA_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_test :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_TEST : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_TEST_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_cmp :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_CMP : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_CMP_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_AND : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_AND_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_OR : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_OR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_XOR : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_XOR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_andn :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_ANDN : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_ANDN_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_NOT : wsize -> Word0.word -> sem_tuple

val coq_Ox86_NOT_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_ror :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_shift_mask : wsize -> Word0.word

val x86_ROR : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_ROR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_ROL : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_ROL_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_rotate_with_carry :
  wsize -> (word -> nat -> word) -> (Word0.word -> bool -> bool) ->
  Word0.word -> Word0.word -> bool -> sem_tuple

val x86_RCR : wsize -> Word0.word -> Word0.word -> bool -> sem_tuple

val coq_Ox86_RCR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_RCL : wsize -> Word0.word -> Word0.word -> bool -> sem_tuple

val coq_Ox86_RCL_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val rflags_OF :
  wsize -> wsize -> Word0.word -> Word0.word -> bool -> bool -> sem_tuple

val x86_SHL : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_SHL_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_SHR : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_SHR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_SAL_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_SAR : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_SAR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_shld :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val safe_shxd : wsize -> safe_cond list

val x86_SHLD :
  wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple exec

val coq_Ox86_SHLD_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_SHRD :
  wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple exec

val coq_Ox86_SHRD_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_rorx :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_RORX : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_RORX_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_bmi_shift :
  wsize -> (Word0.word -> coq_Z -> Word0.word) -> Word0.word -> Word0.word ->
  Word0.word

val check_sarx :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_SARX : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_SARX_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_SHRX : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_SHRX_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_SHLX : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_SHLX_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_BSWAP : wsize -> Word0.word -> sem_tuple

val coq_Ox86_BSWAP_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_POPCNT : wsize -> Word0.word -> sem_tuple

val coq_Ox86_POPCNT_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_BTX :
  (wsize -> Word0.word -> Word0.word -> sem_ot) -> wsize -> Word0.word ->
  Word0.word -> sem_tuple

val coq_Ox86_BTR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_BTS_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_PEXT : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_PEXT_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_PDEP : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_PDEP_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_movd :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_MOVD : wsize -> Word0.word -> sem_tuple

val coq_Ox86_MOVD_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_MOVV_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_VMOV_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_vmovdq :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_VMOVDQ : wsize -> Word0.word -> sem_tuple

val coq_Ox86_VMOVDQA_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_VMOVDQU_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val pp_vpmovx :
  string -> velem -> wsize -> velem -> wsize -> (register, register_ext,
  xmm_register, rflag, condt) asm_arg list -> (register, register_ext,
  xmm_register, rflag, condt) pp_asm_op

val vector_size : velem -> wsize -> coq_Z option

val check_vector_length : velem -> wsize -> velem -> wsize -> bool

val x86_VPMOVSX : velem -> wsize -> velem -> wsize -> Word0.word -> Word0.word

val coq_Ox86_VPMOVSX_instr :
  (velem -> wsize -> velem -> wsize -> (register, register_ext, xmm_register,
  rflag, condt) instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMOVZX : velem -> wsize -> velem -> wsize -> Word0.word -> Word0.word

val coq_Ox86_VPMOVZX_instr :
  (velem -> wsize -> velem -> wsize -> (register, register_ext, xmm_register,
  rflag, condt) instr_desc_t) * (string * x86_op prim_constructor)

val check_xmm_xmm_xmmm :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_VPAND : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPAND_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPANDN : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPANDN_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPOR : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPOR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPXOR : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPXOR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPADD : velem -> wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPADD_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSUB : velem -> wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPSUB_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPAVG : velem -> wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPAVG_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMULL : velem -> wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPMULL_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMUL : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPMUL_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMULU : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPMULU_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMULH : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPMULH_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMULHU : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPMULHU_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMULHRS : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPMULHRS_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_vpextr :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val pp_viname_t :
  string -> velem -> wsize list -> (register, register_ext, xmm_register,
  rflag, condt) asm_arg list -> (register, register_ext, xmm_register, rflag,
  condt) pp_asm_op

val x86_nelem_mask : wsize -> wsize -> Word0.word

val x86_VPEXTR : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPEXTR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val pp_vpinsr :
  velem -> (register, register_ext, xmm_register, rflag, condt) asm_arg list
  -> (register, register_ext, xmm_register, rflag, condt) pp_asm_op

val check_vpinsr :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_VPINSR : velem -> Word0.word -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPINSR_instr :
  (velem -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_xmm_xmm_imm8 :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_u128_shift :
  wsize -> wsize -> (Word0.word -> coq_Z -> Word0.word) -> Word0.word ->
  Word0.word -> sem_tuple

val check_xmm_xmm_xmmmi :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_VPSLL : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSLL_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSRL : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSRL_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSRA : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSRA_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_u128_shift_variable :
  wsize -> wsize -> (Word0.word -> coq_Z -> Word0.word) -> Word0.word ->
  Word0.word -> sem_tuple

val x86_VPSLLV : wsize -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSLLV_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSRLV : wsize -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSRLV_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_vpsxldq :
  wsize -> (Word0.word -> Word0.word -> sem_tuple) -> Word0.word ->
  Word0.word -> sem_tuple

val x86_VPSLLDQ : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSLLDQ_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSRLDQ : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSRLDQ_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSHUFB : wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPSHUFB_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_xmm_xmmm_imm8 :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_vpshuf :
  wsize -> (Word0.word -> coq_Z -> Word0.word) -> Word0.word -> Word0.word ->
  sem_tuple

val x86_VPSHUFHW : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSHUFHW_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSHUFLW : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSHUFLW_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSHUFD : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSHUFD_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPUNPCKH : velem -> wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPUNPCKH_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPUNPCKL : velem -> wsize -> Word0.word -> Word0.word -> Word0.word

val coq_Ox86_VPUNPCKL_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_xmm_xmm_xmmm_imm8 :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val wpblendw : Word0.word -> Word0.word -> Word0.word -> Word0.word

val x86_VPBLEND :
  Equality.sort -> wsize -> Word0.word -> Word0.word -> Word0.word ->
  sem_tuple

val coq_Ox86_VPBLEND_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_xmm_xmm_xmmm_xmm :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_BLENDV :
  velem -> wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_BLENDV_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_SaturatedSignedToUnsigned : wsize -> wsize -> Word0.word -> Word0.word

val coq_SaturatedSignedToSigned : wsize -> wsize -> Word0.word -> Word0.word

val vpack2 :
  wsize -> wsize -> wsize -> (Word0.word -> Word0.word) -> Word0.word ->
  Word0.word -> Word0.word

val x86_VPACKUS :
  Equality.sort -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPACKUS_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPACKSS :
  Equality.sort -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPACKSS_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val wshufps_128 : Word0.word -> Word0.word -> Word0.word -> Word0.word

val x86_VSHUFPS : wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VSHUFPS_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val pp_vpbroadcast :
  velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  asm_arg list -> (register, register_ext, xmm_register, rflag, condt)
  pp_asm_op

val check_xmm_xmmm :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_VPBROADCAST : wsize -> wsize -> Word0.word -> sem_tuple

val coq_Ox86_VPBROADCAST_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VMOVSHDUP : wsize -> Word0.word -> sem_tuple

val coq_Ox86_VMOVSHDUP_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VMOVSLDUP : wsize -> Word0.word -> sem_tuple

val coq_Ox86_VMOVSLDUP_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPALIGNR128 : Word0.word -> Word0.word -> Word0.word -> Word0.word

val x86_VPALIGNR :
  wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPALIGNR_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_VBROADCASTI128_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val check_xmmm_xmm_imm8 :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_VEXTRACTI128 : Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VEXTRACTI128_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_VINSERTI128 : Word0.word -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VINSERTI128_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_VPERM2I128 : Word0.word -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPERM2I128_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_VPERMD : Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPERMD_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_VPERMQ : Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPERMQ_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_MOVEMASK_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPCMPEQ : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPCMPEQ_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPCMPGT : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPCMPGT_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPSIGN : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPSIGN_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMADDUBSW : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPMADDUBSW_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMADDWD : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPMADDWD_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_movpd :
  (register, register_ext, xmm_register, rflag, condt) arg_kind list list list

val x86_VMOVLPD : Word0.word -> sem_tuple

val coq_Ox86_VMOVLPD_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_VMOVHPD : Word0.word -> sem_tuple

val coq_Ox86_VMOVHPD_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_VPMINS : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPMINS_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMINU : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPMINU_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMAXS : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPMAXS_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPMAXU : velem -> wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPMAXU_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val x86_VPABS : velem -> wsize -> Word0.word -> sem_tuple

val coq_Ox86_VPABS_instr :
  (velem -> wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val check_vptest :
  wsize -> (register, register_ext, xmm_register, rflag, condt) arg_kind list
  list list

val x86_VPTEST : wsize -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_VPTEST_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_RDTSC_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_RDTSCP_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_CLFLUSH_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_PREFETCHT0_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_PREFETCHT1_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_PREFETCHT2_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_PREFETCHNTA_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_LFENCE_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_MFENCE_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_SFENCE_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_AESDEC : Word0.word -> Word0.word -> sem_tuple

val x86_AESDECLAST : Word0.word -> Word0.word -> sem_tuple

val x86_AESENC : Word0.word -> Word0.word -> sem_tuple

val x86_AESENCLAST : Word0.word -> Word0.word -> sem_tuple

val x86_AESIMC : Word0.word -> sem_tuple

val x86_AESKEYGENASSIST : Word0.word -> Word0.word -> sem_tuple

val mk_instr_aes2 :
  string -> string -> doit_t -> x86_op -> sem_tuple sem_prod -> msb_flag ->
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val mk_instr_aes3 :
  string -> string -> doit_t -> (wsize -> x86_op) -> (Word0.word ->
  Word0.word -> Word0.word) -> (wsize -> (register, register_ext,
  xmm_register, rflag, condt) instr_desc_t) * (string * x86_op
  prim_constructor)

val coq_Ox86_AESDEC_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_VAESDEC_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_AESDECLAST_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_VAESDECLAST_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_AESENC_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_VAESENC_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_AESENCLAST_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_VAESENCLAST_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_AESIMC_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_VAESIMC_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_AESKEYGENASSIST_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_VAESKEYGENASSIST_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val wclmulq : Word0.word -> Word0.word -> Word0.word

val wVPCLMULDQD :
  wsize -> Word0.word -> Word0.word -> Word0.word -> Word0.word

val x86_VPCLMULQDQ :
  wsize -> Word0.word -> Word0.word -> Word0.word -> sem_tuple

val coq_Ox86_PCLMULQDQ_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_VPCLMULQDQ_instr :
  (wsize -> (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t) * (string * x86_op prim_constructor)

val coq_Ox86_SHA256RNDS2_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_SHA256MSG1_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val coq_Ox86_SHA256MSG2_instr :
  (register, register_ext, xmm_register, rflag, condt)
  instr_desc_t * (string * x86_op prim_constructor)

val x86_instr_desc :
  x86_op -> (register, register_ext, xmm_register, rflag, condt) instr_desc_t

val x86_prim_string : (string * x86_op prim_constructor) list

val eqC_x86_op : x86_op eqTypeC

val x86_op_decl :
  (register, register_ext, xmm_register, rflag, condt, x86_op) asm_op_decl

type x86_prog =
  (register, register_ext, xmm_register, rflag, condt, x86_op) asm_prog
