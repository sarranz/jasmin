(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Eqtype
open Expr
open Fexpr
open Memory_model
open Otbn_decl
open Otbn_instr_decl
open Var0
open Wsize

(** val is_arith_small : coq_Z -> bool **)

let is_arith_small imm =
  (&&)
    (Z.leb
      (Z.opp
        (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xI (Coq_xI (Coq_xO
          Coq_xH))))))
      imm)
    (Z.ltb imm
      (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xI (Coq_xI (Coq_xO Coq_xH))))))

(** val is_arith_small_neg : coq_Z -> bool **)

let is_arith_small_neg imm =
  is_arith_small (Z.opp imm)

module OTBNFopn_core =
 struct
  type opn_args = (lexpr list * otbn_op) * rexpr list

  (** val op_gen : rv_mnemonic -> var_i -> rexpr list -> opn_args **)

  let op_gen mn x res =
    ((((LLvar x) :: []), (RV32 mn)), res)

  (** val op_un_imm : rv_mnemonic -> var_i -> coq_Z -> opn_args **)

  let op_un_imm mn x imm =
    op_gen mn x ((rconst otbn_decl.reg_size imm) :: [])

  (** val op_bin_reg : rv_mnemonic -> var_i -> var_i -> var_i -> opn_args **)

  let op_bin_reg mn x y z =
    op_gen mn x ((rvar y) :: ((rvar z) :: []))

  (** val op_bin_imm : rv_mnemonic -> var_i -> var_i -> coq_Z -> opn_args **)

  let op_bin_imm mn x y imm =
    op_gen mn x ((rvar y) :: ((rconst otbn_decl.reg_size imm) :: []))

  (** val add : var_i -> var_i -> var_i -> opn_args **)

  let add =
    op_bin_reg ADD

  (** val sub : var_i -> var_i -> var_i -> opn_args **)

  let sub =
    op_bin_reg SUB

  (** val li : var_i -> coq_Z -> opn_args **)

  let li =
    op_un_imm LI

  (** val addi : var_i -> var_i -> coq_Z -> opn_args **)

  let addi =
    op_bin_imm ADDI

  (** val subi : var_i -> var_i -> coq_Z -> opn_args **)

  let subi x y imm =
    addi x y (Z.opp imm)

  (** val andi : var_i -> var_i -> coq_Z -> opn_args **)

  let andi =
    op_bin_imm ANDI

  (** val mov : var_i -> var_i -> opn_args **)

  let mov x y =
    addi x y Z0

  (** val smart_mov : var_i -> var_i -> opn_args list **)

  let smart_mov x y =
    if eq_op Var.coq_MvMake_var__canonical__eqtype_Equality
         (Obj.magic x.v_var) (Obj.magic y.v_var)
    then []
    else (mov x y) :: []

  (** val lw : wsize -> var_i -> fexpr -> opn_args **)

  let lw ws x e =
    ((((LLvar x) :: []), (RV32 LW)), ((Load (Aligned, ws, e)) :: []))

  (** val sw : wsize -> fexpr -> var_i -> opn_args **)

  let sw ws e y =
    ((((Store (Aligned, ws, e)) :: []), (RV32 SW)), ((rvar y) :: []))

  (** val align : var_i -> var_i -> wsize -> opn_args **)

  let align x y al =
    andi x y (Z.opp (wsize_size al))

  (** val is_mov : coq_Z option -> coq_Z -> bool **)

  let is_mov neutral imm =
    match neutral with
    | Some n -> Z.eqb imm n
    | None -> false

  (** val gen_unsafe_smart_opi :
      (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
      opn_args) -> (coq_Z -> bool) -> coq_Z option -> var_i -> var_i -> var_i
      -> coq_Z -> opn_args list **)

  let gen_unsafe_smart_opi on_reg on_imm is_small neutral tmp x y imm =
    if is_mov neutral imm
    then smart_mov x y
    else if is_small imm
         then (on_imm x y imm) :: []
         else (li tmp imm) :: ((on_reg x y tmp) :: [])

  (** val gen_smart_opi :
      (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
      opn_args) -> (coq_Z -> bool) -> coq_Z option -> var_i -> var_i -> var_i
      -> coq_Z -> opn_args list option **)

  let gen_smart_opi on_reg on_imm is_small neutral tmp x y imm =
    if (||) (is_mov neutral imm)
         ((||) (is_small imm)
           (negb
             (eq_op Var.coq_MvMake_var__canonical__eqtype_Equality
               (Obj.magic y.v_var) (Obj.magic tmp.v_var))))
    then Some
           (gen_unsafe_smart_opi on_reg on_imm is_small neutral tmp x y imm)
    else None

  (** val smart_addi : var_i -> var_i -> coq_Z -> opn_args list option **)

  let smart_addi x y =
    gen_smart_opi add addi is_arith_small (Some Z0) x x y

  (** val smart_subi : var_i -> var_i -> coq_Z -> opn_args list option **)

  let smart_subi x y imm =
    gen_smart_opi sub subi is_arith_small_neg (Some Z0) x x y imm

  (** val gen_smart_opi_tmp :
      (coq_Z -> bool) -> (var_i -> var_i -> var_i -> opn_args) -> (var_i ->
      var_i -> coq_Z -> opn_args) -> var_i -> var_i -> coq_Z -> opn_args list
      option **)

  let gen_smart_opi_tmp is_arith_small0 on_reg on_imm x tmp imm =
    gen_smart_opi on_reg on_imm is_arith_small0 (Some Z0) tmp x x imm

  (** val smart_addi_tmp : var_i -> var_i -> coq_Z -> opn_args list option **)

  let smart_addi_tmp x tmp imm =
    gen_smart_opi_tmp is_arith_small add addi x tmp imm

  (** val smart_subi_tmp : var_i -> var_i -> coq_Z -> opn_args list option **)

  let smart_subi_tmp x tmp imm =
    gen_smart_opi_tmp is_arith_small_neg sub subi x tmp imm
 end
