(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Flag_combination
open Utils0

type __ = Obj.t

type rflag =
| NF
| ZF
| CF
| VF

val rflag_rect : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1

val rflag_rec : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1

type is_rflag =
| Coq_is_NF
| Coq_is_ZF
| Coq_is_CF
| Coq_is_VF

val is_rflag_rect : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1

val is_rflag_rec : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1

val rflag_tag : rflag -> positive

val is_rflag_inhab : rflag -> is_rflag

val is_rflag_functor : rflag -> is_rflag -> is_rflag

type box_rflag_NF =
| Box_rflag_NF

type rflag_fields_t = __

val rflag_fields : rflag -> rflag_fields_t

val rflag_construct : positive -> rflag_fields_t -> rflag option

val rflag_induction : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1

val rflag_eqb_fields :
  (rflag -> rflag -> bool) -> positive -> rflag_fields_t -> rflag_fields_t ->
  bool

val rflag_eqb : rflag -> rflag -> bool

val rflag_eqb_OK : rflag -> rflag -> reflect

val rflag_eqb_OK_sumbool : rflag -> rflag -> bool

val eqTC_rflag : rflag eqTypeC

val rflag_eqType : Equality.coq_type

val rflags : rflag list

val finTC_rflag : rflag finTypeC

val rflag_finType : Finite.coq_type

val flag_to_string : rflag -> string

val rflag_toS : rflag coq_ToString

type condt =
| EQ_ct
| NE_ct
| CS_ct
| CC_ct
| MI_ct
| PL_ct
| VS_ct
| VC_ct
| HI_ct
| LS_ct
| GE_ct
| LT_ct
| GT_ct
| LE_ct

val condt_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> condt -> 'a1

val condt_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> condt -> 'a1

type is_condt =
| Coq_is_EQ_ct
| Coq_is_NE_ct
| Coq_is_CS_ct
| Coq_is_CC_ct
| Coq_is_MI_ct
| Coq_is_PL_ct
| Coq_is_VS_ct
| Coq_is_VC_ct
| Coq_is_HI_ct
| Coq_is_LS_ct
| Coq_is_GE_ct
| Coq_is_LT_ct
| Coq_is_GT_ct
| Coq_is_LE_ct

val is_condt_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1

val is_condt_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1

val condt_tag : condt -> positive

val is_condt_inhab : condt -> is_condt

val is_condt_functor : condt -> is_condt -> is_condt

type box_condt_EQ_ct =
| Box_condt_EQ_ct

type condt_fields_t = __

val condt_fields : condt -> condt_fields_t

val condt_construct : positive -> condt_fields_t -> condt option

val condt_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1

val condt_eqb_fields :
  (condt -> condt -> bool) -> positive -> condt_fields_t -> condt_fields_t ->
  bool

val condt_eqb : condt -> condt -> bool

val condt_eqb_OK : condt -> condt -> reflect

val condt_eqb_OK_sumbool : condt -> condt -> bool

val eqTC_condt : condt eqTypeC

val condt_eqType : Equality.coq_type

val condts : condt list

val finTC_condt : condt finTypeC

val condt_finType : Finite.coq_type

val string_of_condt : condt -> string

val arm_eval_cond :
  (rflag -> (error, bool) result) -> condt -> (error, bool) result

val arm_fc_of_cfc : combine_flags_core -> flag_combination

val arm_fcp : coq_FlagCombinationParams
