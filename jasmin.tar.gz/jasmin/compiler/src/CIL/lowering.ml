(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Compiler_util
open Expr
open Seq
open Sopn
open Type
open Utils0
open Var0

type fresh_vars = string -> atype -> Ident.Ident.ident

(** val disj_fvars : SvExtra.Sv.t -> SvExtra.Sv.t -> bool **)

let disj_fvars fvars x =
  SvExtra.disjoint x fvars

(** val fvars_correct :
    'a1 asmOp -> progT -> Ident.Ident.ident list -> SvExtra.Sv.t -> 'a1
    fun_decl list -> bool **)

let fvars_correct asmop pT all_fresh_vars fvars fds =
  (&&) (disj_fvars fvars (vars_p asmop pT fds))
    (uniq Ident.ident_eqType (Obj.magic all_fresh_vars))

(** val is_lval_in_memory : lval -> bool **)

let is_lval_in_memory = function
| Lnone (_, _) -> false
| Lvar v -> is_var_in_memory v.v_var
| Lmem (_, _, _, _) -> true
| Laset (_, _, _, v, _) -> is_var_in_memory v.v_var
| Lasub (_, _, _, v, _) -> is_var_in_memory v.v_var

(** val lower_cmd :
    'a1 asmOp -> ((instr_info -> warning_msg -> instr_info) -> fresh_vars ->
    'a1 instr -> 'a1 instr list cexec) -> (instr_info -> warning_msg ->
    instr_info) -> fresh_vars -> 'a1 instr list -> 'a1 instr list cexec **)

let lower_cmd _ lower_i0 warning fv c =
  conc_mapM (lower_i0 warning fv) c

(** val lower_fd :
    'a1 asmOp -> ((instr_info -> warning_msg -> instr_info) -> fresh_vars ->
    'a1 instr -> 'a1 instr list cexec) -> (instr_info -> warning_msg ->
    instr_info) -> fresh_vars -> progT -> 'a1 fundef -> 'a1 fundef cexec **)

let lower_fd asmop lower_i0 warning fv _ fd =
  match lower_cmd asmop lower_i0 warning fv fd.f_body with
  | Ok x -> Ok (with_body asmop fd x)
  | Error s -> Error s

(** val lower_prog :
    'a1 asmOp -> ((instr_info -> warning_msg -> instr_info) -> fresh_vars ->
    'a1 instr -> 'a1 instr list cexec) -> (instr_info -> warning_msg ->
    instr_info) -> fresh_vars -> progT -> 'a1 prog -> 'a1 prog cexec **)

let lower_prog asmop lower_i0 warning fv pT p =
  match map_cfprog_gen (fun x -> x.f_info)
          (lower_fd asmop lower_i0 warning fv pT) p.p_funcs with
  | Ok x -> Ok { p_funcs = x; p_globs = p.p_globs; p_extra = p.p_extra }
  | Error s -> Error s
