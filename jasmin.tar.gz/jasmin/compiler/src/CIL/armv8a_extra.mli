(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Arm_common
open Armv8a
open Armv8a_decl
open Armv8a_instr_decl
open Armv8a_params_core
open Compiler_util
open EqbOK
open Eqb_core_defs
open Eqtype
open Expr
open Fexpr
open Operators
open Sem_type
open Seq
open Sopn
open Type
open Utils0
open Var0
open Word0
open Wsize

type __ = Obj.t

type armv8a_extra_op =
| Oarmv8a_swap of wsize
| Oarmv8a_add_large_imm
| Oarmv8a_smart_li of wsize

val armv8a_extra_op_rect :
  (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> armv8a_extra_op -> 'a1

val armv8a_extra_op_rec :
  (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> armv8a_extra_op -> 'a1

type is_armv8a_extra_op =
| Coq_is_Oarmv8a_swap of wsize * is_wsize
| Coq_is_Oarmv8a_add_large_imm
| Coq_is_Oarmv8a_smart_li of wsize * is_wsize

val is_armv8a_extra_op_rect :
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  armv8a_extra_op -> is_armv8a_extra_op -> 'a1

val is_armv8a_extra_op_rec :
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  armv8a_extra_op -> is_armv8a_extra_op -> 'a1

val armv8a_extra_op_tag : armv8a_extra_op -> positive

val is_armv8a_extra_op_inhab : armv8a_extra_op -> is_armv8a_extra_op

val is_armv8a_extra_op_functor :
  armv8a_extra_op -> is_armv8a_extra_op -> is_armv8a_extra_op

type box_armv8a_extra_op_Oarmv8a_swap =
  wsize
  (* singleton inductive, whose constructor was Box_armv8a_extra_op_Oarmv8a_swap *)

val coq_Box_armv8a_extra_op_Oarmv8a_swap_0 :
  box_armv8a_extra_op_Oarmv8a_swap -> wsize

type box_armv8a_extra_op_Oarmv8a_add_large_imm =
| Box_armv8a_extra_op_Oarmv8a_add_large_imm

type armv8a_extra_op_fields_t = __

val armv8a_extra_op_fields : armv8a_extra_op -> armv8a_extra_op_fields_t

val armv8a_extra_op_construct :
  positive -> armv8a_extra_op_fields_t -> armv8a_extra_op option

val armv8a_extra_op_induction :
  (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
  armv8a_extra_op -> is_armv8a_extra_op -> 'a1

val armv8a_extra_op_eqb_fields :
  (armv8a_extra_op -> armv8a_extra_op -> bool) -> positive ->
  armv8a_extra_op_fields_t -> armv8a_extra_op_fields_t -> bool

val armv8a_extra_op_eqb : armv8a_extra_op -> armv8a_extra_op -> bool

val armv8a_extra_op_eqb_OK : armv8a_extra_op -> armv8a_extra_op -> reflect

val armv8a_extra_op_eqb_OK_sumbool :
  armv8a_extra_op -> armv8a_extra_op -> bool

val coq_HB_unnamed_factory_1 : armv8a_extra_op Coq_hasDecEq.axioms_

val armv8a_extra_armv8a_extra_op__canonical__eqtype_Equality :
  Equality.coq_type

val eqTC_armv8a_extra_op : armv8a_extra_op eqTypeC

val coq_Oarmv8a_add_large_imm_instr : instruction_desc

val smart_li_instr : wsize -> instruction_desc

val get_instr_desc : armv8a_extra_op -> instruction_desc

val armv8a_extra_op_decl : armv8a_extra_op asmOp

module E :
 sig
  val pass_name : string

  val internal_error : instr_info -> string -> pp_error_loc

  val error : instr_info -> string -> pp_error_loc
 end

val asm_args_of_opn_args :
  ARMv8AFopn_core.opn_args list -> (((register, empty, empty, rflag, condt,
  armv8a_asm_op) asm_op_msb_t * lexpr list) * rexpr list) list

val uncons_LLvar : instr_info -> lexpr list -> (var_i * lexpr list) cexec

val uncons_wconst : instr_info -> rexpr list -> (coq_Z * rexpr list) cexec

val smart_li_args :
  instr_info -> Equality.sort -> lexpr list -> rexpr list -> (pp_error_loc,
  (var_i * coq_Z) * rexpr list) result

val assemble_smart_li :
  instr_info -> wsize -> lexpr list -> rexpr list -> (pp_error_loc,
  (((register, empty, empty, rflag, condt, armv8a_asm_op)
  asm_op_msb_t * lexpr list) * rexpr list) list) result

val assemble_extra :
  instr_info -> armv8a_extra_op -> lexpr list -> rexpr list -> (((register,
  empty, empty, rflag, condt, armv8a_asm_op) asm_op_msb_t * lexpr
  list) * rexpr list) list cexec

val armv8a_extra :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) asm_extra

type armv8a_extended_op =
  (register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
  extended_op

val coq_Oarmv8a :
  (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
  empty, rflag, condt, armv8a_asm_op) asm_op_t' -> armv8a_extended_op sopn
