(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open Arch_decl
open Arch_utils
open Eqtype
open Otbn_decl
open Otbn_instr_decl
open Riscv
open Utils0
open Word0
open Wsize

val eval_cond :
  (register -> word) -> (rflag -> bool exec) -> condition -> bool exec

val otbn : (register, empty, wide_register, rflag, condition, otbn_op) asm
