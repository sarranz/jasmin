(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNat
open BinNums
open BinPos
open Datatypes
open Zpower
open Eqtype
open Ssralg
open Ssrbool
open Ssrint

(** val int_to_Z : int -> coq_Z **)

let int_to_Z = function
| Posz n -> Z.of_nat n
| Negz n -> Z.opp (Z.of_nat (S n))

(** val coq_Z_to_int : coq_Z -> int **)

let coq_Z_to_int = function
| Z0 -> Posz O
| Zpos p -> Posz (Pos.to_nat p)
| Zneg p ->
  Obj.magic GRing.opp ssrint_int__canonical__GRing_Zmodule (Posz
    (Pos.to_nat p))

(** val coq_ZeqbP : coq_Z -> coq_Z -> reflect **)

let coq_ZeqbP x y =
  iffP (Z.eqb x y) (if Z.eqb x y then ReflectT else ReflectF)

(** val coq_HB_unnamed_factory_1 : coq_Z Coq_hasDecEq.axioms_ **)

let coq_HB_unnamed_factory_1 =
  { Coq_hasDecEq.eq_op = Z.eqb; Coq_hasDecEq.eqP = coq_ZeqbP }

(** val coq_BinNums_Z__canonical__eqtype_Equality : Equality.coq_type **)

let coq_BinNums_Z__canonical__eqtype_Equality =
  Obj.magic coq_HB_unnamed_factory_1

(** val coq_HB_unnamed_factory_3 : coq_Z Choice.Countable.axioms_ **)

let coq_HB_unnamed_factory_3 =
  Obj.magic Choice.eqtype_can_type__canonical__choice_Countable
    ssrint_int__canonical__choice_Countable coq_Z_to_int int_to_Z

(** val coq_HB_unnamed_mixin_7 : coq_Z Choice.Coq_hasChoice.axioms_ **)

let coq_HB_unnamed_mixin_7 =
  coq_HB_unnamed_factory_3.Choice.Countable.choice_hasChoice_mixin

(** val coq_HB_unnamed_mixin_8 : coq_Z Choice.Choice_isCountable.axioms_ **)

let coq_HB_unnamed_mixin_8 =
  coq_HB_unnamed_factory_3.Choice.Countable.choice_Choice_isCountable_mixin

(** val coq_BinNums_Z__canonical__choice_Countable :
    Choice.Countable.coq_type **)

let coq_BinNums_Z__canonical__choice_Countable =
  { Choice.Countable.choice_hasChoice_mixin =
    (Obj.magic coq_HB_unnamed_mixin_7);
    Choice.Countable.eqtype_hasDecEq_mixin =
    (Obj.magic coq_HB_unnamed_factory_1);
    Choice.Countable.choice_Choice_isCountable_mixin =
    (Obj.magic coq_HB_unnamed_mixin_8) }

(** val coq_HB_unnamed_factory_9 : coq_Z GRing.Coq_isZmodule.axioms_ **)

let coq_HB_unnamed_factory_9 =
  { GRing.Coq_isZmodule.zero = Z0; GRing.Coq_isZmodule.opp = Z.opp;
    GRing.Coq_isZmodule.add = Z.add }

(** val coq_HB_unnamed_mixin_12 : coq_Z GRing.Coq_isNmodule.axioms_ **)

let coq_HB_unnamed_mixin_12 =
  GRing.Builders_8.coq_HB_unnamed_factory_10 coq_HB_unnamed_mixin_7
    coq_HB_unnamed_factory_1 coq_HB_unnamed_factory_9

(** val coq_BinNums_Z__canonical__GRing_Nmodule : GRing.Nmodule.coq_type **)

let coq_BinNums_Z__canonical__GRing_Nmodule =
  { GRing.Nmodule.coq_GRing_isNmodule_mixin =
    (Obj.magic coq_HB_unnamed_mixin_12);
    GRing.Nmodule.choice_hasChoice_mixin =
    (Obj.magic coq_HB_unnamed_mixin_7); GRing.Nmodule.eqtype_hasDecEq_mixin =
    (Obj.magic coq_HB_unnamed_factory_1) }

(** val coq_HB_unnamed_mixin_13 : coq_Z GRing.Nmodule_isZmodule.axioms_ **)

let coq_HB_unnamed_mixin_13 =
  GRing.Builders_8.coq_HB_unnamed_factory_12 coq_HB_unnamed_mixin_7
    coq_HB_unnamed_factory_1 coq_HB_unnamed_factory_9

(** val coq_BinNums_Z__canonical__GRing_Zmodule : GRing.Zmodule.coq_type **)

let coq_BinNums_Z__canonical__GRing_Zmodule =
  { GRing.Zmodule.coq_GRing_isNmodule_mixin =
    (Obj.magic coq_HB_unnamed_mixin_12);
    GRing.Zmodule.choice_hasChoice_mixin =
    (Obj.magic coq_HB_unnamed_mixin_7); GRing.Zmodule.eqtype_hasDecEq_mixin =
    (Obj.magic coq_HB_unnamed_factory_1);
    GRing.Zmodule.coq_GRing_Nmodule_isZmodule_mixin =
    (Obj.magic coq_HB_unnamed_mixin_13) }

(** val coq_HB_unnamed_factory_14 :
    coq_Z GRing.Zmodule_isComNzRing.axioms_ **)

let coq_HB_unnamed_factory_14 =
  { GRing.Zmodule_isComNzRing.one = (Zpos Coq_xH);
    GRing.Zmodule_isComNzRing.mul = Z.mul }

(** val coq_HB_unnamed_mixin_18 : coq_Z GRing.Nmodule_isPzSemiRing.axioms_ **)

let coq_HB_unnamed_mixin_18 =
  GRing.Builders_344.coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing
    coq_HB_unnamed_mixin_12 coq_HB_unnamed_mixin_7 coq_HB_unnamed_factory_1
    coq_HB_unnamed_mixin_13 coq_HB_unnamed_factory_14

(** val coq_BinNums_Z__canonical__GRing_PzSemiRing :
    GRing.PzSemiRing.coq_type **)

let coq_BinNums_Z__canonical__GRing_PzSemiRing =
  { GRing.PzSemiRing.coq_GRing_isNmodule_mixin =
    (Obj.magic coq_HB_unnamed_mixin_12);
    GRing.PzSemiRing.choice_hasChoice_mixin =
    (Obj.magic coq_HB_unnamed_mixin_7);
    GRing.PzSemiRing.eqtype_hasDecEq_mixin =
    (Obj.magic coq_HB_unnamed_factory_1);
    GRing.PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
    (Obj.magic coq_HB_unnamed_mixin_18) }

(** val mod_pow2k : positive -> nat -> (coq_N -> 'a1) -> 'a1 **)

let rec mod_pow2k p n k =
  match n with
  | O -> k N0
  | S n0 ->
    (match p with
     | Coq_xI p0 -> mod_pow2k p0 n0 (fun r -> k (Pos.coq_Nsucc_double r))
     | Coq_xO p0 -> mod_pow2k p0 n0 (fun r -> k (N.double r))
     | Coq_xH -> k (Npos Coq_xH))

(** val mod_pow2 : positive -> nat -> coq_N **)

let mod_pow2 p n =
  mod_pow2k p n (fun x -> x)

(** val zmod_pow2 : coq_Z -> nat -> coq_Z **)

let zmod_pow2 z n =
  match z with
  | Z0 -> Z0
  | Zpos p -> Z.of_N (mod_pow2 p n)
  | Zneg p ->
    (match mod_pow2 p n with
     | N0 -> Z0
     | Npos p0 -> Z.sub (two_power_nat n) (Zpos p0))
