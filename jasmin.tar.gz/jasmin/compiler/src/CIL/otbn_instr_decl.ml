(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Memory_model
open Otbn_decl
open Otbn_options
open Param1
open Param1_trivial
open Sem_type
open Seq
open Sopn
open Ssralg
open Ssrfun
open Ssrnat
open Std
open Strings
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t
let __ = let rec f _ = Obj.repr f in Obj.repr f

module E =
 struct
  (** val no_semantics : error **)

  let no_semantics =
    ErrSemUndef
 end

(** val replace_dot : string -> string **)

let rec replace_dot s =
  (* If this appears, you're using String internals. Please don't *)
 (fun f0 f1 s ->
    let l = String.length s in
    if l = 0 then f0 () else f1 (String.get s 0) (String.sub s 1 (l-1)))

    (fun _ -> "")
    (fun c s0 ->
    let c' =
      if eq_op coq_Ascii_ascii__canonical__eqtype_Equality (Obj.magic c)
           (Obj.magic '.')
      then '_'
      else c
    in
    (* If this appears, you're using String internals. Please don't *)
  (fun (c, s) -> String.make 1 c ^ s)

    (c', (replace_dot s0)))
    s

(** val is_prim_otbn_none : prim_otbn_suffix -> bool **)

let is_prim_otbn_none = function
| PrimOTBNnone -> true
| _ -> false

(** val is_prim_otbn_suff_ws : prim_otbn_suffix -> wsize option **)

let is_prim_otbn_suff_ws = function
| PrimOTBNnone -> Some otbn_decl.reg_size
| PrimOTBNws ws -> Some ws
| _ -> None

(** val is_prim_otbn_suff_fg : prim_otbn_suffix -> bn_flag_group option **)

let is_prim_otbn_suff_fg = function
| PrimOTBNnone -> Some FG0
| PrimOTBNfg fg -> Some fg
| _ -> None

(** val is_prim_otbn_suff_wb :
    prim_otbn_suffix -> (bn_flag_group * bn_halfword_writeback) option **)

let is_prim_otbn_suff_wb = function
| PrimOTBNwb (ofg, wb) -> Some ((Option.default FG0 ofg), wb)
| _ -> None

(** val prim_otbn_none : 'a1 -> 'a1 prim_constructor **)

let prim_otbn_none op =
  let err = fun s -> Error ((^) "invalid OTBN suffix, expected " s) in
  PrimOTBN (fun s -> if is_prim_otbn_none s then Ok op else err "no suffix")

(** val prim_otbn_ws : (wsize -> 'a1) -> 'a1 prim_constructor **)

let prim_otbn_ws f =
  let err = fun s -> Error ((^) "invalid OTBN suffix, expected " s) in
  PrimOTBN (fun s ->
  match is_prim_otbn_suff_ws s with
  | Some ws -> Ok (f ws)
  | None -> err "only an optional word size")

(** val prim_otbn_fg : (bn_flag_group -> 'a1) -> 'a1 prim_constructor **)

let prim_otbn_fg f =
  let err = fun s -> Error ((^) "invalid OTBN suffix, expected " s) in
  PrimOTBN (fun s ->
  match is_prim_otbn_suff_fg s with
  | Some fg -> Ok (f fg)
  | None -> err "only an optional flag group")

(** val prim_otbn_mulqacc_so :
    (bn_flag_group -> bn_halfword_writeback -> 'a1) -> 'a1 prim_constructor **)

let prim_otbn_mulqacc_so f =
  let err = fun s -> Error ((^) "invalid OTBN suffix, expected " s) in
  PrimOTBN (fun s ->
  match is_prim_otbn_suff_wb s with
  | Some p -> let (fg, wb) = p in Ok (f fg wb)
  | None -> err "a writeback and an optional flag group")

(** val is_prim_otbn_suff_wreg : prim_otbn_suffix -> ordinal option **)

let is_prim_otbn_suff_wreg = function
| PrimOTBNwreg i -> Some i
| _ -> None

(** val prim_otbn_wreg : (ordinal -> 'a1) -> 'a1 prim_constructor **)

let prim_otbn_wreg f =
  let err = fun s -> Error ((^) "invalid OTBN suffix, expected " s) in
  PrimOTBN (fun s ->
  match is_prim_otbn_suff_wreg s with
  | Some i -> Ok (f i)
  | None -> err "a wide register index (e.g. _w5)")

type rv_mnemonic =
| ADD
| ADDI
| SUB
| AND
| ANDI
| OR
| ORI
| XOR
| XORI
| SLL
| SLLI
| SRL
| SRLI
| SRA
| SRAI
| LUI
| LW
| SW
| LI
| LA
| NOP

(** val rv_mnemonic_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    rv_mnemonic -> 'a1 **)

let rv_mnemonic_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 = function
| ADD -> f
| ADDI -> f0
| SUB -> f1
| AND -> f2
| ANDI -> f3
| OR -> f4
| ORI -> f5
| XOR -> f6
| XORI -> f7
| SLL -> f8
| SLLI -> f9
| SRL -> f10
| SRLI -> f11
| SRA -> f12
| SRAI -> f13
| LUI -> f14
| LW -> f15
| SW -> f16
| LI -> f17
| LA -> f18
| NOP -> f19

(** val rv_mnemonic_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    rv_mnemonic -> 'a1 **)

let rv_mnemonic_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 = function
| ADD -> f
| ADDI -> f0
| SUB -> f1
| AND -> f2
| ANDI -> f3
| OR -> f4
| ORI -> f5
| XOR -> f6
| XORI -> f7
| SLL -> f8
| SLLI -> f9
| SRL -> f10
| SRLI -> f11
| SRA -> f12
| SRAI -> f13
| LUI -> f14
| LW -> f15
| SW -> f16
| LI -> f17
| LA -> f18
| NOP -> f19

type is_rv_mnemonic =
| Coq_is_ADD
| Coq_is_ADDI
| Coq_is_SUB
| Coq_is_AND
| Coq_is_ANDI
| Coq_is_OR
| Coq_is_ORI
| Coq_is_XOR
| Coq_is_XORI
| Coq_is_SLL
| Coq_is_SLLI
| Coq_is_SRL
| Coq_is_SRLI
| Coq_is_SRA
| Coq_is_SRAI
| Coq_is_LUI
| Coq_is_LW
| Coq_is_SW
| Coq_is_LI
| Coq_is_LA
| Coq_is_NOP

(** val is_rv_mnemonic_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    rv_mnemonic -> is_rv_mnemonic -> 'a1 **)

let is_rv_mnemonic_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 _ = function
| Coq_is_ADD -> f
| Coq_is_ADDI -> f0
| Coq_is_SUB -> f1
| Coq_is_AND -> f2
| Coq_is_ANDI -> f3
| Coq_is_OR -> f4
| Coq_is_ORI -> f5
| Coq_is_XOR -> f6
| Coq_is_XORI -> f7
| Coq_is_SLL -> f8
| Coq_is_SLLI -> f9
| Coq_is_SRL -> f10
| Coq_is_SRLI -> f11
| Coq_is_SRA -> f12
| Coq_is_SRAI -> f13
| Coq_is_LUI -> f14
| Coq_is_LW -> f15
| Coq_is_SW -> f16
| Coq_is_LI -> f17
| Coq_is_LA -> f18
| Coq_is_NOP -> f19

(** val is_rv_mnemonic_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    rv_mnemonic -> is_rv_mnemonic -> 'a1 **)

let is_rv_mnemonic_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 _ = function
| Coq_is_ADD -> f
| Coq_is_ADDI -> f0
| Coq_is_SUB -> f1
| Coq_is_AND -> f2
| Coq_is_ANDI -> f3
| Coq_is_OR -> f4
| Coq_is_ORI -> f5
| Coq_is_XOR -> f6
| Coq_is_XORI -> f7
| Coq_is_SLL -> f8
| Coq_is_SLLI -> f9
| Coq_is_SRL -> f10
| Coq_is_SRLI -> f11
| Coq_is_SRA -> f12
| Coq_is_SRAI -> f13
| Coq_is_LUI -> f14
| Coq_is_LW -> f15
| Coq_is_SW -> f16
| Coq_is_LI -> f17
| Coq_is_LA -> f18
| Coq_is_NOP -> f19

(** val rv_mnemonic_tag : rv_mnemonic -> positive **)

let rv_mnemonic_tag = function
| ADD -> Coq_xH
| ADDI -> Coq_xO Coq_xH
| SUB -> Coq_xI Coq_xH
| AND -> Coq_xO (Coq_xO Coq_xH)
| ANDI -> Coq_xI (Coq_xO Coq_xH)
| OR -> Coq_xO (Coq_xI Coq_xH)
| ORI -> Coq_xI (Coq_xI Coq_xH)
| XOR -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| XORI -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| SLL -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| SLLI -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| SRL -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| SRLI -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| SRA -> Coq_xO (Coq_xI (Coq_xI Coq_xH))
| SRAI -> Coq_xI (Coq_xI (Coq_xI Coq_xH))
| LUI -> Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| LW -> Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| SW -> Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| LI -> Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| LA -> Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| NOP -> Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH)))

(** val is_rv_mnemonic_inhab : rv_mnemonic -> is_rv_mnemonic **)

let is_rv_mnemonic_inhab = function
| ADD -> Coq_is_ADD
| ADDI -> Coq_is_ADDI
| SUB -> Coq_is_SUB
| AND -> Coq_is_AND
| ANDI -> Coq_is_ANDI
| OR -> Coq_is_OR
| ORI -> Coq_is_ORI
| XOR -> Coq_is_XOR
| XORI -> Coq_is_XORI
| SLL -> Coq_is_SLL
| SLLI -> Coq_is_SLLI
| SRL -> Coq_is_SRL
| SRLI -> Coq_is_SRLI
| SRA -> Coq_is_SRA
| SRAI -> Coq_is_SRAI
| LUI -> Coq_is_LUI
| LW -> Coq_is_LW
| SW -> Coq_is_SW
| LI -> Coq_is_LI
| LA -> Coq_is_LA
| NOP -> Coq_is_NOP

(** val is_rv_mnemonic_functor :
    rv_mnemonic -> is_rv_mnemonic -> is_rv_mnemonic **)

let rec is_rv_mnemonic_functor _ x =
  x

type box_rv_mnemonic_ADD =
| Box_rv_mnemonic_ADD

type rv_mnemonic_fields_t = __

(** val rv_mnemonic_fields : rv_mnemonic -> rv_mnemonic_fields_t **)

let rv_mnemonic_fields _ =
  Obj.magic Box_rv_mnemonic_ADD

(** val rv_mnemonic_construct :
    positive -> rv_mnemonic_fields_t -> rv_mnemonic option **)

let rv_mnemonic_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> Some SRAI
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some LI
           | Coq_xH -> Some SLLI)
        | Coq_xH -> Some ORI)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some NOP
           | Coq_xH -> Some SRLI)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some LW
           | Coq_xH -> Some XORI)
        | Coq_xH -> Some ANDI)
     | Coq_xH -> Some SUB)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> Some SRA
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some SW
           | Coq_xH -> Some SLL)
        | Coq_xH -> Some OR)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some LA
           | Coq_xH -> Some SRL)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some LUI
           | Coq_xH -> Some XOR)
        | Coq_xH -> Some AND)
     | Coq_xH -> Some ADDI)
  | Coq_xH -> Some ADD

(** val rv_mnemonic_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    rv_mnemonic -> is_rv_mnemonic -> 'a1 **)

let rv_mnemonic_induction his_ADD his_ADDI his_SUB his_AND his_ANDI his_OR his_ORI his_XOR his_XORI his_SLL his_SLLI his_SRL his_SRLI his_SRA his_SRAI his_LUI his_LW his_SW his_LI his_LA his_NOP _ = function
| Coq_is_ADD -> his_ADD
| Coq_is_ADDI -> his_ADDI
| Coq_is_SUB -> his_SUB
| Coq_is_AND -> his_AND
| Coq_is_ANDI -> his_ANDI
| Coq_is_OR -> his_OR
| Coq_is_ORI -> his_ORI
| Coq_is_XOR -> his_XOR
| Coq_is_XORI -> his_XORI
| Coq_is_SLL -> his_SLL
| Coq_is_SLLI -> his_SLLI
| Coq_is_SRL -> his_SRL
| Coq_is_SRLI -> his_SRLI
| Coq_is_SRA -> his_SRA
| Coq_is_SRAI -> his_SRAI
| Coq_is_LUI -> his_LUI
| Coq_is_LW -> his_LW
| Coq_is_SW -> his_SW
| Coq_is_LI -> his_LI
| Coq_is_LA -> his_LA
| Coq_is_NOP -> his_NOP

(** val rv_mnemonic_eqb_fields :
    (rv_mnemonic -> rv_mnemonic -> bool) -> positive -> rv_mnemonic_fields_t
    -> rv_mnemonic_fields_t -> bool **)

let rv_mnemonic_eqb_fields _ _ _ _ =
  true

(** val rv_mnemonic_eqb : rv_mnemonic -> rv_mnemonic -> bool **)

let rv_mnemonic_eqb x1 x2 =
  eqb_body rv_mnemonic_tag rv_mnemonic_fields
    (Obj.magic rv_mnemonic_eqb_fields (fun _ _ -> true)) (rv_mnemonic_tag x1)
    Box_rv_mnemonic_ADD x2

(** val rv_mnemonic_eqb_OK : rv_mnemonic -> rv_mnemonic -> reflect **)

let rv_mnemonic_eqb_OK =
  iffP2 rv_mnemonic_eqb

(** val rv_mnemonic_eqb_OK_sumbool : rv_mnemonic -> rv_mnemonic -> bool **)

let rv_mnemonic_eqb_OK_sumbool =
  reflect_dec rv_mnemonic_eqb rv_mnemonic_eqb_OK

(** val eqTC_rv_mnemonic : rv_mnemonic eqTypeC **)

let eqTC_rv_mnemonic =
  { beq = rv_mnemonic_eqb; ceqP = rv_mnemonic_eqb_OK }

(** val rv_mnemonic_eqType : Equality.coq_type **)

let rv_mnemonic_eqType =
  ceqT_eqType eqTC_rv_mnemonic

(** val rv_mnemonics : rv_mnemonic list **)

let rv_mnemonics =
  ADD :: (ADDI :: (SUB :: (AND :: (ANDI :: (OR :: (ORI :: (XOR :: (XORI :: (SLL :: (SLLI :: (SRL :: (SRLI :: (SRA :: (SRAI :: (LUI :: (LW :: (SW :: (LI :: (LA :: (NOP :: []))))))))))))))))))))

(** val finTC_rv_mnemonic : rv_mnemonic finTypeC **)

let finTC_rv_mnemonic =
  { _eqC = eqTC_rv_mnemonic; cenum = rv_mnemonics }

(** val rv_mnemonic_to_string : rv_mnemonic -> string **)

let rv_mnemonic_to_string = function
| ADD -> "ADD"
| ADDI -> "ADDI"
| SUB -> "SUB"
| AND -> "AND"
| ANDI -> "ANDI"
| OR -> "OR"
| ORI -> "ORI"
| XOR -> "XOR"
| XORI -> "XORI"
| SLL -> "SLL"
| SLLI -> "SLLI"
| SRL -> "SRL"
| SRLI -> "SRLI"
| SRA -> "SRA"
| SRAI -> "SRAI"
| LUI -> "LUI"
| LW -> "LW"
| SW -> "SW"
| LI -> "LI"
| LA -> "LA"
| NOP -> "NOP"

type bn_basic_mnemonic =
| BN_ADD
| BN_ADDC
| BN_SUB
| BN_SUBB
| BN_AND
| BN_OR
| BN_NOT
| BN_XOR
| BN_CMP
| BN_CMPB

(** val bn_basic_mnemonic_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    bn_basic_mnemonic -> 'a1 **)

let bn_basic_mnemonic_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 = function
| BN_ADD -> f
| BN_ADDC -> f0
| BN_SUB -> f1
| BN_SUBB -> f2
| BN_AND -> f3
| BN_OR -> f4
| BN_NOT -> f5
| BN_XOR -> f6
| BN_CMP -> f7
| BN_CMPB -> f8

(** val bn_basic_mnemonic_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    bn_basic_mnemonic -> 'a1 **)

let bn_basic_mnemonic_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 = function
| BN_ADD -> f
| BN_ADDC -> f0
| BN_SUB -> f1
| BN_SUBB -> f2
| BN_AND -> f3
| BN_OR -> f4
| BN_NOT -> f5
| BN_XOR -> f6
| BN_CMP -> f7
| BN_CMPB -> f8

type is_bn_basic_mnemonic =
| Coq_is_BN_ADD
| Coq_is_BN_ADDC
| Coq_is_BN_SUB
| Coq_is_BN_SUBB
| Coq_is_BN_AND
| Coq_is_BN_OR
| Coq_is_BN_NOT
| Coq_is_BN_XOR
| Coq_is_BN_CMP
| Coq_is_BN_CMPB

(** val is_bn_basic_mnemonic_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    bn_basic_mnemonic -> is_bn_basic_mnemonic -> 'a1 **)

let is_bn_basic_mnemonic_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 _ = function
| Coq_is_BN_ADD -> f
| Coq_is_BN_ADDC -> f0
| Coq_is_BN_SUB -> f1
| Coq_is_BN_SUBB -> f2
| Coq_is_BN_AND -> f3
| Coq_is_BN_OR -> f4
| Coq_is_BN_NOT -> f5
| Coq_is_BN_XOR -> f6
| Coq_is_BN_CMP -> f7
| Coq_is_BN_CMPB -> f8

(** val is_bn_basic_mnemonic_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    bn_basic_mnemonic -> is_bn_basic_mnemonic -> 'a1 **)

let is_bn_basic_mnemonic_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 _ = function
| Coq_is_BN_ADD -> f
| Coq_is_BN_ADDC -> f0
| Coq_is_BN_SUB -> f1
| Coq_is_BN_SUBB -> f2
| Coq_is_BN_AND -> f3
| Coq_is_BN_OR -> f4
| Coq_is_BN_NOT -> f5
| Coq_is_BN_XOR -> f6
| Coq_is_BN_CMP -> f7
| Coq_is_BN_CMPB -> f8

(** val bn_basic_mnemonic_tag : bn_basic_mnemonic -> positive **)

let bn_basic_mnemonic_tag = function
| BN_ADD -> Coq_xH
| BN_ADDC -> Coq_xO Coq_xH
| BN_SUB -> Coq_xI Coq_xH
| BN_SUBB -> Coq_xO (Coq_xO Coq_xH)
| BN_AND -> Coq_xI (Coq_xO Coq_xH)
| BN_OR -> Coq_xO (Coq_xI Coq_xH)
| BN_NOT -> Coq_xI (Coq_xI Coq_xH)
| BN_XOR -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| BN_CMP -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| BN_CMPB -> Coq_xO (Coq_xI (Coq_xO Coq_xH))

(** val is_bn_basic_mnemonic_inhab :
    bn_basic_mnemonic -> is_bn_basic_mnemonic **)

let is_bn_basic_mnemonic_inhab = function
| BN_ADD -> Coq_is_BN_ADD
| BN_ADDC -> Coq_is_BN_ADDC
| BN_SUB -> Coq_is_BN_SUB
| BN_SUBB -> Coq_is_BN_SUBB
| BN_AND -> Coq_is_BN_AND
| BN_OR -> Coq_is_BN_OR
| BN_NOT -> Coq_is_BN_NOT
| BN_XOR -> Coq_is_BN_XOR
| BN_CMP -> Coq_is_BN_CMP
| BN_CMPB -> Coq_is_BN_CMPB

(** val is_bn_basic_mnemonic_functor :
    bn_basic_mnemonic -> is_bn_basic_mnemonic -> is_bn_basic_mnemonic **)

let rec is_bn_basic_mnemonic_functor _ x =
  x

type box_bn_basic_mnemonic_BN_ADD =
| Box_bn_basic_mnemonic_BN_ADD

type bn_basic_mnemonic_fields_t = __

(** val bn_basic_mnemonic_fields :
    bn_basic_mnemonic -> bn_basic_mnemonic_fields_t **)

let bn_basic_mnemonic_fields _ =
  Obj.magic Box_bn_basic_mnemonic_BN_ADD

(** val bn_basic_mnemonic_construct :
    positive -> bn_basic_mnemonic_fields_t -> bn_basic_mnemonic option **)

let bn_basic_mnemonic_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI _ -> Some BN_NOT
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> None
        | Coq_xO _ -> Some BN_CMP
        | Coq_xH -> Some BN_AND)
     | Coq_xH -> Some BN_SUB)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> None
        | Coq_xO _ -> Some BN_CMPB
        | Coq_xH -> Some BN_OR)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> None
        | Coq_xO _ -> Some BN_XOR
        | Coq_xH -> Some BN_SUBB)
     | Coq_xH -> Some BN_ADDC)
  | Coq_xH -> Some BN_ADD

(** val bn_basic_mnemonic_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    bn_basic_mnemonic -> is_bn_basic_mnemonic -> 'a1 **)

let bn_basic_mnemonic_induction his_BN_ADD his_BN_ADDC his_BN_SUB his_BN_SUBB his_BN_AND his_BN_OR his_BN_NOT his_BN_XOR his_BN_CMP his_BN_CMPB _ = function
| Coq_is_BN_ADD -> his_BN_ADD
| Coq_is_BN_ADDC -> his_BN_ADDC
| Coq_is_BN_SUB -> his_BN_SUB
| Coq_is_BN_SUBB -> his_BN_SUBB
| Coq_is_BN_AND -> his_BN_AND
| Coq_is_BN_OR -> his_BN_OR
| Coq_is_BN_NOT -> his_BN_NOT
| Coq_is_BN_XOR -> his_BN_XOR
| Coq_is_BN_CMP -> his_BN_CMP
| Coq_is_BN_CMPB -> his_BN_CMPB

(** val bn_basic_mnemonic_eqb_fields :
    (bn_basic_mnemonic -> bn_basic_mnemonic -> bool) -> positive ->
    bn_basic_mnemonic_fields_t -> bn_basic_mnemonic_fields_t -> bool **)

let bn_basic_mnemonic_eqb_fields _ _ _ _ =
  true

(** val bn_basic_mnemonic_eqb :
    bn_basic_mnemonic -> bn_basic_mnemonic -> bool **)

let bn_basic_mnemonic_eqb x1 x2 =
  eqb_body bn_basic_mnemonic_tag bn_basic_mnemonic_fields
    (Obj.magic bn_basic_mnemonic_eqb_fields (fun _ _ -> true))
    (bn_basic_mnemonic_tag x1) Box_bn_basic_mnemonic_BN_ADD x2

(** val bn_basic_mnemonic_eqb_OK :
    bn_basic_mnemonic -> bn_basic_mnemonic -> reflect **)

let bn_basic_mnemonic_eqb_OK =
  iffP2 bn_basic_mnemonic_eqb

(** val bn_basic_mnemonic_eqb_OK_sumbool :
    bn_basic_mnemonic -> bn_basic_mnemonic -> bool **)

let bn_basic_mnemonic_eqb_OK_sumbool =
  reflect_dec bn_basic_mnemonic_eqb bn_basic_mnemonic_eqb_OK

(** val eqTC_bn_basic_mnemonic : bn_basic_mnemonic eqTypeC **)

let eqTC_bn_basic_mnemonic =
  { beq = bn_basic_mnemonic_eqb; ceqP = bn_basic_mnemonic_eqb_OK }

(** val bn_basic_mnemonic_eqType : Equality.coq_type **)

let bn_basic_mnemonic_eqType =
  ceqT_eqType eqTC_bn_basic_mnemonic

(** val bn_basic_mnemonics : bn_basic_mnemonic list **)

let bn_basic_mnemonics =
  BN_ADD :: (BN_ADDC :: (BN_SUB :: (BN_SUBB :: (BN_AND :: (BN_OR :: (BN_NOT :: (BN_XOR :: (BN_CMP :: (BN_CMPB :: [])))))))))

(** val finTC_bn_basic_mnemonic : bn_basic_mnemonic finTypeC **)

let finTC_bn_basic_mnemonic =
  { _eqC = eqTC_bn_basic_mnemonic; cenum = bn_basic_mnemonics }

(** val bn_basic_mnemonic_to_string : bn_basic_mnemonic -> string **)

let bn_basic_mnemonic_to_string = function
| BN_ADD -> "BN.ADD"
| BN_ADDC -> "BN.ADDC"
| BN_SUB -> "BN.SUB"
| BN_SUBB -> "BN.SUBB"
| BN_AND -> "BN.AND"
| BN_OR -> "BN.OR"
| BN_NOT -> "BN.NOT"
| BN_XOR -> "BN.XOR"
| BN_CMP -> "BN.CMP"
| BN_CMPB -> "BN.CMPB"

type vec_size =
| V8S
| V16H

(** val vec_size_rect : 'a1 -> 'a1 -> vec_size -> 'a1 **)

let vec_size_rect f f0 = function
| V8S -> f
| V16H -> f0

(** val vec_size_rec : 'a1 -> 'a1 -> vec_size -> 'a1 **)

let vec_size_rec f f0 = function
| V8S -> f
| V16H -> f0

type is_vec_size =
| Coq_is_V8S
| Coq_is_V16H

(** val is_vec_size_rect : 'a1 -> 'a1 -> vec_size -> is_vec_size -> 'a1 **)

let is_vec_size_rect f f0 _ = function
| Coq_is_V8S -> f
| Coq_is_V16H -> f0

(** val is_vec_size_rec : 'a1 -> 'a1 -> vec_size -> is_vec_size -> 'a1 **)

let is_vec_size_rec f f0 _ = function
| Coq_is_V8S -> f
| Coq_is_V16H -> f0

(** val vec_size_tag : vec_size -> positive **)

let vec_size_tag = function
| V8S -> Coq_xH
| V16H -> Coq_xO Coq_xH

(** val is_vec_size_inhab : vec_size -> is_vec_size **)

let is_vec_size_inhab = function
| V8S -> Coq_is_V8S
| V16H -> Coq_is_V16H

(** val is_vec_size_functor : vec_size -> is_vec_size -> is_vec_size **)

let rec is_vec_size_functor _ x =
  x

type box_vec_size_V8S =
| Box_vec_size_V8S

type vec_size_fields_t = __

(** val vec_size_fields : vec_size -> vec_size_fields_t **)

let vec_size_fields _ =
  Obj.magic Box_vec_size_V8S

(** val vec_size_construct :
    positive -> vec_size_fields_t -> vec_size option **)

let vec_size_construct p _ =
  match p with
  | Coq_xI _ -> None
  | Coq_xO _ -> Some V16H
  | Coq_xH -> Some V8S

(** val vec_size_induction : 'a1 -> 'a1 -> vec_size -> is_vec_size -> 'a1 **)

let vec_size_induction his_V8S his_V16H _ = function
| Coq_is_V8S -> his_V8S
| Coq_is_V16H -> his_V16H

(** val vec_size_eqb_fields :
    (vec_size -> vec_size -> bool) -> positive -> vec_size_fields_t ->
    vec_size_fields_t -> bool **)

let vec_size_eqb_fields _ _ _ _ =
  true

(** val vec_size_eqb : vec_size -> vec_size -> bool **)

let vec_size_eqb x1 x2 =
  eqb_body vec_size_tag vec_size_fields
    (Obj.magic vec_size_eqb_fields (fun _ _ -> true)) (vec_size_tag x1)
    Box_vec_size_V8S x2

(** val vec_size_eqb_OK : vec_size -> vec_size -> reflect **)

let vec_size_eqb_OK =
  iffP2 vec_size_eqb

(** val vec_size_eqb_OK_sumbool : vec_size -> vec_size -> bool **)

let vec_size_eqb_OK_sumbool =
  reflect_dec vec_size_eqb vec_size_eqb_OK

(** val eqTC_vec_size : vec_size eqTypeC **)

let eqTC_vec_size =
  { beq = vec_size_eqb; ceqP = vec_size_eqb_OK }

(** val vec_size_eqType : Equality.coq_type **)

let vec_size_eqType =
  ceqT_eqType eqTC_vec_size

(** val ve_of_vec_size : vec_size -> wsize **)

let ve_of_vec_size = function
| V8S -> U32
| V16H -> U16

(** val vec_size_to_string : vec_size -> string **)

let vec_size_to_string = function
| V8S -> ".8S"
| V16H -> ".16H"

type trn_size =
| T16H
| T8S
| T4D
| T2Q

(** val trn_size_rect : 'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> 'a1 **)

let trn_size_rect f f0 f1 f2 = function
| T16H -> f
| T8S -> f0
| T4D -> f1
| T2Q -> f2

(** val trn_size_rec : 'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> 'a1 **)

let trn_size_rec f f0 f1 f2 = function
| T16H -> f
| T8S -> f0
| T4D -> f1
| T2Q -> f2

type is_trn_size =
| Coq_is_T16H
| Coq_is_T8S
| Coq_is_T4D
| Coq_is_T2Q

(** val is_trn_size_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> is_trn_size -> 'a1 **)

let is_trn_size_rect f f0 f1 f2 _ = function
| Coq_is_T16H -> f
| Coq_is_T8S -> f0
| Coq_is_T4D -> f1
| Coq_is_T2Q -> f2

(** val is_trn_size_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> is_trn_size -> 'a1 **)

let is_trn_size_rec f f0 f1 f2 _ = function
| Coq_is_T16H -> f
| Coq_is_T8S -> f0
| Coq_is_T4D -> f1
| Coq_is_T2Q -> f2

(** val trn_size_tag : trn_size -> positive **)

let trn_size_tag = function
| T16H -> Coq_xH
| T8S -> Coq_xO Coq_xH
| T4D -> Coq_xI Coq_xH
| T2Q -> Coq_xO (Coq_xO Coq_xH)

(** val is_trn_size_inhab : trn_size -> is_trn_size **)

let is_trn_size_inhab = function
| T16H -> Coq_is_T16H
| T8S -> Coq_is_T8S
| T4D -> Coq_is_T4D
| T2Q -> Coq_is_T2Q

(** val is_trn_size_functor : trn_size -> is_trn_size -> is_trn_size **)

let rec is_trn_size_functor _ x =
  x

type box_trn_size_T16H =
| Box_trn_size_T16H

type trn_size_fields_t = __

(** val trn_size_fields : trn_size -> trn_size_fields_t **)

let trn_size_fields _ =
  Obj.magic Box_trn_size_T16H

(** val trn_size_construct :
    positive -> trn_size_fields_t -> trn_size option **)

let trn_size_construct p _ =
  match p with
  | Coq_xI _ -> Some T4D
  | Coq_xO x ->
    (match x with
     | Coq_xI _ -> None
     | Coq_xO _ -> Some T2Q
     | Coq_xH -> Some T8S)
  | Coq_xH -> Some T16H

(** val trn_size_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> is_trn_size -> 'a1 **)

let trn_size_induction his_T16H his_T8S his_T4D his_T2Q _ = function
| Coq_is_T16H -> his_T16H
| Coq_is_T8S -> his_T8S
| Coq_is_T4D -> his_T4D
| Coq_is_T2Q -> his_T2Q

(** val trn_size_eqb_fields :
    (trn_size -> trn_size -> bool) -> positive -> trn_size_fields_t ->
    trn_size_fields_t -> bool **)

let trn_size_eqb_fields _ _ _ _ =
  true

(** val trn_size_eqb : trn_size -> trn_size -> bool **)

let trn_size_eqb x1 x2 =
  eqb_body trn_size_tag trn_size_fields
    (Obj.magic trn_size_eqb_fields (fun _ _ -> true)) (trn_size_tag x1)
    Box_trn_size_T16H x2

(** val trn_size_eqb_OK : trn_size -> trn_size -> reflect **)

let trn_size_eqb_OK =
  iffP2 trn_size_eqb

(** val trn_size_eqb_OK_sumbool : trn_size -> trn_size -> bool **)

let trn_size_eqb_OK_sumbool =
  reflect_dec trn_size_eqb trn_size_eqb_OK

(** val eqTC_trn_size : trn_size eqTypeC **)

let eqTC_trn_size =
  { beq = trn_size_eqb; ceqP = trn_size_eqb_OK }

(** val trn_size_eqType : Equality.coq_type **)

let trn_size_eqType =
  ceqT_eqType eqTC_trn_size

(** val ve_of_trn_size : trn_size -> wsize **)

let ve_of_trn_size = function
| T16H -> U16
| T8S -> U32
| T4D -> U64
| T2Q -> U128

(** val trn_size_to_string : trn_size -> string **)

let trn_size_to_string = function
| T16H -> ".16H"
| T8S -> ".8S"
| T4D -> ".4D"
| T2Q -> ".2Q"

type trn_mode =
| TRNMeven
| TRNModd

(** val trn_mode_rect : 'a1 -> 'a1 -> trn_mode -> 'a1 **)

let trn_mode_rect f f0 = function
| TRNMeven -> f
| TRNModd -> f0

(** val trn_mode_rec : 'a1 -> 'a1 -> trn_mode -> 'a1 **)

let trn_mode_rec f f0 = function
| TRNMeven -> f
| TRNModd -> f0

type is_trn_mode =
| Coq_is_TRNMeven
| Coq_is_TRNModd

(** val is_trn_mode_rect : 'a1 -> 'a1 -> trn_mode -> is_trn_mode -> 'a1 **)

let is_trn_mode_rect f f0 _ = function
| Coq_is_TRNMeven -> f
| Coq_is_TRNModd -> f0

(** val is_trn_mode_rec : 'a1 -> 'a1 -> trn_mode -> is_trn_mode -> 'a1 **)

let is_trn_mode_rec f f0 _ = function
| Coq_is_TRNMeven -> f
| Coq_is_TRNModd -> f0

(** val trn_mode_tag : trn_mode -> positive **)

let trn_mode_tag = function
| TRNMeven -> Coq_xH
| TRNModd -> Coq_xO Coq_xH

(** val is_trn_mode_inhab : trn_mode -> is_trn_mode **)

let is_trn_mode_inhab = function
| TRNMeven -> Coq_is_TRNMeven
| TRNModd -> Coq_is_TRNModd

(** val is_trn_mode_functor : trn_mode -> is_trn_mode -> is_trn_mode **)

let rec is_trn_mode_functor _ x =
  x

type box_trn_mode_TRNMeven =
| Box_trn_mode_TRNMeven

type trn_mode_fields_t = __

(** val trn_mode_fields : trn_mode -> trn_mode_fields_t **)

let trn_mode_fields _ =
  Obj.magic Box_trn_mode_TRNMeven

(** val trn_mode_construct :
    positive -> trn_mode_fields_t -> trn_mode option **)

let trn_mode_construct p _ =
  match p with
  | Coq_xI _ -> None
  | Coq_xO _ -> Some TRNModd
  | Coq_xH -> Some TRNMeven

(** val trn_mode_induction : 'a1 -> 'a1 -> trn_mode -> is_trn_mode -> 'a1 **)

let trn_mode_induction his_TRNMeven his_TRNModd _ = function
| Coq_is_TRNMeven -> his_TRNMeven
| Coq_is_TRNModd -> his_TRNModd

(** val trn_mode_eqb_fields :
    (trn_mode -> trn_mode -> bool) -> positive -> trn_mode_fields_t ->
    trn_mode_fields_t -> bool **)

let trn_mode_eqb_fields _ _ _ _ =
  true

(** val trn_mode_eqb : trn_mode -> trn_mode -> bool **)

let trn_mode_eqb x1 x2 =
  eqb_body trn_mode_tag trn_mode_fields
    (Obj.magic trn_mode_eqb_fields (fun _ _ -> true)) (trn_mode_tag x1)
    Box_trn_mode_TRNMeven x2

(** val trn_mode_eqb_OK : trn_mode -> trn_mode -> reflect **)

let trn_mode_eqb_OK =
  iffP2 trn_mode_eqb

(** val trn_mode_eqb_OK_sumbool : trn_mode -> trn_mode -> bool **)

let trn_mode_eqb_OK_sumbool =
  reflect_dec trn_mode_eqb trn_mode_eqb_OK

(** val eqTC_trn_mode : trn_mode eqTypeC **)

let eqTC_trn_mode =
  { beq = trn_mode_eqb; ceqP = trn_mode_eqb_OK }

(** val trn_mode_eqType : Equality.coq_type **)

let trn_mode_eqType =
  ceqT_eqType eqTC_trn_mode

(** val wide_reg_index_strings : string list **)

let wide_reg_index_strings =
  "00" :: ("01" :: ("02" :: ("03" :: ("04" :: ("05" :: ("06" :: ("07" :: ("08" :: ("09" :: ("10" :: ("11" :: ("12" :: ("13" :: ("14" :: ("15" :: ("16" :: ("17" :: ("18" :: ("19" :: ("20" :: ("21" :: ("22" :: ("23" :: ("24" :: ("25" :: ("26" :: ("27" :: ("28" :: ("29" :: ("30" :: ("31" :: [])))))))))))))))))))))))))))))))

(** val wide_reg_index_string : nat -> string **)

let wide_reg_index_string i =
  nth "" wide_reg_index_strings i

(** val index_to_wreg : nat -> wide_register **)

let index_to_wreg i =
  nth W00 wide_registers i

type otbn_op =
| RV32 of rv_mnemonic
| BN_basic of bn_basic_mnemonic * bn_flag_group
| BN_basic_shift of bn_basic_mnemonic * bn_flag_group * bn_register_shift
| BN_ADDI of bn_flag_group
| BN_SUBI of bn_flag_group
| BN_MOV
| BN_RSHI
| BN_SEL of bn_flag_group
| BN_ADDM
| BN_SUBM
| BN_ADDV of vec_size * bool
| BN_SUBV of vec_size * bool
| BN_SHV of vec_size * bn_register_shift
| BN_TRN of trn_size * trn_mode
| BN_MULQACC
| BN_MULQACC_Z
| BN_MULQACC_WO of bn_flag_group
| BN_MULQACC_WO_Z of bn_flag_group
| BN_MULQACC_SO of bn_flag_group * bn_halfword_writeback
| BN_MULQACC_SO_Z of bn_flag_group * bn_halfword_writeback
| BN_ACCR
| BN_ACCW
| BN_MODR
| BN_MODW
| BN_LD
| BN_SD
| BN_LID of nat
| BN_SID of nat

(** val otbn_op_rect :
    (rv_mnemonic -> 'a1) -> (bn_basic_mnemonic -> bn_flag_group -> 'a1) ->
    (bn_basic_mnemonic -> bn_flag_group -> bn_register_shift -> 'a1) ->
    (bn_flag_group -> 'a1) -> (bn_flag_group -> 'a1) -> 'a1 -> 'a1 ->
    (bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> bool -> 'a1) ->
    (vec_size -> bool -> 'a1) -> (vec_size -> bn_register_shift -> 'a1) ->
    (trn_size -> trn_mode -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group -> 'a1) ->
    (bn_flag_group -> 'a1) -> (bn_flag_group -> bn_halfword_writeback -> 'a1)
    -> (bn_flag_group -> bn_halfword_writeback -> 'a1) -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> (nat -> 'a1) -> (nat -> 'a1) -> otbn_op -> 'a1 **)

let otbn_op_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 = function
| RV32 r -> f r
| BN_basic (b, b0) -> f0 b b0
| BN_basic_shift (b, b0, b1) -> f1 b b0 b1
| BN_ADDI b -> f2 b
| BN_SUBI b -> f3 b
| BN_MOV -> f4
| BN_RSHI -> f5
| BN_SEL b -> f6 b
| BN_ADDM -> f7
| BN_SUBM -> f8
| BN_ADDV (v, b) -> f9 v b
| BN_SUBV (v, b) -> f10 v b
| BN_SHV (v, b) -> f11 v b
| BN_TRN (t, t0) -> f12 t t0
| BN_MULQACC -> f13
| BN_MULQACC_Z -> f14
| BN_MULQACC_WO b -> f15 b
| BN_MULQACC_WO_Z b -> f16 b
| BN_MULQACC_SO (b, b0) -> f17 b b0
| BN_MULQACC_SO_Z (b, b0) -> f18 b b0
| BN_ACCR -> f19
| BN_ACCW -> f20
| BN_MODR -> f21
| BN_MODW -> f22
| BN_LD -> f23
| BN_SD -> f24
| BN_LID n -> f25 n
| BN_SID n -> f26 n

(** val otbn_op_rec :
    (rv_mnemonic -> 'a1) -> (bn_basic_mnemonic -> bn_flag_group -> 'a1) ->
    (bn_basic_mnemonic -> bn_flag_group -> bn_register_shift -> 'a1) ->
    (bn_flag_group -> 'a1) -> (bn_flag_group -> 'a1) -> 'a1 -> 'a1 ->
    (bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> bool -> 'a1) ->
    (vec_size -> bool -> 'a1) -> (vec_size -> bn_register_shift -> 'a1) ->
    (trn_size -> trn_mode -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group -> 'a1) ->
    (bn_flag_group -> 'a1) -> (bn_flag_group -> bn_halfword_writeback -> 'a1)
    -> (bn_flag_group -> bn_halfword_writeback -> 'a1) -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> (nat -> 'a1) -> (nat -> 'a1) -> otbn_op -> 'a1 **)

let otbn_op_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 = function
| RV32 r -> f r
| BN_basic (b, b0) -> f0 b b0
| BN_basic_shift (b, b0, b1) -> f1 b b0 b1
| BN_ADDI b -> f2 b
| BN_SUBI b -> f3 b
| BN_MOV -> f4
| BN_RSHI -> f5
| BN_SEL b -> f6 b
| BN_ADDM -> f7
| BN_SUBM -> f8
| BN_ADDV (v, b) -> f9 v b
| BN_SUBV (v, b) -> f10 v b
| BN_SHV (v, b) -> f11 v b
| BN_TRN (t, t0) -> f12 t t0
| BN_MULQACC -> f13
| BN_MULQACC_Z -> f14
| BN_MULQACC_WO b -> f15 b
| BN_MULQACC_WO_Z b -> f16 b
| BN_MULQACC_SO (b, b0) -> f17 b b0
| BN_MULQACC_SO_Z (b, b0) -> f18 b b0
| BN_ACCR -> f19
| BN_ACCW -> f20
| BN_MODR -> f21
| BN_MODW -> f22
| BN_LD -> f23
| BN_SD -> f24
| BN_LID n -> f25 n
| BN_SID n -> f26 n

type is_otbn_op =
| Coq_is_RV32 of rv_mnemonic * is_rv_mnemonic
| Coq_is_BN_basic of bn_basic_mnemonic * is_bn_basic_mnemonic * bn_flag_group
   * is_bn_flag_group
| Coq_is_BN_basic_shift of bn_basic_mnemonic * is_bn_basic_mnemonic
   * bn_flag_group * is_bn_flag_group * bn_register_shift
   * is_bn_register_shift
| Coq_is_BN_ADDI of bn_flag_group * is_bn_flag_group
| Coq_is_BN_SUBI of bn_flag_group * is_bn_flag_group
| Coq_is_BN_MOV
| Coq_is_BN_RSHI
| Coq_is_BN_SEL of bn_flag_group * is_bn_flag_group
| Coq_is_BN_ADDM
| Coq_is_BN_SUBM
| Coq_is_BN_ADDV of vec_size * is_vec_size * bool * Param1.Coq_exports.is_bool
| Coq_is_BN_SUBV of vec_size * is_vec_size * bool * Param1.Coq_exports.is_bool
| Coq_is_BN_SHV of vec_size * is_vec_size * bn_register_shift
   * is_bn_register_shift
| Coq_is_BN_TRN of trn_size * is_trn_size * trn_mode * is_trn_mode
| Coq_is_BN_MULQACC
| Coq_is_BN_MULQACC_Z
| Coq_is_BN_MULQACC_WO of bn_flag_group * is_bn_flag_group
| Coq_is_BN_MULQACC_WO_Z of bn_flag_group * is_bn_flag_group
| Coq_is_BN_MULQACC_SO of bn_flag_group * is_bn_flag_group
   * bn_halfword_writeback * is_bn_halfword_writeback
| Coq_is_BN_MULQACC_SO_Z of bn_flag_group * is_bn_flag_group
   * bn_halfword_writeback * is_bn_halfword_writeback
| Coq_is_BN_ACCR
| Coq_is_BN_ACCW
| Coq_is_BN_MODR
| Coq_is_BN_MODW
| Coq_is_BN_LD
| Coq_is_BN_SD
| Coq_is_BN_LID of nat * Prelude.is_nat
| Coq_is_BN_SID of nat * Prelude.is_nat

(** val is_otbn_op_rect :
    (rv_mnemonic -> is_rv_mnemonic -> 'a1) -> (bn_basic_mnemonic ->
    is_bn_basic_mnemonic -> bn_flag_group -> is_bn_flag_group -> 'a1) ->
    (bn_basic_mnemonic -> is_bn_basic_mnemonic -> bn_flag_group ->
    is_bn_flag_group -> bn_register_shift -> is_bn_register_shift -> 'a1) ->
    (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> is_vec_size ->
    bool -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
    bool -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
    bn_register_shift -> is_bn_register_shift -> 'a1) -> (trn_size ->
    is_trn_size -> trn_mode -> is_trn_mode -> 'a1) -> 'a1 -> 'a1 ->
    (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> (bn_flag_group -> is_bn_flag_group ->
    bn_halfword_writeback -> is_bn_halfword_writeback -> 'a1) ->
    (bn_flag_group -> is_bn_flag_group -> bn_halfword_writeback ->
    is_bn_halfword_writeback -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> (nat -> Prelude.is_nat -> 'a1) -> (nat -> Prelude.is_nat -> 'a1)
    -> otbn_op -> is_otbn_op -> 'a1 **)

let is_otbn_op_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 _ = function
| Coq_is_RV32 (r, p_) -> f r p_
| Coq_is_BN_basic (b, p_, b0, p_0) -> f0 b p_ b0 p_0
| Coq_is_BN_basic_shift (b, p_, b0, p_0, b1, p_1) -> f1 b p_ b0 p_0 b1 p_1
| Coq_is_BN_ADDI (b, p_) -> f2 b p_
| Coq_is_BN_SUBI (b, p_) -> f3 b p_
| Coq_is_BN_MOV -> f4
| Coq_is_BN_RSHI -> f5
| Coq_is_BN_SEL (b, p_) -> f6 b p_
| Coq_is_BN_ADDM -> f7
| Coq_is_BN_SUBM -> f8
| Coq_is_BN_ADDV (v, p_, b, p_0) -> f9 v p_ b p_0
| Coq_is_BN_SUBV (v, p_, b, p_0) -> f10 v p_ b p_0
| Coq_is_BN_SHV (v, p_, b, p_0) -> f11 v p_ b p_0
| Coq_is_BN_TRN (t, p_, t0, p_0) -> f12 t p_ t0 p_0
| Coq_is_BN_MULQACC -> f13
| Coq_is_BN_MULQACC_Z -> f14
| Coq_is_BN_MULQACC_WO (b, p_) -> f15 b p_
| Coq_is_BN_MULQACC_WO_Z (b, p_) -> f16 b p_
| Coq_is_BN_MULQACC_SO (b, p_, b0, p_0) -> f17 b p_ b0 p_0
| Coq_is_BN_MULQACC_SO_Z (b, p_, b0, p_0) -> f18 b p_ b0 p_0
| Coq_is_BN_ACCR -> f19
| Coq_is_BN_ACCW -> f20
| Coq_is_BN_MODR -> f21
| Coq_is_BN_MODW -> f22
| Coq_is_BN_LD -> f23
| Coq_is_BN_SD -> f24
| Coq_is_BN_LID (n, p_) -> f25 n p_
| Coq_is_BN_SID (n, p_) -> f26 n p_

(** val is_otbn_op_rec :
    (rv_mnemonic -> is_rv_mnemonic -> 'a1) -> (bn_basic_mnemonic ->
    is_bn_basic_mnemonic -> bn_flag_group -> is_bn_flag_group -> 'a1) ->
    (bn_basic_mnemonic -> is_bn_basic_mnemonic -> bn_flag_group ->
    is_bn_flag_group -> bn_register_shift -> is_bn_register_shift -> 'a1) ->
    (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> is_vec_size ->
    bool -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
    bool -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
    bn_register_shift -> is_bn_register_shift -> 'a1) -> (trn_size ->
    is_trn_size -> trn_mode -> is_trn_mode -> 'a1) -> 'a1 -> 'a1 ->
    (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> (bn_flag_group -> is_bn_flag_group ->
    bn_halfword_writeback -> is_bn_halfword_writeback -> 'a1) ->
    (bn_flag_group -> is_bn_flag_group -> bn_halfword_writeback ->
    is_bn_halfword_writeback -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> (nat -> Prelude.is_nat -> 'a1) -> (nat -> Prelude.is_nat -> 'a1)
    -> otbn_op -> is_otbn_op -> 'a1 **)

let is_otbn_op_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 _ = function
| Coq_is_RV32 (r, p_) -> f r p_
| Coq_is_BN_basic (b, p_, b0, p_0) -> f0 b p_ b0 p_0
| Coq_is_BN_basic_shift (b, p_, b0, p_0, b1, p_1) -> f1 b p_ b0 p_0 b1 p_1
| Coq_is_BN_ADDI (b, p_) -> f2 b p_
| Coq_is_BN_SUBI (b, p_) -> f3 b p_
| Coq_is_BN_MOV -> f4
| Coq_is_BN_RSHI -> f5
| Coq_is_BN_SEL (b, p_) -> f6 b p_
| Coq_is_BN_ADDM -> f7
| Coq_is_BN_SUBM -> f8
| Coq_is_BN_ADDV (v, p_, b, p_0) -> f9 v p_ b p_0
| Coq_is_BN_SUBV (v, p_, b, p_0) -> f10 v p_ b p_0
| Coq_is_BN_SHV (v, p_, b, p_0) -> f11 v p_ b p_0
| Coq_is_BN_TRN (t, p_, t0, p_0) -> f12 t p_ t0 p_0
| Coq_is_BN_MULQACC -> f13
| Coq_is_BN_MULQACC_Z -> f14
| Coq_is_BN_MULQACC_WO (b, p_) -> f15 b p_
| Coq_is_BN_MULQACC_WO_Z (b, p_) -> f16 b p_
| Coq_is_BN_MULQACC_SO (b, p_, b0, p_0) -> f17 b p_ b0 p_0
| Coq_is_BN_MULQACC_SO_Z (b, p_, b0, p_0) -> f18 b p_ b0 p_0
| Coq_is_BN_ACCR -> f19
| Coq_is_BN_ACCW -> f20
| Coq_is_BN_MODR -> f21
| Coq_is_BN_MODW -> f22
| Coq_is_BN_LD -> f23
| Coq_is_BN_SD -> f24
| Coq_is_BN_LID (n, p_) -> f25 n p_
| Coq_is_BN_SID (n, p_) -> f26 n p_

(** val otbn_op_tag : otbn_op -> positive **)

let otbn_op_tag = function
| RV32 _ -> Coq_xH
| BN_basic (_, _) -> Coq_xO Coq_xH
| BN_basic_shift (_, _, _) -> Coq_xI Coq_xH
| BN_ADDI _ -> Coq_xO (Coq_xO Coq_xH)
| BN_SUBI _ -> Coq_xI (Coq_xO Coq_xH)
| BN_MOV -> Coq_xO (Coq_xI Coq_xH)
| BN_RSHI -> Coq_xI (Coq_xI Coq_xH)
| BN_SEL _ -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| BN_ADDM -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| BN_SUBM -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| BN_ADDV (_, _) -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| BN_SUBV (_, _) -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| BN_SHV (_, _) -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| BN_TRN (_, _) -> Coq_xO (Coq_xI (Coq_xI Coq_xH))
| BN_MULQACC -> Coq_xI (Coq_xI (Coq_xI Coq_xH))
| BN_MULQACC_Z -> Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| BN_MULQACC_WO _ -> Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| BN_MULQACC_WO_Z _ -> Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| BN_MULQACC_SO (_, _) -> Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| BN_MULQACC_SO_Z (_, _) -> Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| BN_ACCR -> Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| BN_ACCW -> Coq_xO (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| BN_MODR -> Coq_xI (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| BN_MODW -> Coq_xO (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| BN_LD -> Coq_xI (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| BN_SD -> Coq_xO (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| BN_LID _ -> Coq_xI (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| BN_SID _ -> Coq_xO (Coq_xO (Coq_xI (Coq_xI Coq_xH)))

(** val is_otbn_op_inhab : otbn_op -> is_otbn_op **)

let is_otbn_op_inhab = function
| RV32 h -> Coq_is_RV32 (h, (is_rv_mnemonic_inhab h))
| BN_basic (h, h0) ->
  Coq_is_BN_basic (h, (is_bn_basic_mnemonic_inhab h), h0,
    (is_bn_flag_group_inhab h0))
| BN_basic_shift (h, h0, h1) ->
  Coq_is_BN_basic_shift (h, (is_bn_basic_mnemonic_inhab h), h0,
    (is_bn_flag_group_inhab h0), h1, (is_bn_register_shift_inhab h1))
| BN_ADDI h -> Coq_is_BN_ADDI (h, (is_bn_flag_group_inhab h))
| BN_SUBI h -> Coq_is_BN_SUBI (h, (is_bn_flag_group_inhab h))
| BN_MOV -> Coq_is_BN_MOV
| BN_RSHI -> Coq_is_BN_RSHI
| BN_SEL h -> Coq_is_BN_SEL (h, (is_bn_flag_group_inhab h))
| BN_ADDM -> Coq_is_BN_ADDM
| BN_SUBM -> Coq_is_BN_SUBM
| BN_ADDV (h, h0) ->
  Coq_is_BN_ADDV (h, (is_vec_size_inhab h), h0,
    (Coq_exports.is_bool_inhab h0))
| BN_SUBV (h, h0) ->
  Coq_is_BN_SUBV (h, (is_vec_size_inhab h), h0,
    (Coq_exports.is_bool_inhab h0))
| BN_SHV (h, h0) ->
  Coq_is_BN_SHV (h, (is_vec_size_inhab h), h0,
    (is_bn_register_shift_inhab h0))
| BN_TRN (h, h0) ->
  Coq_is_BN_TRN (h, (is_trn_size_inhab h), h0, (is_trn_mode_inhab h0))
| BN_MULQACC -> Coq_is_BN_MULQACC
| BN_MULQACC_Z -> Coq_is_BN_MULQACC_Z
| BN_MULQACC_WO h -> Coq_is_BN_MULQACC_WO (h, (is_bn_flag_group_inhab h))
| BN_MULQACC_WO_Z h -> Coq_is_BN_MULQACC_WO_Z (h, (is_bn_flag_group_inhab h))
| BN_MULQACC_SO (h, h0) ->
  Coq_is_BN_MULQACC_SO (h, (is_bn_flag_group_inhab h), h0,
    (is_bn_halfword_writeback_inhab h0))
| BN_MULQACC_SO_Z (h, h0) ->
  Coq_is_BN_MULQACC_SO_Z (h, (is_bn_flag_group_inhab h), h0,
    (is_bn_halfword_writeback_inhab h0))
| BN_ACCR -> Coq_is_BN_ACCR
| BN_ACCW -> Coq_is_BN_ACCW
| BN_MODR -> Coq_is_BN_MODR
| BN_MODW -> Coq_is_BN_MODW
| BN_LD -> Coq_is_BN_LD
| BN_SD -> Coq_is_BN_SD
| BN_LID h -> Coq_is_BN_LID (h, (Prelude.is_nat_inhab h))
| BN_SID h -> Coq_is_BN_SID (h, (Prelude.is_nat_inhab h))

(** val is_otbn_op_functor : otbn_op -> is_otbn_op -> is_otbn_op **)

let rec is_otbn_op_functor _ x =
  x

type box_otbn_op_RV32 =
  rv_mnemonic
  (* singleton inductive, whose constructor was Box_otbn_op_RV32 *)

(** val coq_Box_otbn_op_RV32_0 : box_otbn_op_RV32 -> rv_mnemonic **)

let coq_Box_otbn_op_RV32_0 record =
  record

type box_otbn_op_BN_basic = { coq_Box_otbn_op_BN_basic_0 : bn_basic_mnemonic;
                              coq_Box_otbn_op_BN_basic_1 : bn_flag_group }

(** val coq_Box_otbn_op_BN_basic_0 :
    box_otbn_op_BN_basic -> bn_basic_mnemonic **)

let coq_Box_otbn_op_BN_basic_0 record =
  record.coq_Box_otbn_op_BN_basic_0

(** val coq_Box_otbn_op_BN_basic_1 : box_otbn_op_BN_basic -> bn_flag_group **)

let coq_Box_otbn_op_BN_basic_1 record =
  record.coq_Box_otbn_op_BN_basic_1

type box_otbn_op_BN_basic_shift = { coq_Box_otbn_op_BN_basic_shift_0 : 
                                    bn_basic_mnemonic;
                                    coq_Box_otbn_op_BN_basic_shift_1 : 
                                    bn_flag_group;
                                    coq_Box_otbn_op_BN_basic_shift_2 : 
                                    bn_register_shift }

(** val coq_Box_otbn_op_BN_basic_shift_0 :
    box_otbn_op_BN_basic_shift -> bn_basic_mnemonic **)

let coq_Box_otbn_op_BN_basic_shift_0 record =
  record.coq_Box_otbn_op_BN_basic_shift_0

(** val coq_Box_otbn_op_BN_basic_shift_1 :
    box_otbn_op_BN_basic_shift -> bn_flag_group **)

let coq_Box_otbn_op_BN_basic_shift_1 record =
  record.coq_Box_otbn_op_BN_basic_shift_1

(** val coq_Box_otbn_op_BN_basic_shift_2 :
    box_otbn_op_BN_basic_shift -> bn_register_shift **)

let coq_Box_otbn_op_BN_basic_shift_2 record =
  record.coq_Box_otbn_op_BN_basic_shift_2

type box_otbn_op_BN_ADDI =
  bn_flag_group
  (* singleton inductive, whose constructor was Box_otbn_op_BN_ADDI *)

(** val coq_Box_otbn_op_BN_ADDI_0 : box_otbn_op_BN_ADDI -> bn_flag_group **)

let coq_Box_otbn_op_BN_ADDI_0 record =
  record

type box_otbn_op_BN_MOV =
| Box_otbn_op_BN_MOV

type box_otbn_op_BN_ADDV = { coq_Box_otbn_op_BN_ADDV_0 : vec_size;
                             coq_Box_otbn_op_BN_ADDV_1 : bool }

(** val coq_Box_otbn_op_BN_ADDV_0 : box_otbn_op_BN_ADDV -> vec_size **)

let coq_Box_otbn_op_BN_ADDV_0 record =
  record.coq_Box_otbn_op_BN_ADDV_0

(** val coq_Box_otbn_op_BN_ADDV_1 : box_otbn_op_BN_ADDV -> bool **)

let coq_Box_otbn_op_BN_ADDV_1 record =
  record.coq_Box_otbn_op_BN_ADDV_1

type box_otbn_op_BN_SHV = { coq_Box_otbn_op_BN_SHV_0 : vec_size;
                            coq_Box_otbn_op_BN_SHV_1 : bn_register_shift }

(** val coq_Box_otbn_op_BN_SHV_0 : box_otbn_op_BN_SHV -> vec_size **)

let coq_Box_otbn_op_BN_SHV_0 record =
  record.coq_Box_otbn_op_BN_SHV_0

(** val coq_Box_otbn_op_BN_SHV_1 : box_otbn_op_BN_SHV -> bn_register_shift **)

let coq_Box_otbn_op_BN_SHV_1 record =
  record.coq_Box_otbn_op_BN_SHV_1

type box_otbn_op_BN_TRN = { coq_Box_otbn_op_BN_TRN_0 : trn_size;
                            coq_Box_otbn_op_BN_TRN_1 : trn_mode }

(** val coq_Box_otbn_op_BN_TRN_0 : box_otbn_op_BN_TRN -> trn_size **)

let coq_Box_otbn_op_BN_TRN_0 record =
  record.coq_Box_otbn_op_BN_TRN_0

(** val coq_Box_otbn_op_BN_TRN_1 : box_otbn_op_BN_TRN -> trn_mode **)

let coq_Box_otbn_op_BN_TRN_1 record =
  record.coq_Box_otbn_op_BN_TRN_1

type box_otbn_op_BN_MULQACC_SO = { coq_Box_otbn_op_BN_MULQACC_SO_0 : 
                                   bn_flag_group;
                                   coq_Box_otbn_op_BN_MULQACC_SO_1 : 
                                   bn_halfword_writeback }

(** val coq_Box_otbn_op_BN_MULQACC_SO_0 :
    box_otbn_op_BN_MULQACC_SO -> bn_flag_group **)

let coq_Box_otbn_op_BN_MULQACC_SO_0 record =
  record.coq_Box_otbn_op_BN_MULQACC_SO_0

(** val coq_Box_otbn_op_BN_MULQACC_SO_1 :
    box_otbn_op_BN_MULQACC_SO -> bn_halfword_writeback **)

let coq_Box_otbn_op_BN_MULQACC_SO_1 record =
  record.coq_Box_otbn_op_BN_MULQACC_SO_1

type box_otbn_op_BN_LID =
  nat
  (* singleton inductive, whose constructor was Box_otbn_op_BN_LID *)

(** val coq_Box_otbn_op_BN_LID_0 : box_otbn_op_BN_LID -> nat **)

let coq_Box_otbn_op_BN_LID_0 record =
  record

type otbn_op_fields_t = __

(** val otbn_op_fields : otbn_op -> otbn_op_fields_t **)

let otbn_op_fields = function
| RV32 h -> Obj.magic h
| BN_basic (h, h0) ->
  Obj.magic { coq_Box_otbn_op_BN_basic_0 = h; coq_Box_otbn_op_BN_basic_1 =
    h0 }
| BN_basic_shift (h, h0, h1) ->
  Obj.magic { coq_Box_otbn_op_BN_basic_shift_0 = h;
    coq_Box_otbn_op_BN_basic_shift_1 = h0; coq_Box_otbn_op_BN_basic_shift_2 =
    h1 }
| BN_ADDI h -> Obj.magic h
| BN_SUBI h -> Obj.magic h
| BN_SEL h -> Obj.magic h
| BN_ADDV (h, h0) ->
  Obj.magic { coq_Box_otbn_op_BN_ADDV_0 = h; coq_Box_otbn_op_BN_ADDV_1 = h0 }
| BN_SUBV (h, h0) ->
  Obj.magic { coq_Box_otbn_op_BN_ADDV_0 = h; coq_Box_otbn_op_BN_ADDV_1 = h0 }
| BN_SHV (h, h0) ->
  Obj.magic { coq_Box_otbn_op_BN_SHV_0 = h; coq_Box_otbn_op_BN_SHV_1 = h0 }
| BN_TRN (h, h0) ->
  Obj.magic { coq_Box_otbn_op_BN_TRN_0 = h; coq_Box_otbn_op_BN_TRN_1 = h0 }
| BN_MULQACC_WO h -> Obj.magic h
| BN_MULQACC_WO_Z h -> Obj.magic h
| BN_MULQACC_SO (h, h0) ->
  Obj.magic { coq_Box_otbn_op_BN_MULQACC_SO_0 = h;
    coq_Box_otbn_op_BN_MULQACC_SO_1 = h0 }
| BN_MULQACC_SO_Z (h, h0) ->
  Obj.magic { coq_Box_otbn_op_BN_MULQACC_SO_0 = h;
    coq_Box_otbn_op_BN_MULQACC_SO_1 = h0 }
| BN_LID h -> Obj.magic h
| BN_SID h -> Obj.magic h
| _ -> Obj.magic Box_otbn_op_BN_MOV

(** val otbn_op_construct : positive -> otbn_op_fields_t -> otbn_op option **)

let otbn_op_construct p x =
  match p with
  | Coq_xI x0 ->
    (match x0 with
     | Coq_xI x1 ->
       (match x1 with
        | Coq_xI x2 ->
          (match x2 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some BN_MODR
           | Coq_xH -> Some BN_MULQACC)
        | Coq_xO x2 ->
          (match x2 with
           | Coq_xI _ -> Some (BN_LID (Obj.magic x))
           | Coq_xO _ ->
             let { coq_Box_otbn_op_BN_MULQACC_SO_0 =
               box_otbn_op_BN_MULQACC_SO_0; coq_Box_otbn_op_BN_MULQACC_SO_1 =
               box_otbn_op_BN_MULQACC_SO_1 } = Obj.magic x
             in
             Some (BN_MULQACC_SO (box_otbn_op_BN_MULQACC_SO_0,
             box_otbn_op_BN_MULQACC_SO_1))
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_ADDV_0 = box_otbn_op_BN_ADDV_0;
               coq_Box_otbn_op_BN_ADDV_1 = box_otbn_op_BN_ADDV_1 } =
               Obj.magic x
             in
             Some (BN_ADDV (box_otbn_op_BN_ADDV_0, box_otbn_op_BN_ADDV_1)))
        | Coq_xH -> Some BN_RSHI)
     | Coq_xO x1 ->
       (match x1 with
        | Coq_xI x2 ->
          (match x2 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some BN_ACCR
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_SHV_0 = box_otbn_op_BN_SHV_0;
               coq_Box_otbn_op_BN_SHV_1 = box_otbn_op_BN_SHV_1 } = Obj.magic x
             in
             Some (BN_SHV (box_otbn_op_BN_SHV_0, box_otbn_op_BN_SHV_1)))
        | Coq_xO x2 ->
          (match x2 with
           | Coq_xI _ -> Some BN_LD
           | Coq_xO _ -> Some (BN_MULQACC_WO (Obj.magic x))
           | Coq_xH -> Some BN_ADDM)
        | Coq_xH -> Some (BN_SUBI (Obj.magic x)))
     | Coq_xH ->
       let { coq_Box_otbn_op_BN_basic_shift_0 = box_otbn_op_BN_basic_shift_0;
         coq_Box_otbn_op_BN_basic_shift_1 = box_otbn_op_BN_basic_shift_1;
         coq_Box_otbn_op_BN_basic_shift_2 = box_otbn_op_BN_basic_shift_2 } =
         Obj.magic x
       in
       Some (BN_basic_shift (box_otbn_op_BN_basic_shift_0,
       box_otbn_op_BN_basic_shift_1, box_otbn_op_BN_basic_shift_2)))
  | Coq_xO x0 ->
    (match x0 with
     | Coq_xI x1 ->
       (match x1 with
        | Coq_xI x2 ->
          (match x2 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some BN_ACCW
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_TRN_0 = box_otbn_op_BN_TRN_0;
               coq_Box_otbn_op_BN_TRN_1 = box_otbn_op_BN_TRN_1 } = Obj.magic x
             in
             Some (BN_TRN (box_otbn_op_BN_TRN_0, box_otbn_op_BN_TRN_1)))
        | Coq_xO x2 ->
          (match x2 with
           | Coq_xI _ -> Some BN_SD
           | Coq_xO _ -> Some (BN_MULQACC_WO_Z (Obj.magic x))
           | Coq_xH -> Some BN_SUBM)
        | Coq_xH -> Some BN_MOV)
     | Coq_xO x1 ->
       (match x1 with
        | Coq_xI x2 ->
          (match x2 with
           | Coq_xI _ -> Some (BN_SID (Obj.magic x))
           | Coq_xO _ ->
             let { coq_Box_otbn_op_BN_MULQACC_SO_0 =
               box_otbn_op_BN_MULQACC_SO_0; coq_Box_otbn_op_BN_MULQACC_SO_1 =
               box_otbn_op_BN_MULQACC_SO_1 } = Obj.magic x
             in
             Some (BN_MULQACC_SO_Z (box_otbn_op_BN_MULQACC_SO_0,
             box_otbn_op_BN_MULQACC_SO_1))
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_ADDV_0 = box_otbn_op_BN_ADDV_0;
               coq_Box_otbn_op_BN_ADDV_1 = box_otbn_op_BN_ADDV_1 } =
               Obj.magic x
             in
             Some (BN_SUBV (box_otbn_op_BN_ADDV_0, box_otbn_op_BN_ADDV_1)))
        | Coq_xO x2 ->
          (match x2 with
           | Coq_xI _ -> Some BN_MODW
           | Coq_xO _ -> Some BN_MULQACC_Z
           | Coq_xH -> Some (BN_SEL (Obj.magic x)))
        | Coq_xH -> Some (BN_ADDI (Obj.magic x)))
     | Coq_xH ->
       let { coq_Box_otbn_op_BN_basic_0 = box_otbn_op_BN_basic_0;
         coq_Box_otbn_op_BN_basic_1 = box_otbn_op_BN_basic_1 } = Obj.magic x
       in
       Some (BN_basic (box_otbn_op_BN_basic_0, box_otbn_op_BN_basic_1)))
  | Coq_xH -> Some (RV32 (Obj.magic x))

(** val otbn_op_induction :
    (rv_mnemonic -> is_rv_mnemonic -> 'a1) -> (bn_basic_mnemonic ->
    is_bn_basic_mnemonic -> bn_flag_group -> is_bn_flag_group -> 'a1) ->
    (bn_basic_mnemonic -> is_bn_basic_mnemonic -> bn_flag_group ->
    is_bn_flag_group -> bn_register_shift -> is_bn_register_shift -> 'a1) ->
    (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> is_vec_size ->
    bool -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
    bool -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
    bn_register_shift -> is_bn_register_shift -> 'a1) -> (trn_size ->
    is_trn_size -> trn_mode -> is_trn_mode -> 'a1) -> 'a1 -> 'a1 ->
    (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
    is_bn_flag_group -> 'a1) -> (bn_flag_group -> is_bn_flag_group ->
    bn_halfword_writeback -> is_bn_halfword_writeback -> 'a1) ->
    (bn_flag_group -> is_bn_flag_group -> bn_halfword_writeback ->
    is_bn_halfword_writeback -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> (nat -> Prelude.is_nat -> 'a1) -> (nat -> Prelude.is_nat -> 'a1)
    -> otbn_op -> is_otbn_op -> 'a1 **)

let otbn_op_induction his_RV32 his_BN_basic his_BN_basic_shift his_BN_ADDI his_BN_SUBI his_BN_MOV his_BN_RSHI his_BN_SEL his_BN_ADDM his_BN_SUBM his_BN_ADDV his_BN_SUBV his_BN_SHV his_BN_TRN his_BN_MULQACC his_BN_MULQACC_Z his_BN_MULQACC_WO his_BN_MULQACC_WO_Z his_BN_MULQACC_SO his_BN_MULQACC_SO_Z his_BN_ACCR his_BN_ACCW his_BN_MODR his_BN_MODW his_BN_LD his_BN_SD his_BN_LID his_BN_SID _ = function
| Coq_is_RV32 (x0, p_) -> his_RV32 x0 p_
| Coq_is_BN_basic (x0, p_, x1, p_0) -> his_BN_basic x0 p_ x1 p_0
| Coq_is_BN_basic_shift (x0, p_, x1, p_0, x2, p_1) ->
  his_BN_basic_shift x0 p_ x1 p_0 x2 p_1
| Coq_is_BN_ADDI (x0, p_) -> his_BN_ADDI x0 p_
| Coq_is_BN_SUBI (x0, p_) -> his_BN_SUBI x0 p_
| Coq_is_BN_MOV -> his_BN_MOV
| Coq_is_BN_RSHI -> his_BN_RSHI
| Coq_is_BN_SEL (x0, p_) -> his_BN_SEL x0 p_
| Coq_is_BN_ADDM -> his_BN_ADDM
| Coq_is_BN_SUBM -> his_BN_SUBM
| Coq_is_BN_ADDV (x0, p_, x1, p_0) -> his_BN_ADDV x0 p_ x1 p_0
| Coq_is_BN_SUBV (x0, p_, x1, p_0) -> his_BN_SUBV x0 p_ x1 p_0
| Coq_is_BN_SHV (x0, p_, x1, p_0) -> his_BN_SHV x0 p_ x1 p_0
| Coq_is_BN_TRN (x0, p_, x1, p_0) -> his_BN_TRN x0 p_ x1 p_0
| Coq_is_BN_MULQACC -> his_BN_MULQACC
| Coq_is_BN_MULQACC_Z -> his_BN_MULQACC_Z
| Coq_is_BN_MULQACC_WO (x0, p_) -> his_BN_MULQACC_WO x0 p_
| Coq_is_BN_MULQACC_WO_Z (x0, p_) -> his_BN_MULQACC_WO_Z x0 p_
| Coq_is_BN_MULQACC_SO (x0, p_, x1, p_0) -> his_BN_MULQACC_SO x0 p_ x1 p_0
| Coq_is_BN_MULQACC_SO_Z (x0, p_, x1, p_0) -> his_BN_MULQACC_SO_Z x0 p_ x1 p_0
| Coq_is_BN_ACCR -> his_BN_ACCR
| Coq_is_BN_ACCW -> his_BN_ACCW
| Coq_is_BN_MODR -> his_BN_MODR
| Coq_is_BN_MODW -> his_BN_MODW
| Coq_is_BN_LD -> his_BN_LD
| Coq_is_BN_SD -> his_BN_SD
| Coq_is_BN_LID (x0, p_) -> his_BN_LID x0 p_
| Coq_is_BN_SID (x0, p_) -> his_BN_SID x0 p_

(** val otbn_op_eqb_fields :
    (otbn_op -> otbn_op -> bool) -> positive -> otbn_op_fields_t ->
    otbn_op_fields_t -> bool **)

let otbn_op_eqb_fields _ x x0 x1 =
  match x with
  | Coq_xI x2 ->
    (match x2 with
     | Coq_xI x3 ->
       (match x3 with
        | Coq_xO x4 ->
          (match x4 with
           | Coq_xI _ ->
             (&&) (Prelude.nat_eqb (Obj.magic x0) (Obj.magic x1)) true
           | Coq_xO _ ->
             let { coq_Box_otbn_op_BN_MULQACC_SO_0 =
               box_otbn_op_BN_MULQACC_SO_0; coq_Box_otbn_op_BN_MULQACC_SO_1 =
               box_otbn_op_BN_MULQACC_SO_1 } = Obj.magic x0
             in
             let { coq_Box_otbn_op_BN_MULQACC_SO_0 =
               box_otbn_op_BN_MULQACC_SO_2; coq_Box_otbn_op_BN_MULQACC_SO_1 =
               box_otbn_op_BN_MULQACC_SO_3 } = Obj.magic x1
             in
             (&&)
               (bn_flag_group_eqb box_otbn_op_BN_MULQACC_SO_0
                 box_otbn_op_BN_MULQACC_SO_2)
               ((&&)
                 (bn_halfword_writeback_eqb box_otbn_op_BN_MULQACC_SO_1
                   box_otbn_op_BN_MULQACC_SO_3)
                 true)
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_ADDV_0 = box_otbn_op_BN_ADDV_0;
               coq_Box_otbn_op_BN_ADDV_1 = box_otbn_op_BN_ADDV_1 } =
               Obj.magic x0
             in
             let { coq_Box_otbn_op_BN_ADDV_0 = box_otbn_op_BN_ADDV_2;
               coq_Box_otbn_op_BN_ADDV_1 = box_otbn_op_BN_ADDV_3 } =
               Obj.magic x1
             in
             (&&) (vec_size_eqb box_otbn_op_BN_ADDV_0 box_otbn_op_BN_ADDV_2)
               ((&&)
                 (Prelude.bool_eqb box_otbn_op_BN_ADDV_1
                   box_otbn_op_BN_ADDV_3)
                 true))
        | _ -> true)
     | Coq_xO x3 ->
       (match x3 with
        | Coq_xI x4 ->
          (match x4 with
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_SHV_0 = box_otbn_op_BN_SHV_0;
               coq_Box_otbn_op_BN_SHV_1 = box_otbn_op_BN_SHV_1 } =
               Obj.magic x0
             in
             let { coq_Box_otbn_op_BN_SHV_0 = box_otbn_op_BN_SHV_2;
               coq_Box_otbn_op_BN_SHV_1 = box_otbn_op_BN_SHV_3 } =
               Obj.magic x1
             in
             (&&) (vec_size_eqb box_otbn_op_BN_SHV_0 box_otbn_op_BN_SHV_2)
               ((&&)
                 (bn_register_shift_eqb box_otbn_op_BN_SHV_1
                   box_otbn_op_BN_SHV_3)
                 true)
           | _ -> true)
        | Coq_xO x4 ->
          (match x4 with
           | Coq_xO _ ->
             (&&) (bn_flag_group_eqb (Obj.magic x0) (Obj.magic x1)) true
           | _ -> true)
        | Coq_xH ->
          (&&) (bn_flag_group_eqb (Obj.magic x0) (Obj.magic x1)) true)
     | Coq_xH ->
       let { coq_Box_otbn_op_BN_basic_shift_0 = box_otbn_op_BN_basic_shift_0;
         coq_Box_otbn_op_BN_basic_shift_1 = box_otbn_op_BN_basic_shift_1;
         coq_Box_otbn_op_BN_basic_shift_2 = box_otbn_op_BN_basic_shift_2 } =
         Obj.magic x0
       in
       let { coq_Box_otbn_op_BN_basic_shift_0 = box_otbn_op_BN_basic_shift_3;
         coq_Box_otbn_op_BN_basic_shift_1 = box_otbn_op_BN_basic_shift_4;
         coq_Box_otbn_op_BN_basic_shift_2 = box_otbn_op_BN_basic_shift_5 } =
         Obj.magic x1
       in
       (&&)
         (bn_basic_mnemonic_eqb box_otbn_op_BN_basic_shift_0
           box_otbn_op_BN_basic_shift_3)
         ((&&)
           (bn_flag_group_eqb box_otbn_op_BN_basic_shift_1
             box_otbn_op_BN_basic_shift_4)
           ((&&)
             (bn_register_shift_eqb box_otbn_op_BN_basic_shift_2
               box_otbn_op_BN_basic_shift_5)
             true)))
  | Coq_xO x2 ->
    (match x2 with
     | Coq_xI x3 ->
       (match x3 with
        | Coq_xI x4 ->
          (match x4 with
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_TRN_0 = box_otbn_op_BN_TRN_0;
               coq_Box_otbn_op_BN_TRN_1 = box_otbn_op_BN_TRN_1 } =
               Obj.magic x0
             in
             let { coq_Box_otbn_op_BN_TRN_0 = box_otbn_op_BN_TRN_2;
               coq_Box_otbn_op_BN_TRN_1 = box_otbn_op_BN_TRN_3 } =
               Obj.magic x1
             in
             (&&) (trn_size_eqb box_otbn_op_BN_TRN_0 box_otbn_op_BN_TRN_2)
               ((&&) (trn_mode_eqb box_otbn_op_BN_TRN_1 box_otbn_op_BN_TRN_3)
                 true)
           | _ -> true)
        | Coq_xO x4 ->
          (match x4 with
           | Coq_xO _ ->
             (&&) (bn_flag_group_eqb (Obj.magic x0) (Obj.magic x1)) true
           | _ -> true)
        | Coq_xH -> true)
     | Coq_xO x3 ->
       (match x3 with
        | Coq_xI x4 ->
          (match x4 with
           | Coq_xI _ ->
             (&&) (Prelude.nat_eqb (Obj.magic x0) (Obj.magic x1)) true
           | Coq_xO _ ->
             let { coq_Box_otbn_op_BN_MULQACC_SO_0 =
               box_otbn_op_BN_MULQACC_SO_0; coq_Box_otbn_op_BN_MULQACC_SO_1 =
               box_otbn_op_BN_MULQACC_SO_1 } = Obj.magic x0
             in
             let { coq_Box_otbn_op_BN_MULQACC_SO_0 =
               box_otbn_op_BN_MULQACC_SO_2; coq_Box_otbn_op_BN_MULQACC_SO_1 =
               box_otbn_op_BN_MULQACC_SO_3 } = Obj.magic x1
             in
             (&&)
               (bn_flag_group_eqb box_otbn_op_BN_MULQACC_SO_0
                 box_otbn_op_BN_MULQACC_SO_2)
               ((&&)
                 (bn_halfword_writeback_eqb box_otbn_op_BN_MULQACC_SO_1
                   box_otbn_op_BN_MULQACC_SO_3)
                 true)
           | Coq_xH ->
             let { coq_Box_otbn_op_BN_ADDV_0 = box_otbn_op_BN_ADDV_0;
               coq_Box_otbn_op_BN_ADDV_1 = box_otbn_op_BN_ADDV_1 } =
               Obj.magic x0
             in
             let { coq_Box_otbn_op_BN_ADDV_0 = box_otbn_op_BN_ADDV_2;
               coq_Box_otbn_op_BN_ADDV_1 = box_otbn_op_BN_ADDV_3 } =
               Obj.magic x1
             in
             (&&) (vec_size_eqb box_otbn_op_BN_ADDV_0 box_otbn_op_BN_ADDV_2)
               ((&&)
                 (Prelude.bool_eqb box_otbn_op_BN_ADDV_1
                   box_otbn_op_BN_ADDV_3)
                 true))
        | Coq_xO x4 ->
          (match x4 with
           | Coq_xH ->
             (&&) (bn_flag_group_eqb (Obj.magic x0) (Obj.magic x1)) true
           | _ -> true)
        | Coq_xH ->
          (&&) (bn_flag_group_eqb (Obj.magic x0) (Obj.magic x1)) true)
     | Coq_xH ->
       let { coq_Box_otbn_op_BN_basic_0 = box_otbn_op_BN_basic_0;
         coq_Box_otbn_op_BN_basic_1 = box_otbn_op_BN_basic_1 } = Obj.magic x0
       in
       let { coq_Box_otbn_op_BN_basic_0 = box_otbn_op_BN_basic_2;
         coq_Box_otbn_op_BN_basic_1 = box_otbn_op_BN_basic_3 } = Obj.magic x1
       in
       (&&)
         (bn_basic_mnemonic_eqb box_otbn_op_BN_basic_0 box_otbn_op_BN_basic_2)
         ((&&)
           (bn_flag_group_eqb box_otbn_op_BN_basic_1 box_otbn_op_BN_basic_3)
           true))
  | Coq_xH -> (&&) (rv_mnemonic_eqb (Obj.magic x0) (Obj.magic x1)) true

(** val otbn_op_eqb : otbn_op -> otbn_op -> bool **)

let otbn_op_eqb x1 x2 =
  match x1 with
  | RV32 h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true)) (otbn_op_tag (RV32 h))
      h x2
  | BN_basic (h, h0) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_basic (h, h0))) { coq_Box_otbn_op_BN_basic_0 = h;
      coq_Box_otbn_op_BN_basic_1 = h0 } x2
  | BN_basic_shift (h, h0, h1) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_basic_shift (h, h0, h1)))
      { coq_Box_otbn_op_BN_basic_shift_0 = h;
      coq_Box_otbn_op_BN_basic_shift_1 = h0;
      coq_Box_otbn_op_BN_basic_shift_2 = h1 } x2
  | BN_ADDI h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_ADDI h)) h x2
  | BN_SUBI h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_SUBI h)) h x2
  | BN_SEL h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_SEL h)) h x2
  | BN_ADDV (h, h0) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_ADDV (h, h0))) { coq_Box_otbn_op_BN_ADDV_0 = h;
      coq_Box_otbn_op_BN_ADDV_1 = h0 } x2
  | BN_SUBV (h, h0) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_SUBV (h, h0))) { coq_Box_otbn_op_BN_ADDV_0 = h;
      coq_Box_otbn_op_BN_ADDV_1 = h0 } x2
  | BN_SHV (h, h0) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_SHV (h, h0))) { coq_Box_otbn_op_BN_SHV_0 = h;
      coq_Box_otbn_op_BN_SHV_1 = h0 } x2
  | BN_TRN (h, h0) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_TRN (h, h0))) { coq_Box_otbn_op_BN_TRN_0 = h;
      coq_Box_otbn_op_BN_TRN_1 = h0 } x2
  | BN_MULQACC_WO h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_MULQACC_WO h)) h x2
  | BN_MULQACC_WO_Z h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_MULQACC_WO_Z h)) h x2
  | BN_MULQACC_SO (h, h0) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_MULQACC_SO (h, h0)))
      { coq_Box_otbn_op_BN_MULQACC_SO_0 = h;
      coq_Box_otbn_op_BN_MULQACC_SO_1 = h0 } x2
  | BN_MULQACC_SO_Z (h, h0) ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_MULQACC_SO_Z (h, h0)))
      { coq_Box_otbn_op_BN_MULQACC_SO_0 = h;
      coq_Box_otbn_op_BN_MULQACC_SO_1 = h0 } x2
  | BN_LID h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_LID h)) h x2
  | BN_SID h ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true))
      (otbn_op_tag (BN_SID h)) h x2
  | x ->
    eqb_body otbn_op_tag otbn_op_fields
      (Obj.magic otbn_op_eqb_fields (fun _ _ -> true)) (otbn_op_tag x)
      Box_otbn_op_BN_MOV x2

(** val otbn_op_eqb_OK : otbn_op -> otbn_op -> reflect **)

let otbn_op_eqb_OK =
  iffP2 otbn_op_eqb

(** val otbn_op_eqb_OK_sumbool : otbn_op -> otbn_op -> bool **)

let otbn_op_eqb_OK_sumbool =
  reflect_dec otbn_op_eqb otbn_op_eqb_OK

(** val eqTC_otbn_op : otbn_op eqTypeC **)

let eqTC_otbn_op =
  { beq = otbn_op_eqb; ceqP = otbn_op_eqb_OK }

(** val otbn_op_eqType : Equality.coq_type **)

let otbn_op_eqType =
  ceqT_eqType eqTC_otbn_op

(** val otbn_op_to_string : otbn_op -> string **)

let otbn_op_to_string = function
| RV32 mn -> rv_mnemonic_to_string mn
| BN_basic (mn, _) -> bn_basic_mnemonic_to_string mn
| BN_basic_shift (mn, _, _) -> bn_basic_mnemonic_to_string mn
| BN_ADDI _ -> "BN.ADDI"
| BN_SUBI _ -> "BN.SUBI"
| BN_MOV -> "BN.MOV"
| BN_RSHI -> "BN.RSHI"
| BN_SEL _ -> "BN.SEL"
| BN_ADDM -> "BN.ADDM"
| BN_SUBM -> "BN.SUBM"
| BN_ADDV (vs, b) ->
  if b
  then (^) "BN.ADDVM" (vec_size_to_string vs)
  else (^) "BN.ADDV" (vec_size_to_string vs)
| BN_SUBV (vs, b) ->
  if b
  then (^) "BN.SUBVM" (vec_size_to_string vs)
  else (^) "BN.SUBV" (vec_size_to_string vs)
| BN_SHV (vs, b) ->
  (match b with
   | RS_left -> (^) "BN.SHV" ((^) (vec_size_to_string vs) ".SHL")
   | RS_right -> (^) "BN.SHV" ((^) (vec_size_to_string vs) ".SHR"))
| BN_TRN (ts, t) ->
  (match t with
   | TRNMeven -> (^) "BN.TRN1" (trn_size_to_string ts)
   | TRNModd -> (^) "BN.TRN2" (trn_size_to_string ts))
| BN_MULQACC -> "BN.MULQACC"
| BN_MULQACC_Z -> "BN.MULQACC.Z"
| BN_MULQACC_WO _ -> "BN.MULQACC.WO"
| BN_MULQACC_WO_Z _ -> "BN.MULQACC.WO.Z"
| BN_MULQACC_SO (_, _) -> "BN.MULQACC.SO"
| BN_MULQACC_SO_Z (_, _) -> "BN.MULQACC.SO.Z"
| BN_ACCR -> "BN.ACCR"
| BN_ACCW -> "BN.ACCW"
| BN_MODR -> "BN.MODR"
| BN_MODW -> "BN.MODW"
| BN_LD -> "BN.LD"
| BN_SD -> "BN.SD"
| BN_LID _ -> "BN.LID"
| BN_SID _ -> "BN.SID"

(** val ak_u2 :
    (register, empty, wide_register, rflag, condition) arg_kind **)

let ak_u2 =
  CAimm ((Some (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xO Coq_xH))))),
    U8)

(** val ak_u8 :
    (register, empty, wide_register, rflag, condition) arg_kind **)

let ak_u8 =
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xO (Coq_xO (Coq_xO
      Coq_xH))))))),
    U8)

(** val ak_u10 :
    (register, empty, wide_register, rflag, condition) arg_kind **)

let ak_u10 =
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xO (Coq_xI (Coq_xO
      Coq_xH))))))),
    U32)

(** val ak_s12 :
    (register, empty, wide_register, rflag, condition) arg_kind **)

let ak_s12 =
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Signed, (Coq_xO (Coq_xO (Coq_xI
      Coq_xH))))))),
    U32)

(** val ak_bn_shift :
    (register, empty, wide_register, rflag, condition) arg_kind **)

let ak_bn_shift =
  CAimm ((Some (Obj.magic CAimmC_otbn_bn_shift)), U8)

(** val ak_xreg :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg =
  let xreg = CAxmm :: [] in (xreg :: []) :: []

(** val ak_xreg_xreg :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_xreg =
  let xreg = CAxmm :: [] in (xreg :: (xreg :: [])) :: []

(** val ak_xreg_xreg_xreg :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_xreg_xreg =
  let xreg = CAxmm :: [] in (xreg :: (xreg :: (xreg :: []))) :: []

(** val ak_xreg_xreg_imm10 :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_xreg_imm10 =
  let xreg = CAxmm :: [] in
  let imm_u10 = ak_u10 :: [] in (xreg :: (xreg :: (imm_u10 :: []))) :: []

(** val ak_xreg_xreg_imm5 :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_xreg_imm5 =
  let xreg = CAxmm :: [] in
  let imm_u5 = (CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xI (Coq_xO Coq_xH)))))),
    U8)) :: []
  in
  (xreg :: (xreg :: (imm_u5 :: []))) :: []

(** val ak_xreg_xreg_xreg_bool :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_xreg_xreg_bool =
  let xreg = CAxmm :: [] in
  (xreg :: (xreg :: (xreg :: ((CAcond :: []) :: [])))) :: []

(** val ak_xreg_xreg_xreg_shift :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_xreg_xreg_shift =
  let xreg = CAxmm :: [] in
  let imm_u8 = ak_u8 :: [] in
  (xreg :: (xreg :: (xreg :: (imm_u8 :: [])))) :: []

(** val ak_xreg_q_xreg_q_shift :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_q_xreg_q_shift =
  let xreg = CAxmm :: [] in
  let imm_q = ak_u2 :: [] in
  let imm_mulqacc_shift = (CAimm ((Some
    (Obj.magic CAimmC_otbn_mulqacc_shift)), U8)) :: []
  in
  (xreg :: (imm_q :: (xreg :: (imm_q :: (imm_mulqacc_shift :: []))))) :: []

(** val ak_xreg_xreg_q_xreg_q_shift :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_xreg_q_xreg_q_shift =
  let xreg = CAxmm :: [] in
  let imm_q = ak_u2 :: [] in
  let imm_mulqacc_shift = (CAimm ((Some
    (Obj.magic CAimmC_otbn_mulqacc_shift)), U8)) :: []
  in
  (xreg :: (xreg :: (imm_q :: (xreg :: (imm_q :: (imm_mulqacc_shift :: [])))))) :: []

(** val ak_xreg_mem :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_mem =
  let xreg = CAxmm :: [] in (xreg :: (((CAmem false) :: []) :: [])) :: []

(** val ak_xreg_reg_mem :
    (register, empty, wide_register, rflag, condition) i_args_kinds **)

let ak_xreg_reg_mem =
  let xreg = CAxmm :: [] in
  (xreg :: ((CAreg :: []) :: (((CAmem false) :: []) :: []))) :: []

(** val pp_otbn_op :
    otbn_op -> (register, empty, wide_register, rflag, condition) asm_arg
    list -> (register, empty, wide_register, rflag, condition) pp_asm_op **)

let pp_otbn_op =
  let mk = fun name args -> { pp_aop_name = name; pp_aop_ext = PP_name;
    pp_aop_args = (map (fun a -> (otbn_decl.reg_size, a)) args) }
  in
  let wsr_code_MOD = Imm (U8, (wrepr U8 Z0)) in
  let wsr_code_ACC = Imm (U8, (wrepr U8 (Zpos (Coq_xI Coq_xH)))) in
  (fun op args ->
  match op with
  | BN_SHV (vs, _) -> mk ((^) "BN.SHV" (vec_size_to_string vs)) args
  | BN_ACCR -> mk "bn.wsrr" (rcons args wsr_code_ACC)
  | BN_ACCW -> mk "bn.wsrw" (wsr_code_ACC :: args)
  | BN_MODR -> mk "bn.wsrr" (rcons args wsr_code_MOD)
  | BN_MODW -> mk "bn.wsrw" (wsr_code_MOD :: args)
  | BN_LID _ -> mk "BN.LID" args
  | BN_SID _ -> mk "BN.SID" args
  | _ -> mk (otbn_op_to_string op) args)

(** val acc_mod : wide_register list **)

let acc_mod =
  ACC :: (MOD :: [])

(** val coq_EXa :
    nat -> (register, empty, wide_register, rflag, condition)
    Arch_decl.arg_desc **)

let coq_EXa n =
  Arch_decl.ADExplicit ((AK_mem Aligned), n, (ACR_avoid_xreg acc_mod))

(** val coq_EXc :
    nat -> (register, empty, wide_register, rflag, condition)
    Arch_decl.arg_desc **)

let coq_EXc n =
  Arch_decl.ADExplicit (AK_compute, n, (ACR_avoid_xreg acc_mod))

(** val rv_last_ak :
    rv_mnemonic -> (register, empty, wide_register, rflag, condition) arg_kind **)

let rv_last_ak = function
| ADDI -> ak_s12
| ANDI -> ak_s12
| ORI -> ak_s12
| XORI -> ak_s12
| SLLI ->
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xI (Coq_xO Coq_xH)))))), U8)
| SRLI ->
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xI (Coq_xO Coq_xH)))))), U8)
| SRAI ->
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xI (Coq_xO Coq_xH)))))), U8)
| LUI ->
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Unsigned, (Coq_xO (Coq_xO (Coq_xI (Coq_xO
      Coq_xH)))))))),
    U32)
| LW -> CAmem false
| SW -> CAmem false
| LI ->
  CAimm ((Some
    (Obj.magic (CAimmC_otbn_nbits (Signed, (Coq_xO (Coq_xO (Coq_xO (Coq_xO
      (Coq_xO Coq_xH))))))))),
    U32)
| LA -> CAmem true
| _ -> CAreg

(** val _desc_rv_unop :
    wsize -> rv_mnemonic -> (register, empty, wide_register, rflag,
    condition) Arch_decl.arg_desc -> (register, empty, wide_register, rflag,
    condition) Arch_decl.arg_desc -> (word -> word) -> (register, empty,
    wide_register, rflag, condition) instr_desc_t **)

let _desc_rv_unop ws mn =
  let ak_unary = fun ak -> ((CAreg :: []) :: ((ak :: []) :: [])) :: [] in
  let pp_rv_op = fun mn0 args -> pp_otbn_op (RV32 mn0) args in
  (fun ad_in ad_out semi -> { id_valid =
  (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
    (Obj.magic U32));
  id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword ws) :: []); id_in =
  (ad_in :: []); id_tout = ((Coq_lword ws) :: []); id_out = (ad_out :: []);
  id_semi = (Obj.magic (fun x -> Ok (semi x))); id_args_kinds =
  (ak_unary (rv_last_ak mn)); id_nargs = (S (S O)); id_str_jas =
  (pp_s (rv_mnemonic_to_string mn)); id_safe = []; id_doit = DOIT;
  id_pp_asm = (pp_rv_op mn) })

(** val desc_rv_binop :
    wsize -> rv_mnemonic -> wsize -> (word -> word -> word) -> (register,
    empty, wide_register, rflag, condition) instr_desc_t **)

let desc_rv_binop ws mn =
  let ak_binary = fun ak ->
    ((CAreg :: []) :: ((CAreg :: []) :: ((ak :: []) :: []))) :: []
  in
  let pp_rv_op = fun mn0 args -> pp_otbn_op (RV32 mn0) args in
  (fun wsa semi -> { id_valid =
  (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
    (Obj.magic U32));
  id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword ws) :: ((Coq_lword
  wsa) :: [])); id_in =
  ((coq_Ea otbn_decl (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: []));
  id_tout = ((Coq_lword ws) :: []); id_out = ((coq_Ea otbn_decl O) :: []);
  id_semi = (Obj.magic (fun x y -> Ok (semi x y))); id_args_kinds =
  (ak_binary (rv_last_ak mn)); id_nargs = (S (S (S O))); id_str_jas =
  (pp_s (rv_mnemonic_to_string mn)); id_safe = []; id_doit = DOIT;
  id_pp_asm = (pp_rv_op mn) })

(** val desc_nop :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_nop =
  let pp_rv_op = fun mn args -> pp_otbn_op (RV32 mn) args in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = []; id_in = [];
  id_tout = []; id_out = []; id_semi = (Obj.magic (Ok ())); id_args_kinds =
  ([] :: []); id_nargs = O; id_str_jas = (pp_s (rv_mnemonic_to_string NOP));
  id_safe = []; id_doit = DOIT; id_pp_asm = (pp_rv_op NOP) }

(** val mk_shifted_sem :
    wsize -> (wsize -> word -> coq_Z -> word) -> word -> word -> word **)

let mk_shifted_sem ws f w sham =
  f ws w
    (Z.coq_land (wunsigned U8 sham) (Zpos (Coq_xI (Coq_xI (Coq_xI (Coq_xI
      Coq_xH))))))

(** val _desc_rv_mnemonic :
    wsize -> rv_mnemonic -> (register, empty, wide_register, rflag,
    condition) instr_desc_t **)

let _desc_rv_mnemonic ws mn =
  let desc_rv_unop =
    _desc_rv_unop ws mn (coq_Ea otbn_decl (S O)) (coq_Ea otbn_decl O)
  in
  (match mn with
   | ADD -> desc_rv_binop ws mn ws (wadd ws)
   | ADDI -> desc_rv_binop ws mn ws (wadd ws)
   | SUB -> desc_rv_binop ws mn ws (wsub ws)
   | AND -> desc_rv_binop ws mn ws (wand ws)
   | ANDI -> desc_rv_binop ws mn ws (wand ws)
   | OR -> desc_rv_binop ws mn ws (wor ws)
   | ORI -> desc_rv_binop ws mn ws (wor ws)
   | XOR -> desc_rv_binop ws mn ws (wxor ws)
   | XORI -> desc_rv_binop ws mn ws (wxor ws)
   | SLL -> desc_rv_binop ws mn U8 (mk_shifted_sem ws wshl)
   | SLLI -> desc_rv_binop ws mn U8 (mk_shifted_sem ws wshl)
   | SRL -> desc_rv_binop ws mn U8 (mk_shifted_sem ws wshr)
   | SRLI -> desc_rv_binop ws mn U8 (mk_shifted_sem ws wshr)
   | LUI ->
     desc_rv_unop (fun x ->
       wshl ws x (Zpos (Coq_xO (Coq_xO (Coq_xI Coq_xH)))))
   | LW ->
     _desc_rv_unop ws mn (coq_Eu otbn_decl (S O)) (coq_Eu otbn_decl O)
       (fun x -> x)
   | SW ->
     _desc_rv_unop ws mn (coq_Eu otbn_decl O) (coq_Eu otbn_decl (S O))
       (fun x -> x)
   | LI -> desc_rv_unop (fun x -> x)
   | LA ->
     _desc_rv_unop ws mn (coq_Ec otbn_decl (S O)) (coq_Ea otbn_decl O)
       (fun x -> x)
   | NOP -> desc_nop
   | _ -> desc_rv_binop ws mn U8 (mk_shifted_sem ws wsar))

(** val ty_mlz : ltype list **)

let ty_mlz =
  Coq_lbool :: (Coq_lbool :: (Coq_lbool :: []))

(** val ty_cmlz : ltype list **)

let ty_cmlz =
  Coq_lbool :: ty_mlz

(** val current_mlz : bn_flag_group -> rflag list **)

let current_mlz = function
| FG0 -> MF0 :: (LF0 :: (ZF0 :: []))
| FG1 -> MF1 :: (LF1 :: (ZF1 :: []))

(** val current_CF : bn_flag_group -> rflag **)

let current_CF = function
| FG0 -> CF0
| FG1 -> CF1

(** val current_cmlz : bn_flag_group -> rflag list **)

let current_cmlz fg =
  (current_CF fg) :: (current_mlz fg)

(** val ad_mlz :
    bn_flag_group -> (register, empty, wide_register, rflag, condition)
    Arch_decl.arg_desc list **)

let ad_mlz fg =
  map (coq_F otbn_decl) (current_mlz fg)

(** val ad_cmlz :
    bn_flag_group -> (register, empty, wide_register, rflag, condition)
    Arch_decl.arg_desc list **)

let ad_cmlz fg =
  map (coq_F otbn_decl) (current_cmlz fg)

(** val coq_CF_of_Z : coq_Z -> bool option **)

let coq_CF_of_Z z =
  Some
    (eq_op coq_BinNums_Z__canonical__eqtype_Equality
      (Obj.magic Z.coq_land
        (Z.shiftr z (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
          (Coq_xO (Coq_xO Coq_xH))))))))))
        (Zpos Coq_xH))
      (GRing.one coq_BinNums_Z__canonical__GRing_SemiRing))

(** val coq_MF_of_word : word -> bool option **)

let coq_MF_of_word res =
  Some (msb U256 res)

(** val coq_LF_of_word : word -> bool option **)

let coq_LF_of_word res =
  Some (lsb U256 res)

(** val coq_ZF_of_word : word -> bool option **)

let coq_ZF_of_word res =
  Some
    (eq_op (word_word__canonical__eqtype_Equality U256) (Obj.magic res)
      (GRing.zero (word_word__canonical__GRing_Nmodule U256)))

(** val with_mlz : word -> sem_tuple **)

let with_mlz res =
  Obj.magic ((coq_MF_of_word res), ((coq_LF_of_word res),
    ((coq_ZF_of_word res), res)))

(** val with_cmlz : word -> coq_Z -> sem_tuple **)

let with_cmlz res res_unsigned =
  add_tuple
    (map (Obj.magic __)
      (map eval_ltype (cat ty_mlz ((Coq_lword U256) :: []))))
    (coq_CF_of_Z res_unsigned) (with_mlz res)

(** val drop_c :
    (register, empty, wide_register, rflag, condition) instr_desc_t ->
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let drop_c idt =
  idt_drop1 otbn_decl idt

(** val word_shift_of_reg_shift :
    bn_register_shift -> wsize -> word -> coq_Z -> word **)

let word_shift_of_reg_shift sh ws x sham =
  match sh with
  | RS_left -> wshl ws x sham
  | RS_right -> wshr ws x sham

(** val coq_Z_shift_of_reg_shift :
    bn_register_shift -> wsize -> word -> coq_Z -> coq_Z **)

let coq_Z_shift_of_reg_shift sh ws x sham =
  match sh with
  | RS_left -> Z.shiftl (wunsigned ws x) sham
  | RS_right -> Z.shiftr (wunsigned ws x) sham

(** val semi_carry_binop_cmlz :
    (word -> word -> word) -> (coq_Z -> coq_Z -> coq_Z) -> semi_type **)

let semi_carry_binop_cmlz semi semiZ =
  Obj.magic (fun x y cf ->
    let c = Z.b2z cf in
    let res = semi (semi x y) (wrepr U256 c) in
    let res_unsigned = semiZ (semiZ (wunsigned U256 x) (wunsigned U256 y)) c
    in
    Ok (with_cmlz res res_unsigned))

(** val desc_bn_basic_unop :
    bn_basic_mnemonic -> bn_flag_group -> (word -> word) -> (coq_Z -> coq_Z)
    -> (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_bn_basic_unop =
  let pp_bn_basic_op = fun mn fg args -> pp_otbn_op (BN_basic (mn, fg)) args
  in
  let semi_unop_mlz = fun semi x -> Ok (with_mlz (semi x)) in
  (fun mn fg semi _ -> { id_valid = true; id_msb_flag = MSB_MERGE; id_tin =
  ((Coq_lword U256) :: []); id_in = ((coq_EXa (S O)) :: []); id_tout =
  (cat ty_mlz ((Coq_lword U256) :: [])); id_out =
  (cat (ad_mlz fg) ((coq_EXa O) :: [])); id_semi =
  (Obj.magic semi_unop_mlz semi); id_args_kinds = ak_xreg_xreg; id_nargs = (S
  (S O)); id_str_jas = (pp_s (bn_basic_mnemonic_to_string mn)); id_safe = [];
  id_doit = DOIT; id_pp_asm = (pp_bn_basic_op mn fg) })

(** val desc_bn_basic_binop :
    bn_basic_mnemonic -> bn_flag_group -> (word -> word -> word) -> (coq_Z ->
    coq_Z -> coq_Z) -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_bn_basic_binop =
  let pp_bn_basic_op = fun mn fg args -> pp_otbn_op (BN_basic (mn, fg)) args
  in
  let semi_binop_cmlz = fun semi semiZ x y ->
    let res_unsigned = semiZ (wunsigned U256 x) (wunsigned U256 y) in
    Ok (with_cmlz (semi x y) res_unsigned)
  in
  (fun mn fg semi semiZ -> { id_valid = true; id_msb_flag = MSB_MERGE;
  id_tin = ((Coq_lword U256) :: ((Coq_lword U256) :: [])); id_in =
  ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: [])); id_tout =
  (cat ty_cmlz ((Coq_lword U256) :: [])); id_out =
  (cat (ad_cmlz fg) ((coq_EXa O) :: [])); id_semi =
  (Obj.magic semi_binop_cmlz semi semiZ); id_args_kinds = ak_xreg_xreg_xreg;
  id_nargs = (S (S (S O))); id_str_jas =
  (pp_s (bn_basic_mnemonic_to_string mn)); id_safe = []; id_doit = DOIT;
  id_pp_asm = (pp_bn_basic_op mn fg) })

(** val desc_bn_basic_carry_binop :
    bn_basic_mnemonic -> bn_flag_group -> (word -> word -> word) -> (coq_Z ->
    coq_Z -> coq_Z) -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_bn_basic_carry_binop =
  let pp_bn_basic_op = fun mn fg args -> pp_otbn_op (BN_basic (mn, fg)) args
  in
  (fun mn fg semi semiZ -> { id_valid = true; id_msb_flag = MSB_MERGE;
  id_tin = ((Coq_lword U256) :: ((Coq_lword U256) :: (Coq_lbool :: [])));
  id_in =
  ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: ((coq_F otbn_decl
                                                 (current_CF fg)) :: [])));
  id_tout = (cat ty_cmlz ((Coq_lword U256) :: [])); id_out =
  (cat (ad_cmlz fg) ((coq_EXa O) :: [])); id_semi =
  (semi_carry_binop_cmlz semi semiZ); id_args_kinds = ak_xreg_xreg_xreg;
  id_nargs = (S (S (S O))); id_str_jas =
  (pp_s (bn_basic_mnemonic_to_string mn)); id_safe = []; id_doit = DOIT;
  id_pp_asm = (pp_bn_basic_op mn fg) })

(** val desc_BN_CMP :
    bn_flag_group -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_BN_CMP =
  let pp_bn_basic_op = fun mn fg args -> pp_otbn_op (BN_basic (mn, fg)) args
  in
  let semi_binop_cmlz = fun semi semiZ x y ->
    let res_unsigned = semiZ (wunsigned U256 x) (wunsigned U256 y) in
    Ok (with_cmlz (semi x y) res_unsigned)
  in
  (fun fg -> { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
  U256) :: ((Coq_lword U256) :: [])); id_in =
  ((coq_EXa O) :: ((coq_EXa (S O)) :: [])); id_tout = ty_cmlz; id_out =
  (ad_cmlz fg); id_semi =
  (Obj.magic (fun x y ->
    match semi_binop_cmlz (wsub U256) Z.sub x y with
    | Ok x0 ->
      let (x1, y0) = Obj.magic x0 in
      let (x2, y1) = y0 in
      let (x3, y2) = y1 in let (x4, _) = y2 in Ok (x1, (x2, (x3, x4)))
    | Error s -> Error s));
  id_args_kinds = ak_xreg_xreg; id_nargs = (S (S O)); id_str_jas =
  (pp_s (bn_basic_mnemonic_to_string BN_CMP)); id_safe = []; id_doit = DOIT;
  id_pp_asm = (pp_bn_basic_op BN_CMP fg) })

(** val desc_BN_CMPB :
    bn_flag_group -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_BN_CMPB =
  let pp_bn_basic_op = fun mn fg args -> pp_otbn_op (BN_basic (mn, fg)) args
  in
  (fun fg -> { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
  U256) :: ((Coq_lword U256) :: (Coq_lbool :: []))); id_in =
  ((coq_EXa O) :: ((coq_EXa (S O)) :: ((coq_F otbn_decl (current_CF fg)) :: [])));
  id_tout = ty_cmlz; id_out = (ad_cmlz fg); id_semi =
  (Obj.magic (fun x y cf ->
    match Obj.magic semi_carry_binop_cmlz (wsub U256) Z.sub x y cf with
    | Ok x0 ->
      let (x1, y0) = x0 in
      let (x2, y1) = y0 in
      let (x3, y2) = y1 in let (x4, _) = y2 in Ok (x1, (x2, (x3, x4)))
    | Error s -> Error s));
  id_args_kinds = ak_xreg_xreg; id_nargs = (S (S O)); id_str_jas =
  (pp_s (bn_basic_mnemonic_to_string BN_CMPB)); id_safe = []; id_doit = DOIT;
  id_pp_asm = (pp_bn_basic_op BN_CMPB fg) })

(** val desc_bn_basic_mnemonic :
    bn_basic_mnemonic -> bn_flag_group -> (register, empty, wide_register,
    rflag, condition) instr_desc_t **)

let desc_bn_basic_mnemonic mn fg =
  let desc_bin_mlz = fun semi semiZ ->
    idt_drop1 otbn_decl (desc_bn_basic_binop mn fg semi semiZ)
  in
  (match mn with
   | BN_ADD -> desc_bn_basic_binop mn fg (wadd U256) Z.add
   | BN_ADDC -> desc_bn_basic_carry_binop mn fg (wadd U256) Z.add
   | BN_SUB -> desc_bn_basic_binop mn fg (wsub U256) Z.sub
   | BN_SUBB -> desc_bn_basic_carry_binop mn fg (wsub U256) Z.sub
   | BN_AND -> desc_bin_mlz (wand U256) Z.coq_land
   | BN_OR -> desc_bin_mlz (wor U256) Z.coq_lor
   | BN_NOT -> desc_bn_basic_unop mn fg (wnot U256) Z.lnot
   | BN_XOR -> desc_bin_mlz (wxor U256) Z.coq_lxor
   | BN_CMP -> desc_BN_CMP fg
   | BN_CMPB -> desc_BN_CMPB fg)

(** val desc_bn_basic_shift_mnemonic :
    bn_basic_mnemonic -> bn_flag_group -> bn_register_shift -> (register,
    empty, wide_register, rflag, condition) instr_desc_t **)

let desc_bn_basic_shift_mnemonic mn fg sh =
  match mn with
  | BN_ADDC ->
    let d = desc_bn_basic_mnemonic BN_ADDC fg in
    arch_mk_shifted otbn_decl ak_bn_shift d
      (arch_mk_semi3_2_shifted (word_shift_of_reg_shift sh) U256 (Coq_lword
        U256) Coq_lbool d.id_semi)
  | BN_SUBB ->
    let d = desc_bn_basic_mnemonic BN_SUBB fg in
    arch_mk_shifted otbn_decl ak_bn_shift d
      (arch_mk_semi3_2_shifted (word_shift_of_reg_shift sh) U256 (Coq_lword
        U256) Coq_lbool d.id_semi)
  | BN_NOT ->
    let d = desc_bn_basic_mnemonic BN_NOT fg in
    arch_mk_shifted otbn_decl ak_bn_shift d
      (arch_mk_semi1_shifted (word_shift_of_reg_shift sh) U256 d.id_semi)
  | BN_CMPB ->
    let d = desc_bn_basic_mnemonic BN_CMPB fg in
    arch_mk_shifted otbn_decl ak_bn_shift d
      (arch_mk_semi3_2_shifted (word_shift_of_reg_shift sh) U256 (Coq_lword
        U256) Coq_lbool d.id_semi)
  | x ->
    let d = desc_bn_basic_mnemonic x fg in
    arch_mk_shifted otbn_decl ak_bn_shift d
      (arch_mk_semi2_2_shifted (word_shift_of_reg_shift sh) U256 (Coq_lword
        U256) d.id_semi)

(** val semi_modular_binop :
    wsize -> (coq_Z -> coq_Z -> coq_Z -> coq_Z) -> semi_type **)

let semi_modular_binop ws body =
  Obj.magic (fun wx wy wm -> Ok
    (wrepr ws (body (wunsigned ws wx) (wunsigned ws wy) (wunsigned ws wm))))

(** val addm_result : coq_Z -> coq_Z -> coq_Z -> coq_Z **)

let addm_result x y m =
  let res =
    GRing.add coq_BinNums_Z__canonical__GRing_Nmodule (Obj.magic x)
      (Obj.magic y)
  in
  if Z.geb (Obj.magic res) m
  then Obj.magic GRing.add coq_BinNums_Z__canonical__GRing_Nmodule res
         (GRing.opp coq_BinNums_Z__canonical__GRing_Zmodule (Obj.magic m))
  else Obj.magic res

(** val subm_result : coq_Z -> coq_Z -> coq_Z -> coq_Z **)

let subm_result x y m =
  let res =
    GRing.add coq_BinNums_Z__canonical__GRing_Nmodule (Obj.magic x)
      (GRing.opp coq_BinNums_Z__canonical__GRing_Zmodule (Obj.magic y))
  in
  if Z.ltb (Obj.magic res) Z0
  then Obj.magic GRing.add coq_BinNums_Z__canonical__GRing_Nmodule res m
  else Obj.magic res

(** val _desc_otbn_op_modular_binop :
    otbn_op -> wsize -> (coq_Z -> coq_Z -> coq_Z -> coq_Z) -> (register,
    empty, wide_register, rflag, condition) instr_desc_t **)

let _desc_otbn_op_modular_binop mn ws body =
  { id_valid =
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
      (Obj.magic U256));
    id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword ws) :: ((Coq_lword
    ws) :: ((Coq_lword ws) :: []))); id_in =
    ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: ((coq_Xreg otbn_decl MOD) :: [])));
    id_tout = ((Coq_lword ws) :: []); id_out = ((coq_EXa O) :: []); id_semi =
    (semi_modular_binop ws body); id_args_kinds = ak_xreg_xreg_xreg;
    id_nargs = (S (S (S O))); id_str_jas = (pp_s (otbn_op_to_string mn));
    id_safe = []; id_doit = DOIT; id_pp_asm = (pp_otbn_op mn) }

(** val desc_BN_ADDM :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_ADDM =
  let mn = BN_ADDM in _desc_otbn_op_modular_binop mn U256 addm_result

(** val desc_BN_SUBM :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_SUBM =
  let mn = BN_SUBM in _desc_otbn_op_modular_binop mn U256 subm_result

(** val addv_reduce : coq_Z -> coq_Z -> coq_Z **)

let addv_reduce q n =
  if Z.leb q n
  then Obj.magic GRing.add coq_BinNums_Z__canonical__GRing_Nmodule n
         (GRing.opp coq_BinNums_Z__canonical__GRing_Zmodule (Obj.magic q))
  else n

(** val subv_reduce : coq_Z -> coq_Z -> coq_Z **)

let subv_reduce q n =
  if Z.ltb n Z0
  then Obj.magic GRing.add coq_BinNums_Z__canonical__GRing_Nmodule n q
  else n

(** val vec_modulus : wsize -> word -> coq_Z **)

let vec_modulus ve m =
  wunsigned ve (zero_extend ve U256 m)

(** val vec_binop :
    wsize -> (coq_Z -> coq_Z -> coq_Z) -> word -> word -> word **)

let vec_binop ve f a b =
  lift2_vec ve (fun ai bi ->
    wrepr ve (f (wunsigned ve ai) (wunsigned ve bi))) U256 a b

(** val vec_shift : wsize -> bn_register_shift -> word -> word -> word **)

let vec_shift ve sh a wsham =
  lift1_vec ve (fun ai ->
    word_shift_of_reg_shift sh ve ai (wunsigned U8 wsham)) U256 a

(** val desc_bn_vec_binop :
    otbn_op -> wsize -> (coq_Z -> coq_Z -> coq_Z) -> (register, empty,
    wide_register, rflag, condition) instr_desc_t **)

let desc_bn_vec_binop op ve f =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: ((Coq_lword U256) :: [])); id_in =
    ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: [])); id_tout = ((Coq_lword
    U256) :: []); id_out = ((coq_EXa O) :: []); id_semi =
    (Obj.magic (fun a b -> Ok (vec_binop ve f a b))); id_args_kinds =
    ak_xreg_xreg_xreg; id_nargs = (S (S (S O))); id_str_jas =
    (pp_s (otbn_op_to_string op)); id_safe = []; id_doit = DOIT; id_pp_asm =
    (pp_otbn_op op) }

(** val desc_bn_vec_binop_mod :
    otbn_op -> wsize -> (coq_Z -> coq_Z -> coq_Z -> coq_Z) -> (register,
    empty, wide_register, rflag, condition) instr_desc_t **)

let desc_bn_vec_binop_mod op ve g =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: ((Coq_lword U256) :: ((Coq_lword U256) :: []))); id_in =
    ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: ((coq_Xreg otbn_decl MOD) :: [])));
    id_tout = ((Coq_lword U256) :: []); id_out = ((coq_EXa O) :: []);
    id_semi =
    (Obj.magic (fun a b m -> Ok (vec_binop ve (g (vec_modulus ve m)) a b)));
    id_args_kinds = ak_xreg_xreg_xreg; id_nargs = (S (S (S O))); id_str_jas =
    (pp_s (otbn_op_to_string op)); id_safe = []; id_doit = DOIT; id_pp_asm =
    (pp_otbn_op op) }

(** val desc_bn_shv :
    otbn_op -> wsize -> bn_register_shift -> (register, empty, wide_register,
    rflag, condition) instr_desc_t **)

let desc_bn_shv op ve sh =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: ((Coq_lword U8) :: [])); id_in =
    ((coq_EXa (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: [])); id_tout =
    ((Coq_lword U256) :: []); id_out = ((coq_EXa O) :: []); id_semi =
    (Obj.magic (fun a wsham -> Ok (vec_shift ve sh a wsham)));
    id_args_kinds = ak_xreg_xreg_imm5; id_nargs = (S (S (S O))); id_str_jas =
    (pp_s (otbn_op_to_string op)); id_safe = []; id_doit = DOIT; id_pp_asm =
    (pp_otbn_op op) }

(** val desc_BN_ADDV :
    vec_size -> bool -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_BN_ADDV vs modular =
  let ve = ve_of_vec_size vs in
  if modular
  then desc_bn_vec_binop_mod (BN_ADDV (vs, true)) ve (fun q x y ->
         addv_reduce q (Z.add x y))
  else desc_bn_vec_binop (BN_ADDV (vs, false)) ve Z.add

(** val desc_BN_SUBV :
    vec_size -> bool -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_BN_SUBV vs modular =
  let ve = ve_of_vec_size vs in
  if modular
  then desc_bn_vec_binop_mod (BN_SUBV (vs, true)) ve (fun q x y ->
         subv_reduce q (Z.sub x y))
  else desc_bn_vec_binop (BN_SUBV (vs, false)) ve Z.sub

(** val desc_BN_SHV :
    vec_size -> bn_register_shift -> (register, empty, wide_register, rflag,
    condition) instr_desc_t **)

let desc_BN_SHV vs sh =
  desc_bn_shv (BN_SHV (vs, sh)) (ve_of_vec_size vs) sh

(** val trn_lanes : wsize -> trn_mode -> word -> word -> word list **)

let trn_lanes ve m a b =
  let la = split_vec U256 (nat_of_wsize ve) a in
  let lb = split_vec U256 (nat_of_wsize ve) b in
  let d = wrepr ve Z0 in
  let o = match m with
          | TRNMeven -> O
          | TRNModd -> S O in
  flatten
    (map (fun j ->
      (nth d la (addn o (muln (S (S O)) j))) :: ((nth d lb
                                                   (addn o (muln (S (S O)) j))) :: []))
      (iota O (half (size la))))

(** val wtrn : wsize -> trn_mode -> word -> word -> word **)

let wtrn ve m a b =
  make_vec ve U256 (trn_lanes ve m a b)

(** val desc_bn_trn :
    otbn_op -> wsize -> trn_mode -> (register, empty, wide_register, rflag,
    condition) instr_desc_t **)

let desc_bn_trn op ve m =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: ((Coq_lword U256) :: [])); id_in =
    ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: [])); id_tout = ((Coq_lword
    U256) :: []); id_out = ((coq_EXa O) :: []); id_semi =
    (Obj.magic (fun a b -> Ok (wtrn ve m a b))); id_args_kinds =
    ak_xreg_xreg_xreg; id_nargs = (S (S (S O))); id_str_jas =
    (pp_s (otbn_op_to_string op)); id_safe = []; id_doit = DOIT; id_pp_asm =
    (pp_otbn_op op) }

(** val desc_BN_TRN :
    trn_size -> trn_mode -> (register, empty, wide_register, rflag,
    condition) instr_desc_t **)

let desc_BN_TRN ts m =
  desc_bn_trn (BN_TRN (ts, m)) (ve_of_trn_size ts) m

(** val semi_binopI_cmlz :
    (word -> word -> word) -> (coq_Z -> coq_Z -> coq_Z) -> semi_type **)

let semi_binopI_cmlz semi semiZ =
  Obj.magic (fun x y ->
    let res = semi x y in
    let res_unsigned = semiZ (wunsigned U256 x) (wunsigned U256 y) in
    Ok (with_cmlz res res_unsigned))

(** val desc_bn_binopI :
    otbn_op -> bn_flag_group -> (word -> word -> word) -> (coq_Z -> coq_Z ->
    coq_Z) -> (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_bn_binopI op fg semi semiZ =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: ((Coq_lword U256) :: [])); id_in =
    ((coq_EXa (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: [])); id_tout =
    (cat ty_cmlz ((Coq_lword U256) :: [])); id_out =
    (cat (ad_cmlz fg) ((coq_EXa O) :: [])); id_semi =
    (semi_binopI_cmlz semi semiZ); id_args_kinds = ak_xreg_xreg_imm10;
    id_nargs = (S (S (S O))); id_str_jas = (pp_s (otbn_op_to_string op));
    id_safe = []; id_doit = DOIT; id_pp_asm = (pp_otbn_op op) }

(** val desc_BN_MOV :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_MOV =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: []); id_in = ((coq_EXa (S O)) :: []); id_tout = ((Coq_lword
    U256) :: []); id_out = ((coq_EXa O) :: []); id_semi =
    (Obj.magic (fun x -> Ok x)); id_args_kinds = ak_xreg_xreg; id_nargs = (S
    (S O)); id_str_jas = (pp_s (otbn_op_to_string BN_MOV)); id_safe = [];
    id_doit = DOIT; id_pp_asm = (pp_otbn_op BN_MOV) }

(** val desc_BN_SEL :
    bn_flag_group -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_BN_SEL fg =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: ((Coq_lword U256) :: (Coq_lbool :: []))); id_in =
    ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: ((coq_Ea otbn_decl (S (S (S
                                                   O)))) :: [])));
    id_tout = ((Coq_lword U256) :: []); id_out = ((coq_EXa O) :: []);
    id_semi = (Obj.magic (fun wn wm b -> Ok (if b then wn else wm)));
    id_args_kinds = ak_xreg_xreg_xreg_bool; id_nargs = (S (S (S (S O))));
    id_str_jas = (pp_s (otbn_op_to_string (BN_SEL fg))); id_safe = [];
    id_doit = DOIT; id_pp_asm = (pp_otbn_op (BN_SEL fg)) }

(** val semi_BN_RSHI : word -> word -> word -> word exec **)

let semi_BN_RSHI x y wsham =
  let sham = wunsigned U8 wsham in
  let lo_part = wshr U256 y sham in
  let hi_part =
    wshl U256 x
      (Z.sub (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
        (Coq_xO Coq_xH))))))))) sham)
  in
  Ok (wor U256 hi_part lo_part)

(** val desc_BN_RSHI :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_RSHI =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: ((Coq_lword U256) :: ((Coq_lword U8) :: []))); id_in =
    ((coq_EXa (S O)) :: ((coq_EXa (S (S O))) :: ((coq_Ea otbn_decl (S (S (S
                                                   O)))) :: [])));
    id_tout = ((Coq_lword U256) :: []); id_out = ((coq_EXa O) :: []);
    id_semi = (Obj.magic semi_BN_RSHI); id_args_kinds =
    ak_xreg_xreg_xreg_shift; id_nargs = (S (S (S (S O)))); id_str_jas =
    (pp_s (otbn_op_to_string BN_RSHI)); id_safe = []; id_doit = DOIT;
    id_pp_asm = (pp_otbn_op BN_RSHI) }

(** val extract_subword : wsize -> word -> coq_Z -> coq_Z -> word **)

let extract_subword ws x i n =
  wand ws (wshr ws x (Z.mul i n))
    (wrepr ws (Z.sub (Z.shiftl (Zpos Coq_xH) n) (Zpos Coq_xH)))

(** val get_qword : word -> word -> word **)

let get_qword x ix =
  extract_subword U256 x (wunsigned U8 ix) (Zpos (Coq_xO (Coq_xO (Coq_xO
    (Coq_xO (Coq_xO (Coq_xO Coq_xH)))))))

(** val shift_mulqacc : word -> word -> word **)

let shift_mulqacc x wsham =
  wshl U256 x (wunsigned U8 wsham)

(** val mulqacc : word -> word -> word -> word -> word -> word -> word **)

let mulqacc x ix y iy acc sham =
  let x_sub = get_qword x ix in
  let y_sub = get_qword y iy in
  let mul_res =
    shift_mulqacc
      (Obj.magic GRing.mul (word_word__canonical__GRing_SemiRing U256) x_sub
        y_sub)
      sham
  in
  Obj.magic GRing.add (word_word__canonical__GRing_Nmodule U256) acc mul_res

(** val semi_BN_MULQACC : semi_type **)

let semi_BN_MULQACC =
  Obj.magic (fun x ix y iy acc sham -> Ok (mulqacc x ix y iy acc sham))

(** val desc_BN_MULQACC :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_MULQACC =
  let base_mulqacc_tin = (Coq_lword U256) :: ((Coq_lword U8) :: ((Coq_lword
    U256) :: ((Coq_lword U8) :: ((Coq_lword U256) :: ((Coq_lword
    U8) :: [])))))
  in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = base_mulqacc_tin;
  id_in =
  ((coq_EXa O) :: ((coq_Ea otbn_decl (S O)) :: ((coq_EXa (S (S O))) :: (
  (coq_Ea otbn_decl (S (S (S O)))) :: ((coq_Xreg otbn_decl ACC) :: ((coq_Ea
                                                                    otbn_decl
                                                                    (S (S (S
                                                                    (S O))))) :: []))))));
  id_tout = ((Coq_lword U256) :: []); id_out =
  ((coq_Xreg otbn_decl ACC) :: []); id_semi = semi_BN_MULQACC;
  id_args_kinds = ak_xreg_q_xreg_q_shift; id_nargs = (S (S (S (S (S O)))));
  id_str_jas = (pp_s (otbn_op_to_string BN_MULQACC)); id_safe = []; id_doit =
  DOIT; id_pp_asm = (pp_otbn_op BN_MULQACC) }

(** val desc_BN_MULQACC_Z :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_MULQACC_Z =
  let base_mulqacc_z_tin = (Coq_lword U256) :: ((Coq_lword U8) :: ((Coq_lword
    U256) :: ((Coq_lword U8) :: ((Coq_lword U8) :: []))))
  in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = base_mulqacc_z_tin;
  id_in =
  ((coq_EXa O) :: ((coq_Ea otbn_decl (S O)) :: ((coq_EXa (S (S O))) :: (
  (coq_Ea otbn_decl (S (S (S O)))) :: ((coq_Ea otbn_decl (S (S (S (S O))))) :: [])))));
  id_tout = ((Coq_lword U256) :: []); id_out =
  ((coq_Xreg otbn_decl ACC) :: []); id_semi =
  (Obj.magic (fun x ix y iy sham ->
    Obj.magic semi_BN_MULQACC x ix y iy
      (GRing.zero (word_word__canonical__GRing_Nmodule U256)) sham));
  id_args_kinds = ak_xreg_q_xreg_q_shift; id_nargs = (S (S (S (S (S O)))));
  id_str_jas = (pp_s (otbn_op_to_string BN_MULQACC_Z)); id_safe = [];
  id_doit = DOIT; id_pp_asm = (pp_otbn_op BN_MULQACC_Z) }

(** val semi_BN_MULQACC_WO : semi_type **)

let semi_BN_MULQACC_WO =
  Obj.magic (fun x ix y iy acc sham ->
    match Obj.magic semi_BN_MULQACC x ix y iy acc sham with
    | Ok x0 ->
      Ok ((coq_MF_of_word x0), ((coq_LF_of_word x0), ((coq_ZF_of_word x0),
        (x0, x0))))
    | Error s -> Error s)

(** val desc_BN_MULQACC_WO :
    bn_flag_group -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_BN_MULQACC_WO fg =
  let base_mulqacc_tin = (Coq_lword U256) :: ((Coq_lword U8) :: ((Coq_lword
    U256) :: ((Coq_lword U8) :: ((Coq_lword U256) :: ((Coq_lword
    U8) :: [])))))
  in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = base_mulqacc_tin;
  id_in =
  ((coq_EXa (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: ((coq_EXa (S (S (S
                                                          O)))) :: ((coq_Ea
                                                                    otbn_decl
                                                                    (S (S (S
                                                                    (S O))))) :: (
  (coq_Xreg otbn_decl ACC) :: ((coq_Ea otbn_decl (S (S (S (S (S O)))))) :: []))))));
  id_tout = (cat ty_mlz ((Coq_lword U256) :: ((Coq_lword U256) :: [])));
  id_out =
  (cat (ad_mlz fg) ((coq_EXa O) :: ((coq_Xreg otbn_decl ACC) :: [])));
  id_semi = semi_BN_MULQACC_WO; id_args_kinds = ak_xreg_xreg_q_xreg_q_shift;
  id_nargs = (S (S (S (S (S (S O)))))); id_str_jas =
  (pp_s (otbn_op_to_string (BN_MULQACC_WO fg))); id_safe = []; id_doit =
  DOIT; id_pp_asm = (pp_otbn_op (BN_MULQACC_WO fg)) }

(** val desc_BN_MULQACC_WO_Z :
    bn_flag_group -> (register, empty, wide_register, rflag, condition)
    instr_desc_t **)

let desc_BN_MULQACC_WO_Z fg =
  let base_mulqacc_z_tin = (Coq_lword U256) :: ((Coq_lword U8) :: ((Coq_lword
    U256) :: ((Coq_lword U8) :: ((Coq_lword U8) :: []))))
  in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = base_mulqacc_z_tin;
  id_in =
  ((coq_EXa (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: ((coq_EXa (S (S (S
                                                          O)))) :: ((coq_Ea
                                                                    otbn_decl
                                                                    (S (S (S
                                                                    (S O))))) :: (
  (coq_Ea otbn_decl (S (S (S (S (S O)))))) :: []))))); id_tout =
  (cat ty_mlz ((Coq_lword U256) :: ((Coq_lword U256) :: []))); id_out =
  (cat (ad_mlz fg) ((coq_EXa O) :: ((coq_Xreg otbn_decl ACC) :: [])));
  id_semi =
  (Obj.magic (fun x ix y iy sham ->
    Obj.magic semi_BN_MULQACC_WO x ix y iy
      (GRing.zero (word_word__canonical__GRing_Nmodule U256)) sham));
  id_args_kinds = ak_xreg_xreg_q_xreg_q_shift; id_nargs = (S (S (S (S (S (S
  O)))))); id_str_jas = (pp_s (otbn_op_to_string (BN_MULQACC_WO_Z fg)));
  id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_otbn_op (BN_MULQACC_WO_Z fg)) }

(** val wrd_hwsel : bn_halfword_writeback -> coq_Z **)

let wrd_hwsel = function
| WB_upper -> Zpos Coq_xH
| WB_lower -> Z0

(** val mlz_of_MULQACC_SO :
    bn_halfword_writeback -> bool -> bool -> bool -> word ->
    (bool * bool) * bool **)

let mlz_of_MULQACC_SO wb mf lf zf lo_part =
  match wb with
  | WB_upper ->
    (((w2b U256
        (wand U256
          (wshr U256 lo_part (Zpos (Coq_xI (Coq_xI (Coq_xI (Coq_xI (Coq_xI
            (Coq_xI Coq_xH))))))))
          (Obj.magic GRing.one (word_word__canonical__GRing_SemiRing U256)))),
      lf),
      ((&&) zf
        (eq_op (word_word__canonical__eqtype_Equality U256)
          (Obj.magic lo_part)
          (GRing.zero (word_word__canonical__GRing_Nmodule U256)))))
  | WB_lower ->
    ((mf,
      (w2b U256
        (wand U256 lo_part
          (Obj.magic GRing.one (word_word__canonical__GRing_SemiRing U256))))),
      (eq_op (word_word__canonical__eqtype_Equality U256) (Obj.magic lo_part)
        (GRing.zero (word_word__canonical__GRing_Nmodule U256))))

(** val semi_BN_MULQACC_SO : bn_halfword_writeback -> semi_type **)

let semi_BN_MULQACC_SO wb =
  Obj.magic (fun mf lf zf r x ix y iy acc sham ->
    let base_res = mulqacc x ix y iy acc sham in
    let lo_part =
      extract_subword U256 base_res Z0 (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
        (Coq_xO (Coq_xO (Coq_xO Coq_xH))))))))
    in
    let hi_part =
      extract_subword U256 base_res (Zpos Coq_xH) (Zpos (Coq_xO (Coq_xO
        (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH))))))))
    in
    let hw_shift =
      GRing.mul coq_BinNums_Z__canonical__GRing_SemiRing
        (GRing.natmul
          (GRing.SemiRing.Exports.coq_GRing_SemiRing__to__GRing_Nmodule
            coq_BinNums_Z__canonical__GRing_SemiRing)
          (GRing.one coq_BinNums_Z__canonical__GRing_SemiRing) (S (S (S (S (S
          (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S
          (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S
          (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S
          (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S
          (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S (S
          (S (S (S (S (S (S (S (S (S (S (S (S (S
          O)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        (Obj.magic wrd_hwsel wb)
    in
    let hw_mask =
      wrepr U256
        (Z.shiftl
          (Z.sub
            (Z.shiftl (Zpos Coq_xH) (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
              (Coq_xO (Coq_xO (Coq_xO Coq_xH)))))))))
            (Zpos Coq_xH))
          (Obj.magic hw_shift))
    in
    let new_wrd =
      wor U256 (wand U256 r (wnot U256 hw_mask))
        (wshl U256 lo_part (Obj.magic hw_shift))
    in
    let mf' = Some (fst (fst (mlz_of_MULQACC_SO wb mf lf zf lo_part))) in
    let lf' = Some (snd (fst (mlz_of_MULQACC_SO wb mf lf zf lo_part))) in
    let zf' = Some (snd (mlz_of_MULQACC_SO wb mf lf zf lo_part)) in
    Ok (mf', (lf', (zf', (new_wrd, hi_part)))))

(** val desc_BN_MULQACC_SO :
    bn_flag_group -> bn_halfword_writeback -> (register, empty,
    wide_register, rflag, condition) instr_desc_t **)

let desc_BN_MULQACC_SO fg wb =
  let base_mulqacc_tin = (Coq_lword U256) :: ((Coq_lword U8) :: ((Coq_lword
    U256) :: ((Coq_lword U8) :: ((Coq_lword U256) :: ((Coq_lword
    U8) :: [])))))
  in
  let mulqacc_so_tin =
    cat ty_mlz (cat ((Coq_lword U256) :: []) base_mulqacc_tin)
  in
  let mulqacc_so_tout =
    cat ty_mlz ((Coq_lword U256) :: ((Coq_lword U256) :: []))
  in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = mulqacc_so_tin;
  id_in =
  (cat (ad_mlz fg)
    ((coq_EXa O) :: ((coq_EXa (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: (
    (coq_EXa (S (S (S O)))) :: ((coq_Ea otbn_decl (S (S (S (S O))))) :: (
    (coq_Xreg otbn_decl ACC) :: ((coq_Ea otbn_decl (S (S (S (S (S O)))))) :: []))))))));
  id_tout = mulqacc_so_tout; id_out =
  (cat (ad_mlz fg) ((coq_EXa O) :: ((coq_Xreg otbn_decl ACC) :: [])));
  id_semi = (semi_BN_MULQACC_SO wb); id_args_kinds =
  ak_xreg_xreg_q_xreg_q_shift; id_nargs = (S (S (S (S (S (S O))))));
  id_str_jas = (pp_s (otbn_op_to_string (BN_MULQACC_SO (fg, wb)))); id_safe =
  []; id_doit = DOIT; id_pp_asm = (pp_otbn_op (BN_MULQACC_SO (fg, wb))) }

(** val desc_BN_MULQACC_SO_Z :
    bn_flag_group -> bn_halfword_writeback -> (register, empty,
    wide_register, rflag, condition) instr_desc_t **)

let desc_BN_MULQACC_SO_Z fg wb =
  let base_mulqacc_z_tin = (Coq_lword U256) :: ((Coq_lword U8) :: ((Coq_lword
    U256) :: ((Coq_lword U8) :: ((Coq_lword U8) :: []))))
  in
  let mulqacc_so_tout =
    cat ty_mlz ((Coq_lword U256) :: ((Coq_lword U256) :: []))
  in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin =
  (cat ty_mlz (cat ((Coq_lword U256) :: []) base_mulqacc_z_tin)); id_in =
  (cat (ad_mlz fg)
    ((coq_EXa O) :: ((coq_EXa (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: (
    (coq_EXa (S (S (S O)))) :: ((coq_Ea otbn_decl (S (S (S (S O))))) :: (
    (coq_Ea otbn_decl (S (S (S (S (S O)))))) :: [])))))));
  id_tout = mulqacc_so_tout; id_out =
  (cat (ad_mlz fg) ((coq_EXa O) :: ((coq_Xreg otbn_decl ACC) :: [])));
  id_semi =
  (Obj.magic (fun mf lf zf r x ix y iy sham ->
    Obj.magic semi_BN_MULQACC_SO wb mf lf zf r x ix y iy
      (GRing.zero (word_word__canonical__GRing_Nmodule U256)) sham));
  id_args_kinds = ak_xreg_xreg_q_xreg_q_shift; id_nargs = (S (S (S (S (S (S
  O)))))); id_str_jas =
  (pp_s (otbn_op_to_string (BN_MULQACC_SO_Z (fg, wb)))); id_safe = [];
  id_doit = DOIT; id_pp_asm = (pp_otbn_op (BN_MULQACC_SO_Z (fg, wb))) }

(** val desc_BN_WSR :
    otbn_op -> (register, empty, wide_register, rflag, condition) xreg_t ->
    bool -> (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_WSR op xr = function
| true ->
  let ad_in = coq_Xreg otbn_decl xr in
  let ad_out = coq_EXa O in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
  U256) :: []); id_in = (ad_in :: []); id_tout = ((Coq_lword U256) :: []);
  id_out = (ad_out :: []); id_semi = (Obj.magic (fun x -> Ok x));
  id_args_kinds = ak_xreg; id_nargs = (S O); id_str_jas =
  (pp_s (otbn_op_to_string op)); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_otbn_op op) }
| false ->
  let ad_in = coq_EXa O in
  let ad_out = coq_Xreg otbn_decl xr in
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
  U256) :: []); id_in = (ad_in :: []); id_tout = ((Coq_lword U256) :: []);
  id_out = (ad_out :: []); id_semi = (Obj.magic (fun x -> Ok x));
  id_args_kinds = ak_xreg; id_nargs = (S O); id_str_jas =
  (pp_s (otbn_op_to_string op)); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_otbn_op op) }

(** val desc_BN_LD :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_LD =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: []); id_in = ((coq_Ea otbn_decl (S O)) :: []); id_tout =
    ((Coq_lword U256) :: []); id_out = ((coq_Ea otbn_decl O) :: []);
    id_semi = (Obj.magic (fun x -> Ok x)); id_args_kinds = ak_xreg_mem;
    id_nargs = (S (S O)); id_str_jas = (pp_s (otbn_op_to_string BN_LD));
    id_safe = []; id_doit = DOIT; id_pp_asm = (pp_otbn_op BN_LD) }

(** val desc_BN_SD :
    (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_SD =
  { id_valid = true; id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword
    U256) :: []); id_in = ((coq_Ea otbn_decl O) :: []); id_tout = ((Coq_lword
    U256) :: []); id_out = ((coq_Ea otbn_decl (S O)) :: []); id_semi =
    (Obj.magic (fun x -> Ok x)); id_args_kinds = ak_xreg_mem; id_nargs = (S
    (S O)); id_str_jas = (pp_s (otbn_op_to_string BN_SD)); id_safe = [];
    id_doit = DOIT; id_pp_asm = (pp_otbn_op BN_SD) }

(** val coq_BN_LID_semi : nat -> word -> word -> word exec **)

let coq_BN_LID_semi i w x =
  if eq_op coq_BinNums_Z__canonical__eqtype_Equality
       (Obj.magic wunsigned U32 w) (Obj.magic Z.of_nat i)
  then Ok x
  else let s = ErrSemUndef in Error s

(** val desc_BN_LID :
    nat -> (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_LID i =
  let wi = index_to_wreg i in
  let str = (^) "BN_LID_w" (wide_reg_index_string i) in
  { id_valid =
  (Z.ltb (Z.of_nat i) (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
    Coq_xH)))))));
  id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword U32) :: ((Coq_lword
  U256) :: [])); id_in =
  ((coq_Ea otbn_decl (S O)) :: ((coq_Ea otbn_decl (S (S O))) :: []));
  id_tout = ((Coq_lword U256) :: []); id_out = ((Arch_decl.ADExplicit
  ((AK_mem Aligned), O, (ACR_vector wi))) :: []); id_semi =
  (Obj.magic coq_BN_LID_semi i); id_args_kinds = ak_xreg_reg_mem; id_nargs =
  (S (S (S O))); id_str_jas = (fun _ -> str); id_safe = ((UGe (U32,
  (Z.of_nat i), O)) :: ((ULt (U32, O,
  (Z.add (Z.of_nat i) (Zpos Coq_xH)))) :: [])); id_doit = DOIT; id_pp_asm =
  (pp_otbn_op (BN_LID i)) }

(** val coq_BN_SID_semi : nat -> word -> word -> word exec **)

let coq_BN_SID_semi i x w =
  if eq_op coq_BinNums_Z__canonical__eqtype_Equality
       (Obj.magic wunsigned U32 w) (Obj.magic Z.of_nat i)
  then Ok x
  else let s = ErrSemUndef in Error s

(** val desc_BN_SID :
    nat -> (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_BN_SID i =
  let wi = index_to_wreg i in
  let str = (^) "BN_SID_w" (wide_reg_index_string i) in
  { id_valid =
  (Z.ltb (Z.of_nat i) (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
    Coq_xH)))))));
  id_msb_flag = MSB_MERGE; id_tin = ((Coq_lword U256) :: ((Coq_lword
  U32) :: [])); id_in = ((Arch_decl.ADExplicit ((AK_mem Aligned), O,
  (ACR_vector wi))) :: ((coq_Ea otbn_decl (S O)) :: [])); id_tout =
  ((Coq_lword U256) :: []); id_out = ((coq_Ea otbn_decl (S (S O))) :: []);
  id_semi = (Obj.magic coq_BN_SID_semi i); id_args_kinds = ak_xreg_reg_mem;
  id_nargs = (S (S (S O))); id_str_jas = (fun _ -> str); id_safe = ((UGe
  (U32, (Z.of_nat i), (S O))) :: ((ULt (U32, (S O),
  (Z.add (Z.of_nat i) (Zpos Coq_xH)))) :: [])); id_doit = DOIT; id_pp_asm =
  (pp_otbn_op (BN_SID i)) }

(** val desc_otbn_op :
    otbn_op -> (register, empty, wide_register, rflag, condition) instr_desc_t **)

let desc_otbn_op op = match op with
| RV32 mn -> _desc_rv_mnemonic otbn_decl.reg_size mn
| BN_basic (mn, fg) -> desc_bn_basic_mnemonic mn fg
| BN_basic_shift (mn, fg, sh) -> desc_bn_basic_shift_mnemonic mn fg sh
| BN_ADDI fg -> desc_bn_binopI op fg (wadd U256) Z.add
| BN_SUBI fg -> desc_bn_binopI op fg (wsub U256) Z.sub
| BN_MOV -> desc_BN_MOV
| BN_RSHI -> desc_BN_RSHI
| BN_SEL fg -> desc_BN_SEL fg
| BN_ADDM -> desc_BN_ADDM
| BN_SUBM -> desc_BN_SUBM
| BN_ADDV (vs, modular) -> desc_BN_ADDV vs modular
| BN_SUBV (vs, modular) -> desc_BN_SUBV vs modular
| BN_SHV (vs, sh) -> desc_BN_SHV vs sh
| BN_TRN (ts, m) -> desc_BN_TRN ts m
| BN_MULQACC -> desc_BN_MULQACC
| BN_MULQACC_Z -> desc_BN_MULQACC_Z
| BN_MULQACC_WO fg -> desc_BN_MULQACC_WO fg
| BN_MULQACC_WO_Z fg -> desc_BN_MULQACC_WO_Z fg
| BN_MULQACC_SO (fg, wb) -> desc_BN_MULQACC_SO fg wb
| BN_MULQACC_SO_Z (fg, wb) -> desc_BN_MULQACC_SO_Z fg wb
| BN_ACCR -> desc_BN_WSR BN_ACCR ACC true
| BN_ACCW -> desc_BN_WSR BN_ACCW ACC false
| BN_MODR -> desc_BN_WSR BN_MODR MOD true
| BN_MODW -> desc_BN_WSR BN_MODW MOD false
| BN_LD -> desc_BN_LD
| BN_SD -> desc_BN_SD
| BN_LID i -> desc_BN_LID i
| BN_SID i -> desc_BN_SID i

(** val otbn_prim_string : (string * otbn_op prim_constructor) list **)

let otbn_prim_string =
  ("ADD", (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 ADD)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("ADDI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 ADDI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SUB",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SUB)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("AND",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 AND)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("ANDI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 ANDI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("OR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 OR)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("ORI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 ORI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("XOR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 XOR)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("XORI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 XORI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SLL",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SLL)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SLLI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SLLI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SRL",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SRL)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SRLI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SRLI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SRA",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SRA)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SRAI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SRAI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("LUI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 LUI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("LW",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 LW)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("SW",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 SW)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("LI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 LI)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("NOP",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (RV32 NOP)
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ADD",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_ADD, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_ADD, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_ADDC",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_ADDC, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_ADDC, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_SUB",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_SUB, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_SUB, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_SUBB",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_SUBB, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_SUBB, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_AND",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_AND, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_AND, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_OR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_OR, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_OR, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_NOT",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_NOT, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_NOT, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_XOR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_XOR, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_XOR, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_CMP",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_CMP, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_CMP, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_CMPB",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_basic (BN_CMPB, x0))
    | PrimOTBNfg x0 -> Ok (BN_basic (BN_CMPB, x0))
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_ADDI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_ADDI x0)
    | PrimOTBNfg x0 -> Ok (BN_ADDI x0)
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_SUBI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_SUBI x0)
    | PrimOTBNfg x0 -> Ok (BN_SUBI x0)
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_SEL",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_SEL x0)
    | PrimOTBNfg x0 -> Ok (BN_SEL x0)
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_MOV",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_MOV
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_RSHI",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_RSHI
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ADDM",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_ADDM
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SUBM",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_SUBM
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ACCR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_ACCR
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ACCW",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_ACCW
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_MODR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_MODR
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_MODW",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_MODW
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_LD",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_LD
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SD",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_SD
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ADDV_8S",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_ADDV (V8S, false))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ADDV_16H",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_ADDV (V16H, false))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ADDVM_8S",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_ADDV (V8S, true))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_ADDVM_16H",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_ADDV (V16H, true))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SUBV_8S",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SUBV (V8S, false))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SUBV_16H",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SUBV (V16H, false))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SUBVM_8S",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SUBV (V8S, true))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SUBVM_16H",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SUBV (V16H, true))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SHV_8S_SHL",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SHV (V8S, RS_left))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SHV_8S_SHR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SHV (V8S, RS_right))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SHV_16H_SHL",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SHV (V16H, RS_left))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_SHV_16H_SHR",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_SHV (V16H, RS_right))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN1_16H",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T16H, TRNMeven))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN1_8S",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T8S, TRNMeven))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN1_4D",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T4D, TRNMeven))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN1_2Q",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T2Q, TRNMeven))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN2_16H",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T16H, TRNModd))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN2_8S",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T8S, TRNModd))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN2_4D",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T4D, TRNModd))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_TRN2_2Q",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok (BN_TRN (T2Q, TRNModd))
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_MULQACC",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_MULQACC
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_MULQACC_Z",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> Ok BN_MULQACC_Z
    | _ -> Error "invalid OTBN suffix, expected no suffix"))) :: (("BN_MULQACC_WO",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_MULQACC_WO x0)
    | PrimOTBNfg x0 -> Ok (BN_MULQACC_WO x0)
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_MULQACC_WO_Z",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNnone -> let x0 = FG0 in Ok (BN_MULQACC_WO_Z x0)
    | PrimOTBNfg x0 -> Ok (BN_MULQACC_WO_Z x0)
    | _ -> Error "invalid OTBN suffix, expected only an optional flag group"))) :: (("BN_MULQACC_SO",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNwb (x0, x1) ->
      let x2 = ((match x0 with
                 | Some x2 -> x2
                 | None -> FG0), x1) in
      let (x3, x4) = x2 in Ok (BN_MULQACC_SO (x3, x4))
    | _ ->
      Error
        "invalid OTBN suffix, expected a writeback and an optional flag group"))) :: (("BN_MULQACC_SO_Z",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNwb (x0, x1) ->
      let x2 = ((match x0 with
                 | Some x2 -> x2
                 | None -> FG0), x1) in
      let (x3, x4) = x2 in Ok (BN_MULQACC_SO_Z (x3, x4))
    | _ ->
      Error
        "invalid OTBN suffix, expected a writeback and an optional flag group"))) :: (("BN_LID",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNwreg x0 -> Ok (BN_LID x0)
    | _ ->
      Error "invalid OTBN suffix, expected a wide register index (e.g. _w5)"))) :: (("BN_SID",
    (PrimOTBN (fun x ->
    match x with
    | PrimOTBNwreg x0 -> Ok (BN_SID x0)
    | _ ->
      Error "invalid OTBN suffix, expected a wide register index (e.g. _w5)"))) :: []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

(** val otbn_op_decl :
    (register, empty, wide_register, rflag, condition, otbn_op) asm_op_decl **)

let otbn_op_decl =
  { Arch_decl._eqT = eqTC_otbn_op; instr_desc_op = desc_otbn_op;
    Arch_decl.prim_string = otbn_prim_string }

type otbn_prog =
  (register, empty, wide_register, rflag, condition, otbn_op) asm_prog
