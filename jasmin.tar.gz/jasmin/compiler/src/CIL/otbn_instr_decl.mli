(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Memory_model
open Otbn_decl
open Otbn_options
open Param1
open Param1_trivial
open Sem_type
open Seq
open Sopn
open Ssralg
open Ssrfun
open Ssrnat
open Std
open Strings
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t

module E :
 sig
  val no_semantics : error
 end

val replace_dot : string -> string

val is_prim_otbn_none : prim_otbn_suffix -> bool

val is_prim_otbn_suff_ws : prim_otbn_suffix -> wsize option

val is_prim_otbn_suff_fg : prim_otbn_suffix -> bn_flag_group option

val is_prim_otbn_suff_wb :
  prim_otbn_suffix -> (bn_flag_group * bn_halfword_writeback) option

val prim_otbn_none : 'a1 -> 'a1 prim_constructor

val prim_otbn_ws : (wsize -> 'a1) -> 'a1 prim_constructor

val prim_otbn_fg : (bn_flag_group -> 'a1) -> 'a1 prim_constructor

val prim_otbn_mulqacc_so :
  (bn_flag_group -> bn_halfword_writeback -> 'a1) -> 'a1 prim_constructor

val is_prim_otbn_suff_wreg : prim_otbn_suffix -> ordinal option

val prim_otbn_wreg : (ordinal -> 'a1) -> 'a1 prim_constructor

type rv_mnemonic =
| ADD
| ADDI
| SUB
| AND
| ANDI
| OR
| ORI
| XOR
| XORI
| SLL
| SLLI
| SRL
| SRLI
| SRA
| SRAI
| LUI
| LW
| SW
| LI
| LA
| NOP
| NEG

val rv_mnemonic_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> rv_mnemonic -> 'a1

val rv_mnemonic_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> rv_mnemonic -> 'a1

type is_rv_mnemonic =
| Coq_is_ADD
| Coq_is_ADDI
| Coq_is_SUB
| Coq_is_AND
| Coq_is_ANDI
| Coq_is_OR
| Coq_is_ORI
| Coq_is_XOR
| Coq_is_XORI
| Coq_is_SLL
| Coq_is_SLLI
| Coq_is_SRL
| Coq_is_SRLI
| Coq_is_SRA
| Coq_is_SRAI
| Coq_is_LUI
| Coq_is_LW
| Coq_is_SW
| Coq_is_LI
| Coq_is_LA
| Coq_is_NOP
| Coq_is_NEG

val is_rv_mnemonic_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> rv_mnemonic -> is_rv_mnemonic -> 'a1

val is_rv_mnemonic_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> rv_mnemonic -> is_rv_mnemonic -> 'a1

val rv_mnemonic_tag : rv_mnemonic -> positive

val is_rv_mnemonic_inhab : rv_mnemonic -> is_rv_mnemonic

val is_rv_mnemonic_functor : rv_mnemonic -> is_rv_mnemonic -> is_rv_mnemonic

type box_rv_mnemonic_ADD =
| Box_rv_mnemonic_ADD

type rv_mnemonic_fields_t = __

val rv_mnemonic_fields : rv_mnemonic -> rv_mnemonic_fields_t

val rv_mnemonic_construct :
  positive -> rv_mnemonic_fields_t -> rv_mnemonic option

val rv_mnemonic_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> rv_mnemonic -> is_rv_mnemonic -> 'a1

val rv_mnemonic_eqb_fields :
  (rv_mnemonic -> rv_mnemonic -> bool) -> positive -> rv_mnemonic_fields_t ->
  rv_mnemonic_fields_t -> bool

val rv_mnemonic_eqb : rv_mnemonic -> rv_mnemonic -> bool

val rv_mnemonic_eqb_OK : rv_mnemonic -> rv_mnemonic -> reflect

val rv_mnemonic_eqb_OK_sumbool : rv_mnemonic -> rv_mnemonic -> bool

val eqTC_rv_mnemonic : rv_mnemonic eqTypeC

val rv_mnemonic_eqType : Equality.coq_type

val rv_mnemonics : rv_mnemonic list

val finTC_rv_mnemonic : rv_mnemonic finTypeC

val rv_mnemonic_to_string : rv_mnemonic -> string

type bn_basic_mnemonic =
| BN_ADD
| BN_ADDC
| BN_SUB
| BN_SUBB
| BN_AND
| BN_OR
| BN_NOT
| BN_XOR
| BN_CMP
| BN_CMPB

val bn_basic_mnemonic_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  bn_basic_mnemonic -> 'a1

val bn_basic_mnemonic_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  bn_basic_mnemonic -> 'a1

type is_bn_basic_mnemonic =
| Coq_is_BN_ADD
| Coq_is_BN_ADDC
| Coq_is_BN_SUB
| Coq_is_BN_SUBB
| Coq_is_BN_AND
| Coq_is_BN_OR
| Coq_is_BN_NOT
| Coq_is_BN_XOR
| Coq_is_BN_CMP
| Coq_is_BN_CMPB

val is_bn_basic_mnemonic_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  bn_basic_mnemonic -> is_bn_basic_mnemonic -> 'a1

val is_bn_basic_mnemonic_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  bn_basic_mnemonic -> is_bn_basic_mnemonic -> 'a1

val bn_basic_mnemonic_tag : bn_basic_mnemonic -> positive

val is_bn_basic_mnemonic_inhab : bn_basic_mnemonic -> is_bn_basic_mnemonic

val is_bn_basic_mnemonic_functor :
  bn_basic_mnemonic -> is_bn_basic_mnemonic -> is_bn_basic_mnemonic

type box_bn_basic_mnemonic_BN_ADD =
| Box_bn_basic_mnemonic_BN_ADD

type bn_basic_mnemonic_fields_t = __

val bn_basic_mnemonic_fields : bn_basic_mnemonic -> bn_basic_mnemonic_fields_t

val bn_basic_mnemonic_construct :
  positive -> bn_basic_mnemonic_fields_t -> bn_basic_mnemonic option

val bn_basic_mnemonic_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  bn_basic_mnemonic -> is_bn_basic_mnemonic -> 'a1

val bn_basic_mnemonic_eqb_fields :
  (bn_basic_mnemonic -> bn_basic_mnemonic -> bool) -> positive ->
  bn_basic_mnemonic_fields_t -> bn_basic_mnemonic_fields_t -> bool

val bn_basic_mnemonic_eqb : bn_basic_mnemonic -> bn_basic_mnemonic -> bool

val bn_basic_mnemonic_eqb_OK :
  bn_basic_mnemonic -> bn_basic_mnemonic -> reflect

val bn_basic_mnemonic_eqb_OK_sumbool :
  bn_basic_mnemonic -> bn_basic_mnemonic -> bool

val eqTC_bn_basic_mnemonic : bn_basic_mnemonic eqTypeC

val bn_basic_mnemonic_eqType : Equality.coq_type

val bn_basic_mnemonics : bn_basic_mnemonic list

val finTC_bn_basic_mnemonic : bn_basic_mnemonic finTypeC

val bn_basic_mnemonic_to_string : bn_basic_mnemonic -> string

type vec_size =
| V8S
| V16H

val vec_size_rect : 'a1 -> 'a1 -> vec_size -> 'a1

val vec_size_rec : 'a1 -> 'a1 -> vec_size -> 'a1

type is_vec_size =
| Coq_is_V8S
| Coq_is_V16H

val is_vec_size_rect : 'a1 -> 'a1 -> vec_size -> is_vec_size -> 'a1

val is_vec_size_rec : 'a1 -> 'a1 -> vec_size -> is_vec_size -> 'a1

val vec_size_tag : vec_size -> positive

val is_vec_size_inhab : vec_size -> is_vec_size

val is_vec_size_functor : vec_size -> is_vec_size -> is_vec_size

type box_vec_size_V8S =
| Box_vec_size_V8S

type vec_size_fields_t = __

val vec_size_fields : vec_size -> vec_size_fields_t

val vec_size_construct : positive -> vec_size_fields_t -> vec_size option

val vec_size_induction : 'a1 -> 'a1 -> vec_size -> is_vec_size -> 'a1

val vec_size_eqb_fields :
  (vec_size -> vec_size -> bool) -> positive -> vec_size_fields_t ->
  vec_size_fields_t -> bool

val vec_size_eqb : vec_size -> vec_size -> bool

val vec_size_eqb_OK : vec_size -> vec_size -> reflect

val vec_size_eqb_OK_sumbool : vec_size -> vec_size -> bool

val eqTC_vec_size : vec_size eqTypeC

val vec_size_eqType : Equality.coq_type

val ve_of_vec_size : vec_size -> wsize

val vec_size_to_string : vec_size -> string

type trn_size =
| T16H
| T8S
| T4D
| T2Q

val trn_size_rect : 'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> 'a1

val trn_size_rec : 'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> 'a1

type is_trn_size =
| Coq_is_T16H
| Coq_is_T8S
| Coq_is_T4D
| Coq_is_T2Q

val is_trn_size_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> is_trn_size -> 'a1

val is_trn_size_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> is_trn_size -> 'a1

val trn_size_tag : trn_size -> positive

val is_trn_size_inhab : trn_size -> is_trn_size

val is_trn_size_functor : trn_size -> is_trn_size -> is_trn_size

type box_trn_size_T16H =
| Box_trn_size_T16H

type trn_size_fields_t = __

val trn_size_fields : trn_size -> trn_size_fields_t

val trn_size_construct : positive -> trn_size_fields_t -> trn_size option

val trn_size_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> trn_size -> is_trn_size -> 'a1

val trn_size_eqb_fields :
  (trn_size -> trn_size -> bool) -> positive -> trn_size_fields_t ->
  trn_size_fields_t -> bool

val trn_size_eqb : trn_size -> trn_size -> bool

val trn_size_eqb_OK : trn_size -> trn_size -> reflect

val trn_size_eqb_OK_sumbool : trn_size -> trn_size -> bool

val eqTC_trn_size : trn_size eqTypeC

val trn_size_eqType : Equality.coq_type

val ve_of_trn_size : trn_size -> wsize

val trn_size_to_string : trn_size -> string

type trn_mode =
| TRNMeven
| TRNModd

val trn_mode_rect : 'a1 -> 'a1 -> trn_mode -> 'a1

val trn_mode_rec : 'a1 -> 'a1 -> trn_mode -> 'a1

type is_trn_mode =
| Coq_is_TRNMeven
| Coq_is_TRNModd

val is_trn_mode_rect : 'a1 -> 'a1 -> trn_mode -> is_trn_mode -> 'a1

val is_trn_mode_rec : 'a1 -> 'a1 -> trn_mode -> is_trn_mode -> 'a1

val trn_mode_tag : trn_mode -> positive

val is_trn_mode_inhab : trn_mode -> is_trn_mode

val is_trn_mode_functor : trn_mode -> is_trn_mode -> is_trn_mode

type box_trn_mode_TRNMeven =
| Box_trn_mode_TRNMeven

type trn_mode_fields_t = __

val trn_mode_fields : trn_mode -> trn_mode_fields_t

val trn_mode_construct : positive -> trn_mode_fields_t -> trn_mode option

val trn_mode_induction : 'a1 -> 'a1 -> trn_mode -> is_trn_mode -> 'a1

val trn_mode_eqb_fields :
  (trn_mode -> trn_mode -> bool) -> positive -> trn_mode_fields_t ->
  trn_mode_fields_t -> bool

val trn_mode_eqb : trn_mode -> trn_mode -> bool

val trn_mode_eqb_OK : trn_mode -> trn_mode -> reflect

val trn_mode_eqb_OK_sumbool : trn_mode -> trn_mode -> bool

val eqTC_trn_mode : trn_mode eqTypeC

val trn_mode_eqType : Equality.coq_type

val wide_reg_index_strings : string list

val wide_reg_index_string : nat -> string

val index_to_wreg : nat -> wide_register

type otbn_op =
| RV32 of rv_mnemonic
| BN_basic of bn_basic_mnemonic * bn_flag_group
| BN_basic_shift of bn_basic_mnemonic * bn_flag_group * bn_register_shift
| BN_ADDI of bn_flag_group
| BN_SUBI of bn_flag_group
| BN_MOV
| BN_RSHI
| BN_SEL of bn_flag_group
| BN_ADDM
| BN_SUBM
| BN_ADDV of vec_size * bool
| BN_SUBV of vec_size * bool
| BN_SHV of vec_size * bn_register_shift
| BN_TRN of trn_size * trn_mode
| BN_MULQACC
| BN_MULQACC_Z
| BN_MULQACC_WO of bn_flag_group
| BN_MULQACC_WO_Z of bn_flag_group
| BN_MULQACC_SO of bn_flag_group * bn_halfword_writeback
| BN_MULQACC_SO_Z of bn_flag_group * bn_halfword_writeback
| BN_ACCR
| BN_ACCW
| BN_MODR
| BN_MODW
| BN_LD
| BN_SD
| BN_LID of nat
| BN_SID of nat

val otbn_op_rect :
  (rv_mnemonic -> 'a1) -> (bn_basic_mnemonic -> bn_flag_group -> 'a1) ->
  (bn_basic_mnemonic -> bn_flag_group -> bn_register_shift -> 'a1) ->
  (bn_flag_group -> 'a1) -> (bn_flag_group -> 'a1) -> 'a1 -> 'a1 ->
  (bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> bool -> 'a1) ->
  (vec_size -> bool -> 'a1) -> (vec_size -> bn_register_shift -> 'a1) ->
  (trn_size -> trn_mode -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group -> 'a1) ->
  (bn_flag_group -> 'a1) -> (bn_flag_group -> bn_halfword_writeback -> 'a1)
  -> (bn_flag_group -> bn_halfword_writeback -> 'a1) -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> (nat -> 'a1) -> (nat -> 'a1) -> otbn_op -> 'a1

val otbn_op_rec :
  (rv_mnemonic -> 'a1) -> (bn_basic_mnemonic -> bn_flag_group -> 'a1) ->
  (bn_basic_mnemonic -> bn_flag_group -> bn_register_shift -> 'a1) ->
  (bn_flag_group -> 'a1) -> (bn_flag_group -> 'a1) -> 'a1 -> 'a1 ->
  (bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> bool -> 'a1) ->
  (vec_size -> bool -> 'a1) -> (vec_size -> bn_register_shift -> 'a1) ->
  (trn_size -> trn_mode -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group -> 'a1) ->
  (bn_flag_group -> 'a1) -> (bn_flag_group -> bn_halfword_writeback -> 'a1)
  -> (bn_flag_group -> bn_halfword_writeback -> 'a1) -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> (nat -> 'a1) -> (nat -> 'a1) -> otbn_op -> 'a1

type is_otbn_op =
| Coq_is_RV32 of rv_mnemonic * is_rv_mnemonic
| Coq_is_BN_basic of bn_basic_mnemonic * is_bn_basic_mnemonic * bn_flag_group
   * is_bn_flag_group
| Coq_is_BN_basic_shift of bn_basic_mnemonic * is_bn_basic_mnemonic
   * bn_flag_group * is_bn_flag_group * bn_register_shift
   * is_bn_register_shift
| Coq_is_BN_ADDI of bn_flag_group * is_bn_flag_group
| Coq_is_BN_SUBI of bn_flag_group * is_bn_flag_group
| Coq_is_BN_MOV
| Coq_is_BN_RSHI
| Coq_is_BN_SEL of bn_flag_group * is_bn_flag_group
| Coq_is_BN_ADDM
| Coq_is_BN_SUBM
| Coq_is_BN_ADDV of vec_size * is_vec_size * bool * Param1.Coq_exports.is_bool
| Coq_is_BN_SUBV of vec_size * is_vec_size * bool * Param1.Coq_exports.is_bool
| Coq_is_BN_SHV of vec_size * is_vec_size * bn_register_shift
   * is_bn_register_shift
| Coq_is_BN_TRN of trn_size * is_trn_size * trn_mode * is_trn_mode
| Coq_is_BN_MULQACC
| Coq_is_BN_MULQACC_Z
| Coq_is_BN_MULQACC_WO of bn_flag_group * is_bn_flag_group
| Coq_is_BN_MULQACC_WO_Z of bn_flag_group * is_bn_flag_group
| Coq_is_BN_MULQACC_SO of bn_flag_group * is_bn_flag_group
   * bn_halfword_writeback * is_bn_halfword_writeback
| Coq_is_BN_MULQACC_SO_Z of bn_flag_group * is_bn_flag_group
   * bn_halfword_writeback * is_bn_halfword_writeback
| Coq_is_BN_ACCR
| Coq_is_BN_ACCW
| Coq_is_BN_MODR
| Coq_is_BN_MODW
| Coq_is_BN_LD
| Coq_is_BN_SD
| Coq_is_BN_LID of nat * Prelude.is_nat
| Coq_is_BN_SID of nat * Prelude.is_nat

val is_otbn_op_rect :
  (rv_mnemonic -> is_rv_mnemonic -> 'a1) -> (bn_basic_mnemonic ->
  is_bn_basic_mnemonic -> bn_flag_group -> is_bn_flag_group -> 'a1) ->
  (bn_basic_mnemonic -> is_bn_basic_mnemonic -> bn_flag_group ->
  is_bn_flag_group -> bn_register_shift -> is_bn_register_shift -> 'a1) ->
  (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> is_vec_size -> bool
  -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size -> bool
  -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
  bn_register_shift -> is_bn_register_shift -> 'a1) -> (trn_size ->
  is_trn_size -> trn_mode -> is_trn_mode -> 'a1) -> 'a1 -> 'a1 ->
  (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> (bn_flag_group -> is_bn_flag_group ->
  bn_halfword_writeback -> is_bn_halfword_writeback -> 'a1) -> (bn_flag_group
  -> is_bn_flag_group -> bn_halfword_writeback -> is_bn_halfword_writeback ->
  'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (nat -> Prelude.is_nat ->
  'a1) -> (nat -> Prelude.is_nat -> 'a1) -> otbn_op -> is_otbn_op -> 'a1

val is_otbn_op_rec :
  (rv_mnemonic -> is_rv_mnemonic -> 'a1) -> (bn_basic_mnemonic ->
  is_bn_basic_mnemonic -> bn_flag_group -> is_bn_flag_group -> 'a1) ->
  (bn_basic_mnemonic -> is_bn_basic_mnemonic -> bn_flag_group ->
  is_bn_flag_group -> bn_register_shift -> is_bn_register_shift -> 'a1) ->
  (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> is_vec_size -> bool
  -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size -> bool
  -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
  bn_register_shift -> is_bn_register_shift -> 'a1) -> (trn_size ->
  is_trn_size -> trn_mode -> is_trn_mode -> 'a1) -> 'a1 -> 'a1 ->
  (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> (bn_flag_group -> is_bn_flag_group ->
  bn_halfword_writeback -> is_bn_halfword_writeback -> 'a1) -> (bn_flag_group
  -> is_bn_flag_group -> bn_halfword_writeback -> is_bn_halfword_writeback ->
  'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (nat -> Prelude.is_nat ->
  'a1) -> (nat -> Prelude.is_nat -> 'a1) -> otbn_op -> is_otbn_op -> 'a1

val otbn_op_tag : otbn_op -> positive

val is_otbn_op_inhab : otbn_op -> is_otbn_op

val is_otbn_op_functor : otbn_op -> is_otbn_op -> is_otbn_op

type box_otbn_op_RV32 =
  rv_mnemonic
  (* singleton inductive, whose constructor was Box_otbn_op_RV32 *)

val coq_Box_otbn_op_RV32_0 : box_otbn_op_RV32 -> rv_mnemonic

type box_otbn_op_BN_basic = { coq_Box_otbn_op_BN_basic_0 : bn_basic_mnemonic;
                              coq_Box_otbn_op_BN_basic_1 : bn_flag_group }

val coq_Box_otbn_op_BN_basic_0 : box_otbn_op_BN_basic -> bn_basic_mnemonic

val coq_Box_otbn_op_BN_basic_1 : box_otbn_op_BN_basic -> bn_flag_group

type box_otbn_op_BN_basic_shift = { coq_Box_otbn_op_BN_basic_shift_0 : 
                                    bn_basic_mnemonic;
                                    coq_Box_otbn_op_BN_basic_shift_1 : 
                                    bn_flag_group;
                                    coq_Box_otbn_op_BN_basic_shift_2 : 
                                    bn_register_shift }

val coq_Box_otbn_op_BN_basic_shift_0 :
  box_otbn_op_BN_basic_shift -> bn_basic_mnemonic

val coq_Box_otbn_op_BN_basic_shift_1 :
  box_otbn_op_BN_basic_shift -> bn_flag_group

val coq_Box_otbn_op_BN_basic_shift_2 :
  box_otbn_op_BN_basic_shift -> bn_register_shift

type box_otbn_op_BN_ADDI =
  bn_flag_group
  (* singleton inductive, whose constructor was Box_otbn_op_BN_ADDI *)

val coq_Box_otbn_op_BN_ADDI_0 : box_otbn_op_BN_ADDI -> bn_flag_group

type box_otbn_op_BN_MOV =
| Box_otbn_op_BN_MOV

type box_otbn_op_BN_ADDV = { coq_Box_otbn_op_BN_ADDV_0 : vec_size;
                             coq_Box_otbn_op_BN_ADDV_1 : bool }

val coq_Box_otbn_op_BN_ADDV_0 : box_otbn_op_BN_ADDV -> vec_size

val coq_Box_otbn_op_BN_ADDV_1 : box_otbn_op_BN_ADDV -> bool

type box_otbn_op_BN_SHV = { coq_Box_otbn_op_BN_SHV_0 : vec_size;
                            coq_Box_otbn_op_BN_SHV_1 : bn_register_shift }

val coq_Box_otbn_op_BN_SHV_0 : box_otbn_op_BN_SHV -> vec_size

val coq_Box_otbn_op_BN_SHV_1 : box_otbn_op_BN_SHV -> bn_register_shift

type box_otbn_op_BN_TRN = { coq_Box_otbn_op_BN_TRN_0 : trn_size;
                            coq_Box_otbn_op_BN_TRN_1 : trn_mode }

val coq_Box_otbn_op_BN_TRN_0 : box_otbn_op_BN_TRN -> trn_size

val coq_Box_otbn_op_BN_TRN_1 : box_otbn_op_BN_TRN -> trn_mode

type box_otbn_op_BN_MULQACC_SO = { coq_Box_otbn_op_BN_MULQACC_SO_0 : 
                                   bn_flag_group;
                                   coq_Box_otbn_op_BN_MULQACC_SO_1 : 
                                   bn_halfword_writeback }

val coq_Box_otbn_op_BN_MULQACC_SO_0 :
  box_otbn_op_BN_MULQACC_SO -> bn_flag_group

val coq_Box_otbn_op_BN_MULQACC_SO_1 :
  box_otbn_op_BN_MULQACC_SO -> bn_halfword_writeback

type box_otbn_op_BN_LID =
  nat
  (* singleton inductive, whose constructor was Box_otbn_op_BN_LID *)

val coq_Box_otbn_op_BN_LID_0 : box_otbn_op_BN_LID -> nat

type otbn_op_fields_t = __

val otbn_op_fields : otbn_op -> otbn_op_fields_t

val otbn_op_construct : positive -> otbn_op_fields_t -> otbn_op option

val otbn_op_induction :
  (rv_mnemonic -> is_rv_mnemonic -> 'a1) -> (bn_basic_mnemonic ->
  is_bn_basic_mnemonic -> bn_flag_group -> is_bn_flag_group -> 'a1) ->
  (bn_basic_mnemonic -> is_bn_basic_mnemonic -> bn_flag_group ->
  is_bn_flag_group -> bn_register_shift -> is_bn_register_shift -> 'a1) ->
  (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> 'a1 -> 'a1 -> (vec_size -> is_vec_size -> bool
  -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size -> bool
  -> Param1.Coq_exports.is_bool -> 'a1) -> (vec_size -> is_vec_size ->
  bn_register_shift -> is_bn_register_shift -> 'a1) -> (trn_size ->
  is_trn_size -> trn_mode -> is_trn_mode -> 'a1) -> 'a1 -> 'a1 ->
  (bn_flag_group -> is_bn_flag_group -> 'a1) -> (bn_flag_group ->
  is_bn_flag_group -> 'a1) -> (bn_flag_group -> is_bn_flag_group ->
  bn_halfword_writeback -> is_bn_halfword_writeback -> 'a1) -> (bn_flag_group
  -> is_bn_flag_group -> bn_halfword_writeback -> is_bn_halfword_writeback ->
  'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (nat -> Prelude.is_nat ->
  'a1) -> (nat -> Prelude.is_nat -> 'a1) -> otbn_op -> is_otbn_op -> 'a1

val otbn_op_eqb_fields :
  (otbn_op -> otbn_op -> bool) -> positive -> otbn_op_fields_t ->
  otbn_op_fields_t -> bool

val otbn_op_eqb : otbn_op -> otbn_op -> bool

val otbn_op_eqb_OK : otbn_op -> otbn_op -> reflect

val otbn_op_eqb_OK_sumbool : otbn_op -> otbn_op -> bool

val eqTC_otbn_op : otbn_op eqTypeC

val otbn_op_eqType : Equality.coq_type

val otbn_op_to_string : otbn_op -> string

val ak_u2 : (register, empty, wide_register, rflag, condition) arg_kind

val ak_u8 : (register, empty, wide_register, rflag, condition) arg_kind

val ak_u10 : (register, empty, wide_register, rflag, condition) arg_kind

val ak_s12 : (register, empty, wide_register, rflag, condition) arg_kind

val ak_bn_shift : (register, empty, wide_register, rflag, condition) arg_kind

val ak_xreg : (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_xreg :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_xreg_xreg :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_xreg_imm10 :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_xreg_imm5 :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_xreg_xreg_bool :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_xreg_xreg_shift :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_q_xreg_q_shift :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_xreg_q_xreg_q_shift :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_mem :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val ak_xreg_reg_mem :
  (register, empty, wide_register, rflag, condition) i_args_kinds

val pp_otbn_op :
  otbn_op -> (register, empty, wide_register, rflag, condition) asm_arg list
  -> (register, empty, wide_register, rflag, condition) pp_asm_op

val acc_mod : wide_register list

val coq_EXa :
  nat -> (register, empty, wide_register, rflag, condition) Arch_decl.arg_desc

val coq_EXc :
  nat -> (register, empty, wide_register, rflag, condition) Arch_decl.arg_desc

val rv_last_ak :
  rv_mnemonic -> (register, empty, wide_register, rflag, condition) arg_kind

val _desc_rv_unop :
  wsize -> rv_mnemonic -> (register, empty, wide_register, rflag, condition)
  Arch_decl.arg_desc -> (register, empty, wide_register, rflag, condition)
  Arch_decl.arg_desc -> (word -> word) -> (register, empty, wide_register,
  rflag, condition) instr_desc_t

val desc_rv_binop :
  wsize -> rv_mnemonic -> wsize -> (word -> word -> word) -> (register,
  empty, wide_register, rflag, condition) instr_desc_t

val desc_nop : (register, empty, wide_register, rflag, condition) instr_desc_t

val mk_shifted_sem :
  wsize -> (wsize -> word -> coq_Z -> word) -> word -> word -> word

val _desc_rv_mnemonic :
  wsize -> rv_mnemonic -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val ty_mlz : ltype list

val ty_cmlz : ltype list

val current_mlz : bn_flag_group -> rflag list

val current_CF : bn_flag_group -> rflag

val current_cmlz : bn_flag_group -> rflag list

val ad_mlz :
  bn_flag_group -> (register, empty, wide_register, rflag, condition)
  Arch_decl.arg_desc list

val ad_cmlz :
  bn_flag_group -> (register, empty, wide_register, rflag, condition)
  Arch_decl.arg_desc list

val coq_CF_of_Z : coq_Z -> bool option

val coq_MF_of_word : word -> bool option

val coq_LF_of_word : word -> bool option

val coq_ZF_of_word : word -> bool option

val with_mlz : word -> sem_tuple

val with_cmlz : word -> coq_Z -> sem_tuple

val drop_c :
  (register, empty, wide_register, rflag, condition) instr_desc_t ->
  (register, empty, wide_register, rflag, condition) instr_desc_t

val word_shift_of_reg_shift :
  bn_register_shift -> wsize -> word -> coq_Z -> word

val coq_Z_shift_of_reg_shift :
  bn_register_shift -> wsize -> word -> coq_Z -> coq_Z

val semi_carry_binop_cmlz :
  (word -> word -> word) -> (coq_Z -> coq_Z -> coq_Z) -> semi_type

val desc_bn_basic_unop :
  bn_basic_mnemonic -> bn_flag_group -> (word -> word) -> (coq_Z -> coq_Z) ->
  (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_bn_basic_binop :
  bn_basic_mnemonic -> bn_flag_group -> (word -> word -> word) -> (coq_Z ->
  coq_Z -> coq_Z) -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val desc_bn_basic_carry_binop :
  bn_basic_mnemonic -> bn_flag_group -> (word -> word -> word) -> (coq_Z ->
  coq_Z -> coq_Z) -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val desc_BN_CMP :
  bn_flag_group -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val desc_BN_CMPB :
  bn_flag_group -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val desc_bn_basic_mnemonic :
  bn_basic_mnemonic -> bn_flag_group -> (register, empty, wide_register,
  rflag, condition) instr_desc_t

val desc_bn_basic_shift_mnemonic :
  bn_basic_mnemonic -> bn_flag_group -> bn_register_shift -> (register,
  empty, wide_register, rflag, condition) instr_desc_t

val semi_modular_binop :
  wsize -> (coq_Z -> coq_Z -> coq_Z -> coq_Z) -> semi_type

val addm_result : coq_Z -> coq_Z -> coq_Z -> coq_Z

val subm_result : coq_Z -> coq_Z -> coq_Z -> coq_Z

val _desc_otbn_op_modular_binop :
  otbn_op -> wsize -> (coq_Z -> coq_Z -> coq_Z -> coq_Z) -> (register, empty,
  wide_register, rflag, condition) instr_desc_t

val desc_BN_ADDM :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_BN_SUBM :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val addv_reduce : coq_Z -> coq_Z -> coq_Z

val subv_reduce : coq_Z -> coq_Z -> coq_Z

val vec_modulus : wsize -> word -> coq_Z

val vec_binop : wsize -> (coq_Z -> coq_Z -> coq_Z) -> word -> word -> word

val vec_shift : wsize -> bn_register_shift -> word -> word -> word

val desc_bn_vec_binop :
  otbn_op -> wsize -> (coq_Z -> coq_Z -> coq_Z) -> (register, empty,
  wide_register, rflag, condition) instr_desc_t

val desc_bn_vec_binop_mod :
  otbn_op -> wsize -> (coq_Z -> coq_Z -> coq_Z -> coq_Z) -> (register, empty,
  wide_register, rflag, condition) instr_desc_t

val desc_bn_shv :
  otbn_op -> wsize -> bn_register_shift -> (register, empty, wide_register,
  rflag, condition) instr_desc_t

val desc_BN_ADDV :
  vec_size -> bool -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val desc_BN_SUBV :
  vec_size -> bool -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val desc_BN_SHV :
  vec_size -> bn_register_shift -> (register, empty, wide_register, rflag,
  condition) instr_desc_t

val trn_lanes : wsize -> trn_mode -> word -> word -> word list

val wtrn : wsize -> trn_mode -> word -> word -> word

val desc_bn_trn :
  otbn_op -> wsize -> trn_mode -> (register, empty, wide_register, rflag,
  condition) instr_desc_t

val desc_BN_TRN :
  trn_size -> trn_mode -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val semi_binopI_cmlz :
  (word -> word -> word) -> (coq_Z -> coq_Z -> coq_Z) -> semi_type

val desc_bn_binopI :
  otbn_op -> bn_flag_group -> (word -> word -> word) -> (coq_Z -> coq_Z ->
  coq_Z) -> (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_BN_MOV :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_BN_SEL :
  bn_flag_group -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val semi_BN_RSHI : word -> word -> word -> word exec

val desc_BN_RSHI :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val extract_subword : wsize -> word -> coq_Z -> coq_Z -> word

val get_qword : word -> word -> word

val shift_mulqacc : word -> word -> word

val mulqacc : word -> word -> word -> word -> word -> word -> word

val semi_BN_MULQACC : semi_type

val desc_BN_MULQACC :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_BN_MULQACC_Z :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val semi_BN_MULQACC_WO : semi_type

val desc_BN_MULQACC_WO :
  bn_flag_group -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val desc_BN_MULQACC_WO_Z :
  bn_flag_group -> (register, empty, wide_register, rflag, condition)
  instr_desc_t

val wrd_hwsel : bn_halfword_writeback -> coq_Z

val mlz_of_MULQACC_SO :
  bn_halfword_writeback -> bool -> bool -> bool -> word ->
  (bool * bool) * bool

val semi_BN_MULQACC_SO : bn_halfword_writeback -> semi_type

val desc_BN_MULQACC_SO :
  bn_flag_group -> bn_halfword_writeback -> (register, empty, wide_register,
  rflag, condition) instr_desc_t

val desc_BN_MULQACC_SO_Z :
  bn_flag_group -> bn_halfword_writeback -> (register, empty, wide_register,
  rflag, condition) instr_desc_t

val desc_BN_WSR :
  otbn_op -> (register, empty, wide_register, rflag, condition) xreg_t ->
  bool -> (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_BN_LD :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_BN_SD :
  (register, empty, wide_register, rflag, condition) instr_desc_t

val coq_BN_LID_semi : nat -> word -> word -> word exec

val desc_BN_LID :
  nat -> (register, empty, wide_register, rflag, condition) instr_desc_t

val coq_BN_SID_semi : nat -> word -> word -> word exec

val desc_BN_SID :
  nat -> (register, empty, wide_register, rflag, condition) instr_desc_t

val desc_otbn_op :
  otbn_op -> (register, empty, wide_register, rflag, condition) instr_desc_t

val otbn_prim_string : (string * otbn_op prim_constructor) list

val otbn_op_decl :
  (register, empty, wide_register, rflag, condition, otbn_op) asm_op_decl

type otbn_prog =
  (register, empty, wide_register, rflag, condition, otbn_op) asm_prog
