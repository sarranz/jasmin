(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open PrimInt63
open Eqtype
open Gen_map
open Wsize

type __ = Obj.t

module type CORE_IDENT =
 sig
  type t

  val tag : t -> Uint63.t

  val id_name : t -> string

  val id_kind : t -> v_kind
 end

module Cident :
 CORE_IDENT

module Tident :
 sig
  type t = Cident.t

  val tag : t -> Uint63.t

  val t_eqb : t -> t -> bool

  val t_eq_axiom : t eq_axiom

  val coq_HB_unnamed_factory_1 : t Coq_hasDecEq.axioms_

  val coq_Tagged_t__canonical__eqtype_Equality : Equality.coq_type

  val t_eqType : Equality.coq_type

  val cmp : t -> t -> comparison

  module CmpT :
   sig
    val t : Equality.coq_type

    val cmp : Equality.sort -> Equality.sort -> comparison
   end

  module Mt :
   MAP

  module St :
   sig
    module Ordered :
     sig
      type t = Equality.sort

      val compare : t -> t -> comparison

      val eq_dec : t -> t -> bool
     end

    module Raw :
     sig
      type elt = Equality.sort

      type tree =
      | Leaf
      | Node of Int.Z_as_Int.t * tree * Equality.sort * tree

      val empty : tree

      val is_empty : tree -> bool

      val mem : Equality.sort -> tree -> bool

      val min_elt : tree -> elt option

      val max_elt : tree -> elt option

      val choose : tree -> elt option

      val fold : (elt -> 'a1 -> 'a1) -> tree -> 'a1 -> 'a1

      val elements_aux : Equality.sort list -> tree -> Equality.sort list

      val elements : tree -> Equality.sort list

      val rev_elements_aux : Equality.sort list -> tree -> Equality.sort list

      val rev_elements : tree -> Equality.sort list

      val cardinal : tree -> nat

      val maxdepth : tree -> nat

      val mindepth : tree -> nat

      val for_all : (elt -> bool) -> tree -> bool

      val exists_ : (elt -> bool) -> tree -> bool

      type enumeration =
      | End
      | More of elt * tree * enumeration

      val cons : tree -> enumeration -> enumeration

      val compare_more :
        Equality.sort -> (enumeration -> comparison) -> enumeration ->
        comparison

      val compare_cont :
        tree -> (enumeration -> comparison) -> enumeration -> comparison

      val compare_end : enumeration -> comparison

      val compare : tree -> tree -> comparison

      val equal : tree -> tree -> bool

      val subsetl : (tree -> bool) -> Equality.sort -> tree -> bool

      val subsetr : (tree -> bool) -> Equality.sort -> tree -> bool

      val subset : tree -> tree -> bool

      type t = tree

      val height : t -> Int.Z_as_Int.t

      val singleton : Equality.sort -> tree

      val create : t -> Equality.sort -> t -> tree

      val assert_false : t -> Equality.sort -> t -> tree

      val bal : t -> Equality.sort -> t -> tree

      val add : Equality.sort -> tree -> tree

      val join : tree -> elt -> t -> t

      val remove_min : tree -> elt -> t -> t * elt

      val merge : tree -> tree -> tree

      val remove : Equality.sort -> tree -> tree

      val concat : tree -> tree -> tree

      type triple = { t_left : t; t_in : bool; t_right : t }

      val t_left : triple -> t

      val t_in : triple -> bool

      val t_right : triple -> t

      val split : Equality.sort -> tree -> triple

      val inter : tree -> tree -> tree

      val diff : tree -> tree -> tree

      val union : tree -> tree -> tree

      val filter : (elt -> bool) -> tree -> tree

      val partition : (elt -> bool) -> t -> t * t

      val ltb_tree : Equality.sort -> tree -> bool

      val gtb_tree : Equality.sort -> tree -> bool

      val isok : tree -> bool

      module MX :
       sig
        module OrderTac :
         sig
          module OTF :
           sig
            type t = Equality.sort

            val compare : Equality.sort -> Equality.sort -> comparison

            val eq_dec : Equality.sort -> Equality.sort -> bool
           end

          module TO :
           sig
            type t = Equality.sort

            val compare : Equality.sort -> Equality.sort -> comparison

            val eq_dec : Equality.sort -> Equality.sort -> bool
           end
         end

        val eq_dec : Equality.sort -> Equality.sort -> bool

        val lt_dec : Equality.sort -> Equality.sort -> bool

        val eqb : Equality.sort -> Equality.sort -> bool
       end

      module L :
       sig
        module MO :
         sig
          module OrderTac :
           sig
            module OTF :
             sig
              type t = Equality.sort

              val compare : Equality.sort -> Equality.sort -> comparison

              val eq_dec : Equality.sort -> Equality.sort -> bool
             end

            module TO :
             sig
              type t = Equality.sort

              val compare : Equality.sort -> Equality.sort -> comparison

              val eq_dec : Equality.sort -> Equality.sort -> bool
             end
           end

          val eq_dec : Equality.sort -> Equality.sort -> bool

          val lt_dec : Equality.sort -> Equality.sort -> bool

          val eqb : Equality.sort -> Equality.sort -> bool
         end
       end

      val flatten_e : enumeration -> elt list
     end

    module E :
     sig
      type t = Equality.sort

      val compare : Equality.sort -> Equality.sort -> comparison

      val eq_dec : Equality.sort -> Equality.sort -> bool
     end

    type elt = Equality.sort

    type t_ = Raw.t
      (* singleton inductive, whose constructor was Mkt *)

    val this : t_ -> Raw.t

    type t = t_

    val mem : elt -> t -> bool

    val add : elt -> t -> t

    val remove : elt -> t -> t

    val singleton : elt -> t

    val union : t -> t -> t

    val inter : t -> t -> t

    val diff : t -> t -> t

    val equal : t -> t -> bool

    val subset : t -> t -> bool

    val empty : t

    val is_empty : t -> bool

    val elements : t -> elt list

    val choose : t -> elt option

    val fold : (elt -> 'a1 -> 'a1) -> t -> 'a1 -> 'a1

    val cardinal : t -> nat

    val filter : (elt -> bool) -> t -> t

    val for_all : (elt -> bool) -> t -> bool

    val exists_ : (elt -> bool) -> t -> bool

    val partition : (elt -> bool) -> t -> t * t

    val eq_dec : t -> t -> bool

    val compare : t -> t -> comparison

    val min_elt : t -> elt option

    val max_elt : t -> elt option
   end

  module StP :
   sig
    module MP :
     sig
      module Dec :
       sig
        module F :
         sig
          val eqb : Equality.sort -> Equality.sort -> bool
         end

        module MSetLogicalFacts :
         sig
         end

        module MSetDecideAuxiliary :
         sig
         end

        module MSetDecideTestCases :
         sig
         end
       end

      module FM :
       sig
        val eqb : Equality.sort -> Equality.sort -> bool
       end

      val coq_In_dec : St.elt -> St.t -> bool

      val of_list : St.elt list -> St.t

      val to_list : St.t -> St.elt list

      val fold_rec :
        (St.elt -> 'a1 -> 'a1) -> 'a1 -> St.t -> (St.t -> __ -> 'a2) ->
        (St.elt -> 'a1 -> St.t -> St.t -> __ -> __ -> __ -> 'a2 -> 'a2) -> 'a2

      val fold_rec_bis :
        (St.elt -> 'a1 -> 'a1) -> 'a1 -> St.t -> (St.t -> St.t -> 'a1 -> __
        -> 'a2 -> 'a2) -> 'a2 -> (St.elt -> 'a1 -> St.t -> __ -> __ -> 'a2 ->
        'a2) -> 'a2

      val fold_rec_nodep :
        (St.elt -> 'a1 -> 'a1) -> 'a1 -> St.t -> 'a2 -> (St.elt -> 'a1 -> __
        -> 'a2 -> 'a2) -> 'a2

      val fold_rec_weak :
        (St.elt -> 'a1 -> 'a1) -> 'a1 -> (St.t -> St.t -> 'a1 -> __ -> 'a2 ->
        'a2) -> 'a2 -> (St.elt -> 'a1 -> St.t -> __ -> 'a2 -> 'a2) -> St.t ->
        'a2

      val fold_rel :
        (St.elt -> 'a1 -> 'a1) -> (St.elt -> 'a2 -> 'a2) -> 'a1 -> 'a2 ->
        St.t -> 'a3 -> (St.elt -> 'a1 -> 'a2 -> __ -> 'a3 -> 'a3) -> 'a3

      val set_induction :
        (St.t -> __ -> 'a1) -> (St.t -> St.t -> 'a1 -> St.elt -> __ -> __ ->
        'a1) -> St.t -> 'a1

      val set_induction_bis :
        (St.t -> St.t -> __ -> 'a1 -> 'a1) -> 'a1 -> (St.elt -> St.t -> __ ->
        'a1 -> 'a1) -> St.t -> 'a1

      val cardinal_inv_2 : St.t -> nat -> St.elt

      val cardinal_inv_2b : St.t -> St.elt
     end

    val choose_mem_3 : St.t -> St.elt

    val set_rec :
      (St.t -> St.t -> __ -> 'a1 -> 'a1) -> (St.t -> St.elt -> __ -> 'a1 ->
      'a1) -> 'a1 -> St.t -> 'a1

    val for_all_mem_4 : (St.elt -> bool) -> St.t -> St.elt

    val exists_mem_4 : (St.elt -> bool) -> St.t -> St.elt

    val sum : (St.elt -> nat) -> St.t -> nat
   end

  module StD :
   sig
    module F :
     sig
      val eqb : Equality.sort -> Equality.sort -> bool
     end

    module MSetLogicalFacts :
     sig
     end

    module MSetDecideAuxiliary :
     sig
     end

    module MSetDecideTestCases :
     sig
     end
   end
 end

val ident_eqType : Equality.coq_type

module WrapIdent :
 sig
  type t = CoreIdent.Cident.t
 end

module type IDENT =
 sig
  type ident = WrapIdent.t

  module Mid :
   MAP
 end

module Ident :
 sig
  type ident = WrapIdent.t

  val id_name : ident -> string

  val id_kind : ident -> v_kind

  module Mid :
   sig
    module K :
     sig
      val t : Equality.coq_type

      val cmp : Equality.sort -> Equality.sort -> comparison
     end

    type 'x t = 'x Tident.Mt.t

    val empty : 'a1 t

    val is_empty : 'a1 t -> bool

    val get : 'a1 t -> Equality.sort -> 'a1 option

    val set : 'a1 t -> Equality.sort -> 'a1 -> 'a1 t

    val remove : 'a1 t -> Equality.sort -> 'a1 t

    val map : ('a1 -> 'a2) -> 'a1 t -> 'a2 t

    val mapi : (Equality.sort -> 'a1 -> 'a2) -> 'a1 t -> 'a2 t

    val map2 :
      (Equality.sort -> 'a1 option -> 'a2 option -> 'a3 option) -> 'a1 t ->
      'a2 t -> 'a3 t

    val filter_map : (Equality.sort -> 'a1 -> 'a2 option) -> 'a1 t -> 'a2 t

    val incl_def :
      (Equality.sort -> 'a1 -> bool) -> (Equality.sort -> 'a1 -> 'a2 -> bool)
      -> 'a1 t -> 'a2 t -> bool

    val incl : (Equality.sort -> 'a1 -> 'a2 -> bool) -> 'a1 t -> 'a2 t -> bool

    val all : (Equality.sort -> 'a1 -> bool) -> 'a1 t -> bool

    val has : (Equality.sort -> 'a1 -> bool) -> 'a1 t -> bool

    val elements : 'a1 t -> (Equality.sort * 'a1) list

    val fold : (Equality.sort -> 'a1 -> 'a2 -> 'a2) -> 'a1 t -> 'a2 -> 'a2

    val in_codom :
      Equality.coq_type -> Equality.sort -> Equality.sort t -> bool

    val is_emptyP : 'a1 t -> reflect

    val elementsP :
      Equality.coq_type -> (Equality.sort * Equality.sort) -> Equality.sort t
      -> reflect
   end
 end
