(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Armv8a_decl
open Armv8a_instr_decl
open Eqtype
open Expr
open Fexpr
open Seq
open Var0
open Word0
open Wsize

val is_arith_small : coq_Z -> bool

val coq_Z_mod_lnot : coq_Z -> wsize -> coq_Z

module ARMv8AFopn_core :
 sig
  type opn_args = (lexpr list * armv8a_asm_op) * rexpr list

  val mov : var_i -> var_i -> opn_args

  val add : var_i -> var_i -> var_i -> opn_args

  val sub : var_i -> var_i -> var_i -> opn_args

  val movi : var_i -> coq_Z -> opn_args

  val addi : var_i -> var_i -> coq_Z -> opn_args

  val subi : var_i -> var_i -> coq_Z -> opn_args

  val andi : var_i -> var_i -> coq_Z -> opn_args

  val movz : wsize -> var_i -> coq_Z -> coq_Z -> opn_args

  val movn : wsize -> var_i -> coq_Z -> coq_Z -> opn_args

  val movk : wsize -> var_i -> coq_Z -> coq_Z -> opn_args

  val align : var_i -> var_i -> wsize -> opn_args

  val li : wsize -> var_i -> coq_Z -> opn_args list

  val smart_mov : var_i -> var_i -> opn_args list

  val gen_smart_opi :
    (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
    opn_args) -> (coq_Z -> bool) -> coq_Z option -> var_i -> var_i -> var_i
    -> coq_Z -> opn_args list

  val smart_addi : var_i -> var_i -> coq_Z -> opn_args list

  val smart_subi : var_i -> var_i -> coq_Z -> opn_args list

  val gen_smart_opi_tmp :
    (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
    opn_args) -> var_i -> var_i -> coq_Z -> opn_args list

  val smart_addi_tmp : var_i -> var_i -> coq_Z -> opn_args list

  val smart_subi_tmp : var_i -> var_i -> coq_Z -> opn_args list
 end
