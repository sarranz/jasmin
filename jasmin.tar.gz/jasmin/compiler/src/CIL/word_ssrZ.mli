(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNat
open BinNums
open BinPos
open Datatypes
open Zpower
open Eqtype
open Ssralg
open Ssrbool
open Ssrint

val int_to_Z : int -> coq_Z

val coq_Z_to_int : coq_Z -> int

val coq_ZeqbP : coq_Z -> coq_Z -> reflect

val coq_HB_unnamed_factory_1 : coq_Z Coq_hasDecEq.axioms_

val coq_BinNums_Z__canonical__eqtype_Equality : Equality.coq_type

val coq_HB_unnamed_factory_3 : coq_Z Choice.Countable.axioms_

val coq_HB_unnamed_mixin_7 : coq_Z Choice.Coq_hasChoice.axioms_

val coq_HB_unnamed_mixin_8 : coq_Z Choice.Choice_isCountable.axioms_

val coq_BinNums_Z__canonical__choice_Countable : Choice.Countable.coq_type

val coq_HB_unnamed_factory_9 : coq_Z GRing.Coq_isZmodule.axioms_

val coq_HB_unnamed_mixin_12 : coq_Z GRing.Coq_isNmodule.axioms_

val coq_BinNums_Z__canonical__GRing_Nmodule : GRing.Nmodule.coq_type

val coq_HB_unnamed_mixin_13 : coq_Z GRing.Nmodule_isZmodule.axioms_

val coq_BinNums_Z__canonical__GRing_Zmodule : GRing.Zmodule.coq_type

val coq_HB_unnamed_factory_14 : coq_Z GRing.Zmodule_isComNzRing.axioms_

val coq_HB_unnamed_mixin_18 : coq_Z GRing.Nmodule_isPzSemiRing.axioms_

val coq_BinNums_Z__canonical__GRing_PzSemiRing : GRing.PzSemiRing.coq_type

val mod_pow2k : positive -> nat -> (coq_N -> 'a1) -> 'a1

val mod_pow2 : positive -> nat -> coq_N

val zmod_pow2 : coq_Z -> nat -> coq_Z
