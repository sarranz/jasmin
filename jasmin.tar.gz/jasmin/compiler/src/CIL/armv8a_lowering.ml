(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Arm_common
open Armv8a_decl
open Armv8a_extra
open Armv8a_instr_decl
open Armv8a_params_core
open Eqtype
open Expr
open Lowering
open Operators
open Pseudo_operator
open Seq
open Shift_kind
open Sopn
open Ssrbool
open Type
open Utils0
open Var0
open Word0
open Wsize

(** val fv_NF : fresh_vars -> Ident.Ident.ident **)

let fv_NF fv =
  fv "__n__" Coq_abool

(** val fv_ZF : fresh_vars -> Ident.Ident.ident **)

let fv_ZF fv =
  fv "__z__" Coq_abool

(** val fv_CF : fresh_vars -> Ident.Ident.ident **)

let fv_CF fv =
  fv "__c__" Coq_abool

(** val fv_VF : fresh_vars -> Ident.Ident.ident **)

let fv_VF fv =
  fv "__v__" Coq_abool

(** val all_fresh_vars : fresh_vars -> Ident.Ident.ident list **)

let all_fresh_vars fv =
  (fv_NF fv) :: ((fv_ZF fv) :: ((fv_CF fv) :: ((fv_VF fv) :: [])))

(** val fvNF : fresh_vars -> Var.var **)

let fvNF fv =
  { Var.vtype = Coq_abool; Var.vname = (fv_NF fv) }

(** val fvZF : fresh_vars -> Var.var **)

let fvZF fv =
  { Var.vtype = Coq_abool; Var.vname = (fv_ZF fv) }

(** val fvCF : fresh_vars -> Var.var **)

let fvCF fv =
  { Var.vtype = Coq_abool; Var.vname = (fv_CF fv) }

(** val fvVF : fresh_vars -> Var.var **)

let fvVF fv =
  { Var.vtype = Coq_abool; Var.vname = (fv_VF fv) }

(** val fresh_flags : fresh_vars -> Var.var list **)

let fresh_flags fv =
  (fvNF fv) :: ((fvZF fv) :: ((fvCF fv) :: ((fvVF fv) :: [])))

(** val fvars : fresh_vars -> SvExtra.Sv.t **)

let fvars fv =
  SvExtra.sv_of_list (fun x -> Obj.magic x) (fresh_flags fv)

type low_expr =
  ((register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
  extended_op sopn * pexpr list) option

(** val le_skip :
    (register, empty, empty, rflag, condt) arch_toIdent -> low_expr **)

let le_skip _ =
  None

(** val le_issue_sopn :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn ->
    pexpr list -> low_expr **)

let le_issue_sopn _ op es =
  Some (op, es)

(** val le_issue_extra :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extra_op_t -> pexpr
    list -> low_expr **)

let le_issue_extra atoI op =
  le_issue_sopn atoI (Oasm (ExtOp op))

(** val le_issue_aop :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op) asm_op_t' -> pexpr list -> low_expr **)

let le_issue_aop atoI aop =
  le_issue_sopn atoI (Oasm (BaseOp (None, aop)))

(** val le_issue_opts :
    (register, empty, empty, rflag, condt) arch_toIdent -> armv8a_mnemonic ->
    armv8a_options -> pexpr list -> low_expr **)

let le_issue_opts atoI mn opts =
  le_issue_aop atoI (ARMv8A_op (mn, opts))

(** val le_issue :
    (register, empty, empty, rflag, condt) arch_toIdent -> armv8a_mnemonic ->
    wsize -> pexpr list -> low_expr **)

let le_issue atoI mn ws =
  le_issue_opts atoI mn (opts_at ws)

(** val no_pre :
    (register, empty, empty, rflag, condt) arch_toIdent -> low_expr ->
    (((register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
    extended_op instr_r list * (register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op sopn) * pexpr list) option **)

let no_pre _ = function
| Some p -> let (aop, es) = p in Some (([], aop), es)
| None -> None

(** val chk_ws_reg : wsize -> unit option **)

let chk_ws_reg ws =
  oassert
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
        (Obj.magic U64))
      (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
        (Obj.magic U32)))

(** val flags_of_mn : fresh_vars -> armv8a_mnemonic -> Var.var list **)

let flags_of_mn fv mn =
  let ids =
    match mn with
    | ADD -> []
    | ADDS -> []
    | ADC -> []
    | ADCS -> []
    | SUB -> []
    | SUBS -> []
    | NEG -> []
    | MUL -> []
    | MADD -> []
    | MSUB -> []
    | SDIV -> []
    | UDIV -> []
    | AND -> []
    | ORR -> []
    | EOR -> []
    | MVN -> []
    | ASR -> []
    | LSL -> []
    | LSR -> []
    | ROR -> []
    | MOV -> []
    | MOVN -> []
    | MOVZ -> []
    | MOVK -> []
    | ADR -> []
    | SXTB -> []
    | SXTH -> []
    | SXTW -> []
    | UXTB -> []
    | UXTH -> []
    | UXTW -> []
    | CMP -> fvNF :: (fvZF :: (fvCF :: (fvVF :: [])))
    | TST -> fvNF :: (fvZF :: (fvCF :: (fvVF :: [])))
    | _ -> []
  in
  map (fun x -> x fv) ids

(** val lflags_of_mn :
    fresh_vars -> var_info -> armv8a_mnemonic -> lval list **)

let lflags_of_mn fv vi mn =
  map (fun x -> Lvar { v_var = x; v_info = vi }) (flags_of_mn fv mn)

(** val lower_TST : pexpr -> pexpr -> pexpr list option **)

let lower_TST e0 e1 =
  match e0 with
  | Papp2 (s, e00, e01) ->
    (match s with
     | Oland _ ->
       (match e1 with
        | Papp1 (s0, p) ->
          (match s0 with
           | Oword_of_int _ ->
             (match p with
              | Pconst z ->
                (match z with
                 | Z0 -> Some (e00 :: (e01 :: []))
                 | _ -> None)
              | _ -> None)
           | _ -> None)
        | _ -> None)
     | _ -> None)
  | _ -> None

(** val lower_condition_Papp2 :
    fresh_vars -> var_info -> sop2 -> pexpr -> pexpr ->
    (((armv8a_mnemonic * wsize) * pexpr) * pexpr list) option **)

let lower_condition_Papp2 fv vi op e0 e1 =
  match cf_of_condition op with
  | Some p ->
    let (cf, ws) = p in
    (match chk_ws_reg ws with
     | Some _ ->
       let cmp = (((CMP, ws), (pexpr_of_cf cf vi (fresh_flags fv))),
         (e0 :: (e1 :: [])))
       in
       (match op with
        | Oeq o ->
          (match o with
           | Op_int -> None
           | Op_w _ ->
             let zf_var = { v_var = (fvZF fv); v_info = vi } in
             let eZF = Pvar (mk_lvar zf_var) in
             Some
             (match lower_TST e0 e1 with
              | Some es -> (((TST, ws), eZF), es)
              | None -> cmp))
        | Oneq o -> (match o with
                     | Op_int -> None
                     | Op_w _ -> Some cmp)
        | Olt c -> (match c with
                    | Cmp_int -> None
                    | Cmp_w (_, _) -> Some cmp)
        | Ole c -> (match c with
                    | Cmp_int -> None
                    | Cmp_w (_, _) -> Some cmp)
        | Ogt c -> (match c with
                    | Cmp_int -> None
                    | Cmp_w (_, _) -> Some cmp)
        | Oge c -> (match c with
                    | Cmp_int -> None
                    | Cmp_w (_, _) -> Some cmp)
        | _ -> None)
     | None -> None)
  | None -> None

(** val lower_condition_pexpr :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars ->
    var_info -> pexpr -> (((lval list * (register, empty, empty, rflag,
    condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn) * pexpr
    list) * pexpr) option **)

let lower_condition_pexpr atoI fv vi e =
  match is_Papp2 e with
  | Some p ->
    let (p0, e1) = p in
    let (op, e0) = p0 in
    (match lower_condition_Papp2 fv vi op e0 e1 with
     | Some p1 ->
       let (p2, es) = p1 in
       let (p3, e') = p2 in
       let (mn, ws) = p3 in
       Some ((((lflags_of_mn fv vi mn),
       (coq_Oarmv8a atoI (ARMv8A_op (mn, (opts_at ws))))), es), e')
     | None -> None)
  | None -> None

(** val lower_condition :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars ->
    var_info -> pexpr -> (register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op instr_r list * pexpr **)

let lower_condition atoI fv vi e =
  match lower_condition_pexpr atoI fv vi e with
  | Some p ->
    let (p0, c) = p in
    let (p1, es) = p0 in
    let (lvs, op) = p1 in (((Copn (lvs, AT_none, op, es)) :: []), c)
  | None -> ([], e)

(** val get_arg_shift :
    wsize -> pexpr list -> ((pexpr * shift_kind) * pexpr) option **)

let get_arg_shift ws = function
| [] -> None
| p :: l ->
  (match p with
   | Papp2 (op, v, n) ->
     (match v with
      | Pvar _ ->
        (match n with
         | Papp1 (s, p0) ->
           (match s with
            | Oword_of_int w ->
              (match w with
               | U8 ->
                 (match p0 with
                  | Pconst z ->
                    (match l with
                     | [] ->
                       (match shift_of_sop2 ws op with
                        | Some sh ->
                          (match oassert (check_shift_amount ws z) with
                           | Some _ -> Some ((v, sh), n)
                           | None -> None)
                        | None -> None)
                     | _ :: _ -> None)
                  | _ -> None)
               | _ -> None)
            | _ -> None)
         | _ -> None)
      | _ -> None)
   | _ -> None)

(** val arg_shift :
    armv8a_mnemonic -> wsize -> pexpr list -> armv8a_asm_op * pexpr list **)

let arg_shift mn ws e =
  if in_mem (Obj.magic mn)
       (mem (seq_predType armv8a_mnemonic_eqType)
         (Obj.magic has_shift_mnemonics))
  then (match get_arg_shift ws e with
        | Some p ->
          let (p0, esham) = p in
          let (ebase, sh) = p0 in
          if shift_allowed mn sh
          then let osh = Some sh in
               let es = ebase :: (esham :: []) in
               let opts = { has_shift = osh; opts_size = ws } in
               ((ARMv8A_op (mn, opts)), es)
          else let osh = None in
               let opts = { has_shift = osh; opts_size = ws } in
               ((ARMv8A_op (mn, opts)), e)
        | None ->
          let osh = None in
          let opts = { has_shift = osh; opts_size = ws } in
          ((ARMv8A_op (mn, opts)), e))
  else let osh = None in
       let opts = { has_shift = osh; opts_size = ws } in
       ((ARMv8A_op (mn, opts)), e)

(** val lower_Pvar :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> gvar ->
    low_expr **)

let lower_Pvar atoI ws v =
  match chk_ws_reg ws with
  | Some _ ->
    let mn = if is_var_in_memory v.gv.v_var then LDR else MOV in
    le_issue atoI mn ws ((Pvar v) :: [])
  | None -> None

(** val lower_load :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> pexpr ->
    low_expr **)

let lower_load atoI ws e =
  match chk_ws_reg ws with
  | Some _ -> le_issue atoI LDR ws (e :: [])
  | None -> None

(** val mov_imm_op :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> pexpr ->
    (register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
    extended_op sopn **)

let mov_imm_op atoI ws e =
  if isSome (is_const e)
  then Oasm (ExtOp (Oarmv8a_smart_li ws))
  else coq_Oarmv8a atoI (ARMv8A_op (MOV, (opts_at ws)))

(** val uload_mn : wsize -> wsize -> armv8a_mnemonic option **)

let uload_mn _ = function
| U8 -> Some LDRB
| U16 -> Some LDRH
| _ -> None

(** val sload_mn : wsize -> wsize -> armv8a_mnemonic option **)

let sload_mn ws = function
| U8 -> Some LDRSB
| U16 -> Some LDRSH
| U32 ->
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
       (Obj.magic U64)
  then Some LDRSW
  else None
| _ -> None

(** val sext_mn : wsize -> wsize -> armv8a_mnemonic option **)

let sext_mn ws = function
| U8 -> Some SXTB
| U16 -> Some SXTH
| U32 ->
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
       (Obj.magic U64)
  then Some SXTW
  else None
| _ -> None

(** val uext_mn : wsize -> wsize -> armv8a_mnemonic option **)

let uext_mn ws = function
| U8 -> Some UXTB
| U16 -> Some UXTH
| U32 ->
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
       (Obj.magic U64)
  then Some UXTW
  else None
| _ -> None

(** val lower_Papp1 :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> sop1 ->
    pexpr -> low_expr **)

let lower_Papp1 atoI ws op e =
  match chk_ws_reg ws with
  | Some _ ->
    (match op with
     | Oword_of_int ws' ->
       (match oassert (cmp_le wsize_cmp ws ws') with
        | Some _ ->
          let op0 = mov_imm_op atoI ws e in
          le_issue_sopn atoI op0 ((Papp1 ((Oword_of_int ws), e)) :: [])
        | None -> None)
     | Osignext (ws0, ws') ->
       (match oassert
                (eq_op wsize_wsize__canonical__eqtype_Equality
                  (Obj.magic ws0) (Obj.magic ws)) with
        | Some _ ->
          (match oassert (cmp_lt wsize_cmp ws' ws) with
           | Some _ ->
             if is_load e
             then (match sload_mn ws ws' with
                   | Some mn -> le_issue atoI mn ws (e :: [])
                   | None -> None)
             else (match sext_mn ws ws' with
                   | Some mn -> le_issue atoI mn ws (e :: [])
                   | None -> None)
           | None -> None)
        | None -> None)
     | Ozeroext (ws0, ws') ->
       (match oassert
                (eq_op wsize_wsize__canonical__eqtype_Equality
                  (Obj.magic ws0) (Obj.magic ws)) with
        | Some _ ->
          (match oassert (cmp_lt wsize_cmp ws' ws) with
           | Some _ ->
             if is_load e
             then (match uload_mn ws ws' with
                   | Some mn -> le_issue atoI mn ws (e :: [])
                   | None -> None)
             else (match uext_mn ws ws' with
                   | Some mn -> le_issue atoI mn ws (e :: [])
                   | None -> None)
           | None -> None)
        | None -> None)
     | Olnot ws0 ->
       (match oassert
                (eq_op wsize_wsize__canonical__eqtype_Equality
                  (Obj.magic ws0) (Obj.magic ws)) with
        | Some _ ->
          let (op0, es) = arg_shift MVN ws (e :: []) in
          le_issue_aop atoI op0 es
        | None -> None)
     | Oneg o ->
       (match o with
        | Op_int -> le_skip atoI
        | Op_w ws0 ->
          (match oassert
                   (eq_op wsize_wsize__canonical__eqtype_Equality
                     (Obj.magic ws0) (Obj.magic ws)) with
           | Some _ ->
             let (op0, es) = arg_shift NEG ws (e :: []) in
             le_issue_aop atoI op0 es
           | None -> None))
     | _ -> le_skip atoI)
  | None -> None

(** val is_mul : wsize -> pexpr -> (pexpr * pexpr) option **)

let is_mul ws = function
| Papp2 (s, x, y) ->
  (match s with
   | Omul o ->
     (match o with
      | Op_int -> None
      | Op_w ws' -> if cmp_le wsize_cmp ws ws' then Some (x, y) else None)
   | _ -> None)
| _ -> None

(** val check_shift_expr : wsize -> pexpr -> pexpr option **)

let check_shift_expr ws e =
  match is_wconst U8 e with
  | Some n ->
    if eq_op (word_word__canonical__eqtype_Equality U8) (Obj.magic n)
         (Obj.magic wand U8 n
           (wrepr U8 (Z.sub (wsize_bits ws) (Zpos Coq_xH))))
    then Some e
    else None
  | None ->
    (match e with
     | Papp2 (s, a, b) ->
       (match s with
        | Oland _ ->
          (match is_wconst U8 b with
           | Some n ->
             if eq_op (word_word__canonical__eqtype_Equality U8)
                  (Obj.magic n)
                  (Obj.magic wrepr U8 (Z.sub (wsize_bits ws) (Zpos Coq_xH)))
             then Some a
             else None
           | None -> None)
        | _ -> None)
     | _ -> None)

(** val lower_Papp2_op :
    wsize -> sop2 -> pexpr -> pexpr -> ((armv8a_mnemonic * pexpr) * pexpr
    list) option **)

let lower_Papp2_op ws op e0 e1 =
  match chk_ws_reg ws with
  | Some _ ->
    (match op with
     | Oadd o ->
       (match o with
        | Op_int -> None
        | Op_w _ ->
          (match is_mul ws e0 with
           | Some p -> let (x, y) = p in Some ((MADD, x), (y :: (e1 :: [])))
           | None ->
             (match is_mul ws e1 with
              | Some p ->
                let (x, y) = p in Some ((MADD, x), (y :: (e0 :: [])))
              | None -> Some ((ADD, e0), (e1 :: [])))))
     | Omul o ->
       (match o with
        | Op_int -> None
        | Op_w _ -> Some ((MUL, e0), (e1 :: [])))
     | Osub o ->
       (match o with
        | Op_int -> None
        | Op_w _ ->
          (match is_mul ws e1 with
           | Some p -> let (x, y) = p in Some ((MSUB, x), (y :: (e0 :: [])))
           | None -> Some ((SUB, e0), (e1 :: []))))
     | Odiv (s, o) ->
       (match s with
        | Signed ->
          (match o with
           | Op_int -> None
           | Op_w ws' ->
             (match oassert
                      (eq_op wsize_wsize__canonical__eqtype_Equality
                        (Obj.magic ws') (Obj.magic ws)) with
              | Some _ -> Some ((SDIV, e0), (e1 :: []))
              | None -> None))
        | Unsigned ->
          (match o with
           | Op_int -> None
           | Op_w ws' ->
             (match oassert
                      (eq_op wsize_wsize__canonical__eqtype_Equality
                        (Obj.magic ws') (Obj.magic ws)) with
              | Some _ -> Some ((UDIV, e0), (e1 :: []))
              | None -> None)))
     | Oland _ -> Some ((AND, e0), (e1 :: []))
     | Olor _ -> Some ((ORR, e0), (e1 :: []))
     | Olxor _ -> Some ((EOR, e0), (e1 :: []))
     | Olsr ws' ->
       (match oassert
                (eq_op wsize_wsize__canonical__eqtype_Equality
                  (Obj.magic ws') (Obj.magic ws)) with
        | Some _ ->
          if is_zero (Obj.magic U8) e1
          then Some ((MOV, e0), [])
          else (match check_shift_expr ws e1 with
                | Some e1' -> Some ((LSR, e0), (e1' :: []))
                | None -> None)
        | None -> None)
     | Olsl o ->
       (match o with
        | Op_int -> None
        | Op_w ws' ->
          (match oassert
                   (eq_op wsize_wsize__canonical__eqtype_Equality
                     (Obj.magic ws') (Obj.magic ws)) with
           | Some _ ->
             if is_zero (Obj.magic U8) e1
             then Some ((MOV, e0), [])
             else (match check_shift_expr ws e1 with
                   | Some e1' -> Some ((LSL, e0), (e1' :: []))
                   | None -> None)
           | None -> None))
     | Oasr o ->
       (match o with
        | Op_int -> None
        | Op_w ws' ->
          (match oassert
                   (eq_op wsize_wsize__canonical__eqtype_Equality
                     (Obj.magic ws') (Obj.magic ws)) with
           | Some _ ->
             if is_zero (Obj.magic U8) e1
             then Some ((MOV, e0), [])
             else (match check_shift_expr ws e1 with
                   | Some e1' -> Some ((ASR, e0), (e1' :: []))
                   | None -> None)
           | None -> None))
     | Oror ws' ->
       (match oassert
                (eq_op wsize_wsize__canonical__eqtype_Equality
                  (Obj.magic ws') (Obj.magic ws)) with
        | Some _ ->
          if is_zero (Obj.magic U8) e1
          then Some ((MOV, e0), [])
          else Some ((ROR, e0), (e1 :: []))
        | None -> None)
     | Orol ws' ->
       (match oassert
                (eq_op wsize_wsize__canonical__eqtype_Equality
                  (Obj.magic ws') (Obj.magic ws)) with
        | Some _ ->
          (match is_wconst U8 e1 with
           | Some c ->
             if eq_op (word_word__canonical__eqtype_Equality U8)
                  (Obj.magic c) (Obj.magic word0 U8)
             then Some ((MOV, e0), [])
             else Some ((ROR, e0),
                    ((wconst U8 (sub_word U8 (wrepr U8 (wsize_bits ws)) c)) :: []))
           | None -> None)
        | None -> None)
     | _ -> None)
  | None -> None

(** val large_arith_imm :
    wsize -> armv8a_mnemonic -> pexpr list -> coq_Z option **)

let large_arith_imm ws mn es =
  match oassert
          (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
            (Obj.magic U64)) with
  | Some _ ->
    (match es with
     | [] -> None
     | e :: l ->
       (match l with
        | [] ->
          (match is_wconst U64 e with
           | Some c ->
             let n = wunsigned U64 c in
             if is_arith_small n
             then None
             else (match mn with
                   | ADD -> Some n
                   | SUB -> Some (Z.opp n)
                   | _ -> None)
           | None -> None)
        | _ :: _ -> None))
  | None -> None

(** val lower_Papp2 :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> sop2 ->
    pexpr -> pexpr -> low_expr **)

let lower_Papp2 atoI ws op e0 e1 =
  match lower_Papp2_op ws op e0 e1 with
  | Some p ->
    let (p0, e1') = p in
    let (mn, e0') = p0 in
    (match large_arith_imm ws mn e1' with
     | Some imm ->
       le_issue_extra atoI Oarmv8a_add_large_imm
         (e0' :: ((wconst U64 (wrepr U64 imm)) :: []))
     | None ->
       let (aop, es) = arg_shift mn ws e1' in
       le_issue_aop atoI aop (e0' :: es))
  | None -> None

(** val lower_pexpr_aux :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> pexpr ->
    low_expr **)

let lower_pexpr_aux atoI ws e = match e with
| Pvar v -> lower_Pvar atoI ws v
| Pget (_, _, _, _, _) -> lower_load atoI ws e
| Pload (_, _, _) -> lower_load atoI ws e
| Papp1 (op, e0) -> lower_Papp1 atoI ws op e0
| Papp2 (op, a, b) -> lower_Papp2 atoI ws op a b
| _ -> le_skip atoI

(** val is_csel_arg : pexpr -> bool **)

let is_csel_arg = function
| Pvar v -> negb (is_var_in_memory v.gv.v_var)
| _ -> false

(** val lower_Pif :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars ->
    var_info -> wsize -> pexpr -> pexpr -> pexpr -> (((register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op instr_r
    list * (register, empty, empty, rflag, condt, armv8a_asm_op,
    armv8a_extra_op) extended_op sopn) * pexpr list) option **)

let lower_Pif atoI fv vi ws c e0 e1 =
  match chk_ws_reg ws with
  | Some _ ->
    (match oassert ((&&) (is_csel_arg e0) (is_csel_arg e1)) with
     | Some _ ->
       let (pre, c') = lower_condition atoI fv vi c in
       Some ((pre, (coq_Oarmv8a atoI (ARMv8A_op (CSEL, (opts_at ws))))),
       (e0 :: (e1 :: (c' :: []))))
     | None -> None)
  | None -> None

(** val lower_pexpr :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars ->
    var_info -> wsize -> pexpr -> (((register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op instr_r list * (register,
    empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
    sopn) * pexpr list) option **)

let lower_pexpr atoI fv vi ws e = match e with
| Pif (a, c, e0, e1) ->
  (match a with
   | Coq_aword ws' ->
     (match oassert
              (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
                (Obj.magic ws')) with
      | Some _ -> lower_Pif atoI fv vi ws c e0 e1
      | None -> None)
   | _ -> no_pre atoI (lower_pexpr_aux atoI ws e))
| _ -> no_pre atoI (lower_pexpr_aux atoI ws e)

(** val lower_store :
    wsize -> pexpr -> (armv8a_asm_op * pexpr list) option **)

let lower_store ws e =
  match store_mn_of_wsize ws with
  | Some mn ->
    let osz = if cmp_le wsize_cmp ws U16 then U64 else ws in
    (match e with
     | Pvar _ -> Some ((ARMv8A_op (mn, (opts_at osz))), (e :: []))
     | _ -> None)
  | None -> None

(** val lower_cassgn_word :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars -> lval
    -> wsize -> pexpr -> ((register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op instr_r list * ((lval
    list * (register, empty, empty, rflag, condt, armv8a_asm_op,
    armv8a_extra_op) extended_op sopn) * pexpr list)) option **)

let lower_cassgn_word atoI fv lv ws e =
  let vi = var_info_of_lval lv in
  (match if is_lval_in_memory lv
         then (match lower_store ws e with
               | Some p ->
                 let (aop, es) = p in no_pre atoI (le_issue_aop atoI aop es)
               | None -> None)
         else lower_pexpr atoI fv vi ws e with
   | Some p ->
     let (p0, es) = p in
     let (pre, op) = p0 in Some (pre, (((lv :: []), op), es))
   | None -> None)

(** val lower_cassgn_bool :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars -> lval
    -> assgn_tag -> pexpr -> (register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op instr_r list option **)

let lower_cassgn_bool atoI fv lv tag e =
  let vi = var_info_of_lval lv in
  (match lower_condition_pexpr atoI fv vi e with
   | Some p ->
     let (p0, c) = p in
     let (p1, es) = p0 in
     let (lvs, op) = p1 in
     Some ((Copn (lvs, tag, op, es)) :: ((Cassgn (lv, AT_inline, Coq_abool,
     c)) :: []))
   | None -> None)

(** val isLnone : lval -> bool **)

let isLnone = function
| Lnone (_, _) -> true
| _ -> false

(** val lower_add_carry :
    (register, empty, empty, rflag, condt) arch_toIdent -> lval list -> pexpr
    list -> ((lval list * (register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op sopn) * pexpr list) option **)

let lower_add_carry _ lvs es =
  match lvs with
  | [] -> None
  | cf :: l ->
    (match l with
     | [] -> None
     | r :: l0 ->
       (match l0 with
        | [] ->
          (match es with
           | [] -> None
           | x :: l1 ->
             (match l1 with
              | [] -> None
              | y :: l2 ->
                (match l2 with
                 | [] -> None
                 | b :: l3 ->
                   (match l3 with
                    | [] ->
                      let cf_not_none = negb (isLnone cf) in
                      (match b with
                       | Pconst _ -> None
                       | Pbool b0 ->
                         if b0
                         then None
                         else let p = ((if cf_not_none then ADDS else ADD),
                                (x :: (y :: [])))
                              in
                              let (mn, es') = p in
                              let lnoneb = Lnone (dummy_var_info, Coq_abool)
                              in
                              let lvs' =
                                if cf_not_none
                                then lnoneb :: (lnoneb :: (cf :: (lnoneb :: (r :: []))))
                                else r :: []
                              in
                              Some ((lvs', (Oasm (BaseOp (None, (ARMv8A_op
                              (mn, default_opts)))))), es')
                       | Pvar _ ->
                         let p = ((if cf_not_none then ADCS else ADC), es) in
                         let (mn, es') = p in
                         let lnoneb = Lnone (dummy_var_info, Coq_abool) in
                         let lvs' =
                           if cf_not_none
                           then lnoneb :: (lnoneb :: (cf :: (lnoneb :: (r :: []))))
                           else r :: []
                         in
                         Some ((lvs', (Oasm (BaseOp (None, (ARMv8A_op (mn,
                         default_opts)))))), es')
                       | _ -> None)
                    | _ :: _ -> None))))
        | _ :: _ -> None))

(** val with_shift : armv8a_options -> shift_kind -> armv8a_options **)

let with_shift opts sh =
  { has_shift = (Some sh); opts_size = opts.opts_size }

(** val lower_base_op :
    (register, empty, empty, rflag, condt) arch_toIdent -> lval list ->
    armv8a_asm_op -> pexpr list -> ((lval list * (register, empty, empty,
    rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn) * pexpr
    list) option **)

let lower_base_op _ lvs aop es =
  let ARMv8A_op (mn, opts) = aop in
  let ws = opts.opts_size in
  if negb
       (eq_op
         (coq_Datatypes_option__canonical__eqtype_Equality
           shift_kind_shift_kind__canonical__eqtype_Equality)
         (Obj.magic opts.has_shift) (Obj.magic None))
  then (match oassert
                (in_mem (Obj.magic mn)
                  (mem (seq_predType armv8a_mnemonic_eqType)
                    (Obj.magic has_shift_mnemonics))) with
        | Some _ ->
          Some ((lvs, (Oasm (BaseOp (None, (ARMv8A_op (mn, opts)))))), es)
        | None -> None)
  else if in_mem (Obj.magic mn)
            (mem (seq_predType armv8a_mnemonic_eqType)
              (Obj.magic (MVN :: (NEG :: []))))
       then (match es with
             | [] -> None
             | x :: rest ->
               (match get_arg_shift ws (x :: []) with
                | Some p ->
                  let (p0, esham) = p in
                  let (ebase, sh) = p0 in
                  if shift_allowed mn sh
                  then Some ((lvs, (Oasm (BaseOp (None, (ARMv8A_op (mn,
                         (with_shift opts sh))))))),
                         (ebase :: (esham :: rest)))
                  else Some ((lvs, (Oasm (BaseOp (None, (ARMv8A_op (mn,
                         opts)))))), es)
                | None ->
                  Some ((lvs, (Oasm (BaseOp (None, (ARMv8A_op (mn,
                    opts)))))), es)))
       else if in_mem (Obj.magic mn)
                 (mem (seq_predType armv8a_mnemonic_eqType)
                   (Obj.magic
                     (ADD :: (ADDS :: (SUB :: (SUBS :: (AND :: (EOR :: (ORR :: (CMP :: (TST :: [])))))))))))
            then (match es with
                  | [] -> None
                  | x :: l ->
                    (match l with
                     | [] -> None
                     | y :: rest ->
                       (match get_arg_shift ws (y :: []) with
                        | Some p ->
                          let (p0, esham) = p in
                          let (ebase, sh) = p0 in
                          if shift_allowed mn sh
                          then Some ((lvs, (Oasm (BaseOp (None, (ARMv8A_op
                                 (mn, (with_shift opts sh))))))),
                                 (x :: (ebase :: (esham :: rest))))
                          else Some ((lvs, (Oasm (BaseOp (None, (ARMv8A_op
                                 (mn, opts)))))), es)
                        | None ->
                          Some ((lvs, (Oasm (BaseOp (None, (ARMv8A_op (mn,
                            opts)))))), es))))
            else None

(** val lower_swap :
    (register, empty, empty, rflag, condt) arch_toIdent -> atype -> lval list
    -> pexpr list -> ((lval list * (register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op sopn) * pexpr list) option **)

let lower_swap _ ty lvs es =
  match ty with
  | Coq_aarr (_, _) -> Some ((lvs, (Opseudo_op (Oswap ty))), es)
  | Coq_aword sz ->
    if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic sz)
         (Obj.magic U64)
    then Some ((lvs, (Oasm (ExtOp (Oarmv8a_swap sz)))), es)
    else None
  | _ -> None

(** val lower_pseudo_operator :
    (register, empty, empty, rflag, condt) arch_toIdent -> lval list ->
    pseudo_operator -> pexpr list -> ((lval list * (register, empty, empty,
    rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn) * pexpr
    list) option **)

let lower_pseudo_operator atoI lvs op es =
  match op with
  | Oaddcarry w ->
    (match w with
     | U64 -> lower_add_carry atoI lvs es
     | _ -> None)
  | Oswap ty -> lower_swap atoI ty lvs es
  | _ -> None

(** val lower_copn :
    (register, empty, empty, rflag, condt) arch_toIdent -> lval list ->
    (register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
    extended_op sopn -> pexpr list -> ((lval list * (register, empty, empty,
    rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn) * pexpr
    list) option **)

let lower_copn atoI lvs op es =
  match op with
  | Opseudo_op pop -> lower_pseudo_operator atoI lvs pop es
  | Oslh _ -> None
  | Oasm a ->
    (match a with
     | BaseOp a0 ->
       let (o, aop) = a0 in
       (match o with
        | Some _ -> None
        | None -> lower_base_op atoI lvs aop es)
     | ExtOp _ -> None)

(** val lower_i :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars ->
    (register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
    extended_op instr -> (register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op instr list **)

let rec lower_i atoI fv i = match i with
| MkI (ii, ir) ->
  (match ir with
   | Cassgn (lv, tag, ty, e) ->
     let oirs =
       match ty with
       | Coq_abool -> lower_cassgn_bool atoI fv lv tag e
       | Coq_aword ws ->
         (match lower_cassgn_word atoI fv lv ws e with
          | Some p ->
            let (pre, p0) = p in
            let (p1, es) = p0 in
            let (lvs, op) = p1 in
            Some (cat pre ((Copn (lvs, tag, op, es)) :: []))
          | None -> None)
       | _ -> None
     in
     let irs = match oirs with
               | Some irs -> irs
               | None -> ir :: [] in
     map (fun x -> MkI (ii, x)) irs
   | Copn (lvs, tag, op, es) ->
     let ir' =
       match lower_copn atoI lvs op es with
       | Some p ->
         let (p0, es') = p in
         let (lvs', op') = p0 in Copn (lvs', tag, op', es')
       | None -> ir
     in
     (MkI (ii, ir')) :: []
   | Cif (e, c1, c2) ->
     let (pre, e') = lower_condition atoI fv (var_info_of_ii ii) e in
     let c1' = conc_map (lower_i atoI fv) c1 in
     let c2' = conc_map (lower_i atoI fv) c2 in
     map (fun x -> MkI (ii, x)) (cat pre ((Cif (e', c1', c2')) :: []))
   | Cfor (fi, c) ->
     let c' = conc_map (lower_i atoI fv) c in
     (MkI (ii, (Cfor (fi, c')))) :: []
   | Cwhile (a, c0, e, info, c1) ->
     let (pre, e') = lower_condition atoI fv (var_info_of_ii info) e in
     let c0' = conc_map (lower_i atoI fv) c0 in
     let c1' = conc_map (lower_i atoI fv) c1 in
     (MkI (ii, (Cwhile (a, (cat c0' (map (fun x -> MkI (info, x)) pre)), e',
     info, c1')))) :: []
   | _ -> i :: [])
