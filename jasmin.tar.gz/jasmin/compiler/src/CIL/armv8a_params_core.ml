(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Armv8a_decl
open Armv8a_instr_decl
open Eqtype
open Expr
open Fexpr
open Seq
open Var0
open Word0
open Wsize

(** val is_arith_small : coq_Z -> bool **)

let is_arith_small =
  is_arith_imm

(** val coq_Z_mod_lnot : coq_Z -> wsize -> coq_Z **)

let coq_Z_mod_lnot z ws =
  let m = wbase ws in Z.modulo (Z.lnot (Z.modulo z m)) m

module ARMv8AFopn_core =
 struct
  type opn_args = (lexpr list * armv8a_asm_op) * rexpr list

  (** val mov : var_i -> var_i -> opn_args **)

  let mov =
    let op_gen = fun mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      default_opts))), res)
    in
    let mn = MOV in (fun x y -> op_gen mn x ((rvar y) :: []))

  (** val add : var_i -> var_i -> var_i -> opn_args **)

  let add =
    let op_gen = fun mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      default_opts))), res)
    in
    let mn = ADD in (fun x y z -> op_gen mn x ((rvar y) :: ((rvar z) :: [])))

  (** val sub : var_i -> var_i -> var_i -> opn_args **)

  let sub =
    let op_gen = fun mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      default_opts))), res)
    in
    let mn = SUB in (fun x y z -> op_gen mn x ((rvar y) :: ((rvar z) :: [])))

  (** val movi : var_i -> coq_Z -> opn_args **)

  let movi =
    let op_gen = fun mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      default_opts))), res)
    in
    let mn = MOV in
    (fun x imm -> op_gen mn x ((rconst armv8a_decl.reg_size imm) :: []))

  (** val addi : var_i -> var_i -> coq_Z -> opn_args **)

  let addi =
    let op_gen = fun mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      default_opts))), res)
    in
    let mn = ADD in
    (fun x y imm ->
    op_gen mn x ((rvar y) :: ((rconst armv8a_decl.reg_size imm) :: [])))

  (** val subi : var_i -> var_i -> coq_Z -> opn_args **)

  let subi =
    let op_gen = fun mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      default_opts))), res)
    in
    let mn = SUB in
    (fun x y imm ->
    op_gen mn x ((rvar y) :: ((rconst armv8a_decl.reg_size imm) :: [])))

  (** val andi : var_i -> var_i -> coq_Z -> opn_args **)

  let andi =
    let op_gen = fun mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      default_opts))), res)
    in
    let mn = AND in
    (fun x y imm ->
    op_gen mn x ((rvar y) :: ((rconst armv8a_decl.reg_size imm) :: [])))

  (** val movz : wsize -> var_i -> coq_Z -> coq_Z -> opn_args **)

  let movz =
    let op_gen_at = fun ws mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      (opts_at ws)))), res)
    in
    (fun ws x imm sh ->
    op_gen_at ws MOVZ x ((rconst U16 imm) :: ((rconst U8 sh) :: [])))

  (** val movn : wsize -> var_i -> coq_Z -> coq_Z -> opn_args **)

  let movn =
    let op_gen_at = fun ws mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      (opts_at ws)))), res)
    in
    (fun ws x imm sh ->
    op_gen_at ws MOVN x ((rconst U16 imm) :: ((rconst U8 sh) :: [])))

  (** val movk : wsize -> var_i -> coq_Z -> coq_Z -> opn_args **)

  let movk =
    let op_gen_at = fun ws mn x res -> ((((LLvar x) :: []), (ARMv8A_op (mn,
      (opts_at ws)))), res)
    in
    (fun ws x imm sh ->
    op_gen_at ws MOVK x
      ((rvar x) :: ((rconst U16 imm) :: ((rconst U8 sh) :: []))))

  (** val align : var_i -> var_i -> wsize -> opn_args **)

  let align x y al =
    andi x y
      (coq_Z_mod_lnot (Z.sub (wsize_size al) (Zpos Coq_xH))
        armv8a_decl.reg_size)

  (** val li : wsize -> var_i -> coq_Z -> opn_args list **)

  let li ws x imm =
    let n = Z.modulo imm (wbase ws) in
    if Z.ltb n
         (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
           Coq_xH))))))
    then (movz ws x n Z0) :: []
    else if Z.leb
              (Z.sub (wbase ws)
                (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO (Coq_xO
                  (Coq_xO Coq_xH)))))))
              n
         then (movn ws x (coq_Z_mod_lnot n ws) Z0) :: []
         else let c0 =
                Z.modulo n
                  (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO (Coq_xO
                    (Coq_xO Coq_xH))))))
              in
              let c1 =
                Z.modulo
                  (Z.div n
                    (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO
                      (Coq_xO (Coq_xO Coq_xH)))))))
                  (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO (Coq_xO
                    (Coq_xO Coq_xH))))))
              in
              let c2 =
                Z.modulo
                  (Z.div n
                    (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO
                      (Coq_xO (Coq_xO (Coq_xO Coq_xH))))))))
                  (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO (Coq_xO
                    (Coq_xO Coq_xH))))))
              in
              let c3 =
                Z.modulo
                  (Z.div n
                    (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO
                      (Coq_xO (Coq_xO (Coq_xI Coq_xH))))))))
                  (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO (Coq_xO
                    (Coq_xO Coq_xH))))))
              in
              cat ((movz ws x c0 Z0) :: [])
                (cat
                  (if Z.eqb c1 Z0
                   then []
                   else (movk ws x c1 (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
                          Coq_xH)))))) :: [])
                  (cat
                    (if (||) (Z.eqb c2 Z0)
                          (negb
                            (eq_op wsize_wsize__canonical__eqtype_Equality
                              (Obj.magic ws) (Obj.magic U64)))
                     then []
                     else (movk ws x c2 (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
                            (Coq_xO Coq_xH))))))) :: [])
                    (if (||) (Z.eqb c3 Z0)
                          (negb
                            (eq_op wsize_wsize__canonical__eqtype_Equality
                              (Obj.magic ws) (Obj.magic U64)))
                     then []
                     else (movk ws x c3 (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
                            (Coq_xI Coq_xH))))))) :: [])))

  (** val smart_mov : var_i -> var_i -> opn_args list **)

  let smart_mov x y =
    if eq_op Var.coq_MvMake_var__canonical__eqtype_Equality
         (Obj.magic x.v_var) (Obj.magic y.v_var)
    then []
    else (mov x y) :: []

  (** val gen_smart_opi :
      (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
      opn_args) -> (coq_Z -> bool) -> coq_Z option -> var_i -> var_i -> var_i
      -> coq_Z -> opn_args list **)

  let gen_smart_opi on_reg on_imm is_small neutral tmp x y imm =
    let is_mov = match neutral with
                 | Some n -> Z.eqb imm n
                 | None -> false in
    if is_mov
    then smart_mov x y
    else if is_small imm
         then (on_imm x y imm) :: []
         else rcons (li U64 tmp imm) (on_reg x y tmp)

  (** val smart_addi : var_i -> var_i -> coq_Z -> opn_args list **)

  let smart_addi x y =
    gen_smart_opi add addi is_arith_small (Some Z0) x x y

  (** val smart_subi : var_i -> var_i -> coq_Z -> opn_args list **)

  let smart_subi x y imm =
    gen_smart_opi sub subi is_arith_small (Some Z0) x x y imm

  (** val gen_smart_opi_tmp :
      (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
      opn_args) -> var_i -> var_i -> coq_Z -> opn_args list **)

  let gen_smart_opi_tmp on_reg on_imm x tmp imm =
    gen_smart_opi on_reg on_imm is_arith_small (Some Z0) tmp x x imm

  (** val smart_addi_tmp : var_i -> var_i -> coq_Z -> opn_args list **)

  let smart_addi_tmp x tmp imm =
    gen_smart_opi_tmp add addi x tmp imm

  (** val smart_subi_tmp : var_i -> var_i -> coq_Z -> opn_args list **)

  let smart_subi_tmp x tmp imm =
    gen_smart_opi_tmp sub subi x tmp imm
 end
