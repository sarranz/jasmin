(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open Sem_type
open Seq
open Ssrnat
open Type
open Utils0
open Word0
open Wsize

type empty = |

val of_empty : empty -> 'a1

val eqTC_empty : empty eqTypeC

val finTC_empty : empty finTypeC

val empty_toS : ltype -> empty coq_ToString

val ak_reg_reg :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  i_args_kinds

val coq_CAimm_sz :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> wsize -> ('a1, 'a2, 'a3, 'a4, 'a5)
  arg_kind

val ak_reg_imm :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  i_args_kinds

val ak_reg_addr :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  i_args_kinds

val ak_reg_imm8_imm8 :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  i_args_kinds

val ak_reg_reg_reg :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  i_args_kinds

val ak_reg_reg_imm8_imm8 :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  i_args_kinds

val ak_reg_reg_reg_reg :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  i_args_kinds

val behead_tuple :
  ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
  sem_prod

val semi_drop1 :
  ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
  sem_prod

val semi_drop2 :
  ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
  sem_prod

val semi_drop3 :
  ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
  sem_prod

val semi_drop4 :
  ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
  sem_prod

val idt_drop1 :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t

val idt_drop2 :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t

val idt_drop3 :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t

val idt_drop4 :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
  instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t

val rtuple_drop5th :
  ctype -> ctype -> ctype -> ctype -> ctype -> sem_tuple ->
  sem_ot * (sem_ot * (sem_ot * sem_ot))

val arch_mk_semi1_shifted :
  (wsize -> word -> coq_Z -> word) -> wsize -> 'a1 exec sem_prod -> 'a1 exec
  sem_prod

val arch_mk_semi2_2_shifted :
  (wsize -> word -> coq_Z -> word) -> wsize -> ltype -> 'a1 exec sem_prod ->
  'a1 exec sem_prod

val arch_mk_semi3_2_shifted :
  (wsize -> word -> coq_Z -> word) -> wsize -> ltype -> ltype -> 'a1 exec
  sem_prod -> 'a1 exec sem_prod

val arch_mk_shifted :
  ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5) arg_kind
  -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t -> semi_type -> ('a1, 'a2, 'a3,
  'a4, 'a5) instr_desc_t
