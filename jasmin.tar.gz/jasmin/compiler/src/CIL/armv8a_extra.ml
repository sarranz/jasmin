(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Arm_common
open Armv8a
open Armv8a_decl
open Armv8a_instr_decl
open Armv8a_params_core
open Compiler_util
open EqbOK
open Eqb_core_defs
open Eqtype
open Expr
open Fexpr
open Operators
open Sem_type
open Seq
open Sopn
open Type
open Utils0
open Var0
open Word0
open Wsize

type __ = Obj.t

type armv8a_extra_op =
| Oarmv8a_swap of wsize
| Oarmv8a_add_large_imm
| Oarmv8a_smart_li of wsize

(** val armv8a_extra_op_rect :
    (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> armv8a_extra_op -> 'a1 **)

let armv8a_extra_op_rect f f0 f1 = function
| Oarmv8a_swap w -> f w
| Oarmv8a_add_large_imm -> f0
| Oarmv8a_smart_li w -> f1 w

(** val armv8a_extra_op_rec :
    (wsize -> 'a1) -> 'a1 -> (wsize -> 'a1) -> armv8a_extra_op -> 'a1 **)

let armv8a_extra_op_rec f f0 f1 = function
| Oarmv8a_swap w -> f w
| Oarmv8a_add_large_imm -> f0
| Oarmv8a_smart_li w -> f1 w

type is_armv8a_extra_op =
| Coq_is_Oarmv8a_swap of wsize * is_wsize
| Coq_is_Oarmv8a_add_large_imm
| Coq_is_Oarmv8a_smart_li of wsize * is_wsize

(** val is_armv8a_extra_op_rect :
    (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
    armv8a_extra_op -> is_armv8a_extra_op -> 'a1 **)

let is_armv8a_extra_op_rect f f0 f1 _ = function
| Coq_is_Oarmv8a_swap (w, p_) -> f w p_
| Coq_is_Oarmv8a_add_large_imm -> f0
| Coq_is_Oarmv8a_smart_li (w, p_) -> f1 w p_

(** val is_armv8a_extra_op_rec :
    (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
    armv8a_extra_op -> is_armv8a_extra_op -> 'a1 **)

let is_armv8a_extra_op_rec f f0 f1 _ = function
| Coq_is_Oarmv8a_swap (w, p_) -> f w p_
| Coq_is_Oarmv8a_add_large_imm -> f0
| Coq_is_Oarmv8a_smart_li (w, p_) -> f1 w p_

(** val armv8a_extra_op_tag : armv8a_extra_op -> positive **)

let armv8a_extra_op_tag = function
| Oarmv8a_swap _ -> Coq_xH
| Oarmv8a_add_large_imm -> Coq_xO Coq_xH
| Oarmv8a_smart_li _ -> Coq_xI Coq_xH

(** val is_armv8a_extra_op_inhab : armv8a_extra_op -> is_armv8a_extra_op **)

let is_armv8a_extra_op_inhab = function
| Oarmv8a_swap h -> Coq_is_Oarmv8a_swap (h, (is_wsize_inhab h))
| Oarmv8a_add_large_imm -> Coq_is_Oarmv8a_add_large_imm
| Oarmv8a_smart_li h -> Coq_is_Oarmv8a_smart_li (h, (is_wsize_inhab h))

(** val is_armv8a_extra_op_functor :
    armv8a_extra_op -> is_armv8a_extra_op -> is_armv8a_extra_op **)

let rec is_armv8a_extra_op_functor _ x =
  x

type box_armv8a_extra_op_Oarmv8a_swap =
  wsize
  (* singleton inductive, whose constructor was Box_armv8a_extra_op_Oarmv8a_swap *)

(** val coq_Box_armv8a_extra_op_Oarmv8a_swap_0 :
    box_armv8a_extra_op_Oarmv8a_swap -> wsize **)

let coq_Box_armv8a_extra_op_Oarmv8a_swap_0 record =
  record

type box_armv8a_extra_op_Oarmv8a_add_large_imm =
| Box_armv8a_extra_op_Oarmv8a_add_large_imm

type armv8a_extra_op_fields_t = __

(** val armv8a_extra_op_fields :
    armv8a_extra_op -> armv8a_extra_op_fields_t **)

let armv8a_extra_op_fields = function
| Oarmv8a_swap h -> Obj.magic h
| Oarmv8a_add_large_imm -> Obj.magic Box_armv8a_extra_op_Oarmv8a_add_large_imm
| Oarmv8a_smart_li h -> Obj.magic h

(** val armv8a_extra_op_construct :
    positive -> armv8a_extra_op_fields_t -> armv8a_extra_op option **)

let armv8a_extra_op_construct p b =
  match p with
  | Coq_xI _ -> Some (Oarmv8a_smart_li (Obj.magic b))
  | Coq_xO _ -> Some Oarmv8a_add_large_imm
  | Coq_xH -> Some (Oarmv8a_swap (Obj.magic b))

(** val armv8a_extra_op_induction :
    (wsize -> is_wsize -> 'a1) -> 'a1 -> (wsize -> is_wsize -> 'a1) ->
    armv8a_extra_op -> is_armv8a_extra_op -> 'a1 **)

let armv8a_extra_op_induction his_Oarmv8a_swap his_Oarmv8a_add_large_imm his_Oarmv8a_smart_li _ = function
| Coq_is_Oarmv8a_swap (x0, p_) -> his_Oarmv8a_swap x0 p_
| Coq_is_Oarmv8a_add_large_imm -> his_Oarmv8a_add_large_imm
| Coq_is_Oarmv8a_smart_li (x0, p_) -> his_Oarmv8a_smart_li x0 p_

(** val armv8a_extra_op_eqb_fields :
    (armv8a_extra_op -> armv8a_extra_op -> bool) -> positive ->
    armv8a_extra_op_fields_t -> armv8a_extra_op_fields_t -> bool **)

let armv8a_extra_op_eqb_fields _ x a b =
  match x with
  | Coq_xO _ -> true
  | _ -> (&&) (wsize_eqb (Obj.magic a) (Obj.magic b)) true

(** val armv8a_extra_op_eqb : armv8a_extra_op -> armv8a_extra_op -> bool **)

let armv8a_extra_op_eqb x1 x2 =
  match x1 with
  | Oarmv8a_swap h ->
    eqb_body armv8a_extra_op_tag armv8a_extra_op_fields
      (Obj.magic armv8a_extra_op_eqb_fields (fun _ _ -> true))
      (armv8a_extra_op_tag (Oarmv8a_swap h)) h x2
  | Oarmv8a_add_large_imm ->
    eqb_body armv8a_extra_op_tag armv8a_extra_op_fields
      (Obj.magic armv8a_extra_op_eqb_fields (fun _ _ -> true))
      (armv8a_extra_op_tag Oarmv8a_add_large_imm)
      Box_armv8a_extra_op_Oarmv8a_add_large_imm x2
  | Oarmv8a_smart_li h ->
    eqb_body armv8a_extra_op_tag armv8a_extra_op_fields
      (Obj.magic armv8a_extra_op_eqb_fields (fun _ _ -> true))
      (armv8a_extra_op_tag (Oarmv8a_smart_li h)) h x2

(** val armv8a_extra_op_eqb_OK :
    armv8a_extra_op -> armv8a_extra_op -> reflect **)

let armv8a_extra_op_eqb_OK =
  iffP2 armv8a_extra_op_eqb

(** val armv8a_extra_op_eqb_OK_sumbool :
    armv8a_extra_op -> armv8a_extra_op -> bool **)

let armv8a_extra_op_eqb_OK_sumbool =
  reflect_dec armv8a_extra_op_eqb armv8a_extra_op_eqb_OK

(** val coq_HB_unnamed_factory_1 : armv8a_extra_op Coq_hasDecEq.axioms_ **)

let coq_HB_unnamed_factory_1 =
  { Coq_hasDecEq.eq_op = armv8a_extra_op_eqb; Coq_hasDecEq.eqP =
    armv8a_extra_op_eqb_OK }

(** val armv8a_extra_armv8a_extra_op__canonical__eqtype_Equality :
    Equality.coq_type **)

let armv8a_extra_armv8a_extra_op__canonical__eqtype_Equality =
  Obj.magic coq_HB_unnamed_factory_1

(** val eqTC_armv8a_extra_op : armv8a_extra_op eqTypeC **)

let eqTC_armv8a_extra_op =
  { beq = armv8a_extra_op_eqb; ceqP = armv8a_extra_op_eqb_OK }

(** val coq_Oarmv8a_add_large_imm_instr : instruction_desc **)

let coq_Oarmv8a_add_large_imm_instr =
  let ty = Coq_aword armv8a_reg_size in
  let cty = eval_atype ty in
  let ctin = cty :: (cty :: []) in
  let semi0 = fun x y -> add_word armv8a_reg_size x y in
  { str = (fun _ -> "add_large_imm"); tin = (ty :: (ty :: [])); i_in =
  ((ADExplicit ((S O), ACR_any)) :: ((ADExplicit ((S (S O)),
  ACR_any)) :: [])); tout = (ty :: []); i_out = ((ADExplicit (O,
  ACR_any)) :: []); conflicts = (((APout O), (APin O)) :: []); semi =
  (sem_prod_ok ctin (Obj.magic semi0)); i_valid = true; i_safe = []; i_doit =
  DOIT }

(** val smart_li_instr : wsize -> instruction_desc **)

let smart_li_instr ws =
  { str = (pp_sz "smart_li" ws); tin = ((Coq_aword ws) :: []); i_in =
    ((ADExplicit (O, ACR_any)) :: []); tout = ((Coq_aword ws) :: []); i_out =
    ((ADExplicit ((S O), ACR_any)) :: []); conflicts = []; semi =
    (sem_prod_ok (map eval_atype ((Coq_aword ws) :: []))
      (Obj.magic (fun x -> x)));
    i_valid = true; i_safe = []; i_doit = DOIT }

(** val get_instr_desc : armv8a_extra_op -> instruction_desc **)

let get_instr_desc = function
| Oarmv8a_swap sz -> coq_Oswap_instr (Coq_aword sz)
| Oarmv8a_add_large_imm -> coq_Oarmv8a_add_large_imm_instr
| Oarmv8a_smart_li ws -> smart_li_instr ws

(** val armv8a_extra_op_decl : armv8a_extra_op asmOp **)

let armv8a_extra_op_decl =
  { _eqT = eqTC_armv8a_extra_op; asm_op_instr = get_instr_desc; prim_string =
    [] }

module E =
 struct
  (** val pass_name : string **)

  let pass_name =
    "asmgen"

  (** val internal_error : instr_info -> string -> pp_error_loc **)

  let internal_error ii msg =
    { pel_msg = (PPEstring msg); pel_fn = None; pel_fi = None; pel_ii = (Some
      ii); pel_vi = None; pel_pass = (Some pass_name); pel_internal = true }

  (** val error : instr_info -> string -> pp_error_loc **)

  let error ii msg =
    { pel_msg = (PPEstring msg); pel_fn = None; pel_fi = None; pel_ii = (Some
      ii); pel_vi = None; pel_pass = (Some pass_name); pel_internal = false }
 end

(** val asm_args_of_opn_args :
    ARMv8AFopn_core.opn_args list -> (((register, empty, empty, rflag, condt,
    armv8a_asm_op) asm_op_msb_t * lexpr list) * rexpr list) list **)

let asm_args_of_opn_args =
  map (fun pat ->
    let (y, res) = pat in let (les, aop) = y in (((None, aop), les), res))

(** val uncons_LLvar :
    instr_info -> lexpr list -> (var_i * lexpr list) cexec **)

let uncons_LLvar ii = function
| [] -> Error (E.internal_error ii "invalid lvals")
| l :: les0 ->
  (match l with
   | Store (_, _, _) -> Error (E.internal_error ii "invalid lvals")
   | LLvar x -> Ok (x, les0))

(** val uncons_wconst :
    instr_info -> rexpr list -> (coq_Z * rexpr list) cexec **)

let uncons_wconst ii = function
| [] -> Error (E.internal_error ii "invalid arguments")
| r :: res' ->
  (match r with
   | Load (_, _, _) -> Error (E.internal_error ii "invalid arguments")
   | Rexpr f ->
     (match f with
      | Fapp1 (s, f0) ->
        (match s with
         | Oword_of_int _ ->
           (match f0 with
            | Fconst imm -> Ok (imm, res')
            | _ -> Error (E.internal_error ii "invalid arguments"))
         | _ -> Error (E.internal_error ii "invalid arguments"))
      | _ -> Error (E.internal_error ii "invalid arguments")))

(** val smart_li_args :
    instr_info -> Equality.sort -> lexpr list -> rexpr list -> (pp_error_loc,
    (var_i * coq_Z) * rexpr list) result **)

let smart_li_args ii ws les res =
  if (||) (eq_op wsize_wsize__canonical__eqtype_Equality ws (Obj.magic U64))
       (eq_op wsize_wsize__canonical__eqtype_Equality ws (Obj.magic U32))
  then (match uncons_LLvar ii les with
        | Ok x ->
          let (x0, les0) = x in
          if convertible (Var.vtype x0.v_var) (Coq_aword armv8a_decl.reg_size)
          then if nilp les0
               then (match uncons_wconst ii res with
                     | Ok x1 -> let (imm, res0) = x1 in Ok ((x0, imm), res0)
                     | Error s -> Error s)
               else let s = E.internal_error ii "invalid lvals" in Error s
          else let s = E.internal_error ii "invalid type" in Error s
        | Error s -> Error s)
  else let s =
         E.error ii
           "smart immediate assignment is only valid for u64 and u32 variables"
       in
       Error s

(** val assemble_smart_li :
    instr_info -> wsize -> lexpr list -> rexpr list -> (pp_error_loc,
    (((register, empty, empty, rflag, condt, armv8a_asm_op)
    asm_op_msb_t * lexpr list) * rexpr list) list) result **)

let assemble_smart_li ii ws les res =
  match smart_li_args ii (Obj.magic ws) les res with
  | Ok x ->
    let (y, _) = x in
    let (x0, imm) = y in
    Ok (asm_args_of_opn_args (ARMv8AFopn_core.li ws x0 imm))
  | Error s -> Error s

(** val assemble_extra :
    instr_info -> armv8a_extra_op -> lexpr list -> rexpr list -> (((register,
    empty, empty, rflag, condt, armv8a_asm_op) asm_op_msb_t * lexpr
    list) * rexpr list) list cexec **)

let assemble_extra ii o outx inx =
  match o with
  | Oarmv8a_swap sz ->
    if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic sz)
         (Obj.magic U64)
    then (match outx with
          | [] ->
            Error
              (E.error ii
                "only registers are accepted on source and destination of the swap instruction on armv8a")
          | l :: l0 ->
            (match l with
             | Store (_, _, _) ->
               Error
                 (E.error ii
                   "only registers are accepted on source and destination of the swap instruction on armv8a")
             | LLvar x ->
               (match l0 with
                | [] ->
                  Error
                    (E.error ii
                      "only registers are accepted on source and destination of the swap instruction on armv8a")
                | l1 :: l2 ->
                  (match l1 with
                   | Store (_, _, _) ->
                     Error
                       (E.error ii
                         "only registers are accepted on source and destination of the swap instruction on armv8a")
                   | LLvar y ->
                     (match l2 with
                      | [] ->
                        (match inx with
                         | [] ->
                           Error
                             (E.error ii
                               "only registers are accepted on source and destination of the swap instruction on armv8a")
                         | r :: l3 ->
                           (match r with
                            | Load (_, _, _) ->
                              Error
                                (E.error ii
                                  "only registers are accepted on source and destination of the swap instruction on armv8a")
                            | Rexpr f ->
                              (match f with
                               | Fvar z ->
                                 (match l3 with
                                  | [] ->
                                    Error
                                      (E.error ii
                                        "only registers are accepted on source and destination of the swap instruction on armv8a")
                                  | r0 :: l4 ->
                                    (match r0 with
                                     | Load (_, _, _) ->
                                       Error
                                         (E.error ii
                                           "only registers are accepted on source and destination of the swap instruction on armv8a")
                                     | Rexpr f0 ->
                                       (match f0 with
                                        | Fvar w ->
                                          (match l4 with
                                           | [] ->
                                             if negb
                                                  (eq_op
                                                    Var.coq_MvMake_var__canonical__eqtype_Equality
                                                    (Obj.magic x.v_var)
                                                    (Obj.magic w.v_var))
                                             then if negb
                                                       (eq_op
                                                         Var.coq_MvMake_var__canonical__eqtype_Equality
                                                         (Obj.magic y.v_var)
                                                         (Obj.magic x.v_var))
                                                  then if all (fun x0 ->
                                                            convertible
                                                              (Var.vtype
                                                                x0.v_var)
                                                              (Coq_aword U64))
                                                            (x :: (y :: (z :: (w :: []))))
                                                       then Ok ((((None,
                                                              (ARMv8A_op
                                                              (EOR,
                                                              default_opts))),
                                                              ((LLvar
                                                              x) :: [])),
                                                              ((Rexpr (Fvar
                                                              z)) :: ((Rexpr
                                                              (Fvar
                                                              w)) :: []))) :: ((((None,
                                                              (ARMv8A_op
                                                              (EOR,
                                                              default_opts))),
                                                              ((LLvar
                                                              y) :: [])),
                                                              ((Rexpr (Fvar
                                                              x)) :: ((Rexpr
                                                              (Fvar
                                                              w)) :: []))) :: ((((None,
                                                              (ARMv8A_op
                                                              (EOR,
                                                              default_opts))),
                                                              ((LLvar
                                                              x) :: [])),
                                                              ((Rexpr (Fvar
                                                              x)) :: ((Rexpr
                                                              (Fvar
                                                              y)) :: []))) :: [])))
                                                       else let s =
                                                              E.error ii
                                                                "armv8a swap is only valid for registers of type u64"
                                                            in
                                                            Error s
                                                  else let s =
                                                         E.internal_error ii
                                                           "bad armv8a swap : y = x"
                                                       in
                                                       Error s
                                             else let s =
                                                    E.internal_error ii
                                                      "bad armv8a swap : x = w"
                                                  in
                                                  Error s
                                           | _ :: _ ->
                                             Error
                                               (E.error ii
                                                 "only registers are accepted on source and destination of the swap instruction on armv8a"))
                                        | _ ->
                                          Error
                                            (E.error ii
                                              "only registers are accepted on source and destination of the swap instruction on armv8a"))))
                               | _ ->
                                 Error
                                   (E.error ii
                                     "only registers are accepted on source and destination of the swap instruction on armv8a"))))
                      | _ :: _ ->
                        Error
                          (E.error ii
                            "only registers are accepted on source and destination of the swap instruction on armv8a"))))))
    else Error
           (E.error ii "armv8a swap is only valid for registers of type u64")
  | Oarmv8a_add_large_imm ->
    (match outx with
     | [] ->
       Error
         (E.internal_error ii
           "bad armv8a_add_large_imm: invalid args or dests")
     | l :: l0 ->
       (match l with
        | Store (_, _, _) ->
          Error
            (E.internal_error ii
              "bad armv8a_add_large_imm: invalid args or dests")
        | LLvar x ->
          (match l0 with
           | [] ->
             (match inx with
              | [] ->
                Error
                  (E.internal_error ii
                    "bad armv8a_add_large_imm: invalid args or dests")
              | r :: l1 ->
                (match r with
                 | Load (_, _, _) ->
                   Error
                     (E.internal_error ii
                       "bad armv8a_add_large_imm: invalid args or dests")
                 | Rexpr f ->
                   (match f with
                    | Fvar y ->
                      (match l1 with
                       | [] ->
                         Error
                           (E.internal_error ii
                             "bad armv8a_add_large_imm: invalid args or dests")
                       | r0 :: l2 ->
                         (match r0 with
                          | Load (_, _, _) ->
                            Error
                              (E.internal_error ii
                                "bad armv8a_add_large_imm: invalid args or dests")
                          | Rexpr f0 ->
                            (match f0 with
                             | Fapp1 (s, f1) ->
                               (match s with
                                | Oword_of_int _ ->
                                  (match f1 with
                                   | Fconst imm ->
                                     (match l2 with
                                      | [] ->
                                        if negb
                                             (eq_op
                                               Var.coq_MvMake_var__canonical__eqtype_Equality
                                               (Obj.magic x.v_var)
                                               (Obj.magic y.v_var))
                                        then if all (fun x0 ->
                                                  convertible
                                                    (Var.vtype x0.v_var)
                                                    (Coq_aword U64))
                                                  (x :: (y :: []))
                                             then Ok
                                                    (asm_args_of_opn_args
                                                      (ARMv8AFopn_core.smart_addi
                                                        x y imm))
                                             else let s0 =
                                                    E.error ii
                                                      "armv8a_add_large_imm is only valid for registers of type u64"
                                                  in
                                                  Error s0
                                        else let s0 =
                                               E.internal_error ii
                                                 "bad armv8a_add_large_imm: invalid register"
                                             in
                                             Error s0
                                      | _ :: _ ->
                                        Error
                                          (E.internal_error ii
                                            "bad armv8a_add_large_imm: invalid args or dests"))
                                   | _ ->
                                     Error
                                       (E.internal_error ii
                                         "bad armv8a_add_large_imm: invalid args or dests"))
                                | _ ->
                                  Error
                                    (E.internal_error ii
                                      "bad armv8a_add_large_imm: invalid args or dests"))
                             | _ ->
                               Error
                                 (E.internal_error ii
                                   "bad armv8a_add_large_imm: invalid args or dests"))))
                    | _ ->
                      Error
                        (E.internal_error ii
                          "bad armv8a_add_large_imm: invalid args or dests"))))
           | _ :: _ ->
             Error
               (E.internal_error ii
                 "bad armv8a_add_large_imm: invalid args or dests"))))
  | Oarmv8a_smart_li ws -> assemble_smart_li ii ws outx inx

(** val armv8a_extra :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) asm_extra **)

let armv8a_extra atoI =
  { _asm = armv8a; _atoI = atoI; _extra = armv8a_extra_op_decl; to_asm =
    assemble_extra }

type armv8a_extended_op =
  (register, empty, empty, rflag, condt, armv8a_asm_op, armv8a_extra_op)
  extended_op

(** val coq_Oarmv8a :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op) asm_op_t' -> armv8a_extended_op sopn **)

let coq_Oarmv8a _ o =
  Oasm (BaseOp (None, o))
