(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open Arch_decl
open Arch_utils
open Eqtype
open Otbn_decl
open Otbn_instr_decl
open Riscv
open Utils0
open Word0
open Wsize

(** val eval_cond :
    (register -> word) -> (rflag -> bool exec) -> condition -> bool exec **)

let eval_cond getr getf = function
| RVcond (is_eq, r0, r1) ->
  let w0 = sem_cond_arg U32 getr r0 in
  let w1 = sem_cond_arg U32 getr r1 in
  Ok
  (if is_eq
   then eq_op (word_word__canonical__eqtype_Equality U32) (Obj.magic w0)
          (Obj.magic w1)
   else negb
          (eq_op (word_word__canonical__eqtype_Equality U32) (Obj.magic w0)
            (Obj.magic w1)))
| BNcond f -> getf f

(** val otbn :
    (register, empty, wide_register, rflag, condition, otbn_op) asm **)

let otbn =
  { _arch_decl = otbn_decl; _asm_op_decl = otbn_op_decl;
    Arch_decl.eval_cond = eval_cond }
