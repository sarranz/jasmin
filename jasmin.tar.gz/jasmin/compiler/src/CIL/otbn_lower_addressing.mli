(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Compiler_util
open Eqtype
open Expr
open Lea
open Memory_model
open Otbn_decl
open Otbn_extra
open Otbn_instr_decl
open Seq
open Ssrbool
open Type
open Utils0
open Var0
open Wsize

module E :
 sig
  val pass_name : string

  val error : string -> pp_error_loc
 end

val is_one_Pload : pexpr list -> ((aligned * wsize) * pexpr) option

val compute_glob_addr :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i -> pexpr -> ((register, empty, wide_register, rflag, condition,
  otbn_op, extra_op) extended_op instr_r list * pexpr) option

val lower_addressing_i :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i -> (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extended_op instr -> (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op instr list

val lower_addressing_c :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i -> (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extended_op instr list -> (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op instr list

val lower_addressing_fd :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i -> (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extended_op sfundef -> (pp_error_loc, ((register, empty,
  wide_register, rflag, condition, otbn_op, extra_op) extended_op,
  extra_fun_t) _fundef) result

val lower_addressing_prog :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> (string
  -> atype -> Ident.Ident.ident) -> (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op sprog -> (register, empty,
  wide_register, rflag, condition, otbn_op, extra_op) extended_op sprog cexec
