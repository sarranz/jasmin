(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open Eqtype
open Ssrnat

type __ = Obj.t

module GRing :
 sig
  module Coq_isNmodule :
   sig
    type 'v axioms_ = { zero : 'v; add : ('v -> 'v -> 'v) }

    val zero : 'a1 axioms_ -> 'a1

    val add : 'a1 axioms_ -> 'a1 -> 'a1 -> 'a1

    val phant_Build : 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_
   end

  module Nmodule :
   sig
    type 'v axioms_ = { coq_GRing_isNmodule_mixin : 'v Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'v
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'v Coq_hasDecEq.axioms_ }

    val coq_GRing_isNmodule_mixin : 'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    val coq_class : coq_type -> sort axioms_
   end

  val zero : Nmodule.coq_type -> Nmodule.sort

  val add : Nmodule.coq_type -> Nmodule.sort -> Nmodule.sort -> Nmodule.sort

  val natmul : Nmodule.coq_type -> Nmodule.sort -> nat -> Nmodule.sort

  module Nmodule_isZmodule :
   sig
    type 'v axioms_ =
      'v -> 'v
      (* singleton inductive, whose constructor was Axioms_ *)

    val opp :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 axioms_ -> 'a1 -> 'a1

    val phant_Build :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> Nmodule.coq_type -> 'a2 Nmodule.axioms_ -> 'a2
      Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
      Coq_hasDecEq.axioms_ -> Choice.Choice.coq_type -> 'a3
      Choice.Choice.axioms_ -> 'a3 Choice.Coq_hasChoice.axioms_ -> 'a3
      Coq_hasDecEq.axioms_ -> Equality.coq_type -> 'a4 Equality.axioms_ ->
      'a4 Coq_hasDecEq.axioms_ -> ('a1 -> 'a1) -> 'a1 axioms_
   end

  module Zmodule :
   sig
    type 'v axioms_ = { coq_GRing_isNmodule_mixin : 'v Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'v
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'v Coq_hasDecEq.axioms_;
                        coq_GRing_Nmodule_isZmodule_mixin : 'v
                                                            Nmodule_isZmodule.axioms_ }

    val coq_GRing_isNmodule_mixin : 'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_

    val choice_hasChoice_mixin :
      'a1 axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_

    val eqtype_hasDecEq_mixin : 'a1 axioms_ -> 'a1 Coq_hasDecEq.axioms_

    val coq_GRing_Nmodule_isZmodule_mixin :
      'a1 axioms_ -> 'a1 Nmodule_isZmodule.axioms_

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    val coq_class : coq_type -> sort axioms_
   end

  val opp : Zmodule.coq_type -> Zmodule.sort -> Zmodule.sort

  module Coq_isZmodule :
   sig
    type 'v axioms_ = { zero : 'v; opp : ('v -> 'v); add : ('v -> 'v -> 'v) }

    val zero :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> 'a1
      axioms_ -> 'a1

    val opp :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> 'a1
      axioms_ -> 'a1 -> 'a1

    val add :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> 'a1
      axioms_ -> 'a1 -> 'a1 -> 'a1

    val phant_Build :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ ->
      Choice.Choice.coq_type -> 'a2 Choice.Choice.axioms_ -> 'a2
      Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ ->
      Equality.coq_type -> 'a3 Equality.axioms_ -> 'a3 Coq_hasDecEq.axioms_
      -> 'a1 -> ('a1 -> 'a1) -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_

    type ('v, 'tlocal, 'tlocal0) phant_axioms = 'v axioms_
   end

  module Builders_8 :
   sig
    val coq_Builders_8_V__canonical__eqtype_Equality :
      'a1 Coq_hasDecEq.axioms_ -> Equality.coq_type

    val coq_Builders_8_V__canonical__choice_Choice :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ ->
      Choice.Choice.coq_type

    val coq_HB_unnamed_factory_10 :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> ('a1,
      'a1, 'a1) Coq_isZmodule.phant_axioms -> 'a1 Coq_isNmodule.axioms_

    val coq_Builders_8_V__canonical__GRing_Nmodule :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> ('a1,
      'a1, 'a1) Coq_isZmodule.phant_axioms -> Nmodule.coq_type

    val coq_HB_unnamed_factory_12 :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> ('a1,
      'a1, 'a1) Coq_isZmodule.phant_axioms -> 'a1 Nmodule_isZmodule.axioms_
   end

  module Nmodule_isPzSemiRing :
   sig
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    val one :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 axioms_ -> 'a1

    val mul :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 axioms_ -> 'a1 -> 'a1 -> 'a1

    val phant_Build :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> Nmodule.coq_type -> 'a2 Nmodule.axioms_ -> 'a2
      Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
      Coq_hasDecEq.axioms_ -> Choice.Choice.coq_type -> 'a3
      Choice.Choice.axioms_ -> 'a3 Choice.Coq_hasChoice.axioms_ -> 'a3
      Coq_hasDecEq.axioms_ -> Equality.coq_type -> 'a4 Equality.axioms_ ->
      'a4 Coq_hasDecEq.axioms_ -> 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_
   end

  module PzSemiRing :
   sig
    type 'r axioms_ = { coq_GRing_isNmodule_mixin : 'r Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'r
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'r Coq_hasDecEq.axioms_;
                        coq_GRing_Nmodule_isPzSemiRing_mixin : 'r
                                                               Nmodule_isPzSemiRing.axioms_ }

    val coq_GRing_isNmodule_mixin : 'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_

    val choice_hasChoice_mixin :
      'a1 axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_

    val eqtype_hasDecEq_mixin : 'a1 axioms_ -> 'a1 Coq_hasDecEq.axioms_

    val coq_GRing_Nmodule_isPzSemiRing_mixin :
      'a1 axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    val coq_class : coq_type -> sort axioms_

    module Exports :
     sig
      val coq_GRing_PzSemiRing_class__to__GRing_Nmodule_class :
        'a1 axioms_ -> 'a1 Nmodule.axioms_

      val coq_GRing_PzSemiRing__to__GRing_Nmodule :
        coq_type -> Nmodule.coq_type
     end
   end

  val one : PzSemiRing.coq_type -> PzSemiRing.sort

  val mul :
    PzSemiRing.coq_type -> PzSemiRing.sort -> PzSemiRing.sort ->
    PzSemiRing.sort

  module PzSemiRing_isNonZero :
   sig
    type 'r axioms_ =
    | Axioms_

    val phant_Build :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ ->
      PzSemiRing.coq_type -> 'a2 PzSemiRing.axioms_ -> 'a2
      Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
      Coq_hasDecEq.axioms_ -> 'a2 Nmodule_isPzSemiRing.axioms_ -> 'a1 axioms_
   end

  module Zmodule_isPzRing :
   sig
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    val one :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_ ->
      'a1

    val mul :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_ ->
      'a1 -> 'a1 -> 'a1

    val phant_Build :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
      Zmodule.coq_type -> 'a2 Zmodule.axioms_ -> 'a2 Coq_isNmodule.axioms_ ->
      'a2 Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ -> 'a2
      Nmodule_isZmodule.axioms_ -> 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_

    type ('r, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_46 :
   sig
    val coq_Builders_46_R__canonical__eqtype_Equality :
      'a1 Coq_hasDecEq.axioms_ -> Equality.coq_type

    val coq_Builders_46_R__canonical__choice_Choice :
      'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ ->
      Choice.Choice.coq_type

    val coq_Builders_46_R__canonical__GRing_Nmodule :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> Nmodule.coq_type

    val coq_HB_unnamed_factory_48 :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isPzRing.phant_axioms -> 'a1 Nmodule_isPzSemiRing.axioms_
   end

  module Zmodule_isNzRing :
   sig
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    val one :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_ ->
      'a1

    val mul :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_ ->
      'a1 -> 'a1 -> 'a1

    val phant_Build :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
      Zmodule.coq_type -> 'a2 Zmodule.axioms_ -> 'a2 Coq_isNmodule.axioms_ ->
      'a2 Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ -> 'a2
      Nmodule_isZmodule.axioms_ -> 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_

    type ('r, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_59 :
   sig
    val coq_Builders_59_R__canonical__GRing_Zmodule :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
      Zmodule.coq_type

    val coq_HB_unnamed_factory_61 :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isNzRing.phant_axioms -> 'a1 Zmodule_isPzRing.axioms_

    val coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isNzRing.phant_axioms -> 'a1 Nmodule_isPzSemiRing.axioms_

    val coq_Builders_59_R__canonical__GRing_PzSemiRing :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isNzRing.phant_axioms -> PzSemiRing.coq_type

    val coq_HB_unnamed_factory_63 :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isNzRing.phant_axioms -> 'a1 PzSemiRing_isNonZero.axioms_
   end

  module PzSemiRing_hasCommutativeMul :
   sig
    type 'r axioms_ =
    | Axioms_

    val phant_Build :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ ->
      PzSemiRing.coq_type -> 'a2 PzSemiRing.axioms_ -> 'a2
      Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
      Coq_hasDecEq.axioms_ -> 'a2 Nmodule_isPzSemiRing.axioms_ -> 'a1 axioms_
   end

  module PzRing_hasCommutativeMul :
   sig
    type 'r axioms_ =
    | Axioms_

    val phant_Build :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ -> 'a1
      Nmodule_isZmodule.axioms_ -> PzSemiRing.coq_type -> 'a2
      PzSemiRing.axioms_ -> 'a2 Coq_isNmodule.axioms_ -> 'a2
      Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ -> 'a2
      Nmodule_isPzSemiRing.axioms_ -> Zmodule.coq_type -> 'a3 Zmodule.axioms_
      -> 'a3 Coq_isNmodule.axioms_ -> 'a3 Choice.Coq_hasChoice.axioms_ -> 'a3
      Coq_hasDecEq.axioms_ -> 'a3 Nmodule_isZmodule.axioms_ -> 'a1 axioms_

    type ('r, 'rlocal, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_332 :
   sig
    val coq_Builders_332_R__canonical__GRing_PzSemiRing :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ ->
      PzSemiRing.coq_type

    val coq_HB_unnamed_factory_334 :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ -> 'a1
      Nmodule_isZmodule.axioms_ -> ('a1, 'a1, 'a1)
      PzRing_hasCommutativeMul.phant_axioms -> 'a1
      PzSemiRing_hasCommutativeMul.axioms_
   end

  module ComNzRing :
   sig
    type 'r axioms_ = { coq_GRing_isNmodule_mixin : 'r Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'r
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'r Coq_hasDecEq.axioms_;
                        coq_GRing_Nmodule_isZmodule_mixin : 'r
                                                            Nmodule_isZmodule.axioms_;
                        coq_GRing_Nmodule_isPzSemiRing_mixin : 'r
                                                               Nmodule_isPzSemiRing.axioms_;
                        coq_GRing_PzSemiRing_isNonZero_mixin : 'r
                                                               PzSemiRing_isNonZero.axioms_;
                        coq_GRing_PzSemiRing_hasCommutativeMul_mixin : 
                        'r PzSemiRing_hasCommutativeMul.axioms_ }

    val coq_GRing_isNmodule_mixin : 'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_

    val choice_hasChoice_mixin :
      'a1 axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_

    val coq_GRing_Nmodule_isZmodule_mixin :
      'a1 axioms_ -> 'a1 Nmodule_isZmodule.axioms_

    val coq_GRing_Nmodule_isPzSemiRing_mixin :
      'a1 axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    val coq_class : coq_type -> sort axioms_
   end

  module Zmodule_isComNzRing :
   sig
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    val one :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_ ->
      'a1

    val mul :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_ ->
      'a1 -> 'a1 -> 'a1

    type ('r, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_344 :
   sig
    val coq_Builders_344_R__canonical__GRing_Zmodule :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
      Zmodule.coq_type

    val coq_HB_unnamed_factory_346 :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isComNzRing.phant_axioms -> 'a1 Zmodule_isNzRing.axioms_

    val coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_isNonZero :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isComNzRing.phant_axioms -> 'a1 PzSemiRing_isNonZero.axioms_

    val coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isComNzRing.phant_axioms -> 'a1 Nmodule_isPzSemiRing.axioms_

    val coq_Builders_344_R__canonical__GRing_PzSemiRing :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isComNzRing.phant_axioms -> PzSemiRing.coq_type

    val coq_HB_unnamed_factory_349 :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isComNzRing.phant_axioms -> 'a1 PzRing_hasCommutativeMul.axioms_

    val coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_hasCommutativeMul :
      'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
      Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
      Zmodule_isComNzRing.phant_axioms -> 'a1
      PzSemiRing_hasCommutativeMul.axioms_
   end
 end
