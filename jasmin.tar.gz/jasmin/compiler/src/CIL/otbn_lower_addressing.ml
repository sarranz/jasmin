(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Compiler_util
open Eqtype
open Expr
open Lea
open Memory_model
open Otbn_decl
open Otbn_extra
open Otbn_instr_decl
open Seq
open Ssrbool
open Type
open Utils0
open Var0
open Wsize

module E =
 struct
  (** val pass_name : string **)

  let pass_name =
    "lower_addressing"

  (** val error : string -> pp_error_loc **)

  let error msg =
    { pel_msg = (PPEstring msg); pel_fn = None; pel_fi = None; pel_ii = None;
      pel_vi = None; pel_pass = (Some pass_name); pel_internal = true }
 end

(** val is_one_Pload : pexpr list -> ((aligned * wsize) * pexpr) option **)

let is_one_Pload = function
| [] -> None
| p :: l ->
  (match p with
   | Pload (al, ws, e) ->
     (match l with
      | [] -> Some ((al, ws), e)
      | _ :: _ -> None)
   | _ -> None)

(** val compute_glob_addr :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i -> pexpr -> ((register, empty, wide_register, rflag, condition,
    otbn_op, extra_op) extended_op instr_r list * pexpr) option **)

let compute_glob_addr atoI rip tmp e =
  match mk_lea (arch_pd otbn_decl) e with
  | Some lea ->
    (match lea.lea_base with
     | Some base ->
       (match oassert
                ((&&)
                  (eq_op Var.coq_MvMake_var__canonical__eqtype_Equality
                    (Obj.magic rip.v_var) (Obj.magic base.v_var))
                  (negb (isSome lea.lea_offset))) with
        | Some _ ->
          Some (((Copn (((Lvar tmp) :: []), AT_none,
            (coq_Ootbn atoI (RV32 LA)), (e :: []))) :: []), (coq_Plvar tmp))
        | None -> None)
     | None -> None)
  | None -> None

(** val lower_addressing_i :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i -> (register, empty, wide_register, rflag, condition, otbn_op,
    extra_op) extended_op instr -> (register, empty, wide_register, rflag,
    condition, otbn_op, extra_op) extended_op instr list **)

let rec lower_addressing_i atoI rip tmp i = match i with
| MkI (ii, ir) ->
  (match ir with
   | Copn (xs, t, o, es) ->
     (match is_one_Pload es with
      | Some p ->
        let (p0, e) = p in
        let (al, ws) = p0 in
        (match compute_glob_addr atoI rip tmp e with
         | Some p1 ->
           let (prelude, p2) = p1 in
           map (fun i0 -> MkI (ii, i0))
             (cat prelude ((Copn (xs, t, o, ((Pload (al, ws,
               p2)) :: []))) :: []))
         | None -> i :: [])
      | None -> i :: [])
   | Cif (b, c1, c2) ->
     let c3 = conc_map (lower_addressing_i atoI rip tmp) c1 in
     let c4 = conc_map (lower_addressing_i atoI rip tmp) c2 in
     (MkI (ii, (Cif (b, c3, c4)))) :: []
   | Cfor (fi, c) ->
     let c0 = conc_map (lower_addressing_i atoI rip tmp) c in
     (MkI (ii, (Cfor (fi, c0)))) :: []
   | Cwhile (a, c, e, ii', c') ->
     let c0 = conc_map (lower_addressing_i atoI rip tmp) c in
     let c'0 = conc_map (lower_addressing_i atoI rip tmp) c' in
     (MkI (ii, (Cwhile (a, c0, e, ii', c'0)))) :: []
   | _ -> i :: [])

(** val lower_addressing_c :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i -> (register, empty, wide_register, rflag, condition, otbn_op,
    extra_op) extended_op instr list -> (register, empty, wide_register,
    rflag, condition, otbn_op, extra_op) extended_op instr list **)

let lower_addressing_c atoI rip tmp =
  conc_map (lower_addressing_i atoI rip tmp)

(** val lower_addressing_fd :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i -> (register, empty, wide_register, rflag, condition, otbn_op,
    extra_op) extended_op sfundef -> (pp_error_loc, ((register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op,
    extra_fun_t) _fundef) result **)

let lower_addressing_fd atoI rip tmp fd =
  let body = fd.f_body in
  if negb
       (SvExtra.Sv.mem (Obj.magic tmp.v_var)
         (read_c (asm_opI (otbn_extra atoI)) body))
  then if negb (SvExtra.Sv.mem (Obj.magic tmp.v_var) (vars_l fd.f_res))
       then Ok
              (with_body (asm_opI (otbn_extra atoI)) fd
                (lower_addressing_c atoI rip tmp body))
       else let s = E.error "fresh variable not fresh (res)" in Error s
  else let s = E.error "fresh variable not fresh (body)" in Error s

(** val lower_addressing_prog :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (string -> atype -> Ident.Ident.ident) -> (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op sprog ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op sprog cexec **)

let lower_addressing_prog atoI fresh_reg p =
  let rip =
    mk_var_i { Var.vtype = (Coq_aword (arch_pd otbn_decl)); Var.vname =
      (Obj.magic p).p_extra.sp_rip }
  in
  let tmp = { Var.vtype = (Coq_aword (arch_pd otbn_decl)); Var.vname =
    (fresh_reg "__tmp__" (Coq_aword (arch_pd otbn_decl))) }
  in
  let tmpi = mk_var_i tmp in
  (match map_cfprog_gen (fun x -> x.f_info)
           (lower_addressing_fd atoI rip tmpi) p.p_funcs with
   | Ok x -> Ok { p_funcs = x; p_globs = p.p_globs; p_extra = p.p_extra }
   | Error s -> Error s)
