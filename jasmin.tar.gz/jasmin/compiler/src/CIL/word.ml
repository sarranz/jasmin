(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Nat0
open PeanoNat
open Prelude
open Zpower
open Bigop
open Div
open Eqtype
open Fintype
open Ssralg
open Ssrint
open Ssrnat
open Tuple
open Word_ssrZ

let __ = let rec f _ = Obj.repr f in Obj.repr f

(** val modulus : nat -> coq_Z **)

let modulus =
  two_power_nat

type word = coq_Z
  (* singleton inductive, whose constructor was mkWord *)

(** val coq_HB_unnamed_factory_1 : nat -> (coq_Z, word) Coq_isSub.axioms_ **)

let coq_HB_unnamed_factory_1 _ =
  { Coq_isSub.val_subdef = (fun w -> w); Coq_isSub.coq_Sub = (fun x _ -> x);
    Coq_isSub.coq_Sub_rect = (fun _ k_S u -> k_S u __) }

(** val word_word__canonical__eqtype_SubType :
    nat -> coq_Z SubType.coq_type **)

let word_word__canonical__eqtype_SubType nbits =
  Obj.magic coq_HB_unnamed_factory_1 nbits

(** val coq_HB_unnamed_factory_3 : nat -> word Equality.axioms_ **)

let coq_HB_unnamed_factory_3 nbits =
  Obj.magic eqtype_sub_type__canonical__eqtype_Equality
    coq_BinNums_Z__canonical__eqtype_Equality (fun x ->
    (&&) (Z.leb Z0 (Obj.magic x)) (Z.ltb (Obj.magic x) (modulus nbits)))
    (reverse_coercion (Obj.magic word_word__canonical__eqtype_SubType nbits)
      __)

(** val coq_HB_unnamed_mixin_5 : nat -> word Coq_hasDecEq.axioms_ **)

let coq_HB_unnamed_mixin_5 =
  coq_HB_unnamed_factory_3

(** val word_word__canonical__eqtype_Equality : nat -> Equality.coq_type **)

let word_word__canonical__eqtype_Equality nbits =
  Obj.magic coq_HB_unnamed_mixin_5 nbits

(** val coq_HB_unnamed_factory_6 : nat -> word Choice.Countable.axioms_ **)

let coq_HB_unnamed_factory_6 nbits =
  Obj.magic Choice.eqtype_sub_type__canonical__choice_Countable
    coq_BinNums_Z__canonical__choice_Countable (fun x ->
    (&&) (Z.leb Z0 (Obj.magic x)) (Z.ltb (Obj.magic x) (modulus nbits)))
    (reverse_coercion (Obj.magic word_word__canonical__eqtype_SubType nbits)
      __)

(** val coq_HB_unnamed_mixin_10 : nat -> word Choice.Coq_hasChoice.axioms_ **)

let coq_HB_unnamed_mixin_10 nbits =
  (coq_HB_unnamed_factory_6 nbits).Choice.Countable.choice_hasChoice_mixin

(** val mkword : nat -> coq_Z -> word **)

let mkword n z =
  zmod_pow2 z n

(** val urepr : nat -> word -> coq_Z **)

let urepr _ w =
  w

(** val word0 : nat -> word **)

let word0 _ =
  Z0

(** val wsize : nat -> word -> nat **)

let wsize n _ =
  n

(** val add_word : nat -> word -> word -> word **)

let add_word n w1 w2 =
  mkword n (Z.add (urepr n w1) (urepr n w2))

(** val sub_word : nat -> word -> word -> word **)

let sub_word n w1 w2 =
  mkword n (Z.sub (urepr n w1) (urepr n w2))

(** val opp_word : nat -> word -> word **)

let opp_word n w =
  mkword n (Z.opp (urepr n w))

(** val mul_word : nat -> word -> word -> word **)

let mul_word n w1 w2 =
  mkword n (Z.mul (urepr n w1) (urepr n w2))

(** val coq_HB_unnamed_factory_12 :
    nat -> word GRing.Coq_isZmodule.axioms_ **)

let coq_HB_unnamed_factory_12 n =
  { GRing.Coq_isZmodule.zero = (word0 n); GRing.Coq_isZmodule.opp =
    (opp_word n); GRing.Coq_isZmodule.add = (add_word n) }

(** val coq_HB_unnamed_mixin_15 : nat -> word GRing.Coq_isNmodule.axioms_ **)

let coq_HB_unnamed_mixin_15 n =
  GRing.Builders_8.coq_HB_unnamed_factory_10 (coq_HB_unnamed_mixin_10 n)
    (coq_HB_unnamed_mixin_5 n) (coq_HB_unnamed_factory_12 n)

(** val coq_HB_unnamed_mixin_16 :
    nat -> word GRing.Nmodule_isZmodule.axioms_ **)

let coq_HB_unnamed_mixin_16 n =
  GRing.Builders_8.coq_HB_unnamed_factory_12 (coq_HB_unnamed_mixin_10 n)
    (coq_HB_unnamed_mixin_5 n) (coq_HB_unnamed_factory_12 n)

(** val word1 : nat -> word **)

let word1 _ =
  Zpos Coq_xH

(** val coq_HB_unnamed_factory_32 :
    nat -> word GRing.Zmodule_isComNzRing.axioms_ **)

let coq_HB_unnamed_factory_32 n =
  { GRing.Zmodule_isComNzRing.one = (word1 n);
    GRing.Zmodule_isComNzRing.mul = (mul_word (S n)) }

(** val coq_HB_unnamed_mixin_36 :
    nat -> word GRing.Nmodule_isPzSemiRing.axioms_ **)

let coq_HB_unnamed_mixin_36 n =
  GRing.Builders_344.coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing
    (coq_HB_unnamed_mixin_15 (S n)) (coq_HB_unnamed_mixin_10 (S n))
    (coq_HB_unnamed_mixin_5 (S n)) (coq_HB_unnamed_mixin_16 (S n))
    (coq_HB_unnamed_factory_32 n)

(** val coq_HB_unnamed_mixin_37 :
    nat -> word GRing.PzSemiRing_hasCommutativeMul.axioms_ **)

let coq_HB_unnamed_mixin_37 n =
  GRing.Builders_344.coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_hasCommutativeMul
    (coq_HB_unnamed_mixin_15 (S n)) (coq_HB_unnamed_mixin_10 (S n))
    (coq_HB_unnamed_mixin_5 (S n)) (coq_HB_unnamed_mixin_16 (S n))
    (coq_HB_unnamed_factory_32 n)

(** val coq_HB_unnamed_mixin_38 :
    nat -> word GRing.PzSemiRing_isNonZero.axioms_ **)

let coq_HB_unnamed_mixin_38 n =
  GRing.Builders_344.coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_isNonZero
    (coq_HB_unnamed_mixin_15 (S n)) (coq_HB_unnamed_mixin_10 (S n))
    (coq_HB_unnamed_mixin_5 (S n)) (coq_HB_unnamed_mixin_16 (S n))
    (coq_HB_unnamed_factory_32 n)

(** val word_word__canonical__GRing_ComNzRing :
    nat -> GRing.ComNzRing.coq_type **)

let word_word__canonical__GRing_ComNzRing n =
  { GRing.ComNzRing.coq_GRing_isNmodule_mixin =
    (Obj.magic coq_HB_unnamed_mixin_15 (S n));
    GRing.ComNzRing.choice_hasChoice_mixin =
    (Obj.magic coq_HB_unnamed_mixin_10 (S n));
    GRing.ComNzRing.eqtype_hasDecEq_mixin =
    (Obj.magic coq_HB_unnamed_mixin_5 (S n));
    GRing.ComNzRing.coq_GRing_Nmodule_isZmodule_mixin =
    (Obj.magic coq_HB_unnamed_mixin_16 (S n));
    GRing.ComNzRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
    (Obj.magic coq_HB_unnamed_mixin_36 n);
    GRing.ComNzRing.coq_GRing_PzSemiRing_isNonZero_mixin =
    (Obj.magic coq_HB_unnamed_mixin_38 n);
    GRing.ComNzRing.coq_GRing_PzSemiRing_hasCommutativeMul_mixin =
    (Obj.magic coq_HB_unnamed_mixin_37 n) }

(** val wbit : coq_Z -> nat -> bool **)

let wbit z n =
  Z.testbit z (Z.of_nat n)

(** val w2t : nat -> word -> bool tuple_of **)

let w2t n w =
  mktuple n (fun k -> wbit w (nat_of_ord n k))

(** val t2w_def : nat -> bool tuple_of -> coq_Z **)

let t2w_def n t =
  Coq_bigop.body Z0
    (Obj.magic index_enum (fintype_ordinal__canonical__fintype_Finite n))
    (fun i -> BigBody (i, Z.add, true,
    (Z.mul (two_power_nat (nat_of_ord n i))
      (Z.of_nat (nat_of_bool (tnth n t i))))))

(** val t2w : nat -> bool tuple_of -> word **)

let t2w =
  t2w_def

(** val srepr : nat -> word -> coq_Z **)

let srepr n w =
  if wbit w (pred (wsize n w)) then Z.sub w (modulus n) else w

(** val wand : nat -> word -> word -> word **)

let wand _ =
  Z.coq_land

(** val wor : nat -> word -> word -> word **)

let wor _ =
  Z.coq_lor

(** val wxor : nat -> word -> word -> word **)

let wxor _ =
  Z.coq_lxor

(** val pos_shiftr_nat : positive -> nat -> coq_Z **)

let rec pos_shiftr_nat p = function
| O -> Zpos p
| S n' ->
  (match p with
   | Coq_xI p' -> pos_shiftr_nat p' n'
   | Coq_xO p' -> pos_shiftr_nat p' n'
   | Coq_xH -> Z0)

(** val shiftr_nat : coq_Z -> nat -> coq_Z **)

let shiftr_nat a n =
  match a with
  | Z0 -> Z0
  | Zpos p -> pos_shiftr_nat p n
  | Zneg _ -> Nat.iter n Z.div2 a

(** val coq_lsr : nat -> word -> nat -> word **)

let coq_lsr n w k =
  shiftr_nat (urepr n w) k

(** val rotl : nat -> word -> nat -> word **)

let rotl n w k =
  t2w n
    (mktuple n (fun i ->
      wbit w (modn (addn (nat_of_ord n i) (subn n (modn k n))) n)))

(** val rotr : nat -> word -> nat -> word **)

let rotr n w k =
  t2w n (mktuple n (fun i -> wbit w (modn (addn (nat_of_ord n i) k) n)))

(** val subword : nat -> nat -> nat -> word -> word **)

let subword n i l w =
  mkword l (coq_lsr n w i)

(** val wcat_r : nat -> word list -> coq_Z **)

let rec wcat_r n = function
| [] -> Z0
| w :: s0 ->
  Z.coq_lor (urepr n w) (Z.shiftl (wcat_r n s0) (int_to_Z (Posz n)))
