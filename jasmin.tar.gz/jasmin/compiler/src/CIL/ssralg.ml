(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open Eqtype
open Ssrnat

type __ = Obj.t

module GRing =
 struct
  module Coq_isNmodule =
   struct
    type 'v axioms_ = { zero : 'v; add : ('v -> 'v -> 'v) }

    (** val zero : 'a1 axioms_ -> 'a1 **)

    let zero record =
      record.zero

    (** val add : 'a1 axioms_ -> 'a1 -> 'a1 -> 'a1 **)

    let add record =
      record.add

    (** val phant_Build : 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_ **)

    let phant_Build zero0 add0 =
      { zero = zero0; add = add0 }
   end

  module Nmodule =
   struct
    type 'v axioms_ = { coq_GRing_isNmodule_mixin : 'v Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'v
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'v Coq_hasDecEq.axioms_ }

    (** val coq_GRing_isNmodule_mixin :
        'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_ **)

    let coq_GRing_isNmodule_mixin record =
      record.coq_GRing_isNmodule_mixin

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    (** val coq_class : coq_type -> sort axioms_ **)

    let coq_class record =
      record
   end

  (** val zero : Nmodule.coq_type -> Nmodule.sort **)

  let zero s =
    s.Nmodule.coq_GRing_isNmodule_mixin.Coq_isNmodule.zero

  (** val add :
      Nmodule.coq_type -> Nmodule.sort -> Nmodule.sort -> Nmodule.sort **)

  let add s x x0 =
    s.Nmodule.coq_GRing_isNmodule_mixin.Coq_isNmodule.add x x0

  (** val natmul : Nmodule.coq_type -> Nmodule.sort -> nat -> Nmodule.sort **)

  let natmul v x n =
    iterop n (add v) x (zero v)

  module Nmodule_isZmodule =
   struct
    type 'v axioms_ =
      'v -> 'v
      (* singleton inductive, whose constructor was Axioms_ *)

    (** val opp :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 axioms_ -> 'a1 -> 'a1 **)

    let opp _ _ _ record =
      record

    (** val phant_Build :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> Nmodule.coq_type -> 'a2 Nmodule.axioms_ ->
        'a2 Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
        Coq_hasDecEq.axioms_ -> Choice.Choice.coq_type -> 'a3
        Choice.Choice.axioms_ -> 'a3 Choice.Coq_hasChoice.axioms_ -> 'a3
        Coq_hasDecEq.axioms_ -> Equality.coq_type -> 'a4 Equality.axioms_ ->
        'a4 Coq_hasDecEq.axioms_ -> ('a1 -> 'a1) -> 'a1 axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ opp0 =
      opp0
   end

  module Zmodule =
   struct
    type 'v axioms_ = { coq_GRing_isNmodule_mixin : 'v Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'v
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'v Coq_hasDecEq.axioms_;
                        coq_GRing_Nmodule_isZmodule_mixin : 'v
                                                            Nmodule_isZmodule.axioms_ }

    (** val coq_GRing_isNmodule_mixin :
        'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_ **)

    let coq_GRing_isNmodule_mixin record =
      record.coq_GRing_isNmodule_mixin

    (** val choice_hasChoice_mixin :
        'a1 axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ **)

    let choice_hasChoice_mixin record =
      record.choice_hasChoice_mixin

    (** val eqtype_hasDecEq_mixin :
        'a1 axioms_ -> 'a1 Coq_hasDecEq.axioms_ **)

    let eqtype_hasDecEq_mixin record =
      record.eqtype_hasDecEq_mixin

    (** val coq_GRing_Nmodule_isZmodule_mixin :
        'a1 axioms_ -> 'a1 Nmodule_isZmodule.axioms_ **)

    let coq_GRing_Nmodule_isZmodule_mixin record =
      record.coq_GRing_Nmodule_isZmodule_mixin

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    (** val coq_class : coq_type -> sort axioms_ **)

    let coq_class record =
      record
   end

  (** val opp : Zmodule.coq_type -> Zmodule.sort -> Zmodule.sort **)

  let opp s x =
    s.Zmodule.coq_GRing_Nmodule_isZmodule_mixin x

  module Coq_isZmodule =
   struct
    type 'v axioms_ = { zero : 'v; opp : ('v -> 'v); add : ('v -> 'v -> 'v) }

    (** val zero :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> 'a1
        axioms_ -> 'a1 **)

    let zero _ _ record =
      record.zero

    (** val opp :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> 'a1
        axioms_ -> 'a1 -> 'a1 **)

    let opp _ _ record =
      record.opp

    (** val add :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> 'a1
        axioms_ -> 'a1 -> 'a1 -> 'a1 **)

    let add _ _ record =
      record.add

    (** val phant_Build :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ ->
        Choice.Choice.coq_type -> 'a2 Choice.Choice.axioms_ -> 'a2
        Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ ->
        Equality.coq_type -> 'a3 Equality.axioms_ -> 'a3 Coq_hasDecEq.axioms_
        -> 'a1 -> ('a1 -> 'a1) -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ zero0 opp0 add0 =
      { zero = zero0; opp = opp0; add = add0 }

    type ('v, 'tlocal, 'tlocal0) phant_axioms = 'v axioms_
   end

  module Builders_8 =
   struct
    (** val coq_Builders_8_V__canonical__eqtype_Equality :
        'a1 Coq_hasDecEq.axioms_ -> Equality.coq_type **)

    let coq_Builders_8_V__canonical__eqtype_Equality local_mixin_eqtype_hasDecEq =
      Obj.magic local_mixin_eqtype_hasDecEq

    (** val coq_Builders_8_V__canonical__choice_Choice :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ ->
        Choice.Choice.coq_type **)

    let coq_Builders_8_V__canonical__choice_Choice local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq =
      { Choice.Choice.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        Choice.Choice.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq) }

    (** val coq_HB_unnamed_factory_10 :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> ('a1,
        'a1, 'a1) Coq_isZmodule.phant_axioms -> 'a1 Coq_isNmodule.axioms_ **)

    let coq_HB_unnamed_factory_10 _ _ fresh_name_9 =
      Coq_isNmodule.phant_Build fresh_name_9.Coq_isZmodule.zero
        fresh_name_9.Coq_isZmodule.add

    (** val coq_Builders_8_V__canonical__GRing_Nmodule :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> ('a1,
        'a1, 'a1) Coq_isZmodule.phant_axioms -> Nmodule.coq_type **)

    let coq_Builders_8_V__canonical__GRing_Nmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq fresh_name_9 =
      { Nmodule.coq_GRing_isNmodule_mixin =
        (coq_HB_unnamed_factory_10 (Obj.magic local_mixin_choice_hasChoice)
          (Obj.magic local_mixin_eqtype_hasDecEq) (Obj.magic fresh_name_9));
        Nmodule.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        Nmodule.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq) }

    (** val coq_HB_unnamed_factory_12 :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ -> ('a1,
        'a1, 'a1) Coq_isZmodule.phant_axioms -> 'a1 Nmodule_isZmodule.axioms_ **)

    let coq_HB_unnamed_factory_12 local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq fresh_name_9 =
      Nmodule_isZmodule.phant_Build
        (coq_HB_unnamed_factory_10 local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq fresh_name_9)
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        (coq_Builders_8_V__canonical__GRing_Nmodule
          local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
          fresh_name_9)
        { Nmodule.coq_GRing_isNmodule_mixin =
        (coq_HB_unnamed_factory_10 local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq fresh_name_9);
        Nmodule.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        Nmodule.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq }
        (coq_HB_unnamed_factory_10 local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq fresh_name_9)
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        (coq_Builders_8_V__canonical__choice_Choice
          local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq)
        { Choice.Choice.choice_hasChoice_mixin =
        local_mixin_choice_hasChoice; Choice.Choice.eqtype_hasDecEq_mixin =
        local_mixin_eqtype_hasDecEq } local_mixin_choice_hasChoice
        local_mixin_eqtype_hasDecEq
        (coq_Builders_8_V__canonical__eqtype_Equality
          local_mixin_eqtype_hasDecEq)
        local_mixin_eqtype_hasDecEq local_mixin_eqtype_hasDecEq
        fresh_name_9.Coq_isZmodule.opp
   end

  module Nmodule_isPzSemiRing =
   struct
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    (** val one :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 axioms_ -> 'a1 **)

    let one _ _ _ record =
      record.one

    (** val mul :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 axioms_ -> 'a1 -> 'a1 -> 'a1 **)

    let mul _ _ _ record =
      record.mul

    (** val phant_Build :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> Nmodule.coq_type -> 'a2 Nmodule.axioms_ ->
        'a2 Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
        Coq_hasDecEq.axioms_ -> Choice.Choice.coq_type -> 'a3
        Choice.Choice.axioms_ -> 'a3 Choice.Coq_hasChoice.axioms_ -> 'a3
        Coq_hasDecEq.axioms_ -> Equality.coq_type -> 'a4 Equality.axioms_ ->
        'a4 Coq_hasDecEq.axioms_ -> 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1 axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ one0 mul0 =
      { one = one0; mul = mul0 }
   end

  module PzSemiRing =
   struct
    type 'r axioms_ = { coq_GRing_isNmodule_mixin : 'r Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'r
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'r Coq_hasDecEq.axioms_;
                        coq_GRing_Nmodule_isPzSemiRing_mixin : 'r
                                                               Nmodule_isPzSemiRing.axioms_ }

    (** val coq_GRing_isNmodule_mixin :
        'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_ **)

    let coq_GRing_isNmodule_mixin record =
      record.coq_GRing_isNmodule_mixin

    (** val choice_hasChoice_mixin :
        'a1 axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ **)

    let choice_hasChoice_mixin record =
      record.choice_hasChoice_mixin

    (** val eqtype_hasDecEq_mixin :
        'a1 axioms_ -> 'a1 Coq_hasDecEq.axioms_ **)

    let eqtype_hasDecEq_mixin record =
      record.eqtype_hasDecEq_mixin

    (** val coq_GRing_Nmodule_isPzSemiRing_mixin :
        'a1 axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ **)

    let coq_GRing_Nmodule_isPzSemiRing_mixin record =
      record.coq_GRing_Nmodule_isPzSemiRing_mixin

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    (** val coq_class : coq_type -> sort axioms_ **)

    let coq_class record =
      record

    module Exports =
     struct
      (** val coq_GRing_PzSemiRing_class__to__GRing_Nmodule_class :
          'a1 axioms_ -> 'a1 Nmodule.axioms_ **)

      let coq_GRing_PzSemiRing_class__to__GRing_Nmodule_class c =
        { Nmodule.coq_GRing_isNmodule_mixin = c.coq_GRing_isNmodule_mixin;
          Nmodule.choice_hasChoice_mixin = c.choice_hasChoice_mixin;
          Nmodule.eqtype_hasDecEq_mixin = c.eqtype_hasDecEq_mixin }

      (** val coq_GRing_PzSemiRing__to__GRing_Nmodule :
          coq_type -> Nmodule.coq_type **)

      let coq_GRing_PzSemiRing__to__GRing_Nmodule =
        coq_GRing_PzSemiRing_class__to__GRing_Nmodule_class
     end
   end

  (** val one : PzSemiRing.coq_type -> PzSemiRing.sort **)

  let one s =
    s.PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin.Nmodule_isPzSemiRing.one

  (** val mul :
      PzSemiRing.coq_type -> PzSemiRing.sort -> PzSemiRing.sort ->
      PzSemiRing.sort **)

  let mul s x x0 =
    s.PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin.Nmodule_isPzSemiRing.mul
      x x0

  module PzSemiRing_isNonZero =
   struct
    type 'r axioms_ =
    | Axioms_

    (** val phant_Build :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ ->
        PzSemiRing.coq_type -> 'a2 PzSemiRing.axioms_ -> 'a2
        Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
        Coq_hasDecEq.axioms_ -> 'a2 Nmodule_isPzSemiRing.axioms_ -> 'a1
        axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ _ =
      Axioms_
   end

  module Zmodule_isPzRing =
   struct
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    (** val one :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_
        -> 'a1 **)

    let one _ _ _ _ record =
      record.one

    (** val mul :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_
        -> 'a1 -> 'a1 -> 'a1 **)

    let mul _ _ _ _ record =
      record.mul

    (** val phant_Build :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
        Zmodule.coq_type -> 'a2 Zmodule.axioms_ -> 'a2 Coq_isNmodule.axioms_
        -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ ->
        'a2 Nmodule_isZmodule.axioms_ -> 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1
        axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ _ one0 mul0 =
      { one = one0; mul = mul0 }

    type ('r, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_46 =
   struct
    (** val coq_Builders_46_R__canonical__eqtype_Equality :
        'a1 Coq_hasDecEq.axioms_ -> Equality.coq_type **)

    let coq_Builders_46_R__canonical__eqtype_Equality local_mixin_eqtype_hasDecEq =
      Obj.magic local_mixin_eqtype_hasDecEq

    (** val coq_Builders_46_R__canonical__choice_Choice :
        'a1 Choice.Coq_hasChoice.axioms_ -> 'a1 Coq_hasDecEq.axioms_ ->
        Choice.Choice.coq_type **)

    let coq_Builders_46_R__canonical__choice_Choice local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq =
      { Choice.Choice.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        Choice.Choice.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq) }

    (** val coq_Builders_46_R__canonical__GRing_Nmodule :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> Nmodule.coq_type **)

    let coq_Builders_46_R__canonical__GRing_Nmodule local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq =
      { Nmodule.coq_GRing_isNmodule_mixin =
        (Obj.magic local_mixin_GRing_isNmodule);
        Nmodule.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        Nmodule.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq) }

    (** val coq_HB_unnamed_factory_48 :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isPzRing.phant_axioms -> 'a1 Nmodule_isPzSemiRing.axioms_ **)

    let coq_HB_unnamed_factory_48 local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq _ fresh_name_47 =
      Nmodule_isPzSemiRing.phant_Build local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        (coq_Builders_46_R__canonical__GRing_Nmodule
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq)
        { Nmodule.coq_GRing_isNmodule_mixin = local_mixin_GRing_isNmodule;
        Nmodule.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        Nmodule.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq }
        local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
        local_mixin_eqtype_hasDecEq
        (coq_Builders_46_R__canonical__choice_Choice
          local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq)
        { Choice.Choice.choice_hasChoice_mixin =
        local_mixin_choice_hasChoice; Choice.Choice.eqtype_hasDecEq_mixin =
        local_mixin_eqtype_hasDecEq } local_mixin_choice_hasChoice
        local_mixin_eqtype_hasDecEq
        (coq_Builders_46_R__canonical__eqtype_Equality
          local_mixin_eqtype_hasDecEq)
        local_mixin_eqtype_hasDecEq local_mixin_eqtype_hasDecEq
        fresh_name_47.Zmodule_isPzRing.one fresh_name_47.Zmodule_isPzRing.mul
   end

  module Zmodule_isNzRing =
   struct
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    (** val one :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_
        -> 'a1 **)

    let one _ _ _ _ record =
      record.one

    (** val mul :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_
        -> 'a1 -> 'a1 -> 'a1 **)

    let mul _ _ _ _ record =
      record.mul

    (** val phant_Build :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
        Zmodule.coq_type -> 'a2 Zmodule.axioms_ -> 'a2 Coq_isNmodule.axioms_
        -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ ->
        'a2 Nmodule_isZmodule.axioms_ -> 'a1 -> ('a1 -> 'a1 -> 'a1) -> 'a1
        axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ _ one0 mul0 =
      { one = one0; mul = mul0 }

    type ('r, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_59 =
   struct
    (** val coq_Builders_59_R__canonical__GRing_Zmodule :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
        Zmodule.coq_type **)

    let coq_Builders_59_R__canonical__GRing_Zmodule local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule =
      { Zmodule.coq_GRing_isNmodule_mixin =
        (Obj.magic local_mixin_GRing_isNmodule);
        Zmodule.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        Zmodule.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq);
        Zmodule.coq_GRing_Nmodule_isZmodule_mixin =
        (Obj.magic local_mixin_GRing_Nmodule_isZmodule) }

    (** val coq_HB_unnamed_factory_61 :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isNzRing.phant_axioms -> 'a1 Zmodule_isPzRing.axioms_ **)

    let coq_HB_unnamed_factory_61 local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_60 =
      Zmodule_isPzRing.phant_Build local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isZmodule
        (coq_Builders_59_R__canonical__GRing_Zmodule
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule)
        { Zmodule.coq_GRing_isNmodule_mixin = local_mixin_GRing_isNmodule;
        Zmodule.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        Zmodule.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq;
        Zmodule.coq_GRing_Nmodule_isZmodule_mixin =
        local_mixin_GRing_Nmodule_isZmodule } local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isZmodule
        fresh_name_60.Zmodule_isNzRing.one fresh_name_60.Zmodule_isNzRing.mul

    (** val coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isNzRing.phant_axioms -> 'a1 Nmodule_isPzSemiRing.axioms_ **)

    let coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_60 =
      Builders_46.coq_HB_unnamed_factory_48 local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isZmodule
        (coq_HB_unnamed_factory_61 local_mixin_GRing_isNmodule
          local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
          local_mixin_GRing_Nmodule_isZmodule fresh_name_60)

    (** val coq_Builders_59_R__canonical__GRing_PzSemiRing :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isNzRing.phant_axioms -> PzSemiRing.coq_type **)

    let coq_Builders_59_R__canonical__GRing_PzSemiRing local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_60 =
      { PzSemiRing.coq_GRing_isNmodule_mixin =
        (Obj.magic local_mixin_GRing_isNmodule);
        PzSemiRing.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        PzSemiRing.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq);
        PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
        (coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing
          (Obj.magic local_mixin_GRing_isNmodule)
          (Obj.magic local_mixin_choice_hasChoice)
          (Obj.magic local_mixin_eqtype_hasDecEq)
          (Obj.magic local_mixin_GRing_Nmodule_isZmodule)
          (Obj.magic fresh_name_60)) }

    (** val coq_HB_unnamed_factory_63 :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isNzRing.phant_axioms -> 'a1 PzSemiRing_isNonZero.axioms_ **)

    let coq_HB_unnamed_factory_63 local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_60 =
      PzSemiRing_isNonZero.phant_Build local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        (coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_60)
        (coq_Builders_59_R__canonical__GRing_PzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_60)
        { PzSemiRing.coq_GRing_isNmodule_mixin = local_mixin_GRing_isNmodule;
        PzSemiRing.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        PzSemiRing.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq;
        PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
        (coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_60) }
        local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
        local_mixin_eqtype_hasDecEq
        (coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_60)
   end

  module PzSemiRing_hasCommutativeMul =
   struct
    type 'r axioms_ =
    | Axioms_

    (** val phant_Build :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ ->
        PzSemiRing.coq_type -> 'a2 PzSemiRing.axioms_ -> 'a2
        Coq_isNmodule.axioms_ -> 'a2 Choice.Coq_hasChoice.axioms_ -> 'a2
        Coq_hasDecEq.axioms_ -> 'a2 Nmodule_isPzSemiRing.axioms_ -> 'a1
        axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ _ =
      Axioms_
   end

  module PzRing_hasCommutativeMul =
   struct
    type 'r axioms_ =
    | Axioms_

    (** val phant_Build :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ -> 'a1
        Nmodule_isZmodule.axioms_ -> PzSemiRing.coq_type -> 'a2
        PzSemiRing.axioms_ -> 'a2 Coq_isNmodule.axioms_ -> 'a2
        Choice.Coq_hasChoice.axioms_ -> 'a2 Coq_hasDecEq.axioms_ -> 'a2
        Nmodule_isPzSemiRing.axioms_ -> Zmodule.coq_type -> 'a3
        Zmodule.axioms_ -> 'a3 Coq_isNmodule.axioms_ -> 'a3
        Choice.Coq_hasChoice.axioms_ -> 'a3 Coq_hasDecEq.axioms_ -> 'a3
        Nmodule_isZmodule.axioms_ -> 'a1 axioms_ **)

    let phant_Build _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ =
      Axioms_

    type ('r, 'rlocal, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_332 =
   struct
    (** val coq_Builders_332_R__canonical__GRing_PzSemiRing :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ ->
        PzSemiRing.coq_type **)

    let coq_Builders_332_R__canonical__GRing_PzSemiRing local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isPzSemiRing =
      { PzSemiRing.coq_GRing_isNmodule_mixin =
        (Obj.magic local_mixin_GRing_isNmodule);
        PzSemiRing.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        PzSemiRing.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq);
        PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
        (Obj.magic local_mixin_GRing_Nmodule_isPzSemiRing) }

    (** val coq_HB_unnamed_factory_334 :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ -> 'a1
        Nmodule_isZmodule.axioms_ -> ('a1, 'a1, 'a1)
        PzRing_hasCommutativeMul.phant_axioms -> 'a1
        PzSemiRing_hasCommutativeMul.axioms_ **)

    let coq_HB_unnamed_factory_334 local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isPzSemiRing _ _ =
      PzSemiRing_hasCommutativeMul.phant_Build local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isPzSemiRing
        (coq_Builders_332_R__canonical__GRing_PzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isPzSemiRing)
        { PzSemiRing.coq_GRing_isNmodule_mixin = local_mixin_GRing_isNmodule;
        PzSemiRing.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        PzSemiRing.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq;
        PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
        local_mixin_GRing_Nmodule_isPzSemiRing } local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isPzSemiRing
   end

  module ComNzRing =
   struct
    type 'r axioms_ = { coq_GRing_isNmodule_mixin : 'r Coq_isNmodule.axioms_;
                        choice_hasChoice_mixin : 'r
                                                 Choice.Coq_hasChoice.axioms_;
                        eqtype_hasDecEq_mixin : 'r Coq_hasDecEq.axioms_;
                        coq_GRing_Nmodule_isZmodule_mixin : 'r
                                                            Nmodule_isZmodule.axioms_;
                        coq_GRing_Nmodule_isPzSemiRing_mixin : 'r
                                                               Nmodule_isPzSemiRing.axioms_;
                        coq_GRing_PzSemiRing_isNonZero_mixin : 'r
                                                               PzSemiRing_isNonZero.axioms_;
                        coq_GRing_PzSemiRing_hasCommutativeMul_mixin : 
                        'r PzSemiRing_hasCommutativeMul.axioms_ }

    (** val coq_GRing_isNmodule_mixin :
        'a1 axioms_ -> 'a1 Coq_isNmodule.axioms_ **)

    let coq_GRing_isNmodule_mixin record =
      record.coq_GRing_isNmodule_mixin

    (** val choice_hasChoice_mixin :
        'a1 axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ **)

    let choice_hasChoice_mixin record =
      record.choice_hasChoice_mixin

    (** val coq_GRing_Nmodule_isZmodule_mixin :
        'a1 axioms_ -> 'a1 Nmodule_isZmodule.axioms_ **)

    let coq_GRing_Nmodule_isZmodule_mixin record =
      record.coq_GRing_Nmodule_isZmodule_mixin

    (** val coq_GRing_Nmodule_isPzSemiRing_mixin :
        'a1 axioms_ -> 'a1 Nmodule_isPzSemiRing.axioms_ **)

    let coq_GRing_Nmodule_isPzSemiRing_mixin record =
      record.coq_GRing_Nmodule_isPzSemiRing_mixin

    type coq_type =
      __ axioms_
      (* singleton inductive, whose constructor was Pack *)

    type sort = __

    (** val coq_class : coq_type -> sort axioms_ **)

    let coq_class record =
      record
   end

  module Zmodule_isComNzRing =
   struct
    type 'r axioms_ = { one : 'r; mul : ('r -> 'r -> 'r) }

    (** val one :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_
        -> 'a1 **)

    let one _ _ _ _ record =
      record.one

    (** val mul :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> 'a1 axioms_
        -> 'a1 -> 'a1 -> 'a1 **)

    let mul _ _ _ _ record =
      record.mul

    type ('r, 'vlocal) phant_axioms = 'r axioms_
   end

  module Builders_344 =
   struct
    (** val coq_Builders_344_R__canonical__GRing_Zmodule :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ ->
        Zmodule.coq_type **)

    let coq_Builders_344_R__canonical__GRing_Zmodule local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule =
      { Zmodule.coq_GRing_isNmodule_mixin =
        (Obj.magic local_mixin_GRing_isNmodule);
        Zmodule.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        Zmodule.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq);
        Zmodule.coq_GRing_Nmodule_isZmodule_mixin =
        (Obj.magic local_mixin_GRing_Nmodule_isZmodule) }

    (** val coq_HB_unnamed_factory_346 :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isComNzRing.phant_axioms -> 'a1 Zmodule_isNzRing.axioms_ **)

    let coq_HB_unnamed_factory_346 local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_345 =
      Zmodule_isNzRing.phant_Build local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isZmodule
        (coq_Builders_344_R__canonical__GRing_Zmodule
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule)
        { Zmodule.coq_GRing_isNmodule_mixin = local_mixin_GRing_isNmodule;
        Zmodule.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        Zmodule.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq;
        Zmodule.coq_GRing_Nmodule_isZmodule_mixin =
        local_mixin_GRing_Nmodule_isZmodule } local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isZmodule
        fresh_name_345.Zmodule_isComNzRing.one
        fresh_name_345.Zmodule_isComNzRing.mul

    (** val coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_isNonZero :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isComNzRing.phant_axioms -> 'a1 PzSemiRing_isNonZero.axioms_ **)

    let coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_isNonZero local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_345 =
      Builders_59.coq_HB_unnamed_factory_63 local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isZmodule
        (coq_HB_unnamed_factory_346 local_mixin_GRing_isNmodule
          local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
          local_mixin_GRing_Nmodule_isZmodule fresh_name_345)

    (** val coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isComNzRing.phant_axioms -> 'a1 Nmodule_isPzSemiRing.axioms_ **)

    let coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_345 =
      Builders_59.coq_GRing_Zmodule_isNzRing__to__GRing_Nmodule_isPzSemiRing
        local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
        local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
        (coq_HB_unnamed_factory_346 local_mixin_GRing_isNmodule
          local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
          local_mixin_GRing_Nmodule_isZmodule fresh_name_345)

    (** val coq_Builders_344_R__canonical__GRing_PzSemiRing :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isComNzRing.phant_axioms -> PzSemiRing.coq_type **)

    let coq_Builders_344_R__canonical__GRing_PzSemiRing local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_345 =
      { PzSemiRing.coq_GRing_isNmodule_mixin =
        (Obj.magic local_mixin_GRing_isNmodule);
        PzSemiRing.choice_hasChoice_mixin =
        (Obj.magic local_mixin_choice_hasChoice);
        PzSemiRing.eqtype_hasDecEq_mixin =
        (Obj.magic local_mixin_eqtype_hasDecEq);
        PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
        (coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing
          (Obj.magic local_mixin_GRing_isNmodule)
          (Obj.magic local_mixin_choice_hasChoice)
          (Obj.magic local_mixin_eqtype_hasDecEq)
          (Obj.magic local_mixin_GRing_Nmodule_isZmodule)
          (Obj.magic fresh_name_345)) }

    (** val coq_HB_unnamed_factory_349 :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isComNzRing.phant_axioms -> 'a1
        PzRing_hasCommutativeMul.axioms_ **)

    let coq_HB_unnamed_factory_349 local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_345 =
      PzRing_hasCommutativeMul.phant_Build local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        (coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_345)
        local_mixin_GRing_Nmodule_isZmodule
        (coq_Builders_344_R__canonical__GRing_PzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_345)
        { PzSemiRing.coq_GRing_isNmodule_mixin = local_mixin_GRing_isNmodule;
        PzSemiRing.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        PzSemiRing.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq;
        PzSemiRing.coq_GRing_Nmodule_isPzSemiRing_mixin =
        (coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_345) }
        local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
        local_mixin_eqtype_hasDecEq
        (coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_345)
        (coq_Builders_344_R__canonical__GRing_Zmodule
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule)
        { Zmodule.coq_GRing_isNmodule_mixin = local_mixin_GRing_isNmodule;
        Zmodule.choice_hasChoice_mixin = local_mixin_choice_hasChoice;
        Zmodule.eqtype_hasDecEq_mixin = local_mixin_eqtype_hasDecEq;
        Zmodule.coq_GRing_Nmodule_isZmodule_mixin =
        local_mixin_GRing_Nmodule_isZmodule } local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        local_mixin_GRing_Nmodule_isZmodule

    (** val coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_hasCommutativeMul :
        'a1 Coq_isNmodule.axioms_ -> 'a1 Choice.Coq_hasChoice.axioms_ -> 'a1
        Coq_hasDecEq.axioms_ -> 'a1 Nmodule_isZmodule.axioms_ -> ('a1, 'a1)
        Zmodule_isComNzRing.phant_axioms -> 'a1
        PzSemiRing_hasCommutativeMul.axioms_ **)

    let coq_GRing_Zmodule_isComNzRing__to__GRing_PzSemiRing_hasCommutativeMul local_mixin_GRing_isNmodule local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule fresh_name_345 =
      Builders_332.coq_HB_unnamed_factory_334 local_mixin_GRing_isNmodule
        local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
        (coq_GRing_Zmodule_isComNzRing__to__GRing_Nmodule_isPzSemiRing
          local_mixin_GRing_isNmodule local_mixin_choice_hasChoice
          local_mixin_eqtype_hasDecEq local_mixin_GRing_Nmodule_isZmodule
          fresh_name_345)
        local_mixin_GRing_Nmodule_isZmodule
        (coq_HB_unnamed_factory_349 local_mixin_GRing_isNmodule
          local_mixin_choice_hasChoice local_mixin_eqtype_hasDecEq
          local_mixin_GRing_Nmodule_isZmodule fresh_name_345)
   end
 end
