(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Eqtype
open Expr
open Fexpr
open Memory_model
open Otbn_decl
open Otbn_instr_decl
open Var0
open Wsize

val is_arith_small : coq_Z -> bool

val is_arith_small_neg : coq_Z -> bool

module OTBNFopn_core :
 sig
  type opn_args = (lexpr list * otbn_op) * rexpr list

  val op_gen : rv_mnemonic -> var_i -> rexpr list -> opn_args

  val op_un_imm : rv_mnemonic -> var_i -> coq_Z -> opn_args

  val op_bin_reg : rv_mnemonic -> var_i -> var_i -> var_i -> opn_args

  val op_bin_imm : rv_mnemonic -> var_i -> var_i -> coq_Z -> opn_args

  val add : var_i -> var_i -> var_i -> opn_args

  val sub : var_i -> var_i -> var_i -> opn_args

  val li : var_i -> coq_Z -> opn_args

  val addi : var_i -> var_i -> coq_Z -> opn_args

  val subi : var_i -> var_i -> coq_Z -> opn_args

  val andi : var_i -> var_i -> coq_Z -> opn_args

  val xori : var_i -> var_i -> coq_Z -> opn_args

  val mov : var_i -> var_i -> opn_args

  val smart_mov : var_i -> var_i -> opn_args list

  val not : var_i -> var_i -> opn_args

  val lw : wsize -> var_i -> fexpr -> opn_args

  val sw : wsize -> fexpr -> var_i -> opn_args

  val align : var_i -> var_i -> wsize -> opn_args

  val is_mov : coq_Z option -> coq_Z -> bool

  val gen_unsafe_smart_opi :
    (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
    opn_args) -> (coq_Z -> bool) -> coq_Z option -> var_i -> var_i -> var_i
    -> coq_Z -> opn_args list

  val gen_smart_opi :
    (var_i -> var_i -> var_i -> opn_args) -> (var_i -> var_i -> coq_Z ->
    opn_args) -> (coq_Z -> bool) -> coq_Z option -> var_i -> var_i -> var_i
    -> coq_Z -> opn_args list option

  val smart_addi : var_i -> var_i -> coq_Z -> opn_args list option

  val smart_subi : var_i -> var_i -> coq_Z -> opn_args list option

  val gen_smart_opi_tmp :
    (coq_Z -> bool) -> (var_i -> var_i -> var_i -> opn_args) -> (var_i ->
    var_i -> coq_Z -> opn_args) -> var_i -> var_i -> coq_Z -> opn_args list
    option

  val smart_addi_tmp : var_i -> var_i -> coq_Z -> opn_args list option

  val smart_subi_tmp : var_i -> var_i -> coq_Z -> opn_args list option
 end
