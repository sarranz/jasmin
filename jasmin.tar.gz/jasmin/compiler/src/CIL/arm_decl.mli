(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open Arm_common
open Arm_expand_imm
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Operators
open Seq
open Shift_kind
open Ssrbool
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t

val arm_reg_size : wsize

val arm_xreg_size : wsize

type register =
| R00
| R01
| R02
| R03
| R04
| R05
| R06
| R07
| R08
| R09
| R10
| R11
| R12
| LR
| SP

val register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> 'a1

val register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> 'a1

type is_register =
| Coq_is_R00
| Coq_is_R01
| Coq_is_R02
| Coq_is_R03
| Coq_is_R04
| Coq_is_R05
| Coq_is_R06
| Coq_is_R07
| Coq_is_R08
| Coq_is_R09
| Coq_is_R10
| Coq_is_R11
| Coq_is_R12
| Coq_is_LR
| Coq_is_SP

val is_register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> is_register -> 'a1

val is_register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> is_register -> 'a1

val register_tag : register -> positive

val is_register_inhab : register -> is_register

val is_register_functor : register -> is_register -> is_register

type box_register_R00 =
| Box_register_R00

type register_fields_t = __

val register_fields : register -> register_fields_t

val register_construct : positive -> register_fields_t -> register option

val register_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> is_register -> 'a1

val register_eqb_fields :
  (register -> register -> bool) -> positive -> register_fields_t ->
  register_fields_t -> bool

val register_eqb : register -> register -> bool

val register_eqb_OK : register -> register -> reflect

val register_eqb_OK_sumbool : register -> register -> bool

val eqTC_register : register eqTypeC

val arm_register_eqType : Equality.coq_type

val registers : register list

val finTC_register : register finTypeC

val register_finType : Finite.coq_type

val register_to_string : register -> string

val reg_toS : register coq_ToString

val eqTC_shift_kind : shift_kind eqTypeC

val shift_kind_eqType : Equality.coq_type

val shift_kinds : shift_kind list

val string_of_shift_kind : shift_kind -> string

val check_shift_amount : shift_kind -> coq_Z -> bool

val shift_op : shift_kind -> wsize -> word -> coq_Z -> word

val shift_of_sop2 : wsize -> sop2 -> shift_kind option

type arm_caimm_cond =
| CAimmC_arm_shift_amout of shift_kind
| CAimmC_arm_wencoding of expected_wencoding
| CAimmC_arm_0_8_16_24

val arm_caimm_cond_rect :
  (shift_kind -> 'a1) -> (expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond
  -> 'a1

val arm_caimm_cond_rec :
  (shift_kind -> 'a1) -> (expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond
  -> 'a1

type is_arm_caimm_cond =
| Coq_is_CAimmC_arm_shift_amout of shift_kind * is_shift_kind
| Coq_is_CAimmC_arm_wencoding of expected_wencoding * is_expected_wencoding
| Coq_is_CAimmC_arm_0_8_16_24

val is_arm_caimm_cond_rect :
  (shift_kind -> is_shift_kind -> 'a1) -> (expected_wencoding ->
  is_expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond -> is_arm_caimm_cond
  -> 'a1

val is_arm_caimm_cond_rec :
  (shift_kind -> is_shift_kind -> 'a1) -> (expected_wencoding ->
  is_expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond -> is_arm_caimm_cond
  -> 'a1

val arm_caimm_cond_tag : arm_caimm_cond -> positive

val is_arm_caimm_cond_inhab : arm_caimm_cond -> is_arm_caimm_cond

val is_arm_caimm_cond_functor :
  arm_caimm_cond -> is_arm_caimm_cond -> is_arm_caimm_cond

type box_arm_caimm_cond_CAimmC_arm_shift_amout =
  shift_kind
  (* singleton inductive, whose constructor was Box_arm_caimm_cond_CAimmC_arm_shift_amout *)

val coq_Box_arm_caimm_cond_CAimmC_arm_shift_amout_0 :
  box_arm_caimm_cond_CAimmC_arm_shift_amout -> shift_kind

type box_arm_caimm_cond_CAimmC_arm_wencoding =
  expected_wencoding
  (* singleton inductive, whose constructor was Box_arm_caimm_cond_CAimmC_arm_wencoding *)

val coq_Box_arm_caimm_cond_CAimmC_arm_wencoding_0 :
  box_arm_caimm_cond_CAimmC_arm_wencoding -> expected_wencoding

type box_arm_caimm_cond_CAimmC_arm_0_8_16_24 =
| Box_arm_caimm_cond_CAimmC_arm_0_8_16_24

type arm_caimm_cond_fields_t = __

val arm_caimm_cond_fields : arm_caimm_cond -> arm_caimm_cond_fields_t

val arm_caimm_cond_construct :
  positive -> arm_caimm_cond_fields_t -> arm_caimm_cond option

val arm_caimm_cond_induction :
  (shift_kind -> is_shift_kind -> 'a1) -> (expected_wencoding ->
  is_expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond -> is_arm_caimm_cond
  -> 'a1

val arm_caimm_cond_eqb_fields :
  (arm_caimm_cond -> arm_caimm_cond -> bool) -> positive ->
  arm_caimm_cond_fields_t -> arm_caimm_cond_fields_t -> bool

val arm_caimm_cond_eqb : arm_caimm_cond -> arm_caimm_cond -> bool

val arm_caimm_cond_eqb_OK : arm_caimm_cond -> arm_caimm_cond -> reflect

val arm_caimm_cond_eqb_OK_sumbool : arm_caimm_cond -> arm_caimm_cond -> bool

val eqTC_arm_caimm_cond : arm_caimm_cond eqTypeC

val arm_check_CAimm : arm_caimm_cond -> wsize -> word -> bool

val arm_caimm_cond_pp : arm_caimm_cond -> string

val arm_decl : (register, empty, empty, rflag, condt) arch_decl

val arm_linux_call_conv :
  (register, empty, empty, rflag, condt) calling_convention

val is_expandable : coq_Z -> bool

val is_expandable_or_shift : coq_Z -> bool

val arm_internal_call_conv :
  (register, empty, empty, rflag, condt) internal_calling_convention
