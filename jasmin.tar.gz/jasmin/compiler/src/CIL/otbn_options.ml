(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Eqb_core_defs

type __ = Obj.t

type bn_flag_group =
| FG0
| FG1

type is_bn_flag_group =
| Coq_is_FG0
| Coq_is_FG1

(** val bn_flag_group_tag : bn_flag_group -> positive **)

let bn_flag_group_tag = function
| FG0 -> Coq_xH
| FG1 -> Coq_xO Coq_xH

(** val is_bn_flag_group_inhab : bn_flag_group -> is_bn_flag_group **)

let is_bn_flag_group_inhab = function
| FG0 -> Coq_is_FG0
| FG1 -> Coq_is_FG1

type box_bn_flag_group_FG0 =
| Box_bn_flag_group_FG0

type bn_flag_group_fields_t = __

(** val bn_flag_group_fields : bn_flag_group -> bn_flag_group_fields_t **)

let bn_flag_group_fields _ =
  Obj.magic Box_bn_flag_group_FG0

(** val bn_flag_group_eqb_fields :
    (bn_flag_group -> bn_flag_group -> bool) -> positive ->
    bn_flag_group_fields_t -> bn_flag_group_fields_t -> bool **)

let bn_flag_group_eqb_fields _ _ _ _ =
  true

(** val bn_flag_group_eqb : bn_flag_group -> bn_flag_group -> bool **)

let bn_flag_group_eqb x1 x2 =
  eqb_body bn_flag_group_tag bn_flag_group_fields
    (Obj.magic bn_flag_group_eqb_fields (fun _ _ -> true))
    (bn_flag_group_tag x1) Box_bn_flag_group_FG0 x2

(** val bn_flag_groups : bn_flag_group list **)

let bn_flag_groups =
  FG0 :: (FG1 :: [])

type bn_register_shift =
| RS_left
| RS_right

type is_bn_register_shift =
| Coq_is_RS_left
| Coq_is_RS_right

(** val bn_register_shift_tag : bn_register_shift -> positive **)

let bn_register_shift_tag = function
| RS_left -> Coq_xH
| RS_right -> Coq_xO Coq_xH

(** val is_bn_register_shift_inhab :
    bn_register_shift -> is_bn_register_shift **)

let is_bn_register_shift_inhab = function
| RS_left -> Coq_is_RS_left
| RS_right -> Coq_is_RS_right

type box_bn_register_shift_RS_left =
| Box_bn_register_shift_RS_left

type bn_register_shift_fields_t = __

(** val bn_register_shift_fields :
    bn_register_shift -> bn_register_shift_fields_t **)

let bn_register_shift_fields _ =
  Obj.magic Box_bn_register_shift_RS_left

(** val bn_register_shift_eqb_fields :
    (bn_register_shift -> bn_register_shift -> bool) -> positive ->
    bn_register_shift_fields_t -> bn_register_shift_fields_t -> bool **)

let bn_register_shift_eqb_fields _ _ _ _ =
  true

(** val bn_register_shift_eqb :
    bn_register_shift -> bn_register_shift -> bool **)

let bn_register_shift_eqb x1 x2 =
  eqb_body bn_register_shift_tag bn_register_shift_fields
    (Obj.magic bn_register_shift_eqb_fields (fun _ _ -> true))
    (bn_register_shift_tag x1) Box_bn_register_shift_RS_left x2

type bn_halfword_writeback =
| WB_upper
| WB_lower

type is_bn_halfword_writeback =
| Coq_is_WB_upper
| Coq_is_WB_lower

(** val bn_halfword_writeback_tag : bn_halfword_writeback -> positive **)

let bn_halfword_writeback_tag = function
| WB_upper -> Coq_xH
| WB_lower -> Coq_xO Coq_xH

(** val is_bn_halfword_writeback_inhab :
    bn_halfword_writeback -> is_bn_halfword_writeback **)

let is_bn_halfword_writeback_inhab = function
| WB_upper -> Coq_is_WB_upper
| WB_lower -> Coq_is_WB_lower

type box_bn_halfword_writeback_WB_upper =
| Box_bn_halfword_writeback_WB_upper

type bn_halfword_writeback_fields_t = __

(** val bn_halfword_writeback_fields :
    bn_halfword_writeback -> bn_halfword_writeback_fields_t **)

let bn_halfword_writeback_fields _ =
  Obj.magic Box_bn_halfword_writeback_WB_upper

(** val bn_halfword_writeback_eqb_fields :
    (bn_halfword_writeback -> bn_halfword_writeback -> bool) -> positive ->
    bn_halfword_writeback_fields_t -> bn_halfword_writeback_fields_t -> bool **)

let bn_halfword_writeback_eqb_fields _ _ _ _ =
  true

(** val bn_halfword_writeback_eqb :
    bn_halfword_writeback -> bn_halfword_writeback -> bool **)

let bn_halfword_writeback_eqb x1 x2 =
  eqb_body bn_halfword_writeback_tag bn_halfword_writeback_fields
    (Obj.magic bn_halfword_writeback_eqb_fields (fun _ _ -> true))
    (bn_halfword_writeback_tag x1) Box_bn_halfword_writeback_WB_upper x2

(** val bn_halfword_writebacks : bn_halfword_writeback list **)

let bn_halfword_writebacks =
  WB_upper :: (WB_lower :: [])
