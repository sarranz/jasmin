(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_params
open Arch_utils
open Asm_gen
open Compiler_util
open Eqtype
open Expr
open Fexpr
open Lea
open Linearization
open Operators
open Otbn_decl
open Otbn_extra
open Otbn_instr_decl
open Otbn_lower_addressing
open Otbn_lowering
open Otbn_params_core
open Seq
open Slh_lowering
open Sopn
open Ssrbool
open Ssrfun
open Ssrnat
open Stack_alloc_params
open Stack_zeroization
open Type
open Utils0
open Var0
open Word_ssrZ
open Wsize

module E =
 struct
  (** val pass : string **)

  let pass =
    "OTBN parameters"

  (** val szp_cmd : pp_error_loc **)

  let szp_cmd =
    let oii = None in
    let pp = PPEstring "Stack zeroization not implemented" in
    { pel_msg = pp; pel_fn = None; pel_fi = None; pel_ii = oii; pel_vi =
    None; pel_pass = (Some pass); pel_internal = false }
 end

(** val add_imm_op :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> coq_Z -> otbn_extended_op * pexpr list **)

let add_imm_op _ base imm =
  if eq_op coq_BinNums_Z__canonical__eqtype_Equality (Obj.magic imm)
       (Obj.magic Z0)
  then ((ExtOp MOV), ((coq_Plvar base) :: []))
  else if is_arith_small imm
       then ((BaseOp (None, (RV32 ADDI))),
              ((coq_Plvar base) :: ((cast_const (arch_pd otbn_decl) imm) :: [])))
       else ((ExtOp ADD_LARGE_IMM),
              ((coq_Plvar base) :: ((cast_const (arch_pd otbn_decl) imm) :: [])))

(** val mov_ofs :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> lval
    -> assgn_tag -> mov_kind -> pexpr -> pexpr -> (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op instr_r
    option **)

let mov_ofs atoI x tag movk y ofs =
  let mk = fun oa -> Some (Copn ((x :: []), tag, (Oasm (fst oa)), (snd oa)))
  in
  (match movk with
   | MK_LEA ->
     mk ((BaseOp (None, (RV32 LA))),
       ((if is_zero (Obj.magic arch_pd otbn_decl) ofs
         then y
         else add (arch_pd otbn_decl) y ofs) :: []))
   | MK_MOV ->
     (match x with
      | Lvar _ ->
        if is_Pload y
        then (match oassert (is_zero (Obj.magic arch_pd otbn_decl) ofs) with
              | Some _ -> mk ((BaseOp (None, (RV32 LW))), (y :: []))
              | None -> None)
        else (match mk_lea (arch_pd otbn_decl) (add (arch_pd otbn_decl) y ofs) with
              | Some lea ->
                (match lea.lea_base with
                 | Some base ->
                   (match lea.lea_offset with
                    | Some off ->
                      (match oassert
                               ((&&)
                                 (eq_op
                                   coq_BinNums_Z__canonical__eqtype_Equality
                                   (Obj.magic lea.lea_disp) (Obj.magic Z0))
                                 (eq_op
                                   coq_BinNums_Z__canonical__eqtype_Equality
                                   (Obj.magic lea.lea_scale)
                                   (Obj.magic (Zpos Coq_xH)))) with
                       | Some _ ->
                         mk ((BaseOp (None, (RV32 ADD))),
                           ((coq_Plvar base) :: ((coq_Plvar off) :: [])))
                       | None -> None)
                    | None -> mk (add_imm_op atoI base lea.lea_disp))
                 | None -> None)
              | None -> None)
      | Lmem (_, _, _, _) ->
        (match oassert (is_zero (Obj.magic arch_pd otbn_decl) ofs) with
         | Some _ -> mk ((BaseOp (None, (RV32 SW))), (y :: []))
         | None -> None)
      | _ -> None))

(** val immediate :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> coq_Z -> (register, empty, wide_register, rflag, condition, otbn_op,
    extra_op) extended_op instr_r **)

let immediate atoI x imm =
  Copn (((Lvar x) :: []), AT_none, (coq_Ootbn atoI (RV32 LI)),
    ((cast_const (arch_pd otbn_decl) imm) :: []))

(** val swap :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    assgn_tag -> var_i -> var_i -> var_i -> var_i -> (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op instr_r **)

let swap _ t x y z w =
  Copn (((Lvar x) :: ((Lvar y) :: [])), t, (Oasm (ExtOp (SWAP
    otbn_decl.reg_size))), ((coq_Plvar z) :: ((coq_Plvar w) :: [])))

(** val saparams :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op stack_alloc_params **)

let saparams atoI =
  { sap_mov_ofs = (mov_ofs atoI); sap_immediate = (immediate atoI);
    sap_swap = (swap atoI) }

(** val vtmp :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> Var.var **)

let vtmp atoI =
  to_var (Coq_lword otbn_decl.reg_size) otbn_decl.toS_r atoI.toI_r X28

(** val vtmp2 :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> Var.var **)

let vtmp2 atoI =
  to_var (Coq_lword otbn_decl.reg_size) otbn_decl.toS_r atoI.toI_r X29

(** val fopn_args_of_opn_args :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    OTBNFopn_core.opn_args -> (lexpr list * (register, empty, wide_register,
    rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list **)

let fopn_args_of_opn_args atoI = function
| (p, re) -> let (le, op) = p in ((le, (coq_Ootbn atoI op)), re)

(** val allocate_stack_frame :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i option -> coq_Z -> ((lexpr list * (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op
    sopn) * rexpr list) list **)

let allocate_stack_frame atoI rspi tmp sz =
  let c = (OTBNFopn_core.subi rspi rspi sz) :: [] in
  let c' =
    match tmp with
    | Some aux -> OTBNFopn_core.smart_subi_tmp rspi aux sz
    | None -> None
  in
  map (fun x -> fopn_args_of_opn_args atoI x) (Option.default c c')

(** val free_stack_frame :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i option -> coq_Z -> ((lexpr list * (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op
    sopn) * rexpr list) list **)

let free_stack_frame atoI rspi tmp sz =
  let c = (OTBNFopn_core.addi rspi rspi sz) :: [] in
  let c' =
    match tmp with
    | Some aux -> OTBNFopn_core.smart_addi_tmp rspi aux sz
    | None -> None
  in
  map (fun x -> fopn_args_of_opn_args atoI x) (Option.default c c')

(** val smart_addi :
    var_i -> var_i -> coq_Z -> OTBNFopn_core.opn_args list **)

let smart_addi x y imm =
  let c = (OTBNFopn_core.addi x y imm) :: [] in
  let c' = OTBNFopn_core.smart_addi x y imm in Option.default c c'

(** val smart_subi :
    var_i -> var_i -> coq_Z -> OTBNFopn_core.opn_args list **)

let smart_subi x y imm =
  let c = (OTBNFopn_core.subi x y imm) :: [] in
  let c' = OTBNFopn_core.smart_subi x y imm in Option.default c c'

(** val set_up_sp_register :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> coq_Z -> wsize -> var_i -> var_i -> ((lexpr list * (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op
    sopn) * rexpr list) list **)

let set_up_sp_register atoI rspi sf_sz al r _ =
  let c_copy = OTBNFopn_core.smart_mov r rspi in
  let c_sub = smart_subi rspi r sf_sz in
  let c_align = (OTBNFopn_core.align rspi rspi al) :: [] in
  map (fun a -> fopn_args_of_opn_args atoI a) (cat c_copy (cat c_sub c_align))

(** val lmove :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i -> (lexpr list * (register, empty, wide_register, rflag,
    condition, otbn_op, extra_op) extended_op sopn) * rexpr list **)

let lmove atoI xd xs =
  fopn_args_of_opn_args atoI (OTBNFopn_core.mov xd xs)

(** val check_ws : Equality.sort -> bool **)

let check_ws ws =
  eq_op wsize_wsize__canonical__eqtype_Equality ws
    (Obj.magic otbn_decl.reg_size)

(** val lstore :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> coq_Z -> var_i -> (lexpr list * (register, empty, wide_register,
    rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list **)

let lstore atoI xd ofs xs =
  let e = faddv otbn_decl.reg_size xd (fconst otbn_decl.reg_size ofs) in
  fopn_args_of_opn_args atoI (OTBNFopn_core.sw otbn_decl.reg_size e xs)

(** val lload :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i -> coq_Z -> (lexpr list * (register, empty, wide_register,
    rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list **)

let lload atoI xd xs ofs =
  let e = faddv otbn_decl.reg_size xs (fconst otbn_decl.reg_size ofs) in
  fopn_args_of_opn_args atoI (OTBNFopn_core.lw otbn_decl.reg_size xd e)

(** val smart_addi_fopn :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> var_i -> coq_Z -> ((lexpr list * (register, empty, wide_register,
    rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list) list **)

let smart_addi_fopn atoI x y imm =
  map (fun a -> fopn_args_of_opn_args atoI a) (smart_addi x y imm)

(** val lstores :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> (Var.var * coq_Z) list -> ((lexpr list * (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op
    sopn) * rexpr list) list **)

let lstores atoI =
  lstores_imm_dfl (arch_pd otbn_decl) (asm_opI (otbn_extra atoI))
    (Var.vname (vtmp2 atoI)) (lstore atoI) (smart_addi_fopn atoI)
    is_arith_small

(** val lloads :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i
    -> (Var.var * coq_Z) list -> coq_Z -> ((lexpr list * (register, empty,
    wide_register, rflag, condition, otbn_op, extra_op) extended_op
    sopn) * rexpr list) list **)

let lloads atoI =
  lloads_imm_dfl (arch_pd otbn_decl) (asm_opI (otbn_extra atoI))
    (Var.vname (vtmp2 atoI)) (lload atoI) (smart_addi_fopn atoI)
    is_arith_small

(** val liparams :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op linearization_params **)

let liparams atoI =
  { lip_tmp = (Var.vname (vtmp atoI)); lip_tmp2 = (Var.vname (vtmp2 atoI));
    lip_not_saved_stack = ((Var.vname (vtmp atoI)) :: []);
    lip_allocate_stack_frame = (allocate_stack_frame atoI);
    lip_free_stack_frame = (free_stack_frame atoI); lip_set_up_sp_register =
    (set_up_sp_register atoI); lip_lmove = (lmove atoI); lip_check_ws =
    (Obj.magic check_ws); lip_lstore = (lstore atoI); lip_lload =
    (lload atoI); lip_lstores = (lstores atoI); lip_lloads = (lloads atoI) }

(** val loparams :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op lowering_params **)

let loparams atoI =
  { lop_lower_i = (fun _ _ -> Otbn_lowering.lower_i atoI);
    lop_fvars_correct = (fun _ _ _ -> true) }

(** val is_fzero : wsize -> fexpr -> bool **)

let is_fzero ws = function
| Fapp1 (s, f) ->
  (match s with
   | Oword_of_int ws' ->
     (match f with
      | Fconst z ->
        (match z with
         | Z0 ->
           eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws')
             (Obj.magic ws)
         | _ -> false)
      | _ -> false)
   | _ -> false)
| _ -> false

(** val is_fvar : fexpr -> var_i option **)

let is_fvar = function
| Fvar x -> Some x
| _ -> None

(** val condt_not :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> condition -> condition cexec **)

let condt_not atoI =
  let err = fun ii fe -> Asm_gen.E.berror ii fe "Can't assemble condition." in
  (fun ii c ->
  match c with
  | RVcond (is_eq, r0, r1) -> Ok (RVcond ((negb is_eq), r0, r1))
  | BNcond f ->
    Error
      (err ii (Fvar
        (mk_var_i (to_var Coq_lbool otbn_decl.toS_f atoI.toI_f f)))))

(** val sop2_is_eq : instr_info -> fexpr -> sop2 -> bool cexec **)

let sop2_is_eq =
  let err = fun ii fe -> Asm_gen.E.berror ii fe "Can't assemble condition." in
  (fun ii fe o ->
  let chk = fun ws ->
    if eq_op wsize_wsize__canonical__eqtype_Equality ws
         (Obj.magic otbn_decl.reg_size)
    then Ok ()
    else Error (err ii fe)
  in
  (match o with
   | Oeq o0 ->
     (match o0 with
      | Op_int -> Error (err ii fe)
      | Op_w ws ->
        (match Obj.magic chk ws with
         | Ok _ -> Ok true
         | Error s -> Error s))
   | Oneq o0 ->
     (match o0 with
      | Op_int -> Error (err ii fe)
      | Op_w ws ->
        (match Obj.magic chk ws with
         | Ok _ -> Ok false
         | Error s -> Error s))
   | _ -> Error (err ii fe)))

(** val oreg_of_fexpr :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> fexpr -> fexpr -> register option cexec **)

let oreg_of_fexpr atoI =
  let err = fun ii fe -> Asm_gen.E.berror ii fe "Can't assemble condition." in
  (fun ii fe e ->
  if is_fzero otbn_decl.reg_size e
  then Ok None
  else (match is_fvar e with
        | Some x ->
          (match of_var_e (Coq_lword otbn_decl.reg_size) otbn_decl.toS_r
                   atoI.toI_r ii x with
           | Ok x0 -> Ok (Some x0)
           | Error s -> Error s)
        | None -> Error (err ii fe)))

(** val assemble_cond_app2 :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> fexpr -> sop2 -> fexpr -> fexpr -> condition cexec **)

let assemble_cond_app2 atoI ii fe o e0 e1 =
  match sop2_is_eq ii fe o with
  | Ok x ->
    (match oreg_of_fexpr atoI ii fe e0 with
     | Ok x0 ->
       (match oreg_of_fexpr atoI ii fe e1 with
        | Ok x1 -> Ok (RVcond (x, x0, x1))
        | Error s -> Error s)
     | Error s -> Error s)
  | Error s -> Error s

(** val assemble_cond :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> fexpr -> condition cexec **)

let assemble_cond atoI =
  let err = fun ii fe -> Asm_gen.E.berror ii fe "Can't assemble condition." in
  let rec assemble_cond0 ii fe = match fe with
  | Fvar x ->
    (match of_var_e Coq_lbool otbn_decl.toS_f atoI.toI_f ii x with
     | Ok x0 -> Ok (BNcond x0)
     | Error s -> Error s)
  | Fapp1 (s, fe0) ->
    (match s with
     | Onot ->
       (match assemble_cond0 ii fe0 with
        | Ok x -> condt_not atoI ii x
        | Error s0 -> Error s0)
     | _ -> Error (err ii fe))
  | Fapp2 (o, e0, e1) -> assemble_cond_app2 atoI ii fe o e0 e1
  | _ -> Error (err ii fe)
  in assemble_cond0

(** val is_valid_address :
    (register, empty, wide_register, rflag, condition) reg_address -> bool **)

let is_valid_address addr =
  if isSome addr.ad_offset
  then false
  else if negb
            (eq_op coq_Datatypes_nat__canonical__eqtype_Equality
              (Obj.magic addr.ad_scale) (Obj.magic nat_of_bin N0))
       then false
       else true

(** val agparams :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    asm_gen_params **)

let agparams atoI =
  { agp_assemble_cond = (assemble_cond atoI); agp_is_valid_address =
    is_valid_address }

(** val laparams :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    lower_addressing_params **)

let laparams atoI =
  Obj.magic lower_addressing_prog atoI

(** val shparams :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op sh_params **)

let shparams _ _ _ _ =
  None

(** val szparams :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op stack_zeroization_params **)

let szparams _ _ _ _ _ _ _ =
  Error E.szp_cmd

(** val is_move_op :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op asm_op_t -> bool **)

let is_move_op _ = function
| BaseOp a ->
  let (o0, a0) = a in
  (match o0 with
   | Some _ -> false
   | None -> (match a0 with
              | BN_MOV -> true
              | _ -> false))
| ExtOp e -> (match e with
              | MOV -> true
              | _ -> false)

(** val otbn_params :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    architecture_params **)

let otbn_params atoI =
  { ap_sap = (saparams atoI); ap_lip = (liparams atoI); ap_plp = true;
    ap_lop = (loparams atoI); ap_shp = (shparams atoI); ap_lap =
    (laparams atoI); ap_agp = (agparams atoI); ap_szp = (szparams atoI);
    ap_is_move_op = (is_move_op atoI) }
