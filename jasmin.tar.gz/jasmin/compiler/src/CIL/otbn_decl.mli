(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open DecimalString
open Arch_decl
open Arch_utils
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Flag_combination
open Otbn_admit
open Param1
open Param1_trivial
open Seq
open Std
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t

val string_of_Z : coq_Z -> string

val otbn_reg_size : wsize

val otbn_xreg_size : wsize

type register =
| X02
| X03
| X04
| X05
| X06
| X07
| X08
| X09
| X10
| X11
| X12
| X13
| X14
| X15
| X16
| X17
| X18
| X19
| X20
| X21
| X22
| X23
| X24
| X25
| X26
| X27
| X28
| X29
| X30
| X31

val register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register ->
  'a1

val register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register ->
  'a1

type is_register =
| Coq_is_X02
| Coq_is_X03
| Coq_is_X04
| Coq_is_X05
| Coq_is_X06
| Coq_is_X07
| Coq_is_X08
| Coq_is_X09
| Coq_is_X10
| Coq_is_X11
| Coq_is_X12
| Coq_is_X13
| Coq_is_X14
| Coq_is_X15
| Coq_is_X16
| Coq_is_X17
| Coq_is_X18
| Coq_is_X19
| Coq_is_X20
| Coq_is_X21
| Coq_is_X22
| Coq_is_X23
| Coq_is_X24
| Coq_is_X25
| Coq_is_X26
| Coq_is_X27
| Coq_is_X28
| Coq_is_X29
| Coq_is_X30
| Coq_is_X31

val is_register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register ->
  is_register -> 'a1

val is_register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register ->
  is_register -> 'a1

val register_tag : register -> positive

val is_register_inhab : register -> is_register

val is_register_functor : register -> is_register -> is_register

type box_register_X02 =
| Box_register_X02

type register_fields_t = __

val register_fields : register -> register_fields_t

val register_construct : positive -> register_fields_t -> register option

val register_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register ->
  is_register -> 'a1

val register_eqb_fields :
  (register -> register -> bool) -> positive -> register_fields_t ->
  register_fields_t -> bool

val register_eqb : register -> register -> bool

val register_eqb_OK : register -> register -> reflect

val register_eqb_OK_sumbool : register -> register -> bool

val eqTC_register : register eqTypeC

val otbn_register_eqType : Equality.coq_type

val registers : register list

val finTC_register : register finTypeC

val register_finType : Finite.coq_type

val register_to_string : register -> string

val reg_toS : register coq_ToString

type wide_register =
| W00
| W01
| W02
| W03
| W04
| W05
| W06
| W07
| W08
| W09
| W10
| W11
| W12
| W13
| W14
| W15
| W16
| W17
| W18
| W19
| W20
| W21
| W22
| W23
| W24
| W25
| W26
| W27
| W28
| W29
| W30
| W31
| ACC
| MOD

val wide_register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> wide_register -> 'a1

val wide_register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> wide_register -> 'a1

type is_wide_register =
| Coq_is_W00
| Coq_is_W01
| Coq_is_W02
| Coq_is_W03
| Coq_is_W04
| Coq_is_W05
| Coq_is_W06
| Coq_is_W07
| Coq_is_W08
| Coq_is_W09
| Coq_is_W10
| Coq_is_W11
| Coq_is_W12
| Coq_is_W13
| Coq_is_W14
| Coq_is_W15
| Coq_is_W16
| Coq_is_W17
| Coq_is_W18
| Coq_is_W19
| Coq_is_W20
| Coq_is_W21
| Coq_is_W22
| Coq_is_W23
| Coq_is_W24
| Coq_is_W25
| Coq_is_W26
| Coq_is_W27
| Coq_is_W28
| Coq_is_W29
| Coq_is_W30
| Coq_is_W31
| Coq_is_ACC
| Coq_is_MOD

val is_wide_register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> wide_register -> is_wide_register -> 'a1

val is_wide_register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> wide_register -> is_wide_register -> 'a1

val wide_register_tag : wide_register -> positive

val is_wide_register_inhab : wide_register -> is_wide_register

val is_wide_register_functor :
  wide_register -> is_wide_register -> is_wide_register

type box_wide_register_W00 =
| Box_wide_register_W00

type wide_register_fields_t = __

val wide_register_fields : wide_register -> wide_register_fields_t

val wide_register_construct :
  positive -> wide_register_fields_t -> wide_register option

val wide_register_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> wide_register -> is_wide_register -> 'a1

val wide_register_eqb_fields :
  (wide_register -> wide_register -> bool) -> positive ->
  wide_register_fields_t -> wide_register_fields_t -> bool

val wide_register_eqb : wide_register -> wide_register -> bool

val wide_register_eqb_OK : wide_register -> wide_register -> reflect

val wide_register_eqb_OK_sumbool : wide_register -> wide_register -> bool

val eqTC_wide_register : wide_register eqTypeC

val otbn_wide_register_eqType : Equality.coq_type

val wide_registers : wide_register list

val finTC_wide_register : wide_register finTypeC

val wide_register_finType : Finite.coq_type

val wide_register_to_string : wide_register -> string

val xreg_toS : wide_register coq_ToString

type rflag =
| CF0
| CF1
| MF0
| MF1
| LF0
| LF1
| ZF0
| ZF1

val rflag_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1

val rflag_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1

type is_rflag =
| Coq_is_CF0
| Coq_is_CF1
| Coq_is_MF0
| Coq_is_MF1
| Coq_is_LF0
| Coq_is_LF1
| Coq_is_ZF0
| Coq_is_ZF1

val is_rflag_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag
  -> 'a1

val is_rflag_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag
  -> 'a1

val rflag_tag : rflag -> positive

val is_rflag_inhab : rflag -> is_rflag

val is_rflag_functor : rflag -> is_rflag -> is_rflag

type box_rflag_CF0 =
| Box_rflag_CF0

type rflag_fields_t = __

val rflag_fields : rflag -> rflag_fields_t

val rflag_construct : positive -> rflag_fields_t -> rflag option

val rflag_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag
  -> 'a1

val rflag_eqb_fields :
  (rflag -> rflag -> bool) -> positive -> rflag_fields_t -> rflag_fields_t ->
  bool

val rflag_eqb : rflag -> rflag -> bool

val rflag_eqb_OK : rflag -> rflag -> reflect

val rflag_eqb_OK_sumbool : rflag -> rflag -> bool

val eqTC_rflag : rflag eqTypeC

val rflag_eqType : Equality.coq_type

val rflags : rflag list

val finTC_rflag : rflag finTypeC

val rflag_finType : Finite.coq_type

val flag_to_string : rflag -> string

val flag_toS : rflag coq_ToString

type condition =
| RVcond of bool * register option * register option
| BNcond of rflag

val condition_rect :
  (bool -> register option -> register option -> 'a1) -> (rflag -> 'a1) ->
  condition -> 'a1

val condition_rec :
  (bool -> register option -> register option -> 'a1) -> (rflag -> 'a1) ->
  condition -> 'a1

type is_condition =
| Coq_is_RVcond of bool * Param1.Coq_exports.is_bool * register option
   * (register, is_register) Prelude.is_option * register option
   * (register, is_register) Prelude.is_option
| Coq_is_BNcond of rflag * is_rflag

val is_condition_rect :
  (bool -> Param1.Coq_exports.is_bool -> register option -> (register,
  is_register) Prelude.is_option -> register option -> (register,
  is_register) Prelude.is_option -> 'a1) -> (rflag -> is_rflag -> 'a1) ->
  condition -> is_condition -> 'a1

val is_condition_rec :
  (bool -> Param1.Coq_exports.is_bool -> register option -> (register,
  is_register) Prelude.is_option -> register option -> (register,
  is_register) Prelude.is_option -> 'a1) -> (rflag -> is_rflag -> 'a1) ->
  condition -> is_condition -> 'a1

val condition_tag : condition -> positive

val is_condition_inhab : condition -> is_condition

val is_condition_functor : condition -> is_condition -> is_condition

type box_condition_RVcond = { coq_Box_condition_RVcond_0 : bool;
                              coq_Box_condition_RVcond_1 : register option;
                              coq_Box_condition_RVcond_2 : register option }

val coq_Box_condition_RVcond_0 : box_condition_RVcond -> bool

val coq_Box_condition_RVcond_1 : box_condition_RVcond -> register option

val coq_Box_condition_RVcond_2 : box_condition_RVcond -> register option

type box_condition_BNcond =
  rflag
  (* singleton inductive, whose constructor was Box_condition_BNcond *)

val coq_Box_condition_BNcond_0 : box_condition_BNcond -> rflag

type condition_fields_t = __

val condition_fields : condition -> condition_fields_t

val condition_construct : positive -> condition_fields_t -> condition option

val condition_induction :
  (bool -> Param1.Coq_exports.is_bool -> register option -> (register,
  is_register) Prelude.is_option -> register option -> (register,
  is_register) Prelude.is_option -> 'a1) -> (rflag -> is_rflag -> 'a1) ->
  condition -> is_condition -> 'a1

val condition_eqb_fields :
  (condition -> condition -> bool) -> positive -> condition_fields_t ->
  condition_fields_t -> bool

val condition_eqb : condition -> condition -> bool

val condition_eqb_OK : condition -> condition -> reflect

val condition_eqb_OK_sumbool : condition -> condition -> bool

val eqTC_condition : condition eqTypeC

val condition_eqType : Equality.coq_type

val fc_of_cfc : combine_flags_core -> flag_combination

val otbn_fcp : coq_FlagCombinationParams

type otbn_caimm_cond =
| CAimmC_otbn_nbits of signedness * positive
| CAimmC_otbn_bn_shift
| CAimmC_otbn_mulqacc_shift

val otbn_caimm_cond_rect :
  (signedness -> positive -> 'a1) -> 'a1 -> 'a1 -> otbn_caimm_cond -> 'a1

val otbn_caimm_cond_rec :
  (signedness -> positive -> 'a1) -> 'a1 -> 'a1 -> otbn_caimm_cond -> 'a1

type is_otbn_caimm_cond =
| Coq_is_CAimmC_otbn_nbits of signedness * is_signedness * positive
   * is_positive
| Coq_is_CAimmC_otbn_bn_shift
| Coq_is_CAimmC_otbn_mulqacc_shift

val is_otbn_caimm_cond_rect :
  (signedness -> is_signedness -> positive -> is_positive -> 'a1) -> 'a1 ->
  'a1 -> otbn_caimm_cond -> is_otbn_caimm_cond -> 'a1

val is_otbn_caimm_cond_rec :
  (signedness -> is_signedness -> positive -> is_positive -> 'a1) -> 'a1 ->
  'a1 -> otbn_caimm_cond -> is_otbn_caimm_cond -> 'a1

val otbn_caimm_cond_tag : otbn_caimm_cond -> positive

val is_otbn_caimm_cond_inhab : otbn_caimm_cond -> is_otbn_caimm_cond

val is_otbn_caimm_cond_functor :
  otbn_caimm_cond -> is_otbn_caimm_cond -> is_otbn_caimm_cond

type box_otbn_caimm_cond_CAimmC_otbn_nbits = { coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 : 
                                               signedness;
                                               coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 : 
                                               positive }

val coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 :
  box_otbn_caimm_cond_CAimmC_otbn_nbits -> signedness

val coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 :
  box_otbn_caimm_cond_CAimmC_otbn_nbits -> positive

type box_otbn_caimm_cond_CAimmC_otbn_bn_shift =
| Box_otbn_caimm_cond_CAimmC_otbn_bn_shift

type otbn_caimm_cond_fields_t = __

val otbn_caimm_cond_fields : otbn_caimm_cond -> otbn_caimm_cond_fields_t

val otbn_caimm_cond_construct :
  positive -> otbn_caimm_cond_fields_t -> otbn_caimm_cond option

val otbn_caimm_cond_induction :
  (signedness -> is_signedness -> positive -> is_positive -> 'a1) -> 'a1 ->
  'a1 -> otbn_caimm_cond -> is_otbn_caimm_cond -> 'a1

val otbn_caimm_cond_eqb_fields :
  (otbn_caimm_cond -> otbn_caimm_cond -> bool) -> positive ->
  otbn_caimm_cond_fields_t -> otbn_caimm_cond_fields_t -> bool

val otbn_caimm_cond_eqb : otbn_caimm_cond -> otbn_caimm_cond -> bool

val otbn_caimm_cond_eqb_OK : otbn_caimm_cond -> otbn_caimm_cond -> reflect

val otbn_caimm_cond_eqb_OK_sumbool :
  otbn_caimm_cond -> otbn_caimm_cond -> bool

val eqTC_otbn_caimm_cond : otbn_caimm_cond eqTypeC

val check_nbits : signedness -> positive -> wsize -> word -> bool

val check_bn_shift : coq_Z -> bool

val check_mulqacc_shift : coq_Z -> bool

val otbn_check_CAimm : otbn_caimm_cond -> wsize -> word -> bool

val otbn_caimm_cond_pp : otbn_caimm_cond -> string

val otbn_decl : (register, empty, wide_register, rflag, condition) arch_decl

val otbn_call_conv :
  (register, empty, wide_register, rflag, condition) calling_convention

val internal_call_conv :
  (register, empty, wide_register, rflag, condition)
  internal_calling_convention
