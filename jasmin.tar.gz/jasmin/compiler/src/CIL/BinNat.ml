(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open BinPos

module N =
 struct
  (** val double : coq_N -> coq_N **)

  let double = function
  | N0 -> N0
  | Npos p -> Npos (Coq_xO p)

  (** val testbit : coq_N -> coq_N -> bool **)

  let testbit a n =
    match a with
    | N0 -> false
    | Npos p -> Pos.testbit p n
 end
