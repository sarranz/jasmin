(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Arch_decl
open Arch_extra
open Arch_utils
open Expr
open Fexpr
open Riscv_decl
open Riscv_extra
open Riscv_instr_decl
open Riscv_params_core
open Seq
open Sopn
open Wsize

module RISCVFopn :
 sig
  val to_opn :
    (register, empty, empty, empty, condt) arch_toIdent -> ((lexpr
    list * (register, empty, empty, empty, condt, riscv_op)
    asm_op_t') * rexpr list) -> (lexpr list * ((register, empty, empty,
    empty, condt, riscv_op) asm_op_t', (register, empty, empty, empty, condt,
    riscv_op, riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val mov :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val add :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    var_i -> (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val sub :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    var_i -> (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val li :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> coq_Z ->
    (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val addi :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val subi :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val andi :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val align :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    wsize -> (lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list

  val smart_addi :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list) list

  val smart_subi :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list) list

  val smart_addi_tmp :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list) list

  val smart_subi_tmp :
    (register, empty, empty, empty, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * ((register, empty, empty, empty, condt, riscv_op)
    asm_op_t', (register, empty, empty, empty, condt, riscv_op,
    riscv_extra_op) extra_op_t) extended_op_gen sopn) * rexpr list) list
 end
