(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open DecimalString
open Arch_decl
open Arch_utils
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Flag_combination
open Otbn_admit
open Param1
open Param1_trivial
open Seq
open Std
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t

(** val string_of_Z : coq_Z -> string **)

let string_of_Z z =
  NilZero.string_of_int (Z.to_int z)

(** val otbn_reg_size : wsize **)

let otbn_reg_size =
  U32

(** val otbn_xreg_size : wsize **)

let otbn_xreg_size =
  U256

type register =
| X02
| X03
| X04
| X05
| X06
| X07
| X08
| X09
| X10
| X11
| X12
| X13
| X14
| X15
| X16
| X17
| X18
| X19
| X20
| X21
| X22
| X23
| X24
| X25
| X26
| X27
| X28
| X29
| X30
| X31

(** val register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register
    -> 'a1 **)

let register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 = function
| X02 -> f
| X03 -> f0
| X04 -> f1
| X05 -> f2
| X06 -> f3
| X07 -> f4
| X08 -> f5
| X09 -> f6
| X10 -> f7
| X11 -> f8
| X12 -> f9
| X13 -> f10
| X14 -> f11
| X15 -> f12
| X16 -> f13
| X17 -> f14
| X18 -> f15
| X19 -> f16
| X20 -> f17
| X21 -> f18
| X22 -> f19
| X23 -> f20
| X24 -> f21
| X25 -> f22
| X26 -> f23
| X27 -> f24
| X28 -> f25
| X29 -> f26
| X30 -> f27
| X31 -> f28

(** val register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register
    -> 'a1 **)

let register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 = function
| X02 -> f
| X03 -> f0
| X04 -> f1
| X05 -> f2
| X06 -> f3
| X07 -> f4
| X08 -> f5
| X09 -> f6
| X10 -> f7
| X11 -> f8
| X12 -> f9
| X13 -> f10
| X14 -> f11
| X15 -> f12
| X16 -> f13
| X17 -> f14
| X18 -> f15
| X19 -> f16
| X20 -> f17
| X21 -> f18
| X22 -> f19
| X23 -> f20
| X24 -> f21
| X25 -> f22
| X26 -> f23
| X27 -> f24
| X28 -> f25
| X29 -> f26
| X30 -> f27
| X31 -> f28

type is_register =
| Coq_is_X02
| Coq_is_X03
| Coq_is_X04
| Coq_is_X05
| Coq_is_X06
| Coq_is_X07
| Coq_is_X08
| Coq_is_X09
| Coq_is_X10
| Coq_is_X11
| Coq_is_X12
| Coq_is_X13
| Coq_is_X14
| Coq_is_X15
| Coq_is_X16
| Coq_is_X17
| Coq_is_X18
| Coq_is_X19
| Coq_is_X20
| Coq_is_X21
| Coq_is_X22
| Coq_is_X23
| Coq_is_X24
| Coq_is_X25
| Coq_is_X26
| Coq_is_X27
| Coq_is_X28
| Coq_is_X29
| Coq_is_X30
| Coq_is_X31

(** val is_register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register
    -> is_register -> 'a1 **)

let is_register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 _ = function
| Coq_is_X02 -> f
| Coq_is_X03 -> f0
| Coq_is_X04 -> f1
| Coq_is_X05 -> f2
| Coq_is_X06 -> f3
| Coq_is_X07 -> f4
| Coq_is_X08 -> f5
| Coq_is_X09 -> f6
| Coq_is_X10 -> f7
| Coq_is_X11 -> f8
| Coq_is_X12 -> f9
| Coq_is_X13 -> f10
| Coq_is_X14 -> f11
| Coq_is_X15 -> f12
| Coq_is_X16 -> f13
| Coq_is_X17 -> f14
| Coq_is_X18 -> f15
| Coq_is_X19 -> f16
| Coq_is_X20 -> f17
| Coq_is_X21 -> f18
| Coq_is_X22 -> f19
| Coq_is_X23 -> f20
| Coq_is_X24 -> f21
| Coq_is_X25 -> f22
| Coq_is_X26 -> f23
| Coq_is_X27 -> f24
| Coq_is_X28 -> f25
| Coq_is_X29 -> f26
| Coq_is_X30 -> f27
| Coq_is_X31 -> f28

(** val is_register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register
    -> is_register -> 'a1 **)

let is_register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 _ = function
| Coq_is_X02 -> f
| Coq_is_X03 -> f0
| Coq_is_X04 -> f1
| Coq_is_X05 -> f2
| Coq_is_X06 -> f3
| Coq_is_X07 -> f4
| Coq_is_X08 -> f5
| Coq_is_X09 -> f6
| Coq_is_X10 -> f7
| Coq_is_X11 -> f8
| Coq_is_X12 -> f9
| Coq_is_X13 -> f10
| Coq_is_X14 -> f11
| Coq_is_X15 -> f12
| Coq_is_X16 -> f13
| Coq_is_X17 -> f14
| Coq_is_X18 -> f15
| Coq_is_X19 -> f16
| Coq_is_X20 -> f17
| Coq_is_X21 -> f18
| Coq_is_X22 -> f19
| Coq_is_X23 -> f20
| Coq_is_X24 -> f21
| Coq_is_X25 -> f22
| Coq_is_X26 -> f23
| Coq_is_X27 -> f24
| Coq_is_X28 -> f25
| Coq_is_X29 -> f26
| Coq_is_X30 -> f27
| Coq_is_X31 -> f28

(** val register_tag : register -> positive **)

let register_tag = function
| X02 -> Coq_xH
| X03 -> Coq_xO Coq_xH
| X04 -> Coq_xI Coq_xH
| X05 -> Coq_xO (Coq_xO Coq_xH)
| X06 -> Coq_xI (Coq_xO Coq_xH)
| X07 -> Coq_xO (Coq_xI Coq_xH)
| X08 -> Coq_xI (Coq_xI Coq_xH)
| X09 -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| X10 -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| X11 -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| X12 -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| X13 -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| X14 -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| X15 -> Coq_xO (Coq_xI (Coq_xI Coq_xH))
| X16 -> Coq_xI (Coq_xI (Coq_xI Coq_xH))
| X17 -> Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| X18 -> Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| X19 -> Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| X20 -> Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| X21 -> Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| X22 -> Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| X23 -> Coq_xO (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| X24 -> Coq_xI (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| X25 -> Coq_xO (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| X26 -> Coq_xI (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| X27 -> Coq_xO (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| X28 -> Coq_xI (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| X29 -> Coq_xO (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| X30 -> Coq_xI (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| X31 -> Coq_xO (Coq_xI (Coq_xI (Coq_xI Coq_xH)))

(** val is_register_inhab : register -> is_register **)

let is_register_inhab = function
| X02 -> Coq_is_X02
| X03 -> Coq_is_X03
| X04 -> Coq_is_X04
| X05 -> Coq_is_X05
| X06 -> Coq_is_X06
| X07 -> Coq_is_X07
| X08 -> Coq_is_X08
| X09 -> Coq_is_X09
| X10 -> Coq_is_X10
| X11 -> Coq_is_X11
| X12 -> Coq_is_X12
| X13 -> Coq_is_X13
| X14 -> Coq_is_X14
| X15 -> Coq_is_X15
| X16 -> Coq_is_X16
| X17 -> Coq_is_X17
| X18 -> Coq_is_X18
| X19 -> Coq_is_X19
| X20 -> Coq_is_X20
| X21 -> Coq_is_X21
| X22 -> Coq_is_X22
| X23 -> Coq_is_X23
| X24 -> Coq_is_X24
| X25 -> Coq_is_X25
| X26 -> Coq_is_X26
| X27 -> Coq_is_X27
| X28 -> Coq_is_X28
| X29 -> Coq_is_X29
| X30 -> Coq_is_X30
| X31 -> Coq_is_X31

(** val is_register_functor : register -> is_register -> is_register **)

let rec is_register_functor _ x =
  x

type box_register_X02 =
| Box_register_X02

type register_fields_t = __

(** val register_fields : register -> register_fields_t **)

let register_fields _ =
  Obj.magic Box_register_X02

(** val register_construct :
    positive -> register_fields_t -> register option **)

let register_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> None
           | Coq_xO _ -> Some X24
           | Coq_xH -> Some X16)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some X28
           | Coq_xO _ -> Some X20
           | Coq_xH -> Some X12)
        | Coq_xH -> Some X08)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some X30
           | Coq_xO _ -> Some X22
           | Coq_xH -> Some X14)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some X26
           | Coq_xO _ -> Some X18
           | Coq_xH -> Some X10)
        | Coq_xH -> Some X06)
     | Coq_xH -> Some X04)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some X31
           | Coq_xO _ -> Some X23
           | Coq_xH -> Some X15)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some X27
           | Coq_xO _ -> Some X19
           | Coq_xH -> Some X11)
        | Coq_xH -> Some X07)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some X29
           | Coq_xO _ -> Some X21
           | Coq_xH -> Some X13)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some X25
           | Coq_xO _ -> Some X17
           | Coq_xH -> Some X09)
        | Coq_xH -> Some X05)
     | Coq_xH -> Some X03)
  | Coq_xH -> Some X02

(** val register_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register
    -> is_register -> 'a1 **)

let register_induction his_X02 his_X03 his_X04 his_X05 his_X06 his_X07 his_X08 his_X09 his_X10 his_X11 his_X12 his_X13 his_X14 his_X15 his_X16 his_X17 his_X18 his_X19 his_X20 his_X21 his_X22 his_X23 his_X24 his_X25 his_X26 his_X27 his_X28 his_X29 his_X30 his_X31 _ = function
| Coq_is_X02 -> his_X02
| Coq_is_X03 -> his_X03
| Coq_is_X04 -> his_X04
| Coq_is_X05 -> his_X05
| Coq_is_X06 -> his_X06
| Coq_is_X07 -> his_X07
| Coq_is_X08 -> his_X08
| Coq_is_X09 -> his_X09
| Coq_is_X10 -> his_X10
| Coq_is_X11 -> his_X11
| Coq_is_X12 -> his_X12
| Coq_is_X13 -> his_X13
| Coq_is_X14 -> his_X14
| Coq_is_X15 -> his_X15
| Coq_is_X16 -> his_X16
| Coq_is_X17 -> his_X17
| Coq_is_X18 -> his_X18
| Coq_is_X19 -> his_X19
| Coq_is_X20 -> his_X20
| Coq_is_X21 -> his_X21
| Coq_is_X22 -> his_X22
| Coq_is_X23 -> his_X23
| Coq_is_X24 -> his_X24
| Coq_is_X25 -> his_X25
| Coq_is_X26 -> his_X26
| Coq_is_X27 -> his_X27
| Coq_is_X28 -> his_X28
| Coq_is_X29 -> his_X29
| Coq_is_X30 -> his_X30
| Coq_is_X31 -> his_X31

(** val register_eqb_fields :
    (register -> register -> bool) -> positive -> register_fields_t ->
    register_fields_t -> bool **)

let register_eqb_fields _ _ _ _ =
  true

(** val register_eqb : register -> register -> bool **)

let register_eqb x1 x2 =
  eqb_body register_tag register_fields
    (Obj.magic register_eqb_fields (fun _ _ -> true)) (register_tag x1)
    Box_register_X02 x2

(** val register_eqb_OK : register -> register -> reflect **)

let register_eqb_OK =
  iffP2 register_eqb

(** val register_eqb_OK_sumbool : register -> register -> bool **)

let register_eqb_OK_sumbool =
  reflect_dec register_eqb register_eqb_OK

(** val eqTC_register : register eqTypeC **)

let eqTC_register =
  { beq = register_eqb; ceqP = register_eqb_OK }

(** val otbn_register_eqType : Equality.coq_type **)

let otbn_register_eqType =
  ceqT_eqType eqTC_register

(** val registers : register list **)

let registers =
  X02 :: (X03 :: (X04 :: (X05 :: (X06 :: (X07 :: (X08 :: (X09 :: (X10 :: (X11 :: (X12 :: (X13 :: (X14 :: (X15 :: (X16 :: (X17 :: (X18 :: (X19 :: (X20 :: (X21 :: (X22 :: (X23 :: (X24 :: (X25 :: (X26 :: (X27 :: (X28 :: (X29 :: (X30 :: (X31 :: [])))))))))))))))))))))))))))))

(** val finTC_register : register finTypeC **)

let finTC_register =
  { _eqC = eqTC_register; cenum = registers }

(** val register_finType : Finite.coq_type **)

let register_finType =
  cfinT_finType finTC_register

(** val register_to_string : register -> string **)

let register_to_string = function
| X02 -> "x2"
| X03 -> "x3"
| X04 -> "x4"
| X05 -> "x5"
| X06 -> "x6"
| X07 -> "x7"
| X08 -> "x8"
| X09 -> "x9"
| X10 -> "x10"
| X11 -> "x11"
| X12 -> "x12"
| X13 -> "x13"
| X14 -> "x14"
| X15 -> "x15"
| X16 -> "x16"
| X17 -> "x17"
| X18 -> "x18"
| X19 -> "x19"
| X20 -> "x20"
| X21 -> "x21"
| X22 -> "x22"
| X23 -> "x23"
| X24 -> "x24"
| X25 -> "x25"
| X26 -> "x26"
| X27 -> "x27"
| X28 -> "x28"
| X29 -> "x29"
| X30 -> "x30"
| X31 -> "x31"

(** val reg_toS : register coq_ToString **)

let reg_toS =
  { category = "register"; _finC = finTC_register; to_string =
    register_to_string }

type wide_register =
| W00
| W01
| W02
| W03
| W04
| W05
| W06
| W07
| W08
| W09
| W10
| W11
| W12
| W13
| W14
| W15
| W16
| W17
| W18
| W19
| W20
| W21
| W22
| W23
| W24
| W25
| W26
| W27
| W28
| W29
| W30
| W31
| ACC
| MOD

(** val wide_register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> wide_register -> 'a1 **)

let wide_register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 = function
| W00 -> f
| W01 -> f0
| W02 -> f1
| W03 -> f2
| W04 -> f3
| W05 -> f4
| W06 -> f5
| W07 -> f6
| W08 -> f7
| W09 -> f8
| W10 -> f9
| W11 -> f10
| W12 -> f11
| W13 -> f12
| W14 -> f13
| W15 -> f14
| W16 -> f15
| W17 -> f16
| W18 -> f17
| W19 -> f18
| W20 -> f19
| W21 -> f20
| W22 -> f21
| W23 -> f22
| W24 -> f23
| W25 -> f24
| W26 -> f25
| W27 -> f26
| W28 -> f27
| W29 -> f28
| W30 -> f29
| W31 -> f30
| ACC -> f31
| MOD -> f32

(** val wide_register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> wide_register -> 'a1 **)

let wide_register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 = function
| W00 -> f
| W01 -> f0
| W02 -> f1
| W03 -> f2
| W04 -> f3
| W05 -> f4
| W06 -> f5
| W07 -> f6
| W08 -> f7
| W09 -> f8
| W10 -> f9
| W11 -> f10
| W12 -> f11
| W13 -> f12
| W14 -> f13
| W15 -> f14
| W16 -> f15
| W17 -> f16
| W18 -> f17
| W19 -> f18
| W20 -> f19
| W21 -> f20
| W22 -> f21
| W23 -> f22
| W24 -> f23
| W25 -> f24
| W26 -> f25
| W27 -> f26
| W28 -> f27
| W29 -> f28
| W30 -> f29
| W31 -> f30
| ACC -> f31
| MOD -> f32

type is_wide_register =
| Coq_is_W00
| Coq_is_W01
| Coq_is_W02
| Coq_is_W03
| Coq_is_W04
| Coq_is_W05
| Coq_is_W06
| Coq_is_W07
| Coq_is_W08
| Coq_is_W09
| Coq_is_W10
| Coq_is_W11
| Coq_is_W12
| Coq_is_W13
| Coq_is_W14
| Coq_is_W15
| Coq_is_W16
| Coq_is_W17
| Coq_is_W18
| Coq_is_W19
| Coq_is_W20
| Coq_is_W21
| Coq_is_W22
| Coq_is_W23
| Coq_is_W24
| Coq_is_W25
| Coq_is_W26
| Coq_is_W27
| Coq_is_W28
| Coq_is_W29
| Coq_is_W30
| Coq_is_W31
| Coq_is_ACC
| Coq_is_MOD

(** val is_wide_register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> wide_register -> is_wide_register -> 'a1 **)

let is_wide_register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 _ = function
| Coq_is_W00 -> f
| Coq_is_W01 -> f0
| Coq_is_W02 -> f1
| Coq_is_W03 -> f2
| Coq_is_W04 -> f3
| Coq_is_W05 -> f4
| Coq_is_W06 -> f5
| Coq_is_W07 -> f6
| Coq_is_W08 -> f7
| Coq_is_W09 -> f8
| Coq_is_W10 -> f9
| Coq_is_W11 -> f10
| Coq_is_W12 -> f11
| Coq_is_W13 -> f12
| Coq_is_W14 -> f13
| Coq_is_W15 -> f14
| Coq_is_W16 -> f15
| Coq_is_W17 -> f16
| Coq_is_W18 -> f17
| Coq_is_W19 -> f18
| Coq_is_W20 -> f19
| Coq_is_W21 -> f20
| Coq_is_W22 -> f21
| Coq_is_W23 -> f22
| Coq_is_W24 -> f23
| Coq_is_W25 -> f24
| Coq_is_W26 -> f25
| Coq_is_W27 -> f26
| Coq_is_W28 -> f27
| Coq_is_W29 -> f28
| Coq_is_W30 -> f29
| Coq_is_W31 -> f30
| Coq_is_ACC -> f31
| Coq_is_MOD -> f32

(** val is_wide_register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> wide_register -> is_wide_register -> 'a1 **)

let is_wide_register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 _ = function
| Coq_is_W00 -> f
| Coq_is_W01 -> f0
| Coq_is_W02 -> f1
| Coq_is_W03 -> f2
| Coq_is_W04 -> f3
| Coq_is_W05 -> f4
| Coq_is_W06 -> f5
| Coq_is_W07 -> f6
| Coq_is_W08 -> f7
| Coq_is_W09 -> f8
| Coq_is_W10 -> f9
| Coq_is_W11 -> f10
| Coq_is_W12 -> f11
| Coq_is_W13 -> f12
| Coq_is_W14 -> f13
| Coq_is_W15 -> f14
| Coq_is_W16 -> f15
| Coq_is_W17 -> f16
| Coq_is_W18 -> f17
| Coq_is_W19 -> f18
| Coq_is_W20 -> f19
| Coq_is_W21 -> f20
| Coq_is_W22 -> f21
| Coq_is_W23 -> f22
| Coq_is_W24 -> f23
| Coq_is_W25 -> f24
| Coq_is_W26 -> f25
| Coq_is_W27 -> f26
| Coq_is_W28 -> f27
| Coq_is_W29 -> f28
| Coq_is_W30 -> f29
| Coq_is_W31 -> f30
| Coq_is_ACC -> f31
| Coq_is_MOD -> f32

(** val wide_register_tag : wide_register -> positive **)

let wide_register_tag = function
| W00 -> Coq_xH
| W01 -> Coq_xO Coq_xH
| W02 -> Coq_xI Coq_xH
| W03 -> Coq_xO (Coq_xO Coq_xH)
| W04 -> Coq_xI (Coq_xO Coq_xH)
| W05 -> Coq_xO (Coq_xI Coq_xH)
| W06 -> Coq_xI (Coq_xI Coq_xH)
| W07 -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| W08 -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| W09 -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| W10 -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| W11 -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| W12 -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| W13 -> Coq_xO (Coq_xI (Coq_xI Coq_xH))
| W14 -> Coq_xI (Coq_xI (Coq_xI Coq_xH))
| W15 -> Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| W16 -> Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| W17 -> Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| W18 -> Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| W19 -> Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| W20 -> Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| W21 -> Coq_xO (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| W22 -> Coq_xI (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| W23 -> Coq_xO (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| W24 -> Coq_xI (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| W25 -> Coq_xO (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| W26 -> Coq_xI (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| W27 -> Coq_xO (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| W28 -> Coq_xI (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| W29 -> Coq_xO (Coq_xI (Coq_xI (Coq_xI Coq_xH)))
| W30 -> Coq_xI (Coq_xI (Coq_xI (Coq_xI Coq_xH)))
| W31 -> Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH))))
| ACC -> Coq_xI (Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH))))
| MOD -> Coq_xO (Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH))))

(** val is_wide_register_inhab : wide_register -> is_wide_register **)

let is_wide_register_inhab = function
| W00 -> Coq_is_W00
| W01 -> Coq_is_W01
| W02 -> Coq_is_W02
| W03 -> Coq_is_W03
| W04 -> Coq_is_W04
| W05 -> Coq_is_W05
| W06 -> Coq_is_W06
| W07 -> Coq_is_W07
| W08 -> Coq_is_W08
| W09 -> Coq_is_W09
| W10 -> Coq_is_W10
| W11 -> Coq_is_W11
| W12 -> Coq_is_W12
| W13 -> Coq_is_W13
| W14 -> Coq_is_W14
| W15 -> Coq_is_W15
| W16 -> Coq_is_W16
| W17 -> Coq_is_W17
| W18 -> Coq_is_W18
| W19 -> Coq_is_W19
| W20 -> Coq_is_W20
| W21 -> Coq_is_W21
| W22 -> Coq_is_W22
| W23 -> Coq_is_W23
| W24 -> Coq_is_W24
| W25 -> Coq_is_W25
| W26 -> Coq_is_W26
| W27 -> Coq_is_W27
| W28 -> Coq_is_W28
| W29 -> Coq_is_W29
| W30 -> Coq_is_W30
| W31 -> Coq_is_W31
| ACC -> Coq_is_ACC
| MOD -> Coq_is_MOD

(** val is_wide_register_functor :
    wide_register -> is_wide_register -> is_wide_register **)

let rec is_wide_register_functor _ x =
  x

type box_wide_register_W00 =
| Box_wide_register_W00

type wide_register_fields_t = __

(** val wide_register_fields : wide_register -> wide_register_fields_t **)

let wide_register_fields _ =
  Obj.magic Box_wide_register_W00

(** val wide_register_construct :
    positive -> wide_register_fields_t -> wide_register option **)

let wide_register_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some W30
           | Coq_xO _ -> Some W22
           | Coq_xH -> Some W14)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some W26
           | Coq_xO _ -> Some W18
           | Coq_xH -> Some W10)
        | Coq_xH -> Some W06)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some W28
           | Coq_xO _ -> Some W20
           | Coq_xH -> Some W12)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some W24
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some ACC
              | Coq_xH -> Some W16)
           | Coq_xH -> Some W08)
        | Coq_xH -> Some W04)
     | Coq_xH -> Some W02)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some W29
           | Coq_xO _ -> Some W21
           | Coq_xH -> Some W13)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some W25
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some MOD
              | Coq_xH -> Some W17)
           | Coq_xH -> Some W09)
        | Coq_xH -> Some W05)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some W27
           | Coq_xO _ -> Some W19
           | Coq_xH -> Some W11)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some W23
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some W31
              | Coq_xH -> Some W15)
           | Coq_xH -> Some W07)
        | Coq_xH -> Some W03)
     | Coq_xH -> Some W01)
  | Coq_xH -> Some W00

(** val wide_register_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> wide_register -> is_wide_register -> 'a1 **)

let wide_register_induction his_W00 his_W01 his_W02 his_W03 his_W04 his_W05 his_W06 his_W07 his_W08 his_W09 his_W10 his_W11 his_W12 his_W13 his_W14 his_W15 his_W16 his_W17 his_W18 his_W19 his_W20 his_W21 his_W22 his_W23 his_W24 his_W25 his_W26 his_W27 his_W28 his_W29 his_W30 his_W31 his_ACC his_MOD _ = function
| Coq_is_W00 -> his_W00
| Coq_is_W01 -> his_W01
| Coq_is_W02 -> his_W02
| Coq_is_W03 -> his_W03
| Coq_is_W04 -> his_W04
| Coq_is_W05 -> his_W05
| Coq_is_W06 -> his_W06
| Coq_is_W07 -> his_W07
| Coq_is_W08 -> his_W08
| Coq_is_W09 -> his_W09
| Coq_is_W10 -> his_W10
| Coq_is_W11 -> his_W11
| Coq_is_W12 -> his_W12
| Coq_is_W13 -> his_W13
| Coq_is_W14 -> his_W14
| Coq_is_W15 -> his_W15
| Coq_is_W16 -> his_W16
| Coq_is_W17 -> his_W17
| Coq_is_W18 -> his_W18
| Coq_is_W19 -> his_W19
| Coq_is_W20 -> his_W20
| Coq_is_W21 -> his_W21
| Coq_is_W22 -> his_W22
| Coq_is_W23 -> his_W23
| Coq_is_W24 -> his_W24
| Coq_is_W25 -> his_W25
| Coq_is_W26 -> his_W26
| Coq_is_W27 -> his_W27
| Coq_is_W28 -> his_W28
| Coq_is_W29 -> his_W29
| Coq_is_W30 -> his_W30
| Coq_is_W31 -> his_W31
| Coq_is_ACC -> his_ACC
| Coq_is_MOD -> his_MOD

(** val wide_register_eqb_fields :
    (wide_register -> wide_register -> bool) -> positive ->
    wide_register_fields_t -> wide_register_fields_t -> bool **)

let wide_register_eqb_fields _ _ _ _ =
  true

(** val wide_register_eqb : wide_register -> wide_register -> bool **)

let wide_register_eqb x1 x2 =
  eqb_body wide_register_tag wide_register_fields
    (Obj.magic wide_register_eqb_fields (fun _ _ -> true))
    (wide_register_tag x1) Box_wide_register_W00 x2

(** val wide_register_eqb_OK : wide_register -> wide_register -> reflect **)

let wide_register_eqb_OK =
  iffP2 wide_register_eqb

(** val wide_register_eqb_OK_sumbool :
    wide_register -> wide_register -> bool **)

let wide_register_eqb_OK_sumbool =
  reflect_dec wide_register_eqb wide_register_eqb_OK

(** val eqTC_wide_register : wide_register eqTypeC **)

let eqTC_wide_register =
  { beq = wide_register_eqb; ceqP = wide_register_eqb_OK }

(** val otbn_wide_register_eqType : Equality.coq_type **)

let otbn_wide_register_eqType =
  ceqT_eqType eqTC_wide_register

(** val wide_registers : wide_register list **)

let wide_registers =
  W00 :: (W01 :: (W02 :: (W03 :: (W04 :: (W05 :: (W06 :: (W07 :: (W08 :: (W09 :: (W10 :: (W11 :: (W12 :: (W13 :: (W14 :: (W15 :: (W16 :: (W17 :: (W18 :: (W19 :: (W20 :: (W21 :: (W22 :: (W23 :: (W24 :: (W25 :: (W26 :: (W27 :: (W28 :: (W29 :: (W30 :: (W31 :: (ACC :: (MOD :: [])))))))))))))))))))))))))))))))))

(** val finTC_wide_register : wide_register finTypeC **)

let finTC_wide_register =
  { _eqC = eqTC_wide_register; cenum = wide_registers }

(** val wide_register_finType : Finite.coq_type **)

let wide_register_finType =
  cfinT_finType finTC_wide_register

(** val wide_register_to_string : wide_register -> string **)

let wide_register_to_string = function
| W00 -> "w0"
| W01 -> "w1"
| W02 -> "w2"
| W03 -> "w3"
| W04 -> "w4"
| W05 -> "w5"
| W06 -> "w6"
| W07 -> "w7"
| W08 -> "w8"
| W09 -> "w9"
| W10 -> "w10"
| W11 -> "w11"
| W12 -> "w12"
| W13 -> "w13"
| W14 -> "w14"
| W15 -> "w15"
| W16 -> "w16"
| W17 -> "w17"
| W18 -> "w18"
| W19 -> "w19"
| W20 -> "w20"
| W21 -> "w21"
| W22 -> "w22"
| W23 -> "w23"
| W24 -> "w24"
| W25 -> "w25"
| W26 -> "w26"
| W27 -> "w27"
| W28 -> "w28"
| W29 -> "w29"
| W30 -> "w30"
| W31 -> "w31"
| ACC -> "acc"
| MOD -> "mod"

(** val xreg_toS : wide_register coq_ToString **)

let xreg_toS =
  { category = "wide_register"; _finC = finTC_wide_register; to_string =
    wide_register_to_string }

type rflag =
| CF0
| CF1
| MF0
| MF1
| LF0
| LF1
| ZF0
| ZF1

(** val rflag_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1 **)

let rflag_rect f f0 f1 f2 f3 f4 f5 f6 = function
| CF0 -> f
| CF1 -> f0
| MF0 -> f1
| MF1 -> f2
| LF0 -> f3
| LF1 -> f4
| ZF0 -> f5
| ZF1 -> f6

(** val rflag_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1 **)

let rflag_rec f f0 f1 f2 f3 f4 f5 f6 = function
| CF0 -> f
| CF1 -> f0
| MF0 -> f1
| MF1 -> f2
| LF0 -> f3
| LF1 -> f4
| ZF0 -> f5
| ZF1 -> f6

type is_rflag =
| Coq_is_CF0
| Coq_is_CF1
| Coq_is_MF0
| Coq_is_MF1
| Coq_is_LF0
| Coq_is_LF1
| Coq_is_ZF0
| Coq_is_ZF1

(** val is_rflag_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag
    -> 'a1 **)

let is_rflag_rect f f0 f1 f2 f3 f4 f5 f6 _ = function
| Coq_is_CF0 -> f
| Coq_is_CF1 -> f0
| Coq_is_MF0 -> f1
| Coq_is_MF1 -> f2
| Coq_is_LF0 -> f3
| Coq_is_LF1 -> f4
| Coq_is_ZF0 -> f5
| Coq_is_ZF1 -> f6

(** val is_rflag_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag
    -> 'a1 **)

let is_rflag_rec f f0 f1 f2 f3 f4 f5 f6 _ = function
| Coq_is_CF0 -> f
| Coq_is_CF1 -> f0
| Coq_is_MF0 -> f1
| Coq_is_MF1 -> f2
| Coq_is_LF0 -> f3
| Coq_is_LF1 -> f4
| Coq_is_ZF0 -> f5
| Coq_is_ZF1 -> f6

(** val rflag_tag : rflag -> positive **)

let rflag_tag = function
| CF0 -> Coq_xH
| CF1 -> Coq_xO Coq_xH
| MF0 -> Coq_xI Coq_xH
| MF1 -> Coq_xO (Coq_xO Coq_xH)
| LF0 -> Coq_xI (Coq_xO Coq_xH)
| LF1 -> Coq_xO (Coq_xI Coq_xH)
| ZF0 -> Coq_xI (Coq_xI Coq_xH)
| ZF1 -> Coq_xO (Coq_xO (Coq_xO Coq_xH))

(** val is_rflag_inhab : rflag -> is_rflag **)

let is_rflag_inhab = function
| CF0 -> Coq_is_CF0
| CF1 -> Coq_is_CF1
| MF0 -> Coq_is_MF0
| MF1 -> Coq_is_MF1
| LF0 -> Coq_is_LF0
| LF1 -> Coq_is_LF1
| ZF0 -> Coq_is_ZF0
| ZF1 -> Coq_is_ZF1

(** val is_rflag_functor : rflag -> is_rflag -> is_rflag **)

let rec is_rflag_functor _ x =
  x

type box_rflag_CF0 =
| Box_rflag_CF0

type rflag_fields_t = __

(** val rflag_fields : rflag -> rflag_fields_t **)

let rflag_fields _ =
  Obj.magic Box_rflag_CF0

(** val rflag_construct : positive -> rflag_fields_t -> rflag option **)

let rflag_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI _ -> Some ZF0
     | Coq_xO _ -> Some LF0
     | Coq_xH -> Some MF0)
  | Coq_xO x ->
    (match x with
     | Coq_xI _ -> Some LF1
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> None
        | Coq_xO _ -> Some ZF1
        | Coq_xH -> Some MF1)
     | Coq_xH -> Some CF1)
  | Coq_xH -> Some CF0

(** val rflag_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag
    -> 'a1 **)

let rflag_induction his_CF0 his_CF1 his_MF0 his_MF1 his_LF0 his_LF1 his_ZF0 his_ZF1 _ = function
| Coq_is_CF0 -> his_CF0
| Coq_is_CF1 -> his_CF1
| Coq_is_MF0 -> his_MF0
| Coq_is_MF1 -> his_MF1
| Coq_is_LF0 -> his_LF0
| Coq_is_LF1 -> his_LF1
| Coq_is_ZF0 -> his_ZF0
| Coq_is_ZF1 -> his_ZF1

(** val rflag_eqb_fields :
    (rflag -> rflag -> bool) -> positive -> rflag_fields_t -> rflag_fields_t
    -> bool **)

let rflag_eqb_fields _ _ _ _ =
  true

(** val rflag_eqb : rflag -> rflag -> bool **)

let rflag_eqb x1 x2 =
  eqb_body rflag_tag rflag_fields
    (Obj.magic rflag_eqb_fields (fun _ _ -> true)) (rflag_tag x1)
    Box_rflag_CF0 x2

(** val rflag_eqb_OK : rflag -> rflag -> reflect **)

let rflag_eqb_OK =
  iffP2 rflag_eqb

(** val rflag_eqb_OK_sumbool : rflag -> rflag -> bool **)

let rflag_eqb_OK_sumbool =
  reflect_dec rflag_eqb rflag_eqb_OK

(** val eqTC_rflag : rflag eqTypeC **)

let eqTC_rflag =
  { beq = rflag_eqb; ceqP = rflag_eqb_OK }

(** val rflag_eqType : Equality.coq_type **)

let rflag_eqType =
  ceqT_eqType eqTC_rflag

(** val rflags : rflag list **)

let rflags =
  CF0 :: (CF1 :: (MF0 :: (MF1 :: (LF0 :: (LF1 :: (ZF0 :: (ZF1 :: [])))))))

(** val finTC_rflag : rflag finTypeC **)

let finTC_rflag =
  { _eqC = eqTC_rflag; cenum = rflags }

(** val rflag_finType : Finite.coq_type **)

let rflag_finType =
  cfinT_finType finTC_rflag

(** val flag_to_string : rflag -> string **)

let flag_to_string = function
| CF0 -> "CF0"
| CF1 -> "CF1"
| MF0 -> "MF0"
| MF1 -> "MF1"
| LF0 -> "LF0"
| LF1 -> "LF1"
| ZF0 -> "ZF0"
| ZF1 -> "ZF1"

(** val flag_toS : rflag coq_ToString **)

let flag_toS =
  { category = "flag"; _finC = finTC_rflag; to_string = flag_to_string }

type condition =
| RVcond of bool * register option * register option
| BNcond of rflag

(** val condition_rect :
    (bool -> register option -> register option -> 'a1) -> (rflag -> 'a1) ->
    condition -> 'a1 **)

let condition_rect f f0 = function
| RVcond (b, o, o0) -> f b o o0
| BNcond r -> f0 r

(** val condition_rec :
    (bool -> register option -> register option -> 'a1) -> (rflag -> 'a1) ->
    condition -> 'a1 **)

let condition_rec f f0 = function
| RVcond (b, o, o0) -> f b o o0
| BNcond r -> f0 r

type is_condition =
| Coq_is_RVcond of bool * Param1.Coq_exports.is_bool * register option
   * (register, is_register) Prelude.is_option * register option
   * (register, is_register) Prelude.is_option
| Coq_is_BNcond of rflag * is_rflag

(** val is_condition_rect :
    (bool -> Param1.Coq_exports.is_bool -> register option -> (register,
    is_register) Prelude.is_option -> register option -> (register,
    is_register) Prelude.is_option -> 'a1) -> (rflag -> is_rflag -> 'a1) ->
    condition -> is_condition -> 'a1 **)

let is_condition_rect f f0 _ = function
| Coq_is_RVcond (b, p_, o, p_0, o0, p_1) -> f b p_ o p_0 o0 p_1
| Coq_is_BNcond (r, p_) -> f0 r p_

(** val is_condition_rec :
    (bool -> Param1.Coq_exports.is_bool -> register option -> (register,
    is_register) Prelude.is_option -> register option -> (register,
    is_register) Prelude.is_option -> 'a1) -> (rflag -> is_rflag -> 'a1) ->
    condition -> is_condition -> 'a1 **)

let is_condition_rec f f0 _ = function
| Coq_is_RVcond (b, p_, o, p_0, o0, p_1) -> f b p_ o p_0 o0 p_1
| Coq_is_BNcond (r, p_) -> f0 r p_

(** val condition_tag : condition -> positive **)

let condition_tag = function
| RVcond (_, _, _) -> Coq_xH
| BNcond _ -> Coq_xO Coq_xH

(** val is_condition_inhab : condition -> is_condition **)

let is_condition_inhab = function
| RVcond (h, h0, h1) ->
  Coq_is_RVcond (h, (Coq_exports.is_bool_inhab h), h0,
    (Prelude.is_option_inhab is_register_inhab h0), h1,
    (Prelude.is_option_inhab is_register_inhab h1))
| BNcond h -> Coq_is_BNcond (h, (is_rflag_inhab h))

(** val is_condition_functor : condition -> is_condition -> is_condition **)

let rec is_condition_functor _ x =
  x

type box_condition_RVcond = { coq_Box_condition_RVcond_0 : bool;
                              coq_Box_condition_RVcond_1 : register option;
                              coq_Box_condition_RVcond_2 : register option }

(** val coq_Box_condition_RVcond_0 : box_condition_RVcond -> bool **)

let coq_Box_condition_RVcond_0 record =
  record.coq_Box_condition_RVcond_0

(** val coq_Box_condition_RVcond_1 :
    box_condition_RVcond -> register option **)

let coq_Box_condition_RVcond_1 record =
  record.coq_Box_condition_RVcond_1

(** val coq_Box_condition_RVcond_2 :
    box_condition_RVcond -> register option **)

let coq_Box_condition_RVcond_2 record =
  record.coq_Box_condition_RVcond_2

type box_condition_BNcond =
  rflag
  (* singleton inductive, whose constructor was Box_condition_BNcond *)

(** val coq_Box_condition_BNcond_0 : box_condition_BNcond -> rflag **)

let coq_Box_condition_BNcond_0 record =
  record

type condition_fields_t = __

(** val condition_fields : condition -> condition_fields_t **)

let condition_fields = function
| RVcond (h, h0, h1) ->
  Obj.magic { coq_Box_condition_RVcond_0 = h; coq_Box_condition_RVcond_1 =
    h0; coq_Box_condition_RVcond_2 = h1 }
| BNcond h -> Obj.magic h

(** val condition_construct :
    positive -> condition_fields_t -> condition option **)

let condition_construct p x =
  match p with
  | Coq_xI _ -> None
  | Coq_xO _ -> Some (BNcond (Obj.magic x))
  | Coq_xH ->
    let { coq_Box_condition_RVcond_0 = box_condition_RVcond_0;
      coq_Box_condition_RVcond_1 = box_condition_RVcond_1;
      coq_Box_condition_RVcond_2 = box_condition_RVcond_2 } = Obj.magic x
    in
    Some (RVcond (box_condition_RVcond_0, box_condition_RVcond_1,
    box_condition_RVcond_2))

(** val condition_induction :
    (bool -> Param1.Coq_exports.is_bool -> register option -> (register,
    is_register) Prelude.is_option -> register option -> (register,
    is_register) Prelude.is_option -> 'a1) -> (rflag -> is_rflag -> 'a1) ->
    condition -> is_condition -> 'a1 **)

let condition_induction his_RVcond his_BNcond _ = function
| Coq_is_RVcond (x0, p_, x1, p_0, x2, p_1) -> his_RVcond x0 p_ x1 p_0 x2 p_1
| Coq_is_BNcond (x0, p_) -> his_BNcond x0 p_

(** val condition_eqb_fields :
    (condition -> condition -> bool) -> positive -> condition_fields_t ->
    condition_fields_t -> bool **)

let condition_eqb_fields _ x x0 x1 =
  match x with
  | Coq_xI _ -> true
  | Coq_xO _ -> (&&) (rflag_eqb (Obj.magic x0) (Obj.magic x1)) true
  | Coq_xH ->
    let { coq_Box_condition_RVcond_0 = box_condition_RVcond_0;
      coq_Box_condition_RVcond_1 = box_condition_RVcond_1;
      coq_Box_condition_RVcond_2 = box_condition_RVcond_2 } = Obj.magic x0
    in
    let { coq_Box_condition_RVcond_0 = box_condition_RVcond_3;
      coq_Box_condition_RVcond_1 = box_condition_RVcond_4;
      coq_Box_condition_RVcond_2 = box_condition_RVcond_5 } = Obj.magic x1
    in
    (&&) (Prelude.bool_eqb box_condition_RVcond_0 box_condition_RVcond_3)
      ((&&)
        (Prelude.option_eqb register_eqb box_condition_RVcond_1
          box_condition_RVcond_4)
        ((&&)
          (Prelude.option_eqb register_eqb box_condition_RVcond_2
            box_condition_RVcond_5)
          true))

(** val condition_eqb : condition -> condition -> bool **)

let condition_eqb x1 x2 =
  match x1 with
  | RVcond (h, h0, h1) ->
    eqb_body condition_tag condition_fields
      (Obj.magic condition_eqb_fields (fun _ _ -> true))
      (condition_tag (RVcond (h, h0, h1))) { coq_Box_condition_RVcond_0 = h;
      coq_Box_condition_RVcond_1 = h0; coq_Box_condition_RVcond_2 = h1 } x2
  | BNcond h ->
    eqb_body condition_tag condition_fields
      (Obj.magic condition_eqb_fields (fun _ _ -> true))
      (condition_tag (BNcond h)) h x2

(** val condition_eqb_OK : condition -> condition -> reflect **)

let condition_eqb_OK =
  iffP2 condition_eqb

(** val condition_eqb_OK_sumbool : condition -> condition -> bool **)

let condition_eqb_OK_sumbool =
  reflect_dec condition_eqb condition_eqb_OK

(** val eqTC_condition : condition eqTypeC **)

let eqTC_condition =
  { beq = condition_eqb; ceqP = condition_eqb_OK }

(** val condition_eqType : Equality.coq_type **)

let condition_eqType =
  ceqT_eqType eqTC_condition

(** val fc_of_cfc : combine_flags_core -> flag_combination **)

let fc_of_cfc _ =
  coq_OTBN_ADMIT "not implemented"

(** val otbn_fcp : coq_FlagCombinationParams **)

let otbn_fcp =
  fc_of_cfc

type otbn_caimm_cond =
| CAimmC_otbn_nbits of signedness * positive
| CAimmC_otbn_bn_shift
| CAimmC_otbn_mulqacc_shift

(** val otbn_caimm_cond_rect :
    (signedness -> positive -> 'a1) -> 'a1 -> 'a1 -> otbn_caimm_cond -> 'a1 **)

let otbn_caimm_cond_rect f f0 f1 = function
| CAimmC_otbn_nbits (s, p) -> f s p
| CAimmC_otbn_bn_shift -> f0
| CAimmC_otbn_mulqacc_shift -> f1

(** val otbn_caimm_cond_rec :
    (signedness -> positive -> 'a1) -> 'a1 -> 'a1 -> otbn_caimm_cond -> 'a1 **)

let otbn_caimm_cond_rec f f0 f1 = function
| CAimmC_otbn_nbits (s, p) -> f s p
| CAimmC_otbn_bn_shift -> f0
| CAimmC_otbn_mulqacc_shift -> f1

type is_otbn_caimm_cond =
| Coq_is_CAimmC_otbn_nbits of signedness * is_signedness * positive
   * is_positive
| Coq_is_CAimmC_otbn_bn_shift
| Coq_is_CAimmC_otbn_mulqacc_shift

(** val is_otbn_caimm_cond_rect :
    (signedness -> is_signedness -> positive -> is_positive -> 'a1) -> 'a1 ->
    'a1 -> otbn_caimm_cond -> is_otbn_caimm_cond -> 'a1 **)

let is_otbn_caimm_cond_rect f f0 f1 _ = function
| Coq_is_CAimmC_otbn_nbits (s, p_, p, p_0) -> f s p_ p p_0
| Coq_is_CAimmC_otbn_bn_shift -> f0
| Coq_is_CAimmC_otbn_mulqacc_shift -> f1

(** val is_otbn_caimm_cond_rec :
    (signedness -> is_signedness -> positive -> is_positive -> 'a1) -> 'a1 ->
    'a1 -> otbn_caimm_cond -> is_otbn_caimm_cond -> 'a1 **)

let is_otbn_caimm_cond_rec f f0 f1 _ = function
| Coq_is_CAimmC_otbn_nbits (s, p_, p, p_0) -> f s p_ p p_0
| Coq_is_CAimmC_otbn_bn_shift -> f0
| Coq_is_CAimmC_otbn_mulqacc_shift -> f1

(** val otbn_caimm_cond_tag : otbn_caimm_cond -> positive **)

let otbn_caimm_cond_tag = function
| CAimmC_otbn_nbits (_, _) -> Coq_xH
| CAimmC_otbn_bn_shift -> Coq_xO Coq_xH
| CAimmC_otbn_mulqacc_shift -> Coq_xI Coq_xH

(** val is_otbn_caimm_cond_inhab : otbn_caimm_cond -> is_otbn_caimm_cond **)

let is_otbn_caimm_cond_inhab = function
| CAimmC_otbn_nbits (h, h0) ->
  Coq_is_CAimmC_otbn_nbits (h, (is_signedness_inhab h), h0,
    (is_positive_inhab h0))
| CAimmC_otbn_bn_shift -> Coq_is_CAimmC_otbn_bn_shift
| CAimmC_otbn_mulqacc_shift -> Coq_is_CAimmC_otbn_mulqacc_shift

(** val is_otbn_caimm_cond_functor :
    otbn_caimm_cond -> is_otbn_caimm_cond -> is_otbn_caimm_cond **)

let rec is_otbn_caimm_cond_functor _ x =
  x

type box_otbn_caimm_cond_CAimmC_otbn_nbits = { coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 : 
                                               signedness;
                                               coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 : 
                                               positive }

(** val coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 :
    box_otbn_caimm_cond_CAimmC_otbn_nbits -> signedness **)

let coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 record =
  record.coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0

(** val coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 :
    box_otbn_caimm_cond_CAimmC_otbn_nbits -> positive **)

let coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 record =
  record.coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1

type box_otbn_caimm_cond_CAimmC_otbn_bn_shift =
| Box_otbn_caimm_cond_CAimmC_otbn_bn_shift

type otbn_caimm_cond_fields_t = __

(** val otbn_caimm_cond_fields :
    otbn_caimm_cond -> otbn_caimm_cond_fields_t **)

let otbn_caimm_cond_fields = function
| CAimmC_otbn_nbits (h, h0) ->
  Obj.magic { coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 = h;
    coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 = h0 }
| _ -> Obj.magic Box_otbn_caimm_cond_CAimmC_otbn_bn_shift

(** val otbn_caimm_cond_construct :
    positive -> otbn_caimm_cond_fields_t -> otbn_caimm_cond option **)

let otbn_caimm_cond_construct p b =
  match p with
  | Coq_xI _ -> Some CAimmC_otbn_mulqacc_shift
  | Coq_xO _ -> Some CAimmC_otbn_bn_shift
  | Coq_xH ->
    let { coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 =
      box_otbn_caimm_cond_CAimmC_otbn_nbits_0;
      coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 =
      box_otbn_caimm_cond_CAimmC_otbn_nbits_1 } = Obj.magic b
    in
    Some (CAimmC_otbn_nbits (box_otbn_caimm_cond_CAimmC_otbn_nbits_0,
    box_otbn_caimm_cond_CAimmC_otbn_nbits_1))

(** val otbn_caimm_cond_induction :
    (signedness -> is_signedness -> positive -> is_positive -> 'a1) -> 'a1 ->
    'a1 -> otbn_caimm_cond -> is_otbn_caimm_cond -> 'a1 **)

let otbn_caimm_cond_induction his_CAimmC_otbn_nbits his_CAimmC_otbn_bn_shift his_CAimmC_otbn_mulqacc_shift _ = function
| Coq_is_CAimmC_otbn_nbits (x0, p_, x1, p_0) ->
  his_CAimmC_otbn_nbits x0 p_ x1 p_0
| Coq_is_CAimmC_otbn_bn_shift -> his_CAimmC_otbn_bn_shift
| Coq_is_CAimmC_otbn_mulqacc_shift -> his_CAimmC_otbn_mulqacc_shift

(** val otbn_caimm_cond_eqb_fields :
    (otbn_caimm_cond -> otbn_caimm_cond -> bool) -> positive ->
    otbn_caimm_cond_fields_t -> otbn_caimm_cond_fields_t -> bool **)

let otbn_caimm_cond_eqb_fields _ x a b =
  match x with
  | Coq_xH ->
    let { coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 =
      box_otbn_caimm_cond_CAimmC_otbn_nbits_0;
      coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 =
      box_otbn_caimm_cond_CAimmC_otbn_nbits_1 } = Obj.magic a
    in
    let { coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 =
      box_otbn_caimm_cond_CAimmC_otbn_nbits_2;
      coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 =
      box_otbn_caimm_cond_CAimmC_otbn_nbits_3 } = Obj.magic b
    in
    (&&)
      (signedness_eqb box_otbn_caimm_cond_CAimmC_otbn_nbits_0
        box_otbn_caimm_cond_CAimmC_otbn_nbits_2)
      ((&&)
        (positive_eqb box_otbn_caimm_cond_CAimmC_otbn_nbits_1
          box_otbn_caimm_cond_CAimmC_otbn_nbits_3)
        true)
  | _ -> true

(** val otbn_caimm_cond_eqb : otbn_caimm_cond -> otbn_caimm_cond -> bool **)

let otbn_caimm_cond_eqb x1 x2 =
  match x1 with
  | CAimmC_otbn_nbits (h, h0) ->
    eqb_body otbn_caimm_cond_tag otbn_caimm_cond_fields
      (Obj.magic otbn_caimm_cond_eqb_fields (fun _ _ -> true))
      (otbn_caimm_cond_tag (CAimmC_otbn_nbits (h, h0)))
      { coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_0 = h;
      coq_Box_otbn_caimm_cond_CAimmC_otbn_nbits_1 = h0 } x2
  | x ->
    eqb_body otbn_caimm_cond_tag otbn_caimm_cond_fields
      (Obj.magic otbn_caimm_cond_eqb_fields (fun _ _ -> true))
      (otbn_caimm_cond_tag x) Box_otbn_caimm_cond_CAimmC_otbn_bn_shift x2

(** val otbn_caimm_cond_eqb_OK :
    otbn_caimm_cond -> otbn_caimm_cond -> reflect **)

let otbn_caimm_cond_eqb_OK =
  iffP2 otbn_caimm_cond_eqb

(** val otbn_caimm_cond_eqb_OK_sumbool :
    otbn_caimm_cond -> otbn_caimm_cond -> bool **)

let otbn_caimm_cond_eqb_OK_sumbool =
  reflect_dec otbn_caimm_cond_eqb otbn_caimm_cond_eqb_OK

(** val eqTC_otbn_caimm_cond : otbn_caimm_cond eqTypeC **)

let eqTC_otbn_caimm_cond =
  { beq = otbn_caimm_cond_eqb; ceqP = otbn_caimm_cond_eqb_OK }

(** val check_nbits : signedness -> positive -> wsize -> word -> bool **)

let check_nbits s n ws w =
  let (lo, hi) = signedness_bounds s n in
  let i = match s with
          | Signed -> wsigned ws w
          | Unsigned -> wunsigned ws w in
  (&&) (Z.leb lo i) (Z.ltb i hi)

(** val check_bn_shift : coq_Z -> bool **)

let check_bn_shift i =
  (&&) (Z.leb Z0 i)
    ((&&)
      (Z.leb i (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xI (Coq_xI (Coq_xI (Coq_xI
        Coq_xH)))))))))
      (eq_op coq_BinNums_Z__canonical__eqtype_Equality
        (Obj.magic Z.modulo i (Zpos (Coq_xO (Coq_xO (Coq_xO Coq_xH)))))
        (Obj.magic Z0)))

(** val check_mulqacc_shift : coq_Z -> bool **)

let check_mulqacc_shift i =
  (&&) (Z.leb Z0 i)
    ((&&)
      (Z.leb i (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xI
        Coq_xH)))))))))
      (eq_op coq_BinNums_Z__canonical__eqtype_Equality
        (Obj.magic Z.modulo i (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
          (Coq_xO Coq_xH))))))))
        (Obj.magic Z0)))

(** val otbn_check_CAimm : otbn_caimm_cond -> wsize -> word -> bool **)

let otbn_check_CAimm checker ws w =
  match checker with
  | CAimmC_otbn_nbits (s, n) -> check_nbits s n ws w
  | CAimmC_otbn_bn_shift -> check_bn_shift (wunsigned ws w)
  | CAimmC_otbn_mulqacc_shift -> check_mulqacc_shift (wunsigned ws w)

(** val otbn_caimm_cond_pp : otbn_caimm_cond -> string **)

let otbn_caimm_cond_pp = function
| CAimmC_otbn_nbits (s, n) ->
  let (lo, hi) = signedness_bounds s n in
  String.concat ""
    ("[" :: ((string_of_Z lo) :: (", " :: ((string_of_Z hi) :: (")" :: [])))))
| CAimmC_otbn_bn_shift -> "[0, 248] in steps of 8"
| CAimmC_otbn_mulqacc_shift -> "[0, 192] in steps of 64"

(** val otbn_decl :
    (register, empty, wide_register, rflag, condition) arch_decl **)

let otbn_decl =
  { reg_size = U32; xreg_size = U256; cond_eqC = eqTC_condition; toS_r =
    reg_toS; toS_rx = (empty_toS (Coq_lword U32)); toS_x = xreg_toS; toS_f =
    flag_toS; ad_rsp = X02; ad_fcp = otbn_fcp; caimm_cond_eqC =
    (Obj.magic eqTC_otbn_caimm_cond); caimm_cond_pp =
    (Obj.magic otbn_caimm_cond_pp); check_CAimm =
    (Obj.magic otbn_check_CAimm) }

(** val otbn_call_conv :
    (register, empty, wide_register, rflag, condition) calling_convention **)

let otbn_call_conv =
  let callee_saved_registers =
    X02 :: (X08 :: (X09 :: (X18 :: (X19 :: (X20 :: (X21 :: (X22 :: (X23 :: (X24 :: (X25 :: (X26 :: (X27 :: []))))))))))))
  in
  { callee_saved = (map (fun x -> ARReg x) callee_saved_registers);
  call_reg_args =
  (X10 :: (X11 :: (X12 :: (X13 :: (X14 :: (X15 :: (X16 :: (X17 :: []))))))));
  call_xreg_args =
  (W00 :: (W01 :: (W02 :: (W03 :: (W04 :: (W05 :: (W06 :: (W07 :: []))))))));
  call_reg_ret = (X10 :: (X11 :: [])); call_xreg_ret = (W00 :: (W01 :: [])) }

(** val internal_call_conv :
    (register, empty, wide_register, rflag, condition)
    internal_calling_convention **)

let internal_call_conv =
  { icall_reg =
    (X10 :: (X11 :: (X12 :: (X13 :: (X14 :: (X15 :: (X16 :: (X17 :: (X05 :: (X06 :: (X07 :: (X08 :: (X09 :: (X18 :: (X19 :: (X20 :: (X21 :: (X22 :: (X23 :: (X24 :: (X25 :: (X26 :: (X27 :: (X28 :: (X29 :: (X30 :: (X31 :: [])))))))))))))))))))))))))));
    icall_regx = []; icall_xreg = []; icall_rflag = [] }
