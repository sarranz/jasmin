(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open Sem_type
open Seq
open Ssrnat
open Type
open Utils0
open Word0
open Wsize

type empty = |

(** val of_empty : empty -> 'a1 **)

let of_empty _ =
  assert false (* absurd case *)

(** val eqTC_empty : empty eqTypeC **)

let eqTC_empty =
  { beq = of_empty; ceqP = (fun _ _ -> assert false (* absurd case *)) }

(** val finTC_empty : empty finTypeC **)

let finTC_empty =
  { _eqC = eqTC_empty; cenum = [] }

(** val empty_toS : ltype -> empty coq_ToString **)

let empty_toS _ =
  { category = "empty"; _finC = finTC_empty; to_string = of_empty }

(** val ak_reg_reg :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    i_args_kinds **)

let ak_reg_reg _ =
  ((CAreg :: []) :: ((CAreg :: []) :: [])) :: []

(** val coq_CAimm_sz :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> wsize -> ('a1, 'a2, 'a3, 'a4, 'a5)
    arg_kind **)

let coq_CAimm_sz _ sz =
  CAimm (None, sz)

(** val ak_reg_imm :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    i_args_kinds **)

let ak_reg_imm ad =
  ((CAreg :: []) :: (((coq_CAimm_sz ad ad.reg_size) :: []) :: [])) :: []

(** val ak_reg_addr :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    i_args_kinds **)

let ak_reg_addr _ =
  ((CAreg :: []) :: (((CAmem true) :: []) :: [])) :: []

(** val ak_reg_imm8_imm8 :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    i_args_kinds **)

let ak_reg_imm8_imm8 ad =
  ((CAreg :: []) :: (((coq_CAimm_sz ad U8) :: []) :: (((coq_CAimm_sz ad U8) :: []) :: []))) :: []

(** val ak_reg_reg_reg :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    i_args_kinds **)

let ak_reg_reg_reg _ =
  ((CAreg :: []) :: ((CAreg :: []) :: ((CAreg :: []) :: []))) :: []

(** val ak_reg_reg_imm8_imm8 :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    i_args_kinds **)

let ak_reg_reg_imm8_imm8 ad =
  ((CAreg :: []) :: ((CAreg :: []) :: (((coq_CAimm_sz ad U8) :: []) :: ((
    (coq_CAimm_sz ad U8) :: []) :: [])))) :: []

(** val ak_reg_reg_reg_reg :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    i_args_kinds **)

let ak_reg_reg_reg_reg _ =
  ((CAreg :: []) :: ((CAreg :: []) :: ((CAreg :: []) :: ((CAreg :: []) :: [])))) :: []

(** val behead_tuple :
    ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
    sem_prod **)

let behead_tuple tin tout f =
  match tout with
  | [] ->
    sem_prod_app (map eval_ltype tin) f (fun x ->
      match x with
      | Ok _ -> Ok ()
      | Error s -> Error s)
  | _ :: tout' ->
    (match tout' with
     | [] ->
       sem_prod_app (map eval_ltype tin) f (fun x ->
         match x with
         | Ok _ -> Ok ()
         | Error s -> Error s)
     | _ :: _ ->
       sem_prod_app (map eval_ltype tin) f (fun x ->
         match x with
         | Ok x0 -> let (_, p) = x0 in Ok p
         | Error s -> Error s))

(** val semi_drop1 :
    ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
    sem_prod **)

let semi_drop1 =
  behead_tuple

(** val semi_drop2 :
    ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
    sem_prod **)

let semi_drop2 tin tout semi =
  behead_tuple tin (behead tout) (behead_tuple tin tout semi)

(** val semi_drop3 :
    ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
    sem_prod **)

let semi_drop3 tin tout semi =
  behead_tuple tin (behead (behead tout))
    (behead_tuple tin (behead tout) (behead_tuple tin tout semi))

(** val semi_drop4 :
    ltype list -> ltype list -> sem_tuple exec sem_prod -> sem_tuple exec
    sem_prod **)

let semi_drop4 tin tout semi =
  behead_tuple tin (behead (behead (behead tout)))
    (behead_tuple tin (behead (behead tout))
      (behead_tuple tin (behead tout) (behead_tuple tin tout semi)))

(** val idt_drop1 :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t **)

let idt_drop1 _ idt =
  { id_valid = idt.id_valid; id_msb_flag = idt.id_msb_flag; id_tin =
    idt.id_tin; id_in = idt.id_in; id_tout = (iter (S O) behead idt.id_tout);
    id_out = (iter (S O) behead idt.id_out); id_semi =
    (semi_drop1 idt.id_tin idt.id_tout idt.id_semi); id_args_kinds =
    idt.id_args_kinds; id_nargs = idt.id_nargs; id_str_jas = idt.id_str_jas;
    id_safe = idt.id_safe; id_doit = idt.id_doit; id_pp_asm = idt.id_pp_asm }

(** val idt_drop2 :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t **)

let idt_drop2 _ idt =
  { id_valid = idt.id_valid; id_msb_flag = idt.id_msb_flag; id_tin =
    idt.id_tin; id_in = idt.id_in; id_tout =
    (iter (S (S O)) behead idt.id_tout); id_out =
    (iter (S (S O)) behead idt.id_out); id_semi =
    (semi_drop2 idt.id_tin idt.id_tout idt.id_semi); id_args_kinds =
    idt.id_args_kinds; id_nargs = idt.id_nargs; id_str_jas = idt.id_str_jas;
    id_safe = idt.id_safe; id_doit = idt.id_doit; id_pp_asm = idt.id_pp_asm }

(** val idt_drop3 :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t **)

let idt_drop3 _ idt =
  { id_valid = idt.id_valid; id_msb_flag = idt.id_msb_flag; id_tin =
    idt.id_tin; id_in = idt.id_in; id_tout =
    (iter (S (S (S O))) behead idt.id_tout); id_out =
    (iter (S (S (S O))) behead idt.id_out); id_semi =
    (semi_drop3 idt.id_tin idt.id_tout idt.id_semi); id_args_kinds =
    idt.id_args_kinds; id_nargs = idt.id_nargs; id_str_jas = idt.id_str_jas;
    id_safe = idt.id_safe; id_doit = idt.id_doit; id_pp_asm = idt.id_pp_asm }

(** val idt_drop4 :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5)
    instr_desc_t -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t **)

let idt_drop4 _ idt =
  { id_valid = idt.id_valid; id_msb_flag = idt.id_msb_flag; id_tin =
    idt.id_tin; id_in = idt.id_in; id_tout =
    (iter (S (S (S (S O)))) behead idt.id_tout); id_out =
    (iter (S (S (S (S O)))) behead idt.id_out); id_semi =
    (semi_drop4 idt.id_tin idt.id_tout idt.id_semi); id_args_kinds =
    idt.id_args_kinds; id_nargs = idt.id_nargs; id_str_jas = idt.id_str_jas;
    id_safe = idt.id_safe; id_doit = idt.id_doit; id_pp_asm = idt.id_pp_asm }

(** val rtuple_drop5th :
    ctype -> ctype -> ctype -> ctype -> ctype -> sem_tuple ->
    sem_ot * (sem_ot * (sem_ot * sem_ot)) **)

let rtuple_drop5th _ _ _ _ _ xs =
  let (x0, l) = Obj.magic xs in
  let (x1, p) = l in
  let (x2, p0) = p in let (x3, _) = p0 in (x0, (x1, (x2, x3)))

(** val arch_mk_semi1_shifted :
    (wsize -> word -> coq_Z -> word) -> wsize -> 'a1 exec sem_prod -> 'a1
    exec sem_prod **)

let arch_mk_semi1_shifted shift_op ws semi =
  Obj.magic (fun wn shift_amount ->
    let sham = wunsigned U8 shift_amount in
    Obj.magic semi (shift_op ws wn sham))

(** val arch_mk_semi2_2_shifted :
    (wsize -> word -> coq_Z -> word) -> wsize -> ltype -> 'a1 exec sem_prod
    -> 'a1 exec sem_prod **)

let arch_mk_semi2_2_shifted shift_op ws _ semi =
  Obj.magic (fun x wy shift_amount ->
    let sham = wunsigned U8 shift_amount in
    Obj.magic semi x (shift_op ws wy sham))

(** val arch_mk_semi3_2_shifted :
    (wsize -> word -> coq_Z -> word) -> wsize -> ltype -> ltype -> 'a1 exec
    sem_prod -> 'a1 exec sem_prod **)

let arch_mk_semi3_2_shifted shift_op ws _ _ semi =
  Obj.magic (fun x wy z shift_amount ->
    let sham = wunsigned U8 shift_amount in
    Obj.magic semi x (shift_op ws wy sham) z)

(** val arch_mk_shifted :
    ('a1, 'a2, 'a3, 'a4, 'a5) arch_decl -> ('a1, 'a2, 'a3, 'a4, 'a5) arg_kind
    -> ('a1, 'a2, 'a3, 'a4, 'a5) instr_desc_t -> semi_type -> ('a1, 'a2, 'a3,
    'a4, 'a5) instr_desc_t **)

let arch_mk_shifted ad ak idt semi' =
  { id_valid = idt.id_valid; id_msb_flag = MSB_MERGE; id_tin =
    (cat idt.id_tin ((Coq_lword U8) :: [])); id_in =
    (cat idt.id_in ((coq_Ea ad idt.id_nargs) :: [])); id_tout = idt.id_tout;
    id_out = idt.id_out; id_semi = semi'; id_args_kinds =
    (map (fun x -> cat x ((ak :: []) :: [])) idt.id_args_kinds); id_nargs =
    (S idt.id_nargs); id_str_jas = idt.id_str_jas; id_safe = idt.id_safe;
    id_doit = idt.id_doit; id_pp_asm = idt.id_pp_asm }
