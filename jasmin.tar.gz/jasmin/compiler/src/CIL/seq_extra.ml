(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)


(** val pairfoldl :
    ('a2 -> 'a1 -> 'a1 -> 'a2) -> 'a2 -> 'a1 -> 'a1 list -> 'a2 **)

let rec pairfoldl f z t = function
| [] -> z
| x :: s' -> pairfoldl f (f z t x) x s'
