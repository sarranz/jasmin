(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open Arm_common
open Armv8a_decl
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Sem_type
open Seq
open Shift_kind
open Sopn
open Ssrbool
open Std
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize
open Xseq

type __ = Obj.t

module E :
 sig
  val no_semantics : error
 end

type armv8a_options = { has_shift : shift_kind option; opts_size : wsize }

val has_shift : armv8a_options -> shift_kind option

val opts_size : armv8a_options -> wsize

type is_armv8a_options =
| Coq_is_Build_armv8a_options of shift_kind option
   * (shift_kind, is_shift_kind) Prelude.is_option * wsize * is_wsize

val is_armv8a_options_rect :
  (shift_kind option -> (shift_kind, is_shift_kind) Prelude.is_option ->
  wsize -> is_wsize -> 'a1) -> armv8a_options -> is_armv8a_options -> 'a1

val is_armv8a_options_rec :
  (shift_kind option -> (shift_kind, is_shift_kind) Prelude.is_option ->
  wsize -> is_wsize -> 'a1) -> armv8a_options -> is_armv8a_options -> 'a1

val armv8a_options_tag : armv8a_options -> positive

val is_armv8a_options_inhab : armv8a_options -> is_armv8a_options

val is_armv8a_options_functor :
  armv8a_options -> is_armv8a_options -> is_armv8a_options

type box_armv8a_options_Build_armv8a_options = { coq_Box_armv8a_options_Build_armv8a_options_0 : 
                                                 shift_kind option;
                                                 coq_Box_armv8a_options_Build_armv8a_options_1 : 
                                                 wsize }

val coq_Box_armv8a_options_Build_armv8a_options_0 :
  box_armv8a_options_Build_armv8a_options -> shift_kind option

val coq_Box_armv8a_options_Build_armv8a_options_1 :
  box_armv8a_options_Build_armv8a_options -> wsize

type armv8a_options_fields_t = box_armv8a_options_Build_armv8a_options

val armv8a_options_fields : armv8a_options -> armv8a_options_fields_t

val armv8a_options_construct :
  positive -> box_armv8a_options_Build_armv8a_options -> armv8a_options option

val armv8a_options_induction :
  (shift_kind option -> (shift_kind, is_shift_kind) Prelude.is_option ->
  wsize -> is_wsize -> 'a1) -> armv8a_options -> is_armv8a_options -> 'a1

val armv8a_options_eqb_fields :
  (armv8a_options -> armv8a_options -> bool) -> positive ->
  box_armv8a_options_Build_armv8a_options ->
  box_armv8a_options_Build_armv8a_options -> bool

val armv8a_options_eqb : armv8a_options -> armv8a_options -> bool

val armv8a_options_eqb_OK : armv8a_options -> armv8a_options -> reflect

val armv8a_options_eqb_OK_sumbool : armv8a_options -> armv8a_options -> bool

val eqTC_armv8a_options : armv8a_options eqTypeC

val armv8a_options_eqType : Equality.coq_type

val default_opts : armv8a_options

val opts_at : wsize -> armv8a_options

type armv8a_mnemonic =
| ADD
| ADDS
| ADC
| ADCS
| SUB
| SUBS
| NEG
| MUL
| MADD
| MSUB
| SDIV
| UDIV
| AND
| ORR
| EOR
| MVN
| ASR
| LSL
| LSR
| ROR
| MOV
| MOVN
| MOVZ
| MOVK
| ADR
| SXTB
| SXTH
| SXTW
| UXTB
| UXTH
| UXTW
| CMP
| TST
| CSEL
| LDR
| LDRB
| LDRH
| LDRSB
| LDRSH
| LDRSW
| STR
| STRB
| STRH

val armv8a_mnemonic_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> armv8a_mnemonic -> 'a1

val armv8a_mnemonic_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> armv8a_mnemonic -> 'a1

type is_armv8a_mnemonic =
| Coq_is_ADD
| Coq_is_ADDS
| Coq_is_ADC
| Coq_is_ADCS
| Coq_is_SUB
| Coq_is_SUBS
| Coq_is_NEG
| Coq_is_MUL
| Coq_is_MADD
| Coq_is_MSUB
| Coq_is_SDIV
| Coq_is_UDIV
| Coq_is_AND
| Coq_is_ORR
| Coq_is_EOR
| Coq_is_MVN
| Coq_is_ASR
| Coq_is_LSL
| Coq_is_LSR
| Coq_is_ROR
| Coq_is_MOV
| Coq_is_MOVN
| Coq_is_MOVZ
| Coq_is_MOVK
| Coq_is_ADR
| Coq_is_SXTB
| Coq_is_SXTH
| Coq_is_SXTW
| Coq_is_UXTB
| Coq_is_UXTH
| Coq_is_UXTW
| Coq_is_CMP
| Coq_is_TST
| Coq_is_CSEL
| Coq_is_LDR
| Coq_is_LDRB
| Coq_is_LDRH
| Coq_is_LDRSB
| Coq_is_LDRSH
| Coq_is_LDRSW
| Coq_is_STR
| Coq_is_STRB
| Coq_is_STRH

val is_armv8a_mnemonic_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> armv8a_mnemonic -> is_armv8a_mnemonic -> 'a1

val is_armv8a_mnemonic_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> armv8a_mnemonic -> is_armv8a_mnemonic -> 'a1

val armv8a_mnemonic_tag : armv8a_mnemonic -> positive

val is_armv8a_mnemonic_inhab : armv8a_mnemonic -> is_armv8a_mnemonic

val is_armv8a_mnemonic_functor :
  armv8a_mnemonic -> is_armv8a_mnemonic -> is_armv8a_mnemonic

type box_armv8a_mnemonic_ADD =
| Box_armv8a_mnemonic_ADD

type armv8a_mnemonic_fields_t = __

val armv8a_mnemonic_fields : armv8a_mnemonic -> armv8a_mnemonic_fields_t

val armv8a_mnemonic_construct :
  positive -> armv8a_mnemonic_fields_t -> armv8a_mnemonic option

val armv8a_mnemonic_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> armv8a_mnemonic -> is_armv8a_mnemonic -> 'a1

val armv8a_mnemonic_eqb_fields :
  (armv8a_mnemonic -> armv8a_mnemonic -> bool) -> positive ->
  armv8a_mnemonic_fields_t -> armv8a_mnemonic_fields_t -> bool

val armv8a_mnemonic_eqb : armv8a_mnemonic -> armv8a_mnemonic -> bool

val armv8a_mnemonic_eqb_OK : armv8a_mnemonic -> armv8a_mnemonic -> reflect

val armv8a_mnemonic_eqb_OK_sumbool :
  armv8a_mnemonic -> armv8a_mnemonic -> bool

val eqTC_armv8a_mnemonic : armv8a_mnemonic eqTypeC

val armv8a_mnemonic_eqType : Equality.coq_type

val armv8a_mnemonics : armv8a_mnemonic list

val finTC_armv8a_mnemonic : armv8a_mnemonic finTypeC

val armv8a_mnemonic_finType : Finite.coq_type

val has_shift_mnemonics : armv8a_mnemonic list

val ror_shift_mnemonics : armv8a_mnemonic list

val shift_allowed : armv8a_mnemonic -> shift_kind -> bool

val sized_mnemonics : armv8a_mnemonic list

val wsize_uload_mn : (wsize * armv8a_mnemonic) list

val uload_mn_of_wsize : wsize -> armv8a_mnemonic option

val wsize_sload_mn : (wsize * armv8a_mnemonic) list

val sload_mn_of_wsize : wsize -> armv8a_mnemonic option

val wsize_of_sload_mn : armv8a_mnemonic -> wsize option

val wsize_of_narrow_load_mn : armv8a_mnemonic -> wsize option

val wsize_store_mn : (wsize * armv8a_mnemonic) list

val store_mn_of_wsize : wsize -> armv8a_mnemonic option

val wsize_of_narrow_store_mn : armv8a_mnemonic -> wsize option

val string_of_armv8a_mnemonic : armv8a_mnemonic -> string

type armv8a_asm_op =
| ARMv8A_op of armv8a_mnemonic * armv8a_options

val armv8a_asm_op_rect :
  (armv8a_mnemonic -> armv8a_options -> 'a1) -> armv8a_asm_op -> 'a1

val armv8a_asm_op_rec :
  (armv8a_mnemonic -> armv8a_options -> 'a1) -> armv8a_asm_op -> 'a1

type is_armv8a_asm_op =
| Coq_is_ARMv8A_op of armv8a_mnemonic * is_armv8a_mnemonic * armv8a_options
   * is_armv8a_options

val is_armv8a_asm_op_rect :
  (armv8a_mnemonic -> is_armv8a_mnemonic -> armv8a_options ->
  is_armv8a_options -> 'a1) -> armv8a_asm_op -> is_armv8a_asm_op -> 'a1

val is_armv8a_asm_op_rec :
  (armv8a_mnemonic -> is_armv8a_mnemonic -> armv8a_options ->
  is_armv8a_options -> 'a1) -> armv8a_asm_op -> is_armv8a_asm_op -> 'a1

val armv8a_asm_op_tag : armv8a_asm_op -> positive

val is_armv8a_asm_op_inhab : armv8a_asm_op -> is_armv8a_asm_op

val is_armv8a_asm_op_functor :
  armv8a_asm_op -> is_armv8a_asm_op -> is_armv8a_asm_op

type box_armv8a_asm_op_ARMv8A_op = { coq_Box_armv8a_asm_op_ARMv8A_op_0 : 
                                     armv8a_mnemonic;
                                     coq_Box_armv8a_asm_op_ARMv8A_op_1 : 
                                     armv8a_options }

val coq_Box_armv8a_asm_op_ARMv8A_op_0 :
  box_armv8a_asm_op_ARMv8A_op -> armv8a_mnemonic

val coq_Box_armv8a_asm_op_ARMv8A_op_1 :
  box_armv8a_asm_op_ARMv8A_op -> armv8a_options

type armv8a_asm_op_fields_t = box_armv8a_asm_op_ARMv8A_op

val armv8a_asm_op_fields : armv8a_asm_op -> armv8a_asm_op_fields_t

val armv8a_asm_op_construct :
  positive -> box_armv8a_asm_op_ARMv8A_op -> armv8a_asm_op option

val armv8a_asm_op_induction :
  (armv8a_mnemonic -> is_armv8a_mnemonic -> armv8a_options ->
  is_armv8a_options -> 'a1) -> armv8a_asm_op -> is_armv8a_asm_op -> 'a1

val armv8a_asm_op_eqb_fields :
  (armv8a_asm_op -> armv8a_asm_op -> bool) -> positive ->
  box_armv8a_asm_op_ARMv8A_op -> box_armv8a_asm_op_ARMv8A_op -> bool

val armv8a_asm_op_eqb : armv8a_asm_op -> armv8a_asm_op -> bool

val armv8a_asm_op_eqb_OK : armv8a_asm_op -> armv8a_asm_op -> reflect

val armv8a_asm_op_eqb_OK_sumbool : armv8a_asm_op -> armv8a_asm_op -> bool

val eqTC_armv8a_asm_op : armv8a_asm_op eqTypeC

val armv8a_asm_op_eqType : Equality.coq_type

val ad_nzcv : (register, empty, empty, rflag, condt) Arch_decl.arg_desc list

val coq_NF_of_word : wsize -> word -> bool

val coq_ZF_of_word : wsize -> word -> bool

val nzcv_of_aluop : wsize -> word -> coq_Z -> coq_Z -> sem_tuple

val nzcv_of_logop : wsize -> word -> sem_tuple

val nzcv_w_of_aluop : wsize -> word -> coq_Z -> coq_Z -> ltuple

val nzcv_w_of_logop : wsize -> word -> ltuple

val mk_semi1_shifted :
  wsize -> shift_kind -> 'a1 exec sem_prod -> 'a1 exec sem_prod

val mk_semi2_2_shifted :
  ltype -> wsize -> shift_kind -> 'a1 exec sem_prod -> 'a1 exec sem_prod

val args_kinds_no_imm :
  (register, empty, empty, rflag, condt) args_kinds -> bool

val mk_shifted :
  wsize -> shift_kind -> armv8a_mnemonic -> (register, empty, empty, rflag,
  condt) instr_desc_t -> semi_type -> (register, empty, empty, rflag, condt)
  instr_desc_t

val pp_armv8a_op :
  armv8a_mnemonic -> armv8a_options -> (register, empty, empty, rflag, condt)
  asm_arg list -> (register, empty, empty, rflag, condt) pp_asm_op

val pp_armv8a_op_szs :
  armv8a_mnemonic -> wsize list -> (register, empty, empty, rflag, condt)
  asm_arg list -> (register, empty, empty, rflag, condt) pp_asm_op

val mk_arith_instr :
  armv8a_options -> armv8a_mnemonic -> armv8a_caimm_cond option -> (word ->
  word -> sem_tuple) -> (register, empty, empty, rflag, condt) instr_desc_t

val mk_ariths_instr :
  armv8a_options -> armv8a_mnemonic -> armv8a_caimm_cond option -> (word ->
  word -> sem_tuple) -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_ADD_semi : wsize -> word -> word -> sem_tuple

val armv8a_ADD_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_ADDS_semi : wsize -> word -> word -> sem_tuple

val armv8a_ADDS_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_SUB_semi : wsize -> word -> word -> sem_tuple

val armv8a_SUB_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_SUBS_semi : wsize -> word -> word -> sem_tuple

val armv8a_SUBS_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val mk_carry_instr :
  armv8a_options -> armv8a_mnemonic -> (word -> word -> bool -> sem_tuple) ->
  (register, empty, empty, rflag, condt) instr_desc_t

val mk_carrys_instr :
  armv8a_options -> armv8a_mnemonic -> (word -> word -> bool -> sem_tuple) ->
  (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_ADC_semi : wsize -> word -> word -> bool -> sem_tuple

val armv8a_ADC_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_ADCS_semi : wsize -> word -> word -> bool -> sem_tuple

val armv8a_ADCS_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_NEG_semi : wsize -> word -> sem_tuple

val armv8a_NEG_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val mk_rrr_instr :
  armv8a_options -> armv8a_mnemonic -> doit_t -> (word -> word -> sem_tuple)
  -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MUL_semi : wsize -> word -> word -> sem_tuple

val armv8a_MUL_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_SDIV_semi : wsize -> word -> word -> sem_tuple

val armv8a_SDIV_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_UDIV_semi : wsize -> word -> word -> sem_tuple

val armv8a_UDIV_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val mk_madd_instr :
  armv8a_options -> armv8a_mnemonic -> (word -> word -> word -> sem_tuple) ->
  (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MADD_semi : wsize -> word -> word -> word -> sem_tuple

val armv8a_MADD_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MSUB_semi : wsize -> word -> word -> word -> sem_tuple

val armv8a_MSUB_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_bitwise_semi :
  wsize -> (word -> word) -> (word -> word) -> (word -> word -> word) -> word
  -> word -> sem_tuple

val armv8a_AND_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_ORR_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_EOR_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MVN_semi : wsize -> word -> sem_tuple

val armv8a_MVN_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_shift_semi :
  wsize -> (wsize -> word -> coq_Z -> word) -> word -> word -> sem_tuple

val mk_shift_instr :
  armv8a_options -> armv8a_mnemonic -> (wsize -> word -> coq_Z -> word) ->
  (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_ASR_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_LSL_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_LSR_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_ROR_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MOV_semi : wsize -> word -> sem_tuple

val armv8a_MOV_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val mk_movw_instr :
  armv8a_options -> armv8a_mnemonic -> (word -> word -> sem_tuple) ->
  (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MOVZ_semi : wsize -> word -> word -> sem_tuple

val armv8a_MOVZ_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MOVN_semi : wsize -> word -> word -> sem_tuple

val armv8a_MOVN_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_MOVK_semi : wsize -> word -> word -> word -> sem_tuple

val armv8a_MOVK_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_extend_semi : wsize -> bool -> wsize -> word -> word

val mk_extend_instr :
  armv8a_options -> armv8a_mnemonic -> wsize -> bool -> bool -> (register,
  empty, empty, rflag, condt) instr_desc_t

val armv8a_ADR_semi : word -> sem_tuple

val armv8a_ADR_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_SXTB_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_SXTH_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_SXTW_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_UXTB_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_UXTH_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_UXTW_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val mk_cmp_instr :
  armv8a_options -> armv8a_mnemonic -> armv8a_caimm_cond option -> (word ->
  word -> sem_tuple) -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_CMP_semi : wsize -> word -> word -> sem_tuple

val armv8a_CMP_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_TST_semi : wsize -> word -> word -> sem_tuple

val armv8a_TST_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val mk_csel_instr :
  armv8a_options -> armv8a_mnemonic -> (word -> word -> bool -> sem_tuple) ->
  (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_CSEL_semi : wsize -> word -> word -> bool -> sem_tuple

val armv8a_CSEL_instr :
  armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_load_instr :
  armv8a_options -> armv8a_mnemonic -> (register, empty, empty, rflag, condt)
  instr_desc_t

val armv8a_store_instr :
  armv8a_options -> armv8a_mnemonic -> (register, empty, empty, rflag, condt)
  instr_desc_t

val mn_desc :
  armv8a_options -> armv8a_mnemonic -> (register, empty, empty, rflag, condt)
  instr_desc_t

val armv8a_instr_desc :
  armv8a_asm_op -> (register, empty, empty, rflag, condt) instr_desc_t

val armv8a_prim_sized : armv8a_mnemonic -> armv8a_asm_op prim_constructor

val armv8a_prim_string : (string * armv8a_asm_op prim_constructor) list

val armv8a_op_decl :
  (register, empty, empty, rflag, condt, armv8a_asm_op) asm_op_decl

type armv8a_prog =
  (register, empty, empty, rflag, condt, armv8a_asm_op) asm_prog
