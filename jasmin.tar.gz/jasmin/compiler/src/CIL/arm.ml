(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Arch_decl
open Arch_utils
open Arm_common
open Arm_decl
open Arm_instr_decl

(** val arm : (register, empty, empty, rflag, condt, arm_op) asm **)

let arm =
  { _arch_decl = arm_decl; _asm_op_decl = arm_op_decl; eval_cond = (fun _ ->
    arm_eval_cond) }
