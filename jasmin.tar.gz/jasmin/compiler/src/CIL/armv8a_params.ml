(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_params
open Arch_utils
open Arm_common
open Armv8a_decl
open Armv8a_extra
open Armv8a_instr_decl
open Armv8a_lowering
open Armv8a_params_core
open Armv8a_stack_zeroization
open Asm_gen
open Compiler_util
open Constant_prop
open Eqtype
open Expr
open Fexpr
open Lea
open Linearization
open Lowering
open Memory_model
open Operators
open Seq
open Shift_kind
open Slh_lowering
open Sopn
open Ssrbool
open Ssrfun
open Ssrnat
open Stack_alloc_params
open Stack_zeroization
open Type
open Utils0
open Var0
open Word0
open Word_ssrZ
open Wsize

(** val to_opn :
    (register, empty, empty, rflag, condt) arch_toIdent -> ((lexpr
    list * (register, empty, empty, rflag, condt, armv8a_asm_op)
    asm_op_t') * rexpr list) -> (lexpr list * armv8a_extended_op
    sopn) * rexpr list **)

let to_opn atoI = function
| (y, e) -> let (d, o) = y in ((d, (coq_Oarmv8a atoI o)), e)

(** val coq_ARMv8AFopn_mov :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    (lexpr list * armv8a_extended_op sopn) * rexpr list **)

let coq_ARMv8AFopn_mov atoI x y =
  to_opn atoI (ARMv8AFopn_core.mov x y)

(** val coq_ARMv8AFopn_addi :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> (lexpr list * armv8a_extended_op sopn) * rexpr list **)

let coq_ARMv8AFopn_addi atoI x y imm =
  to_opn atoI (ARMv8AFopn_core.addi x y imm)

(** val coq_ARMv8AFopn_subi :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> (lexpr list * armv8a_extended_op sopn) * rexpr list **)

let coq_ARMv8AFopn_subi atoI x y imm =
  to_opn atoI (ARMv8AFopn_core.subi x y imm)

(** val coq_ARMv8AFopn_align :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    wsize -> (lexpr list * armv8a_extended_op sopn) * rexpr list **)

let coq_ARMv8AFopn_align atoI x y al =
  to_opn atoI (ARMv8AFopn_core.align x y al)

(** val coq_ARMv8AFopn_smart_addi :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list **)

let coq_ARMv8AFopn_smart_addi atoI x y imm =
  map (to_opn atoI) (ARMv8AFopn_core.smart_addi x y imm)

(** val coq_ARMv8AFopn_smart_subi :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list **)

let coq_ARMv8AFopn_smart_subi atoI x y imm =
  map (to_opn atoI) (ARMv8AFopn_core.smart_subi x y imm)

(** val coq_ARMv8AFopn_smart_addi_tmp :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list **)

let coq_ARMv8AFopn_smart_addi_tmp atoI x tmp imm =
  map (to_opn atoI) (ARMv8AFopn_core.smart_addi_tmp x tmp imm)

(** val coq_ARMv8AFopn_smart_subi_tmp :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i ->
    coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list) list **)

let coq_ARMv8AFopn_smart_subi_tmp atoI x tmp imm =
  map (to_opn atoI) (ARMv8AFopn_core.smart_subi_tmp x tmp imm)

(** val armv8a_mov_ofs :
    (register, empty, empty, rflag, condt) arch_toIdent -> lval -> assgn_tag
    -> mov_kind -> pexpr -> pexpr -> (register, empty, empty, rflag, condt,
    armv8a_asm_op, armv8a_extra_op) extended_op instr_r option **)

let armv8a_mov_ofs atoI x tag movk y ofs =
  let mk = fun oa ->
    let (op, args) = oa in
    Some (Copn ((x :: []), tag,
    (coq_Oarmv8a atoI (ARMv8A_op (op, default_opts))), args))
  in
  (match movk with
   | MK_LEA ->
     mk (ADR,
       ((if is_zero (Obj.magic arch_pd armv8a_decl) ofs
         then y
         else add (arch_pd armv8a_decl) y ofs) :: []))
   | MK_MOV ->
     (match x with
      | Lvar _ ->
        if is_Pload y
        then if is_zero (Obj.magic arch_pd armv8a_decl) ofs
             then mk (LDR, (y :: []))
             else None
        else (match mk_lea (arch_pd armv8a_decl)
                      (add (arch_pd armv8a_decl) y ofs) with
              | Some lea ->
                (match lea.lea_base with
                 | Some base ->
                   (match lea.lea_offset with
                    | Some off ->
                      if eq_op coq_BinNums_Z__canonical__eqtype_Equality
                           (Obj.magic lea.lea_disp) (Obj.magic Z0)
                      then (match Option.map Z.of_nat
                                    (shift_of_scale lea.lea_scale) with
                            | Some scale ->
                              if eq_op
                                   coq_BinNums_Z__canonical__eqtype_Equality
                                   (Obj.magic scale) (Obj.magic Z0)
                              then mk (ADD,
                                     ((coq_Plvar base) :: ((coq_Plvar off) :: [])))
                              else let opts = { has_shift = (Some SLSL);
                                     opts_size = U64 }
                                   in
                                   Some (Copn ((x :: []), tag,
                                   (coq_Oarmv8a atoI (ARMv8A_op (ADD, opts))),
                                   ((coq_Plvar base) :: ((coq_Plvar off) :: (
                                   (eword_of_int U8 scale) :: [])))))
                            | None -> None)
                      else None
                    | None ->
                      if eq_op coq_BinNums_Z__canonical__eqtype_Equality
                           (Obj.magic lea.lea_disp) (Obj.magic Z0)
                      then mk (MOV, ((coq_Plvar base) :: []))
                      else if is_arith_small lea.lea_disp
                           then mk (ADD,
                                  ((coq_Plvar base) :: ((cast_const
                                                          (arch_pd
                                                            armv8a_decl)
                                                          lea.lea_disp) :: [])))
                           else Some (Copn ((x :: []), tag, (Oasm (ExtOp
                                  Oarmv8a_add_large_imm)),
                                  ((coq_Plvar base) :: ((cast_const
                                                          (arch_pd
                                                            armv8a_decl)
                                                          lea.lea_disp) :: [])))))
                 | None -> None)
              | None -> None)
      | Lmem (_, _, _, _) ->
        if is_zero (Obj.magic arch_pd armv8a_decl) ofs
        then mk (STR, (y :: []))
        else None
      | _ -> None))

(** val armv8a_immediate :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> coq_Z ->
    ((register, empty, empty, rflag, condt, armv8a_asm_op) asm_op_t',
    armv8a_extra_op) extended_op_gen instr_r **)

let armv8a_immediate _ x z =
  Copn (((Lvar x) :: []), AT_none, (Oasm (ExtOp (Oarmv8a_smart_li
    armv8a_decl.reg_size))), ((cast_const (arch_pd armv8a_decl) z) :: []))

(** val armv8a_swap :
    (register, empty, empty, rflag, condt) arch_toIdent -> assgn_tag -> var_i
    -> var_i -> var_i -> var_i -> ((register, empty, empty, rflag, condt,
    armv8a_asm_op) asm_op_t', armv8a_extra_op) extended_op_gen instr_r **)

let armv8a_swap _ t x y z w =
  Copn (((Lvar x) :: ((Lvar y) :: [])), t, (Oasm (ExtOp (Oarmv8a_swap
    armv8a_decl.reg_size))), ((coq_Plvar z) :: ((coq_Plvar w) :: [])))

(** val armv8a_saparams :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
    stack_alloc_params **)

let armv8a_saparams atoI =
  { sap_mov_ofs = (armv8a_mov_ofs atoI); sap_immediate =
    (armv8a_immediate atoI); sap_swap = (armv8a_swap atoI) }

(** val armv8a_allocate_stack_frame :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i
    option -> coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list)
    list **)

let armv8a_allocate_stack_frame atoI rspi tmp sz =
  match tmp with
  | Some aux -> coq_ARMv8AFopn_smart_subi_tmp atoI rspi aux sz
  | None -> (coq_ARMv8AFopn_subi atoI rspi rspi sz) :: []

(** val armv8a_free_stack_frame :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> var_i
    option -> coq_Z -> ((lexpr list * armv8a_extended_op sopn) * rexpr list)
    list **)

let armv8a_free_stack_frame atoI rspi tmp sz =
  match tmp with
  | Some aux -> coq_ARMv8AFopn_smart_addi_tmp atoI rspi aux sz
  | None -> (coq_ARMv8AFopn_addi atoI rspi rspi sz) :: []

(** val armv8a_set_up_sp_register :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i -> coq_Z ->
    wsize -> var_i -> var_i -> ((lexpr list * (register, empty, empty, rflag,
    condt, armv8a_asm_op, armv8a_extra_op) extended_op sopn) * rexpr list)
    list **)

let armv8a_set_up_sp_register atoI rspi sf_sz al r tmp =
  let load_imm = coq_ARMv8AFopn_smart_subi atoI tmp rspi sf_sz in
  let i0 = coq_ARMv8AFopn_align atoI tmp tmp al in
  let i1 = coq_ARMv8AFopn_mov atoI r rspi in
  let i2 = coq_ARMv8AFopn_mov atoI rspi tmp in
  cat load_imm (i0 :: (i1 :: (i2 :: [])))

(** val armv8a_tmp :
    (register, empty, empty, rflag, condt) arch_toIdent -> Ident.Ident.ident **)

let armv8a_tmp atoI =
  Var.vname
    (mk_var_i
      (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r atoI.toI_r
        R16)).v_var

(** val armv8a_tmp2 :
    (register, empty, empty, rflag, condt) arch_toIdent -> Ident.Ident.ident **)

let armv8a_tmp2 atoI =
  Var.vname
    (mk_var_i
      (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r atoI.toI_r
        R17)).v_var

(** val armv8a_lmove :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> var_i ->
    var_i -> (lexpr list * armv8a_extended_op sopn) * rexpr list **)

let armv8a_lmove atoI _ xd xs =
  ((((LLvar xd) :: []), (coq_Oarmv8a atoI (ARMv8A_op (MOV, default_opts)))),
    ((Rexpr (Fvar xs)) :: []))

(** val armv8a_check_ws : Equality.sort -> bool **)

let armv8a_check_ws ws =
  eq_op wsize_wsize__canonical__eqtype_Equality ws
    (Obj.magic armv8a_decl.reg_size)

(** val armv8a_lstore :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> var_i ->
    coq_Z -> var_i -> (lexpr list * armv8a_extended_op sopn) * rexpr list **)

let armv8a_lstore atoI ws xd ofs xs =
  let mn = STR in
  ((((Store (Aligned, ws,
  (faddv (arch_pd armv8a_decl) xd (fconst ws ofs)))) :: []),
  (coq_Oarmv8a atoI (ARMv8A_op (mn, default_opts)))), ((Rexpr (Fvar
  xs)) :: []))

(** val armv8a_lload :
    (register, empty, empty, rflag, condt) arch_toIdent -> wsize -> var_i ->
    var_i -> coq_Z -> (lexpr list * armv8a_extended_op sopn) * rexpr list **)

let armv8a_lload atoI ws xd xs ofs =
  let mn = LDR in
  ((((LLvar xd) :: []), (coq_Oarmv8a atoI (ARMv8A_op (mn, default_opts)))),
  ((Load (Aligned, ws,
  (faddv (arch_pd armv8a_decl) xs (fconst ws ofs)))) :: []))

(** val armv8a_lloads :
    (register, empty, empty, rflag, condt) arch_toIdent -> var_i ->
    (Var.var * coq_Z) list -> coq_Z -> ((lexpr list * (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
    sopn) * rexpr list) list **)

let armv8a_lloads atoI rspi to_restore spofs =
  let restore_regs =
    if all (fun pat -> let (_, ofs) = pat in is_arith_small ofs) to_restore
    then map (fun pat ->
           let (x, ofs) = pat in
           armv8a_lload atoI (wsize_of_atype (Var.vtype x)) { v_var = x;
             v_info = dummy_var_info } rspi ofs)
           to_restore
    else let ofs0 = snd (head (rspi.v_var, Z0) to_restore) in
         let to_restore0 =
           map (fun pat -> let (x, ofs) = pat in (x, (Z.sub ofs ofs0)))
             to_restore
         in
         cat
           (coq_ARMv8AFopn_smart_addi atoI
             (mk_var_i
               (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r
                 atoI.toI_r R17))
             rspi ofs0)
           (map (fun pat ->
             let (x, ofs) = pat in
             armv8a_lload atoI (wsize_of_atype (Var.vtype x)) { v_var = x;
               v_info = dummy_var_info }
               (mk_var_i
                 (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r
                   atoI.toI_r R17))
               ofs)
             to_restore0)
  in
  let restore_sp =
    if is_arith_small spofs
    then (armv8a_lload atoI (arch_pd armv8a_decl)
           (mk_var_i
             (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r
               atoI.toI_r R17))
           rspi spofs) :: ((armv8a_lmove atoI (arch_pd armv8a_decl) rspi
                             (mk_var_i
                               (to_var (Coq_lword armv8a_decl.reg_size)
                                 armv8a_decl.toS_r atoI.toI_r R17))) :: [])
    else cat
           (coq_ARMv8AFopn_smart_addi atoI
             (mk_var_i
               (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r
                 atoI.toI_r R17))
             rspi spofs)
           ((armv8a_lload atoI (arch_pd armv8a_decl)
              (mk_var_i
                (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r
                  atoI.toI_r R17))
              (mk_var_i
                (to_var (Coq_lword armv8a_decl.reg_size) armv8a_decl.toS_r
                  atoI.toI_r R17))
              Z0) :: ((armv8a_lmove atoI (arch_pd armv8a_decl) rspi
                        (mk_var_i
                          (to_var (Coq_lword armv8a_decl.reg_size)
                            armv8a_decl.toS_r atoI.toI_r R17))) :: []))
  in
  cat restore_regs restore_sp

(** val armv8a_liparams :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
    linearization_params **)

let armv8a_liparams atoI =
  { lip_tmp = (armv8a_tmp atoI); lip_tmp2 = (armv8a_tmp2 atoI);
    lip_not_saved_stack = ((armv8a_tmp atoI) :: []);
    lip_allocate_stack_frame = (armv8a_allocate_stack_frame atoI);
    lip_free_stack_frame = (armv8a_free_stack_frame atoI);
    lip_set_up_sp_register = (armv8a_set_up_sp_register atoI); lip_lmove =
    (armv8a_lmove atoI); lip_check_ws = (Obj.magic armv8a_check_ws);
    lip_lstore = (armv8a_lstore atoI); lip_lload = (armv8a_lload atoI);
    lip_lstores =
    (lstores_imm_dfl (arch_pd armv8a_decl) (asm_opI (armv8a_extra atoI))
      (armv8a_tmp2 atoI) (armv8a_lstore atoI)
      (coq_ARMv8AFopn_smart_addi atoI) is_arith_small);
    lip_lloads = (armv8a_lloads atoI) }

(** val armv8a_fvars_correct :
    (register, empty, empty, rflag, condt) arch_toIdent -> fresh_vars ->
    progT -> (register, empty, empty, rflag, condt, armv8a_asm_op,
    armv8a_extra_op) extended_op fun_decl list -> bool **)

let armv8a_fvars_correct atoI fv pT fds =
  fvars_correct (asm_opI (armv8a_extra atoI)) pT (all_fresh_vars fv)
    (fvars fv) fds

(** val armv8a_loparams :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
    lowering_params **)

let armv8a_loparams atoI =
  { lop_lower_i = (fun _ fv i -> Ok (Armv8a_lowering.lower_i atoI fv i));
    lop_fvars_correct = (armv8a_fvars_correct atoI) }

(** val armv8a_shparams :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op sh_params **)

let armv8a_shparams _ _ _ _ =
  None

(** val condt_of_rflag : rflag -> condt **)

let condt_of_rflag = function
| NF -> MI_ct
| ZF -> EQ_ct
| CF -> CS_ct
| VF -> VS_ct

(** val condt_not : condt -> condt **)

let condt_not = function
| EQ_ct -> NE_ct
| NE_ct -> EQ_ct
| CS_ct -> CC_ct
| CC_ct -> CS_ct
| MI_ct -> PL_ct
| PL_ct -> MI_ct
| VS_ct -> VC_ct
| VC_ct -> VS_ct
| HI_ct -> LS_ct
| LS_ct -> HI_ct
| GE_ct -> LT_ct
| LT_ct -> GE_ct
| GT_ct -> LE_ct
| LE_ct -> GT_ct

(** val condt_and : condt -> condt -> condt option **)

let condt_and c0 c1 =
  match c0 with
  | NE_ct ->
    (match c1 with
     | CS_ct -> Some HI_ct
     | GE_ct -> Some GT_ct
     | _ -> None)
  | CS_ct -> (match c1 with
              | NE_ct -> Some HI_ct
              | _ -> None)
  | GE_ct -> (match c1 with
              | NE_ct -> Some GT_ct
              | _ -> None)
  | _ -> None

(** val condt_or : condt -> condt -> condt option **)

let condt_or c0 c1 =
  match c0 with
  | EQ_ct ->
    (match c1 with
     | CC_ct -> Some LS_ct
     | LT_ct -> Some LE_ct
     | _ -> None)
  | CC_ct -> (match c1 with
              | EQ_ct -> Some LS_ct
              | _ -> None)
  | LT_ct -> (match c1 with
              | EQ_ct -> Some LE_ct
              | _ -> None)
  | _ -> None

(** val is_rflags_GE : rflag -> rflag -> bool **)

let is_rflags_GE r0 r1 =
  match r0 with
  | NF -> (match r1 with
           | VF -> true
           | _ -> false)
  | VF -> (match r1 with
           | NF -> true
           | _ -> false)
  | _ -> false

(** val assemble_cond :
    (register, empty, empty, rflag, condt) arch_toIdent -> instr_info ->
    fexpr -> condt cexec **)

let rec assemble_cond atoI ii e = match e with
| Fvar v ->
  (match of_var_e Coq_lbool armv8a_decl.toS_f atoI.toI_f ii v with
   | Ok x -> Ok (condt_of_rflag x)
   | Error s -> Error s)
| Fapp1 (s, e0) ->
  (match s with
   | Onot ->
     (match assemble_cond atoI ii e0 with
      | Ok x -> Ok (condt_not x)
      | Error s0 -> Error s0)
   | _ -> Error (Asm_gen.E.berror ii e "Can't assemble condition."))
| Fapp2 (s, e0, e1) ->
  (match s with
   | Obeq ->
     (match e0 with
      | Fvar x0 ->
        (match e1 with
         | Fvar x1 ->
           (match of_var_e Coq_lbool armv8a_decl.toS_f atoI.toI_f ii x0 with
            | Ok x ->
              (match of_var_e Coq_lbool armv8a_decl.toS_f atoI.toI_f ii x1 with
               | Ok x2 ->
                 if is_rflags_GE x x2
                 then Ok GE_ct
                 else Error (Asm_gen.E.berror ii e "Invalid condition (EQ).")
               | Error s0 -> Error s0)
            | Error s0 -> Error s0)
         | _ -> Error (Asm_gen.E.berror ii e "Can't assemble condition."))
      | _ -> Error (Asm_gen.E.berror ii e "Can't assemble condition."))
   | Oand ->
     (match assemble_cond atoI ii e0 with
      | Ok x ->
        (match assemble_cond atoI ii e1 with
         | Ok x0 ->
           (match condt_and x x0 with
            | Some ct -> Ok ct
            | None -> Error (Asm_gen.E.berror ii e "Invalid condition (AND)"))
         | Error s0 -> Error s0)
      | Error s0 -> Error s0)
   | Oor ->
     (match assemble_cond atoI ii e0 with
      | Ok x ->
        (match assemble_cond atoI ii e1 with
         | Ok x0 ->
           (match condt_or x x0 with
            | Some ct -> Ok ct
            | None -> Error (Asm_gen.E.berror ii e "Invalid condition (OR)"))
         | Error s0 -> Error s0)
      | Error s0 -> Error s0)
   | _ -> Error (Asm_gen.E.berror ii e "Can't assemble condition."))
| _ -> Error (Asm_gen.E.berror ii e "Can't assemble condition.")

(** val is_valid_address :
    (register, empty, empty, rflag, condt) reg_address -> bool **)

let is_valid_address addr =
  if negb
       (eq_op (word_word__canonical__eqtype_Equality (arch_pd armv8a_decl))
         (Obj.magic addr.ad_disp) (Obj.magic word0 (arch_pd armv8a_decl)))
  then if isSome addr.ad_offset
       then false
       else if negb
                 (eq_op coq_Datatypes_nat__canonical__eqtype_Equality
                   (Obj.magic addr.ad_scale) (Obj.magic O))
            then false
            else true
  else if isSome addr.ad_offset
       then true
       else if negb
                 (eq_op coq_Datatypes_nat__canonical__eqtype_Equality
                   (Obj.magic addr.ad_scale) (Obj.magic O))
            then false
            else true

(** val armv8a_agparams :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) asm_gen_params **)

let armv8a_agparams atoI =
  { agp_assemble_cond = (assemble_cond atoI); agp_is_valid_address =
    is_valid_address }

(** val armv8a_szparams :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op
    stack_zeroization_params **)

let armv8a_szparams =
  stack_zeroization_cmd

(** val armv8a_is_move_op :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) extended_op asm_op_t
    -> bool **)

let armv8a_is_move_op _ = function
| BaseOp a ->
  let (o0, a0) = a in
  (match o0 with
   | Some _ -> false
   | None ->
     let ARMv8A_op (o1, opts) = a0 in
     if in_mem (Obj.magic o1)
          (mem (seq_predType armv8a_mnemonic_eqType)
            (Obj.magic (MOV :: (LDR :: (STR :: (STRH :: (STRB :: [])))))))
     then negb (isSome opts.has_shift)
     else false)
| ExtOp _ -> false

(** val armv8a_params :
    (register, empty, empty, rflag, condt) arch_toIdent -> (register, empty,
    empty, rflag, condt, armv8a_asm_op, armv8a_extra_op) architecture_params **)

let armv8a_params atoI =
  { ap_sap = (armv8a_saparams atoI); ap_lip = (armv8a_liparams atoI);
    ap_plp = false; ap_lop = (armv8a_loparams atoI); ap_shp =
    (armv8a_shparams atoI); ap_lap = (fun _ p -> Ok p); ap_agp =
    (armv8a_agparams atoI); ap_szp = (armv8a_szparams atoI); ap_is_move_op =
    (armv8a_is_move_op atoI) }
