(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open Arm_common
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Operators
open Seq
open Shift_kind
open Ssrbool
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t

val armv8a_reg_size : wsize

val armv8a_xreg_size : wsize

type register =
| R0
| R1
| R2
| R3
| R4
| R5
| R6
| R7
| R8
| R9
| R10
| R11
| R12
| R13
| R14
| R15
| R16
| R17
| R19
| R20
| R21
| R22
| R23
| R24
| R25
| R26
| R27
| R28
| R29
| R30
| RSP

val register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  register -> 'a1

val register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  register -> 'a1

type is_register =
| Coq_is_R0
| Coq_is_R1
| Coq_is_R2
| Coq_is_R3
| Coq_is_R4
| Coq_is_R5
| Coq_is_R6
| Coq_is_R7
| Coq_is_R8
| Coq_is_R9
| Coq_is_R10
| Coq_is_R11
| Coq_is_R12
| Coq_is_R13
| Coq_is_R14
| Coq_is_R15
| Coq_is_R16
| Coq_is_R17
| Coq_is_R19
| Coq_is_R20
| Coq_is_R21
| Coq_is_R22
| Coq_is_R23
| Coq_is_R24
| Coq_is_R25
| Coq_is_R26
| Coq_is_R27
| Coq_is_R28
| Coq_is_R29
| Coq_is_R30
| Coq_is_RSP

val is_register_rect :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  register -> is_register -> 'a1

val is_register_rec :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  register -> is_register -> 'a1

val register_tag : register -> positive

val is_register_inhab : register -> is_register

val is_register_functor : register -> is_register -> is_register

type box_register_R0 =
| Box_register_R0

type register_fields_t = __

val register_fields : register -> register_fields_t

val register_construct : positive -> register_fields_t -> register option

val register_induction :
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
  -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
  register -> is_register -> 'a1

val register_eqb_fields :
  (register -> register -> bool) -> positive -> register_fields_t ->
  register_fields_t -> bool

val register_eqb : register -> register -> bool

val register_eqb_OK : register -> register -> reflect

val register_eqb_OK_sumbool : register -> register -> bool

val eqTC_register : register eqTypeC

val armv8a_register_eqType : Equality.coq_type

val registers : register list

val finTC_register : register finTypeC

val register_finType : Finite.coq_type

val register_to_string : register -> string

val reg_toS : register coq_ToString

val eqTC_shift_kind : shift_kind eqTypeC

val shift_kind_eqType : Equality.coq_type

val shift_kinds : shift_kind list

val string_of_shift_kind : shift_kind -> string

val check_shift_amount : wsize -> coq_Z -> bool

val shift_op : shift_kind -> wsize -> word -> coq_Z -> word

val shift_of_sop2 : wsize -> sop2 -> shift_kind option

val is_arith_imm : coq_Z -> bool

val z_rotr : coq_Z -> coq_Z -> coq_Z -> coq_Z

val is_ones_run : coq_Z -> coq_Z -> bool

val is_bitmask_imm : wsize -> coq_Z -> bool

val is_wide_imm : wsize -> coq_Z -> bool

val is_mov_imm : wsize -> coq_Z -> bool

type armv8a_caimm_cond =
| CAimmC_armv8a_shift_amount of wsize
| CAimmC_armv8a_halfword_shift of wsize
| CAimmC_armv8a_arith_imm
| CAimmC_armv8a_bitmask_imm
| CAimmC_armv8a_mov_imm

val armv8a_caimm_cond_rect :
  (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> armv8a_caimm_cond
  -> 'a1

val armv8a_caimm_cond_rec :
  (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> armv8a_caimm_cond
  -> 'a1

type is_armv8a_caimm_cond =
| Coq_is_CAimmC_armv8a_shift_amount of wsize * is_wsize
| Coq_is_CAimmC_armv8a_halfword_shift of wsize * is_wsize
| Coq_is_CAimmC_armv8a_arith_imm
| Coq_is_CAimmC_armv8a_bitmask_imm
| Coq_is_CAimmC_armv8a_mov_imm

val is_armv8a_caimm_cond_rect :
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> armv8a_caimm_cond -> is_armv8a_caimm_cond -> 'a1

val is_armv8a_caimm_cond_rec :
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> armv8a_caimm_cond -> is_armv8a_caimm_cond -> 'a1

val armv8a_caimm_cond_tag : armv8a_caimm_cond -> positive

val is_armv8a_caimm_cond_inhab : armv8a_caimm_cond -> is_armv8a_caimm_cond

val is_armv8a_caimm_cond_functor :
  armv8a_caimm_cond -> is_armv8a_caimm_cond -> is_armv8a_caimm_cond

type box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount =
  wsize
  (* singleton inductive, whose constructor was Box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount *)

val coq_Box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount_0 :
  box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount -> wsize

type box_armv8a_caimm_cond_CAimmC_armv8a_arith_imm =
| Box_armv8a_caimm_cond_CAimmC_armv8a_arith_imm

type armv8a_caimm_cond_fields_t = __

val armv8a_caimm_cond_fields : armv8a_caimm_cond -> armv8a_caimm_cond_fields_t

val armv8a_caimm_cond_construct :
  positive -> armv8a_caimm_cond_fields_t -> armv8a_caimm_cond option

val armv8a_caimm_cond_induction :
  (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
  'a1 -> armv8a_caimm_cond -> is_armv8a_caimm_cond -> 'a1

val armv8a_caimm_cond_eqb_fields :
  (armv8a_caimm_cond -> armv8a_caimm_cond -> bool) -> positive ->
  armv8a_caimm_cond_fields_t -> armv8a_caimm_cond_fields_t -> bool

val armv8a_caimm_cond_eqb : armv8a_caimm_cond -> armv8a_caimm_cond -> bool

val armv8a_caimm_cond_eqb_OK :
  armv8a_caimm_cond -> armv8a_caimm_cond -> reflect

val armv8a_caimm_cond_eqb_OK_sumbool :
  armv8a_caimm_cond -> armv8a_caimm_cond -> bool

val eqTC_armv8a_caimm_cond : armv8a_caimm_cond eqTypeC

val armv8a_check_CAimm : armv8a_caimm_cond -> wsize -> word -> bool

val armv8a_caimm_cond_pp : armv8a_caimm_cond -> string

val armv8a_decl : (register, empty, empty, rflag, condt) arch_decl

val armv8a_call_conv :
  (register, empty, empty, rflag, condt) calling_convention

val armv8a_internal_call_conv :
  (register, empty, empty, rflag, condt) internal_calling_convention
