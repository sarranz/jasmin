(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open Arm_common
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Operators
open Seq
open Shift_kind
open Ssrbool
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t

(** val armv8a_reg_size : wsize **)

let armv8a_reg_size =
  U64

(** val armv8a_xreg_size : wsize **)

let armv8a_xreg_size =
  U128

type register =
| R0
| R1
| R2
| R3
| R4
| R5
| R6
| R7
| R8
| R9
| R10
| R11
| R12
| R13
| R14
| R15
| R16
| R17
| R19
| R20
| R21
| R22
| R23
| R24
| R25
| R26
| R27
| R28
| R29
| R30
| RSP

(** val register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    register -> 'a1 **)

let register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 = function
| R0 -> f
| R1 -> f0
| R2 -> f1
| R3 -> f2
| R4 -> f3
| R5 -> f4
| R6 -> f5
| R7 -> f6
| R8 -> f7
| R9 -> f8
| R10 -> f9
| R11 -> f10
| R12 -> f11
| R13 -> f12
| R14 -> f13
| R15 -> f14
| R16 -> f15
| R17 -> f16
| R19 -> f17
| R20 -> f18
| R21 -> f19
| R22 -> f20
| R23 -> f21
| R24 -> f22
| R25 -> f23
| R26 -> f24
| R27 -> f25
| R28 -> f26
| R29 -> f27
| R30 -> f28
| RSP -> f29

(** val register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    register -> 'a1 **)

let register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 = function
| R0 -> f
| R1 -> f0
| R2 -> f1
| R3 -> f2
| R4 -> f3
| R5 -> f4
| R6 -> f5
| R7 -> f6
| R8 -> f7
| R9 -> f8
| R10 -> f9
| R11 -> f10
| R12 -> f11
| R13 -> f12
| R14 -> f13
| R15 -> f14
| R16 -> f15
| R17 -> f16
| R19 -> f17
| R20 -> f18
| R21 -> f19
| R22 -> f20
| R23 -> f21
| R24 -> f22
| R25 -> f23
| R26 -> f24
| R27 -> f25
| R28 -> f26
| R29 -> f27
| R30 -> f28
| RSP -> f29

type is_register =
| Coq_is_R0
| Coq_is_R1
| Coq_is_R2
| Coq_is_R3
| Coq_is_R4
| Coq_is_R5
| Coq_is_R6
| Coq_is_R7
| Coq_is_R8
| Coq_is_R9
| Coq_is_R10
| Coq_is_R11
| Coq_is_R12
| Coq_is_R13
| Coq_is_R14
| Coq_is_R15
| Coq_is_R16
| Coq_is_R17
| Coq_is_R19
| Coq_is_R20
| Coq_is_R21
| Coq_is_R22
| Coq_is_R23
| Coq_is_R24
| Coq_is_R25
| Coq_is_R26
| Coq_is_R27
| Coq_is_R28
| Coq_is_R29
| Coq_is_R30
| Coq_is_RSP

(** val is_register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    register -> is_register -> 'a1 **)

let is_register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 _ = function
| Coq_is_R0 -> f
| Coq_is_R1 -> f0
| Coq_is_R2 -> f1
| Coq_is_R3 -> f2
| Coq_is_R4 -> f3
| Coq_is_R5 -> f4
| Coq_is_R6 -> f5
| Coq_is_R7 -> f6
| Coq_is_R8 -> f7
| Coq_is_R9 -> f8
| Coq_is_R10 -> f9
| Coq_is_R11 -> f10
| Coq_is_R12 -> f11
| Coq_is_R13 -> f12
| Coq_is_R14 -> f13
| Coq_is_R15 -> f14
| Coq_is_R16 -> f15
| Coq_is_R17 -> f16
| Coq_is_R19 -> f17
| Coq_is_R20 -> f18
| Coq_is_R21 -> f19
| Coq_is_R22 -> f20
| Coq_is_R23 -> f21
| Coq_is_R24 -> f22
| Coq_is_R25 -> f23
| Coq_is_R26 -> f24
| Coq_is_R27 -> f25
| Coq_is_R28 -> f26
| Coq_is_R29 -> f27
| Coq_is_R30 -> f28
| Coq_is_RSP -> f29

(** val is_register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    register -> is_register -> 'a1 **)

let is_register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 _ = function
| Coq_is_R0 -> f
| Coq_is_R1 -> f0
| Coq_is_R2 -> f1
| Coq_is_R3 -> f2
| Coq_is_R4 -> f3
| Coq_is_R5 -> f4
| Coq_is_R6 -> f5
| Coq_is_R7 -> f6
| Coq_is_R8 -> f7
| Coq_is_R9 -> f8
| Coq_is_R10 -> f9
| Coq_is_R11 -> f10
| Coq_is_R12 -> f11
| Coq_is_R13 -> f12
| Coq_is_R14 -> f13
| Coq_is_R15 -> f14
| Coq_is_R16 -> f15
| Coq_is_R17 -> f16
| Coq_is_R19 -> f17
| Coq_is_R20 -> f18
| Coq_is_R21 -> f19
| Coq_is_R22 -> f20
| Coq_is_R23 -> f21
| Coq_is_R24 -> f22
| Coq_is_R25 -> f23
| Coq_is_R26 -> f24
| Coq_is_R27 -> f25
| Coq_is_R28 -> f26
| Coq_is_R29 -> f27
| Coq_is_R30 -> f28
| Coq_is_RSP -> f29

(** val register_tag : register -> positive **)

let register_tag = function
| R0 -> Coq_xH
| R1 -> Coq_xO Coq_xH
| R2 -> Coq_xI Coq_xH
| R3 -> Coq_xO (Coq_xO Coq_xH)
| R4 -> Coq_xI (Coq_xO Coq_xH)
| R5 -> Coq_xO (Coq_xI Coq_xH)
| R6 -> Coq_xI (Coq_xI Coq_xH)
| R7 -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| R8 -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| R9 -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| R10 -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| R11 -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| R12 -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| R13 -> Coq_xO (Coq_xI (Coq_xI Coq_xH))
| R14 -> Coq_xI (Coq_xI (Coq_xI Coq_xH))
| R15 -> Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| R16 -> Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| R17 -> Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| R19 -> Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| R20 -> Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| R21 -> Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| R22 -> Coq_xO (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| R23 -> Coq_xI (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| R24 -> Coq_xO (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| R25 -> Coq_xI (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| R26 -> Coq_xO (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| R27 -> Coq_xI (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| R28 -> Coq_xO (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| R29 -> Coq_xI (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| R30 -> Coq_xO (Coq_xI (Coq_xI (Coq_xI Coq_xH)))
| RSP -> Coq_xI (Coq_xI (Coq_xI (Coq_xI Coq_xH)))

(** val is_register_inhab : register -> is_register **)

let is_register_inhab = function
| R0 -> Coq_is_R0
| R1 -> Coq_is_R1
| R2 -> Coq_is_R2
| R3 -> Coq_is_R3
| R4 -> Coq_is_R4
| R5 -> Coq_is_R5
| R6 -> Coq_is_R6
| R7 -> Coq_is_R7
| R8 -> Coq_is_R8
| R9 -> Coq_is_R9
| R10 -> Coq_is_R10
| R11 -> Coq_is_R11
| R12 -> Coq_is_R12
| R13 -> Coq_is_R13
| R14 -> Coq_is_R14
| R15 -> Coq_is_R15
| R16 -> Coq_is_R16
| R17 -> Coq_is_R17
| R19 -> Coq_is_R19
| R20 -> Coq_is_R20
| R21 -> Coq_is_R21
| R22 -> Coq_is_R22
| R23 -> Coq_is_R23
| R24 -> Coq_is_R24
| R25 -> Coq_is_R25
| R26 -> Coq_is_R26
| R27 -> Coq_is_R27
| R28 -> Coq_is_R28
| R29 -> Coq_is_R29
| R30 -> Coq_is_R30
| RSP -> Coq_is_RSP

(** val is_register_functor : register -> is_register -> is_register **)

let rec is_register_functor _ x =
  x

type box_register_R0 =
| Box_register_R0

type register_fields_t = __

(** val register_fields : register -> register_fields_t **)

let register_fields _ =
  Obj.magic Box_register_R0

(** val register_construct :
    positive -> register_fields_t -> register option **)

let register_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some RSP
           | Coq_xO _ -> Some R23
           | Coq_xH -> Some R14)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some R27
           | Coq_xO _ -> Some R19
           | Coq_xH -> Some R10)
        | Coq_xH -> Some R6)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some R29
           | Coq_xO _ -> Some R21
           | Coq_xH -> Some R12)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some R25
           | Coq_xO _ -> Some R16
           | Coq_xH -> Some R8)
        | Coq_xH -> Some R4)
     | Coq_xH -> Some R2)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some R30
           | Coq_xO _ -> Some R22
           | Coq_xH -> Some R13)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some R26
           | Coq_xO _ -> Some R17
           | Coq_xH -> Some R9)
        | Coq_xH -> Some R5)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some R28
           | Coq_xO _ -> Some R20
           | Coq_xH -> Some R11)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI _ -> Some R24
           | Coq_xO _ -> Some R15
           | Coq_xH -> Some R7)
        | Coq_xH -> Some R3)
     | Coq_xH -> Some R1)
  | Coq_xH -> Some R0

(** val register_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    register -> is_register -> 'a1 **)

let register_induction his_R0 his_R1 his_R2 his_R3 his_R4 his_R5 his_R6 his_R7 his_R8 his_R9 his_R10 his_R11 his_R12 his_R13 his_R14 his_R15 his_R16 his_R17 his_R19 his_R20 his_R21 his_R22 his_R23 his_R24 his_R25 his_R26 his_R27 his_R28 his_R29 his_R30 his_RSP _ = function
| Coq_is_R0 -> his_R0
| Coq_is_R1 -> his_R1
| Coq_is_R2 -> his_R2
| Coq_is_R3 -> his_R3
| Coq_is_R4 -> his_R4
| Coq_is_R5 -> his_R5
| Coq_is_R6 -> his_R6
| Coq_is_R7 -> his_R7
| Coq_is_R8 -> his_R8
| Coq_is_R9 -> his_R9
| Coq_is_R10 -> his_R10
| Coq_is_R11 -> his_R11
| Coq_is_R12 -> his_R12
| Coq_is_R13 -> his_R13
| Coq_is_R14 -> his_R14
| Coq_is_R15 -> his_R15
| Coq_is_R16 -> his_R16
| Coq_is_R17 -> his_R17
| Coq_is_R19 -> his_R19
| Coq_is_R20 -> his_R20
| Coq_is_R21 -> his_R21
| Coq_is_R22 -> his_R22
| Coq_is_R23 -> his_R23
| Coq_is_R24 -> his_R24
| Coq_is_R25 -> his_R25
| Coq_is_R26 -> his_R26
| Coq_is_R27 -> his_R27
| Coq_is_R28 -> his_R28
| Coq_is_R29 -> his_R29
| Coq_is_R30 -> his_R30
| Coq_is_RSP -> his_RSP

(** val register_eqb_fields :
    (register -> register -> bool) -> positive -> register_fields_t ->
    register_fields_t -> bool **)

let register_eqb_fields _ _ _ _ =
  true

(** val register_eqb : register -> register -> bool **)

let register_eqb x1 x2 =
  eqb_body register_tag register_fields
    (Obj.magic register_eqb_fields (fun _ _ -> true)) (register_tag x1)
    Box_register_R0 x2

(** val register_eqb_OK : register -> register -> reflect **)

let register_eqb_OK =
  iffP2 register_eqb

(** val register_eqb_OK_sumbool : register -> register -> bool **)

let register_eqb_OK_sumbool =
  reflect_dec register_eqb register_eqb_OK

(** val eqTC_register : register eqTypeC **)

let eqTC_register =
  { beq = register_eqb; ceqP = register_eqb_OK }

(** val armv8a_register_eqType : Equality.coq_type **)

let armv8a_register_eqType =
  ceqT_eqType eqTC_register

(** val registers : register list **)

let registers =
  R0 :: (R1 :: (R2 :: (R3 :: (R4 :: (R5 :: (R6 :: (R7 :: (R8 :: (R9 :: (R10 :: (R11 :: (R12 :: (R13 :: (R14 :: (R15 :: (R16 :: (R17 :: (R19 :: (R20 :: (R21 :: (R22 :: (R23 :: (R24 :: (R25 :: (R26 :: (R27 :: (R28 :: (R29 :: (R30 :: (RSP :: []))))))))))))))))))))))))))))))

(** val finTC_register : register finTypeC **)

let finTC_register =
  { _eqC = eqTC_register; cenum = registers }

(** val register_finType : Finite.coq_type **)

let register_finType =
  cfinT_finType finTC_register

(** val register_to_string : register -> string **)

let register_to_string = function
| R0 -> "x0"
| R1 -> "x1"
| R2 -> "x2"
| R3 -> "x3"
| R4 -> "x4"
| R5 -> "x5"
| R6 -> "x6"
| R7 -> "x7"
| R8 -> "x8"
| R9 -> "x9"
| R10 -> "x10"
| R11 -> "x11"
| R12 -> "x12"
| R13 -> "x13"
| R14 -> "x14"
| R15 -> "x15"
| R16 -> "x16"
| R17 -> "x17"
| R19 -> "x19"
| R20 -> "x20"
| R21 -> "x21"
| R22 -> "x22"
| R23 -> "x23"
| R24 -> "x24"
| R25 -> "x25"
| R26 -> "x26"
| R27 -> "x27"
| R28 -> "x28"
| R29 -> "x29"
| R30 -> "x30"
| RSP -> "sp"

(** val reg_toS : register coq_ToString **)

let reg_toS =
  { category = "register"; _finC = finTC_register; to_string =
    register_to_string }

(** val eqTC_shift_kind : shift_kind eqTypeC **)

let eqTC_shift_kind =
  { beq = shift_kind_eqb; ceqP = shift_kind_eqb_OK }

(** val shift_kind_eqType : Equality.coq_type **)

let shift_kind_eqType =
  ceqT_eqType eqTC_shift_kind

(** val shift_kinds : shift_kind list **)

let shift_kinds =
  SLSL :: (SLSR :: (SASR :: (SROR :: [])))

(** val string_of_shift_kind : shift_kind -> string **)

let string_of_shift_kind = function
| SLSL -> "lsl"
| SLSR -> "lsr"
| SASR -> "asr"
| SROR -> "ror"

(** val check_shift_amount : wsize -> coq_Z -> bool **)

let check_shift_amount ws z =
  (&&) (Z.leb Z0 z) (Z.ltb z (wsize_bits ws))

(** val shift_op : shift_kind -> wsize -> word -> coq_Z -> word **)

let shift_op = function
| SLSL -> wshl
| SLSR -> wshr
| SASR -> wsar
| SROR -> wror

(** val shift_of_sop2 : wsize -> sop2 -> shift_kind option **)

let shift_of_sop2 ws op =
  match oassert
          ((||)
            (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
              (Obj.magic U64))
            (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
              (Obj.magic U32))) with
  | Some _ ->
    (match op with
     | Olsr ws' ->
       if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws')
            (Obj.magic ws)
       then Some SLSR
       else None
     | Olsl o ->
       (match o with
        | Op_int -> None
        | Op_w ws' ->
          if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws')
               (Obj.magic ws)
          then Some SLSL
          else None)
     | Oasr o ->
       (match o with
        | Op_int -> None
        | Op_w ws' ->
          if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws')
               (Obj.magic ws)
          then Some SASR
          else None)
     | Oror ws' ->
       if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws')
            (Obj.magic ws)
       then Some SROR
       else None
     | _ -> None)
  | None -> None

(** val is_arith_imm : coq_Z -> bool **)

let is_arith_imm z =
  (||)
    ((&&) (Z.leb Z0 z)
      (Z.ltb z (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
        (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH)))))))))))))))
    ((&&) (Z.leb Z0 z)
      ((&&)
        (Z.ltb z
          (Z.mul (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            Coq_xH))))))))))))) (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            Coq_xH)))))))))))))))
        (Z.eqb
          (Z.modulo z (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            Coq_xH))))))))))))))
          Z0)))

(** val z_rotr : coq_Z -> coq_Z -> coq_Z -> coq_Z **)

let z_rotr e x r =
  Z.modulo
    (Z.add (Z.div x (Z.pow (Zpos (Coq_xO Coq_xH)) r))
      (Z.mul (Z.modulo x (Z.pow (Zpos (Coq_xO Coq_xH)) r))
        (Z.pow (Zpos (Coq_xO Coq_xH)) (Z.sub e r))))
    (Z.pow (Zpos (Coq_xO Coq_xH)) e)

(** val is_ones_run : coq_Z -> coq_Z -> bool **)

let is_ones_run e y =
  (&&) (Z.ltb Z0 y)
    ((&&) (Z.ltb y (Z.sub (Z.pow (Zpos (Coq_xO Coq_xH)) e) (Zpos Coq_xH)))
      (Z.eqb (Z.coq_land y (Z.add y (Zpos Coq_xH))) Z0))

(** val is_bitmask_imm : wsize -> coq_Z -> bool **)

let is_bitmask_imm ws x =
  let n = wsize_bits ws in
  has (fun e ->
    (&&) (Z.leb e n)
      ((&&) (Z.eqb (z_rotr n x e) x)
        (has (fun r ->
          is_ones_run e
            (z_rotr e (Z.modulo x (Z.pow (Zpos (Coq_xO Coq_xH)) e)) r))
          (map Z.of_nat (iota O (Z.to_nat e))))))
    ((Zpos (Coq_xO Coq_xH)) :: ((Zpos (Coq_xO (Coq_xO Coq_xH))) :: ((Zpos
    (Coq_xO (Coq_xO (Coq_xO Coq_xH)))) :: ((Zpos (Coq_xO (Coq_xO (Coq_xO
    (Coq_xO Coq_xH))))) :: ((Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
    Coq_xH)))))) :: ((Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
    Coq_xH))))))) :: []))))))

(** val is_wide_imm : wsize -> coq_Z -> bool **)

let is_wide_imm ws x =
  has (fun sh ->
    (&&) (Z.eqb (Z.modulo x (Z.pow (Zpos (Coq_xO Coq_xH)) sh)) Z0)
      (Z.ltb (Z.div x (Z.pow (Zpos (Coq_xO Coq_xH)) sh))
        (Z.pow (Zpos (Coq_xO Coq_xH)) (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
          Coq_xH))))))))
    (filter (fun sh -> Z.ltb sh (wsize_bits ws)) (Z0 :: ((Zpos (Coq_xO
      (Coq_xO (Coq_xO (Coq_xO Coq_xH))))) :: ((Zpos (Coq_xO (Coq_xO (Coq_xO
      (Coq_xO (Coq_xO Coq_xH)))))) :: ((Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
      (Coq_xI Coq_xH)))))) :: [])))))

(** val is_mov_imm : wsize -> coq_Z -> bool **)

let is_mov_imm ws x =
  (||) (is_wide_imm ws x)
    ((||) (is_wide_imm ws (Z.modulo (Z.lnot x) (wbase ws)))
      (is_bitmask_imm ws x))

type armv8a_caimm_cond =
| CAimmC_armv8a_shift_amount of wsize
| CAimmC_armv8a_halfword_shift of wsize
| CAimmC_armv8a_arith_imm
| CAimmC_armv8a_bitmask_imm
| CAimmC_armv8a_mov_imm

(** val armv8a_caimm_cond_rect :
    (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 ->
    armv8a_caimm_cond -> 'a1 **)

let armv8a_caimm_cond_rect f f0 f1 f2 f3 = function
| CAimmC_armv8a_shift_amount w -> f w
| CAimmC_armv8a_halfword_shift w -> f0 w
| CAimmC_armv8a_arith_imm -> f1
| CAimmC_armv8a_bitmask_imm -> f2
| CAimmC_armv8a_mov_imm -> f3

(** val armv8a_caimm_cond_rec :
    (wsize -> 'a1) -> (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 ->
    armv8a_caimm_cond -> 'a1 **)

let armv8a_caimm_cond_rec f f0 f1 f2 f3 = function
| CAimmC_armv8a_shift_amount w -> f w
| CAimmC_armv8a_halfword_shift w -> f0 w
| CAimmC_armv8a_arith_imm -> f1
| CAimmC_armv8a_bitmask_imm -> f2
| CAimmC_armv8a_mov_imm -> f3

type is_armv8a_caimm_cond =
| Coq_is_CAimmC_armv8a_shift_amount of wsize * is_wsize
| Coq_is_CAimmC_armv8a_halfword_shift of wsize * is_wsize
| Coq_is_CAimmC_armv8a_arith_imm
| Coq_is_CAimmC_armv8a_bitmask_imm
| Coq_is_CAimmC_armv8a_mov_imm

(** val is_armv8a_caimm_cond_rect :
    (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
    'a1 -> armv8a_caimm_cond -> is_armv8a_caimm_cond -> 'a1 **)

let is_armv8a_caimm_cond_rect f f0 f1 f2 f3 _ = function
| Coq_is_CAimmC_armv8a_shift_amount (w, p_) -> f w p_
| Coq_is_CAimmC_armv8a_halfword_shift (w, p_) -> f0 w p_
| Coq_is_CAimmC_armv8a_arith_imm -> f1
| Coq_is_CAimmC_armv8a_bitmask_imm -> f2
| Coq_is_CAimmC_armv8a_mov_imm -> f3

(** val is_armv8a_caimm_cond_rec :
    (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
    'a1 -> armv8a_caimm_cond -> is_armv8a_caimm_cond -> 'a1 **)

let is_armv8a_caimm_cond_rec f f0 f1 f2 f3 _ = function
| Coq_is_CAimmC_armv8a_shift_amount (w, p_) -> f w p_
| Coq_is_CAimmC_armv8a_halfword_shift (w, p_) -> f0 w p_
| Coq_is_CAimmC_armv8a_arith_imm -> f1
| Coq_is_CAimmC_armv8a_bitmask_imm -> f2
| Coq_is_CAimmC_armv8a_mov_imm -> f3

(** val armv8a_caimm_cond_tag : armv8a_caimm_cond -> positive **)

let armv8a_caimm_cond_tag = function
| CAimmC_armv8a_shift_amount _ -> Coq_xH
| CAimmC_armv8a_halfword_shift _ -> Coq_xO Coq_xH
| CAimmC_armv8a_arith_imm -> Coq_xI Coq_xH
| CAimmC_armv8a_bitmask_imm -> Coq_xO (Coq_xO Coq_xH)
| CAimmC_armv8a_mov_imm -> Coq_xI (Coq_xO Coq_xH)

(** val is_armv8a_caimm_cond_inhab :
    armv8a_caimm_cond -> is_armv8a_caimm_cond **)

let is_armv8a_caimm_cond_inhab = function
| CAimmC_armv8a_shift_amount h ->
  Coq_is_CAimmC_armv8a_shift_amount (h, (is_wsize_inhab h))
| CAimmC_armv8a_halfword_shift h ->
  Coq_is_CAimmC_armv8a_halfword_shift (h, (is_wsize_inhab h))
| CAimmC_armv8a_arith_imm -> Coq_is_CAimmC_armv8a_arith_imm
| CAimmC_armv8a_bitmask_imm -> Coq_is_CAimmC_armv8a_bitmask_imm
| CAimmC_armv8a_mov_imm -> Coq_is_CAimmC_armv8a_mov_imm

(** val is_armv8a_caimm_cond_functor :
    armv8a_caimm_cond -> is_armv8a_caimm_cond -> is_armv8a_caimm_cond **)

let rec is_armv8a_caimm_cond_functor _ x =
  x

type box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount =
  wsize
  (* singleton inductive, whose constructor was Box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount *)

(** val coq_Box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount_0 :
    box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount -> wsize **)

let coq_Box_armv8a_caimm_cond_CAimmC_armv8a_shift_amount_0 record =
  record

type box_armv8a_caimm_cond_CAimmC_armv8a_arith_imm =
| Box_armv8a_caimm_cond_CAimmC_armv8a_arith_imm

type armv8a_caimm_cond_fields_t = __

(** val armv8a_caimm_cond_fields :
    armv8a_caimm_cond -> armv8a_caimm_cond_fields_t **)

let armv8a_caimm_cond_fields = function
| CAimmC_armv8a_shift_amount h -> Obj.magic h
| CAimmC_armv8a_halfword_shift h -> Obj.magic h
| _ -> Obj.magic Box_armv8a_caimm_cond_CAimmC_armv8a_arith_imm

(** val armv8a_caimm_cond_construct :
    positive -> armv8a_caimm_cond_fields_t -> armv8a_caimm_cond option **)

let armv8a_caimm_cond_construct p x =
  match p with
  | Coq_xI x0 ->
    (match x0 with
     | Coq_xI _ -> None
     | Coq_xO _ -> Some CAimmC_armv8a_mov_imm
     | Coq_xH -> Some CAimmC_armv8a_arith_imm)
  | Coq_xO x0 ->
    (match x0 with
     | Coq_xI _ -> None
     | Coq_xO _ -> Some CAimmC_armv8a_bitmask_imm
     | Coq_xH -> Some (CAimmC_armv8a_halfword_shift (Obj.magic x)))
  | Coq_xH -> Some (CAimmC_armv8a_shift_amount (Obj.magic x))

(** val armv8a_caimm_cond_induction :
    (wsize -> is_wsize -> 'a1) -> (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 ->
    'a1 -> armv8a_caimm_cond -> is_armv8a_caimm_cond -> 'a1 **)

let armv8a_caimm_cond_induction his_CAimmC_armv8a_shift_amount his_CAimmC_armv8a_halfword_shift his_CAimmC_armv8a_arith_imm his_CAimmC_armv8a_bitmask_imm his_CAimmC_armv8a_mov_imm _ = function
| Coq_is_CAimmC_armv8a_shift_amount (x0, p_) ->
  his_CAimmC_armv8a_shift_amount x0 p_
| Coq_is_CAimmC_armv8a_halfword_shift (x0, p_) ->
  his_CAimmC_armv8a_halfword_shift x0 p_
| Coq_is_CAimmC_armv8a_arith_imm -> his_CAimmC_armv8a_arith_imm
| Coq_is_CAimmC_armv8a_bitmask_imm -> his_CAimmC_armv8a_bitmask_imm
| Coq_is_CAimmC_armv8a_mov_imm -> his_CAimmC_armv8a_mov_imm

(** val armv8a_caimm_cond_eqb_fields :
    (armv8a_caimm_cond -> armv8a_caimm_cond -> bool) -> positive ->
    armv8a_caimm_cond_fields_t -> armv8a_caimm_cond_fields_t -> bool **)

let armv8a_caimm_cond_eqb_fields _ x x0 x1 =
  match x with
  | Coq_xI _ -> true
  | Coq_xO x2 ->
    (match x2 with
     | Coq_xH -> (&&) (wsize_eqb (Obj.magic x0) (Obj.magic x1)) true
     | _ -> true)
  | Coq_xH -> (&&) (wsize_eqb (Obj.magic x0) (Obj.magic x1)) true

(** val armv8a_caimm_cond_eqb :
    armv8a_caimm_cond -> armv8a_caimm_cond -> bool **)

let armv8a_caimm_cond_eqb x1 x2 =
  match x1 with
  | CAimmC_armv8a_shift_amount h ->
    eqb_body armv8a_caimm_cond_tag armv8a_caimm_cond_fields
      (Obj.magic armv8a_caimm_cond_eqb_fields (fun _ _ -> true))
      (armv8a_caimm_cond_tag (CAimmC_armv8a_shift_amount h)) h x2
  | CAimmC_armv8a_halfword_shift h ->
    eqb_body armv8a_caimm_cond_tag armv8a_caimm_cond_fields
      (Obj.magic armv8a_caimm_cond_eqb_fields (fun _ _ -> true))
      (armv8a_caimm_cond_tag (CAimmC_armv8a_halfword_shift h)) h x2
  | x ->
    eqb_body armv8a_caimm_cond_tag armv8a_caimm_cond_fields
      (Obj.magic armv8a_caimm_cond_eqb_fields (fun _ _ -> true))
      (armv8a_caimm_cond_tag x) Box_armv8a_caimm_cond_CAimmC_armv8a_arith_imm
      x2

(** val armv8a_caimm_cond_eqb_OK :
    armv8a_caimm_cond -> armv8a_caimm_cond -> reflect **)

let armv8a_caimm_cond_eqb_OK =
  iffP2 armv8a_caimm_cond_eqb

(** val armv8a_caimm_cond_eqb_OK_sumbool :
    armv8a_caimm_cond -> armv8a_caimm_cond -> bool **)

let armv8a_caimm_cond_eqb_OK_sumbool =
  reflect_dec armv8a_caimm_cond_eqb armv8a_caimm_cond_eqb_OK

(** val eqTC_armv8a_caimm_cond : armv8a_caimm_cond eqTypeC **)

let eqTC_armv8a_caimm_cond =
  { beq = armv8a_caimm_cond_eqb; ceqP = armv8a_caimm_cond_eqb_OK }

(** val armv8a_check_CAimm : armv8a_caimm_cond -> wsize -> word -> bool **)

let armv8a_check_CAimm checker ws w =
  match checker with
  | CAimmC_armv8a_shift_amount ws' -> check_shift_amount ws' (wunsigned ws w)
  | CAimmC_armv8a_halfword_shift ws' ->
    let x = wunsigned ws w in
    (&&)
      (in_mem (Obj.magic x)
        (mem (seq_predType coq_BinNums_Z__canonical__eqtype_Equality)
          (Obj.magic (Z0 :: ((Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            Coq_xH))))) :: ((Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
            Coq_xH)))))) :: ((Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xI
            Coq_xH)))))) :: [])))))))
      (Z.ltb x (wsize_bits ws'))
  | CAimmC_armv8a_arith_imm -> is_arith_imm (wunsigned ws w)
  | CAimmC_armv8a_bitmask_imm -> is_bitmask_imm ws (wunsigned ws w)
  | CAimmC_armv8a_mov_imm -> is_mov_imm ws (wunsigned ws w)

(** val armv8a_caimm_cond_pp : armv8a_caimm_cond -> string **)

let armv8a_caimm_cond_pp = function
| CAimmC_armv8a_shift_amount ws ->
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
       (Obj.magic U64)
  then "[0, 63]"
  else "[0, 31]"
| CAimmC_armv8a_halfword_shift ws ->
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
       (Obj.magic U64)
  then "[0; 16; 32; 48]"
  else "[0; 16]"
| CAimmC_armv8a_arith_imm -> "(arith imm12, optionally << 12)"
| CAimmC_armv8a_bitmask_imm -> "(logical bitmask immediate)"
| CAimmC_armv8a_mov_imm -> "(wide, inverted wide or bitmask immediate)"

(** val armv8a_decl : (register, empty, empty, rflag, condt) arch_decl **)

let armv8a_decl =
  { reg_size = armv8a_reg_size; xreg_size = armv8a_xreg_size; cond_eqC =
    eqTC_condt; toS_r = reg_toS; toS_rx = (empty_toS (Coq_lword U64));
    toS_x = (empty_toS (Coq_lword U128)); toS_f = rflag_toS; ad_rsp = RSP;
    ad_fcp = arm_fcp; caimm_cond_eqC = (Obj.magic eqTC_armv8a_caimm_cond);
    caimm_cond_pp = (Obj.magic armv8a_caimm_cond_pp); check_CAimm =
    (Obj.magic armv8a_check_CAimm) }

(** val armv8a_call_conv :
    (register, empty, empty, rflag, condt) calling_convention **)

let armv8a_call_conv =
  { callee_saved =
    (map (fun x -> ARReg x)
      (R19 :: (R20 :: (R21 :: (R22 :: (R23 :: (R24 :: (R25 :: (R26 :: (R27 :: (R28 :: (R29 :: (RSP :: [])))))))))))));
    call_reg_args =
    (R0 :: (R1 :: (R2 :: (R3 :: (R4 :: (R5 :: (R6 :: (R7 :: []))))))));
    call_xreg_args = []; call_reg_ret =
    (R0 :: (R1 :: (R2 :: (R3 :: (R4 :: (R5 :: (R6 :: (R7 :: []))))))));
    call_xreg_ret = [] }

(** val armv8a_internal_call_conv :
    (register, empty, empty, rflag, condt) internal_calling_convention **)

let armv8a_internal_call_conv =
  { icall_reg =
    (R0 :: (R1 :: (R2 :: (R3 :: (R4 :: (R5 :: (R6 :: (R7 :: (R8 :: (R9 :: (R10 :: (R11 :: (R12 :: (R13 :: (R14 :: (R15 :: (R16 :: (R17 :: (R19 :: (R20 :: (R21 :: (R22 :: (R23 :: (R24 :: (R25 :: (R26 :: (R27 :: (R28 :: (R29 :: [])))))))))))))))))))))))))))));
    icall_regx = []; icall_xreg = []; icall_rflag =
    (CF :: (NF :: (ZF :: (VF :: [])))) }
