(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Arch_decl
open Arch_utils
open Arm_common
open Armv8a_decl
open Armv8a_instr_decl

(** val armv8a :
    (register, empty, empty, rflag, condt, armv8a_asm_op) asm **)

let armv8a =
  { _arch_decl = armv8a_decl; _asm_op_decl = armv8a_op_decl; eval_cond =
    (fun _ -> arm_eval_cond) }
