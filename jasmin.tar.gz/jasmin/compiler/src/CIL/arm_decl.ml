(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open Arm_expand_imm
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Flag_combination
open Operators
open Seq
open Shift_kind
open Ssrbool
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize

type __ = Obj.t

(** val arm_reg_size : wsize **)

let arm_reg_size =
  U32

(** val arm_xreg_size : wsize **)

let arm_xreg_size =
  U64

type register =
| R00
| R01
| R02
| R03
| R04
| R05
| R06
| R07
| R08
| R09
| R10
| R11
| R12
| LR
| SP

(** val register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> 'a1 **)

let register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 = function
| R00 -> f
| R01 -> f0
| R02 -> f1
| R03 -> f2
| R04 -> f3
| R05 -> f4
| R06 -> f5
| R07 -> f6
| R08 -> f7
| R09 -> f8
| R10 -> f9
| R11 -> f10
| R12 -> f11
| LR -> f12
| SP -> f13

(** val register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> 'a1 **)

let register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 = function
| R00 -> f
| R01 -> f0
| R02 -> f1
| R03 -> f2
| R04 -> f3
| R05 -> f4
| R06 -> f5
| R07 -> f6
| R08 -> f7
| R09 -> f8
| R10 -> f9
| R11 -> f10
| R12 -> f11
| LR -> f12
| SP -> f13

type is_register =
| Coq_is_R00
| Coq_is_R01
| Coq_is_R02
| Coq_is_R03
| Coq_is_R04
| Coq_is_R05
| Coq_is_R06
| Coq_is_R07
| Coq_is_R08
| Coq_is_R09
| Coq_is_R10
| Coq_is_R11
| Coq_is_R12
| Coq_is_LR
| Coq_is_SP

(** val is_register_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> is_register -> 'a1 **)

let is_register_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 _ = function
| Coq_is_R00 -> f
| Coq_is_R01 -> f0
| Coq_is_R02 -> f1
| Coq_is_R03 -> f2
| Coq_is_R04 -> f3
| Coq_is_R05 -> f4
| Coq_is_R06 -> f5
| Coq_is_R07 -> f6
| Coq_is_R08 -> f7
| Coq_is_R09 -> f8
| Coq_is_R10 -> f9
| Coq_is_R11 -> f10
| Coq_is_R12 -> f11
| Coq_is_LR -> f12
| Coq_is_SP -> f13

(** val is_register_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> is_register -> 'a1 **)

let is_register_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 _ = function
| Coq_is_R00 -> f
| Coq_is_R01 -> f0
| Coq_is_R02 -> f1
| Coq_is_R03 -> f2
| Coq_is_R04 -> f3
| Coq_is_R05 -> f4
| Coq_is_R06 -> f5
| Coq_is_R07 -> f6
| Coq_is_R08 -> f7
| Coq_is_R09 -> f8
| Coq_is_R10 -> f9
| Coq_is_R11 -> f10
| Coq_is_R12 -> f11
| Coq_is_LR -> f12
| Coq_is_SP -> f13

(** val register_tag : register -> positive **)

let register_tag = function
| R00 -> Coq_xH
| R01 -> Coq_xO Coq_xH
| R02 -> Coq_xI Coq_xH
| R03 -> Coq_xO (Coq_xO Coq_xH)
| R04 -> Coq_xI (Coq_xO Coq_xH)
| R05 -> Coq_xO (Coq_xI Coq_xH)
| R06 -> Coq_xI (Coq_xI Coq_xH)
| R07 -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| R08 -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| R09 -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| R10 -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| R11 -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| R12 -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| LR -> Coq_xO (Coq_xI (Coq_xI Coq_xH))
| SP -> Coq_xI (Coq_xI (Coq_xI Coq_xH))

(** val is_register_inhab : register -> is_register **)

let is_register_inhab = function
| R00 -> Coq_is_R00
| R01 -> Coq_is_R01
| R02 -> Coq_is_R02
| R03 -> Coq_is_R03
| R04 -> Coq_is_R04
| R05 -> Coq_is_R05
| R06 -> Coq_is_R06
| R07 -> Coq_is_R07
| R08 -> Coq_is_R08
| R09 -> Coq_is_R09
| R10 -> Coq_is_R10
| R11 -> Coq_is_R11
| R12 -> Coq_is_R12
| LR -> Coq_is_LR
| SP -> Coq_is_SP

(** val is_register_functor : register -> is_register -> is_register **)

let rec is_register_functor _ x =
  x

type box_register_R00 =
| Box_register_R00

type register_fields_t = __

(** val register_fields : register -> register_fields_t **)

let register_fields _ =
  Obj.magic Box_register_R00

(** val register_construct :
    positive -> register_fields_t -> register option **)

let register_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> Some SP
        | Coq_xO _ -> Some R10
        | Coq_xH -> Some R06)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> Some R12
        | Coq_xO _ -> Some R08
        | Coq_xH -> Some R04)
     | Coq_xH -> Some R02)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> Some LR
        | Coq_xO _ -> Some R09
        | Coq_xH -> Some R05)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> Some R11
        | Coq_xO _ -> Some R07
        | Coq_xH -> Some R03)
     | Coq_xH -> Some R01)
  | Coq_xH -> Some R00

(** val register_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> register -> is_register -> 'a1 **)

let register_induction his_R00 his_R01 his_R02 his_R03 his_R04 his_R05 his_R06 his_R07 his_R08 his_R09 his_R10 his_R11 his_R12 his_LR his_SP _ = function
| Coq_is_R00 -> his_R00
| Coq_is_R01 -> his_R01
| Coq_is_R02 -> his_R02
| Coq_is_R03 -> his_R03
| Coq_is_R04 -> his_R04
| Coq_is_R05 -> his_R05
| Coq_is_R06 -> his_R06
| Coq_is_R07 -> his_R07
| Coq_is_R08 -> his_R08
| Coq_is_R09 -> his_R09
| Coq_is_R10 -> his_R10
| Coq_is_R11 -> his_R11
| Coq_is_R12 -> his_R12
| Coq_is_LR -> his_LR
| Coq_is_SP -> his_SP

(** val register_eqb_fields :
    (register -> register -> bool) -> positive -> register_fields_t ->
    register_fields_t -> bool **)

let register_eqb_fields _ _ _ _ =
  true

(** val register_eqb : register -> register -> bool **)

let register_eqb x1 x2 =
  eqb_body register_tag register_fields
    (Obj.magic register_eqb_fields (fun _ _ -> true)) (register_tag x1)
    Box_register_R00 x2

(** val register_eqb_OK : register -> register -> reflect **)

let register_eqb_OK =
  iffP2 register_eqb

(** val register_eqb_OK_sumbool : register -> register -> bool **)

let register_eqb_OK_sumbool =
  reflect_dec register_eqb register_eqb_OK

(** val eqTC_register : register eqTypeC **)

let eqTC_register =
  { beq = register_eqb; ceqP = register_eqb_OK }

(** val arm_register_eqType : Equality.coq_type **)

let arm_register_eqType =
  ceqT_eqType eqTC_register

(** val registers : register list **)

let registers =
  R00 :: (R01 :: (R02 :: (R03 :: (R04 :: (R05 :: (R06 :: (R07 :: (R08 :: (R09 :: (R10 :: (R11 :: (R12 :: (LR :: (SP :: []))))))))))))))

(** val finTC_register : register finTypeC **)

let finTC_register =
  { _eqC = eqTC_register; cenum = registers }

(** val register_finType : Finite.coq_type **)

let register_finType =
  cfinT_finType finTC_register

(** val register_to_string : register -> string **)

let register_to_string = function
| R00 -> "r0"
| R01 -> "r1"
| R02 -> "r2"
| R03 -> "r3"
| R04 -> "r4"
| R05 -> "r5"
| R06 -> "r6"
| R07 -> "r7"
| R08 -> "r8"
| R09 -> "r9"
| R10 -> "r10"
| R11 -> "r11"
| R12 -> "r12"
| LR -> "lr"
| SP -> "sp"

(** val reg_toS : register coq_ToString **)

let reg_toS =
  { category = "register"; _finC = finTC_register; to_string =
    register_to_string }

type rflag =
| NF
| ZF
| CF
| VF

(** val rflag_rect : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1 **)

let rflag_rect f f0 f1 f2 = function
| NF -> f
| ZF -> f0
| CF -> f1
| VF -> f2

(** val rflag_rec : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1 **)

let rflag_rec f f0 f1 f2 = function
| NF -> f
| ZF -> f0
| CF -> f1
| VF -> f2

type is_rflag =
| Coq_is_NF
| Coq_is_ZF
| Coq_is_CF
| Coq_is_VF

(** val is_rflag_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1 **)

let is_rflag_rect f f0 f1 f2 _ = function
| Coq_is_NF -> f
| Coq_is_ZF -> f0
| Coq_is_CF -> f1
| Coq_is_VF -> f2

(** val is_rflag_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1 **)

let is_rflag_rec f f0 f1 f2 _ = function
| Coq_is_NF -> f
| Coq_is_ZF -> f0
| Coq_is_CF -> f1
| Coq_is_VF -> f2

(** val rflag_tag : rflag -> positive **)

let rflag_tag = function
| NF -> Coq_xH
| ZF -> Coq_xO Coq_xH
| CF -> Coq_xI Coq_xH
| VF -> Coq_xO (Coq_xO Coq_xH)

(** val is_rflag_inhab : rflag -> is_rflag **)

let is_rflag_inhab = function
| NF -> Coq_is_NF
| ZF -> Coq_is_ZF
| CF -> Coq_is_CF
| VF -> Coq_is_VF

(** val is_rflag_functor : rflag -> is_rflag -> is_rflag **)

let rec is_rflag_functor _ x =
  x

type box_rflag_NF =
| Box_rflag_NF

type rflag_fields_t = __

(** val rflag_fields : rflag -> rflag_fields_t **)

let rflag_fields _ =
  Obj.magic Box_rflag_NF

(** val rflag_construct : positive -> rflag_fields_t -> rflag option **)

let rflag_construct p _ =
  match p with
  | Coq_xI _ -> Some CF
  | Coq_xO x ->
    (match x with
     | Coq_xI _ -> None
     | Coq_xO _ -> Some VF
     | Coq_xH -> Some ZF)
  | Coq_xH -> Some NF

(** val rflag_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1 **)

let rflag_induction his_NF his_ZF his_CF his_VF _ = function
| Coq_is_NF -> his_NF
| Coq_is_ZF -> his_ZF
| Coq_is_CF -> his_CF
| Coq_is_VF -> his_VF

(** val rflag_eqb_fields :
    (rflag -> rflag -> bool) -> positive -> rflag_fields_t -> rflag_fields_t
    -> bool **)

let rflag_eqb_fields _ _ _ _ =
  true

(** val rflag_eqb : rflag -> rflag -> bool **)

let rflag_eqb x1 x2 =
  eqb_body rflag_tag rflag_fields
    (Obj.magic rflag_eqb_fields (fun _ _ -> true)) (rflag_tag x1)
    Box_rflag_NF x2

(** val rflag_eqb_OK : rflag -> rflag -> reflect **)

let rflag_eqb_OK =
  iffP2 rflag_eqb

(** val rflag_eqb_OK_sumbool : rflag -> rflag -> bool **)

let rflag_eqb_OK_sumbool =
  reflect_dec rflag_eqb rflag_eqb_OK

(** val eqTC_rflag : rflag eqTypeC **)

let eqTC_rflag =
  { beq = rflag_eqb; ceqP = rflag_eqb_OK }

(** val rflag_eqType : Equality.coq_type **)

let rflag_eqType =
  ceqT_eqType eqTC_rflag

(** val rflags : rflag list **)

let rflags =
  NF :: (ZF :: (CF :: (VF :: [])))

(** val finTC_rflag : rflag finTypeC **)

let finTC_rflag =
  { _eqC = eqTC_rflag; cenum = rflags }

(** val rflag_finType : Finite.coq_type **)

let rflag_finType =
  cfinT_finType finTC_rflag

(** val flag_to_string : rflag -> string **)

let flag_to_string = function
| NF -> "NF"
| ZF -> "ZF"
| CF -> "CF"
| VF -> "VF"

(** val rflag_toS : rflag coq_ToString **)

let rflag_toS =
  { category = "rflag"; _finC = finTC_rflag; to_string = flag_to_string }

type condt =
| EQ_ct
| NE_ct
| CS_ct
| CC_ct
| MI_ct
| PL_ct
| VS_ct
| VC_ct
| HI_ct
| LS_ct
| GE_ct
| LT_ct
| GT_ct
| LE_ct

(** val condt_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> 'a1 **)

let condt_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 = function
| EQ_ct -> f
| NE_ct -> f0
| CS_ct -> f1
| CC_ct -> f2
| MI_ct -> f3
| PL_ct -> f4
| VS_ct -> f5
| VC_ct -> f6
| HI_ct -> f7
| LS_ct -> f8
| GE_ct -> f9
| LT_ct -> f10
| GT_ct -> f11
| LE_ct -> f12

(** val condt_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> 'a1 **)

let condt_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 = function
| EQ_ct -> f
| NE_ct -> f0
| CS_ct -> f1
| CC_ct -> f2
| MI_ct -> f3
| PL_ct -> f4
| VS_ct -> f5
| VC_ct -> f6
| HI_ct -> f7
| LS_ct -> f8
| GE_ct -> f9
| LT_ct -> f10
| GT_ct -> f11
| LE_ct -> f12

type is_condt =
| Coq_is_EQ_ct
| Coq_is_NE_ct
| Coq_is_CS_ct
| Coq_is_CC_ct
| Coq_is_MI_ct
| Coq_is_PL_ct
| Coq_is_VS_ct
| Coq_is_VC_ct
| Coq_is_HI_ct
| Coq_is_LS_ct
| Coq_is_GE_ct
| Coq_is_LT_ct
| Coq_is_GT_ct
| Coq_is_LE_ct

(** val is_condt_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1 **)

let is_condt_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 _ = function
| Coq_is_EQ_ct -> f
| Coq_is_NE_ct -> f0
| Coq_is_CS_ct -> f1
| Coq_is_CC_ct -> f2
| Coq_is_MI_ct -> f3
| Coq_is_PL_ct -> f4
| Coq_is_VS_ct -> f5
| Coq_is_VC_ct -> f6
| Coq_is_HI_ct -> f7
| Coq_is_LS_ct -> f8
| Coq_is_GE_ct -> f9
| Coq_is_LT_ct -> f10
| Coq_is_GT_ct -> f11
| Coq_is_LE_ct -> f12

(** val is_condt_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1 **)

let is_condt_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 _ = function
| Coq_is_EQ_ct -> f
| Coq_is_NE_ct -> f0
| Coq_is_CS_ct -> f1
| Coq_is_CC_ct -> f2
| Coq_is_MI_ct -> f3
| Coq_is_PL_ct -> f4
| Coq_is_VS_ct -> f5
| Coq_is_VC_ct -> f6
| Coq_is_HI_ct -> f7
| Coq_is_LS_ct -> f8
| Coq_is_GE_ct -> f9
| Coq_is_LT_ct -> f10
| Coq_is_GT_ct -> f11
| Coq_is_LE_ct -> f12

(** val condt_tag : condt -> positive **)

let condt_tag = function
| EQ_ct -> Coq_xH
| NE_ct -> Coq_xO Coq_xH
| CS_ct -> Coq_xI Coq_xH
| CC_ct -> Coq_xO (Coq_xO Coq_xH)
| MI_ct -> Coq_xI (Coq_xO Coq_xH)
| PL_ct -> Coq_xO (Coq_xI Coq_xH)
| VS_ct -> Coq_xI (Coq_xI Coq_xH)
| VC_ct -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| HI_ct -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| LS_ct -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| GE_ct -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| LT_ct -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| GT_ct -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| LE_ct -> Coq_xO (Coq_xI (Coq_xI Coq_xH))

(** val is_condt_inhab : condt -> is_condt **)

let is_condt_inhab = function
| EQ_ct -> Coq_is_EQ_ct
| NE_ct -> Coq_is_NE_ct
| CS_ct -> Coq_is_CS_ct
| CC_ct -> Coq_is_CC_ct
| MI_ct -> Coq_is_MI_ct
| PL_ct -> Coq_is_PL_ct
| VS_ct -> Coq_is_VS_ct
| VC_ct -> Coq_is_VC_ct
| HI_ct -> Coq_is_HI_ct
| LS_ct -> Coq_is_LS_ct
| GE_ct -> Coq_is_GE_ct
| LT_ct -> Coq_is_LT_ct
| GT_ct -> Coq_is_GT_ct
| LE_ct -> Coq_is_LE_ct

(** val is_condt_functor : condt -> is_condt -> is_condt **)

let rec is_condt_functor _ x =
  x

type box_condt_EQ_ct =
| Box_condt_EQ_ct

type condt_fields_t = __

(** val condt_fields : condt -> condt_fields_t **)

let condt_fields _ =
  Obj.magic Box_condt_EQ_ct

(** val condt_construct : positive -> condt_fields_t -> condt option **)

let condt_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> None
        | Coq_xO _ -> Some GE_ct
        | Coq_xH -> Some VS_ct)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> Some GT_ct
        | Coq_xO _ -> Some HI_ct
        | Coq_xH -> Some MI_ct)
     | Coq_xH -> Some CS_ct)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> Some LE_ct
        | Coq_xO _ -> Some LS_ct
        | Coq_xH -> Some PL_ct)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> Some LT_ct
        | Coq_xO _ -> Some VC_ct
        | Coq_xH -> Some CC_ct)
     | Coq_xH -> Some NE_ct)
  | Coq_xH -> Some EQ_ct

(** val condt_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1 **)

let condt_induction his_EQ_ct his_NE_ct his_CS_ct his_CC_ct his_MI_ct his_PL_ct his_VS_ct his_VC_ct his_HI_ct his_LS_ct his_GE_ct his_LT_ct his_GT_ct his_LE_ct _ = function
| Coq_is_EQ_ct -> his_EQ_ct
| Coq_is_NE_ct -> his_NE_ct
| Coq_is_CS_ct -> his_CS_ct
| Coq_is_CC_ct -> his_CC_ct
| Coq_is_MI_ct -> his_MI_ct
| Coq_is_PL_ct -> his_PL_ct
| Coq_is_VS_ct -> his_VS_ct
| Coq_is_VC_ct -> his_VC_ct
| Coq_is_HI_ct -> his_HI_ct
| Coq_is_LS_ct -> his_LS_ct
| Coq_is_GE_ct -> his_GE_ct
| Coq_is_LT_ct -> his_LT_ct
| Coq_is_GT_ct -> his_GT_ct
| Coq_is_LE_ct -> his_LE_ct

(** val condt_eqb_fields :
    (condt -> condt -> bool) -> positive -> condt_fields_t -> condt_fields_t
    -> bool **)

let condt_eqb_fields _ _ _ _ =
  true

(** val condt_eqb : condt -> condt -> bool **)

let condt_eqb x1 x2 =
  eqb_body condt_tag condt_fields
    (Obj.magic condt_eqb_fields (fun _ _ -> true)) (condt_tag x1)
    Box_condt_EQ_ct x2

(** val condt_eqb_OK : condt -> condt -> reflect **)

let condt_eqb_OK =
  iffP2 condt_eqb

(** val condt_eqb_OK_sumbool : condt -> condt -> bool **)

let condt_eqb_OK_sumbool =
  reflect_dec condt_eqb condt_eqb_OK

(** val eqTC_condt : condt eqTypeC **)

let eqTC_condt =
  { beq = condt_eqb; ceqP = condt_eqb_OK }

(** val condt_eqType : Equality.coq_type **)

let condt_eqType =
  ceqT_eqType eqTC_condt

(** val condts : condt list **)

let condts =
  EQ_ct :: (NE_ct :: (CS_ct :: (CC_ct :: (MI_ct :: (PL_ct :: (VS_ct :: (VC_ct :: (HI_ct :: (LS_ct :: (GE_ct :: (LT_ct :: (GT_ct :: (LE_ct :: [])))))))))))))

(** val finTC_condt : condt finTypeC **)

let finTC_condt =
  { _eqC = eqTC_condt; cenum = condts }

(** val condt_finType : Finite.coq_type **)

let condt_finType =
  cfinT_finType finTC_condt

(** val string_of_condt : condt -> string **)

let string_of_condt = function
| EQ_ct -> "eq"
| NE_ct -> "ne"
| CS_ct -> "cs"
| CC_ct -> "cc"
| MI_ct -> "mi"
| PL_ct -> "pl"
| VS_ct -> "vs"
| VC_ct -> "vc"
| HI_ct -> "hi"
| LS_ct -> "ls"
| GE_ct -> "ge"
| LT_ct -> "lt"
| GT_ct -> "gt"
| LE_ct -> "le"

(** val eqTC_shift_kind : shift_kind eqTypeC **)

let eqTC_shift_kind =
  { beq = shift_kind_eqb; ceqP = shift_kind_eqb_OK }

(** val shift_kind_eqType : Equality.coq_type **)

let shift_kind_eqType =
  ceqT_eqType eqTC_shift_kind

(** val shift_kinds : shift_kind list **)

let shift_kinds =
  SLSL :: (SLSR :: (SASR :: (SROR :: [])))

(** val string_of_shift_kind : shift_kind -> string **)

let string_of_shift_kind = function
| SLSL -> "lsl"
| SLSR -> "lsr"
| SASR -> "asr"
| SROR -> "ror"

(** val check_shift_amount : shift_kind -> coq_Z -> bool **)

let check_shift_amount sk z =
  let (lo, hi) = shift_amount_bounds sk in (&&) (Z.leb lo z) (Z.leb z hi)

(** val shift_op : shift_kind -> wsize -> word -> coq_Z -> word **)

let shift_op = function
| SLSL -> wshl
| SLSR -> wshr
| SASR -> wsar
| SROR -> wror

(** val shift_of_sop2 : wsize -> sop2 -> shift_kind option **)

let shift_of_sop2 ws op =
  match oassert
          (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
            (Obj.magic U32)) with
  | Some _ ->
    (match op with
     | Olsr w -> (match w with
                  | U32 -> Some SLSR
                  | _ -> None)
     | Olsl o ->
       (match o with
        | Op_int -> None
        | Op_w w -> (match w with
                     | U32 -> Some SLSL
                     | _ -> None))
     | Oasr o ->
       (match o with
        | Op_int -> None
        | Op_w w -> (match w with
                     | U32 -> Some SASR
                     | _ -> None))
     | Oror w -> (match w with
                  | U32 -> Some SROR
                  | _ -> None)
     | _ -> None)
  | None -> None

(** val arm_fc_of_cfc : combine_flags_core -> flag_combination **)

let arm_fc_of_cfc cfc =
  let vnf = FCVar0 in
  let vzf = FCVar1 in
  let vcf = FCVar2 in
  let vvf = FCVar3 in
  (match cfc with
   | CFC_B -> FCNot vcf
   | CFC_E -> vzf
   | CFC_L -> FCNot (FCEq (vnf, vvf))
   | CFC_BE -> FCOr ((FCNot vcf), vzf)
   | CFC_LE -> FCOr (vzf, (FCNot (FCEq (vnf, vvf)))))

(** val arm_fcp : coq_FlagCombinationParams **)

let arm_fcp =
  arm_fc_of_cfc

type arm_caimm_cond =
| CAimmC_arm_shift_amout of shift_kind
| CAimmC_arm_wencoding of expected_wencoding
| CAimmC_arm_0_8_16_24

(** val arm_caimm_cond_rect :
    (shift_kind -> 'a1) -> (expected_wencoding -> 'a1) -> 'a1 ->
    arm_caimm_cond -> 'a1 **)

let arm_caimm_cond_rect f f0 f1 = function
| CAimmC_arm_shift_amout s -> f s
| CAimmC_arm_wencoding e -> f0 e
| CAimmC_arm_0_8_16_24 -> f1

(** val arm_caimm_cond_rec :
    (shift_kind -> 'a1) -> (expected_wencoding -> 'a1) -> 'a1 ->
    arm_caimm_cond -> 'a1 **)

let arm_caimm_cond_rec f f0 f1 = function
| CAimmC_arm_shift_amout s -> f s
| CAimmC_arm_wencoding e -> f0 e
| CAimmC_arm_0_8_16_24 -> f1

type is_arm_caimm_cond =
| Coq_is_CAimmC_arm_shift_amout of shift_kind * is_shift_kind
| Coq_is_CAimmC_arm_wencoding of expected_wencoding * is_expected_wencoding
| Coq_is_CAimmC_arm_0_8_16_24

(** val is_arm_caimm_cond_rect :
    (shift_kind -> is_shift_kind -> 'a1) -> (expected_wencoding ->
    is_expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond ->
    is_arm_caimm_cond -> 'a1 **)

let is_arm_caimm_cond_rect f f0 f1 _ = function
| Coq_is_CAimmC_arm_shift_amout (s, p_) -> f s p_
| Coq_is_CAimmC_arm_wencoding (e, p_) -> f0 e p_
| Coq_is_CAimmC_arm_0_8_16_24 -> f1

(** val is_arm_caimm_cond_rec :
    (shift_kind -> is_shift_kind -> 'a1) -> (expected_wencoding ->
    is_expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond ->
    is_arm_caimm_cond -> 'a1 **)

let is_arm_caimm_cond_rec f f0 f1 _ = function
| Coq_is_CAimmC_arm_shift_amout (s, p_) -> f s p_
| Coq_is_CAimmC_arm_wencoding (e, p_) -> f0 e p_
| Coq_is_CAimmC_arm_0_8_16_24 -> f1

(** val arm_caimm_cond_tag : arm_caimm_cond -> positive **)

let arm_caimm_cond_tag = function
| CAimmC_arm_shift_amout _ -> Coq_xH
| CAimmC_arm_wencoding _ -> Coq_xO Coq_xH
| CAimmC_arm_0_8_16_24 -> Coq_xI Coq_xH

(** val is_arm_caimm_cond_inhab : arm_caimm_cond -> is_arm_caimm_cond **)

let is_arm_caimm_cond_inhab = function
| CAimmC_arm_shift_amout h ->
  Coq_is_CAimmC_arm_shift_amout (h, (is_shift_kind_inhab h))
| CAimmC_arm_wencoding h ->
  Coq_is_CAimmC_arm_wencoding (h, (is_expected_wencoding_inhab h))
| CAimmC_arm_0_8_16_24 -> Coq_is_CAimmC_arm_0_8_16_24

(** val is_arm_caimm_cond_functor :
    arm_caimm_cond -> is_arm_caimm_cond -> is_arm_caimm_cond **)

let rec is_arm_caimm_cond_functor _ x =
  x

type box_arm_caimm_cond_CAimmC_arm_shift_amout =
  shift_kind
  (* singleton inductive, whose constructor was Box_arm_caimm_cond_CAimmC_arm_shift_amout *)

(** val coq_Box_arm_caimm_cond_CAimmC_arm_shift_amout_0 :
    box_arm_caimm_cond_CAimmC_arm_shift_amout -> shift_kind **)

let coq_Box_arm_caimm_cond_CAimmC_arm_shift_amout_0 record =
  record

type box_arm_caimm_cond_CAimmC_arm_wencoding =
  expected_wencoding
  (* singleton inductive, whose constructor was Box_arm_caimm_cond_CAimmC_arm_wencoding *)

(** val coq_Box_arm_caimm_cond_CAimmC_arm_wencoding_0 :
    box_arm_caimm_cond_CAimmC_arm_wencoding -> expected_wencoding **)

let coq_Box_arm_caimm_cond_CAimmC_arm_wencoding_0 record =
  record

type box_arm_caimm_cond_CAimmC_arm_0_8_16_24 =
| Box_arm_caimm_cond_CAimmC_arm_0_8_16_24

type arm_caimm_cond_fields_t = __

(** val arm_caimm_cond_fields : arm_caimm_cond -> arm_caimm_cond_fields_t **)

let arm_caimm_cond_fields = function
| CAimmC_arm_shift_amout h -> Obj.magic h
| CAimmC_arm_wencoding h -> Obj.magic h
| CAimmC_arm_0_8_16_24 -> Obj.magic Box_arm_caimm_cond_CAimmC_arm_0_8_16_24

(** val arm_caimm_cond_construct :
    positive -> arm_caimm_cond_fields_t -> arm_caimm_cond option **)

let arm_caimm_cond_construct p b =
  match p with
  | Coq_xI _ -> Some CAimmC_arm_0_8_16_24
  | Coq_xO _ -> Some (CAimmC_arm_wencoding (Obj.magic b))
  | Coq_xH -> Some (CAimmC_arm_shift_amout (Obj.magic b))

(** val arm_caimm_cond_induction :
    (shift_kind -> is_shift_kind -> 'a1) -> (expected_wencoding ->
    is_expected_wencoding -> 'a1) -> 'a1 -> arm_caimm_cond ->
    is_arm_caimm_cond -> 'a1 **)

let arm_caimm_cond_induction his_CAimmC_arm_shift_amout his_CAimmC_arm_wencoding his_CAimmC_arm_0_8_16_24 _ = function
| Coq_is_CAimmC_arm_shift_amout (x0, p_) -> his_CAimmC_arm_shift_amout x0 p_
| Coq_is_CAimmC_arm_wencoding (x0, p_) -> his_CAimmC_arm_wencoding x0 p_
| Coq_is_CAimmC_arm_0_8_16_24 -> his_CAimmC_arm_0_8_16_24

(** val arm_caimm_cond_eqb_fields :
    (arm_caimm_cond -> arm_caimm_cond -> bool) -> positive ->
    arm_caimm_cond_fields_t -> arm_caimm_cond_fields_t -> bool **)

let arm_caimm_cond_eqb_fields _ x a b =
  match x with
  | Coq_xI _ -> true
  | Coq_xO _ -> (&&) (expected_wencoding_eqb (Obj.magic a) (Obj.magic b)) true
  | Coq_xH -> (&&) (shift_kind_eqb (Obj.magic a) (Obj.magic b)) true

(** val arm_caimm_cond_eqb : arm_caimm_cond -> arm_caimm_cond -> bool **)

let arm_caimm_cond_eqb x1 x2 =
  match x1 with
  | CAimmC_arm_shift_amout h ->
    eqb_body arm_caimm_cond_tag arm_caimm_cond_fields
      (Obj.magic arm_caimm_cond_eqb_fields (fun _ _ -> true))
      (arm_caimm_cond_tag (CAimmC_arm_shift_amout h)) h x2
  | CAimmC_arm_wencoding h ->
    eqb_body arm_caimm_cond_tag arm_caimm_cond_fields
      (Obj.magic arm_caimm_cond_eqb_fields (fun _ _ -> true))
      (arm_caimm_cond_tag (CAimmC_arm_wencoding h)) h x2
  | CAimmC_arm_0_8_16_24 ->
    eqb_body arm_caimm_cond_tag arm_caimm_cond_fields
      (Obj.magic arm_caimm_cond_eqb_fields (fun _ _ -> true))
      (arm_caimm_cond_tag CAimmC_arm_0_8_16_24)
      Box_arm_caimm_cond_CAimmC_arm_0_8_16_24 x2

(** val arm_caimm_cond_eqb_OK :
    arm_caimm_cond -> arm_caimm_cond -> reflect **)

let arm_caimm_cond_eqb_OK =
  iffP2 arm_caimm_cond_eqb

(** val arm_caimm_cond_eqb_OK_sumbool :
    arm_caimm_cond -> arm_caimm_cond -> bool **)

let arm_caimm_cond_eqb_OK_sumbool =
  reflect_dec arm_caimm_cond_eqb arm_caimm_cond_eqb_OK

(** val eqTC_arm_caimm_cond : arm_caimm_cond eqTypeC **)

let eqTC_arm_caimm_cond =
  { beq = arm_caimm_cond_eqb; ceqP = arm_caimm_cond_eqb_OK }

(** val arm_check_CAimm : arm_caimm_cond -> wsize -> word -> bool **)

let arm_check_CAimm checker ws w =
  match checker with
  | CAimmC_arm_shift_amout sk -> check_shift_amount sk (wunsigned ws w)
  | CAimmC_arm_wencoding ew -> check_ei_kind ew ws w
  | CAimmC_arm_0_8_16_24 ->
    let x = wunsigned ws w in
    in_mem (Obj.magic x)
      (mem (seq_predType coq_BinNums_Z__canonical__eqtype_Equality)
        (Obj.magic (Z0 :: ((Zpos (Coq_xO (Coq_xO (Coq_xO Coq_xH)))) :: ((Zpos
          (Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH))))) :: ((Zpos (Coq_xO
          (Coq_xO (Coq_xO (Coq_xI Coq_xH))))) :: []))))))

(** val arm_caimm_cond_pp : arm_caimm_cond -> string **)

let arm_caimm_cond_pp = function
| CAimmC_arm_shift_amout sk ->
  (match sk with
   | SLSL -> "[0, 31]"
   | SROR -> "[1, 31]"
   | _ -> "[1, 32]")
| CAimmC_arm_wencoding ew ->
  (^) "(shift = "
    ((^) (string_of_ew ew.on_shift)
      ((^) ", none = " ((^) (string_of_ew ew.on_none) ")")))
| CAimmC_arm_0_8_16_24 -> "[0; 8; 16; 24]"

(** val arm_decl : (register, empty, empty, rflag, condt) arch_decl **)

let arm_decl =
  { reg_size = arm_reg_size; xreg_size = arm_xreg_size; cond_eqC =
    eqTC_condt; toS_r = reg_toS; toS_rx = (empty_toS (Coq_lword U32));
    toS_x = (empty_toS (Coq_lword U64)); toS_f = rflag_toS; ad_rsp = SP;
    ad_fcp = arm_fcp; caimm_cond_eqC = (Obj.magic eqTC_arm_caimm_cond);
    caimm_cond_pp = (Obj.magic arm_caimm_cond_pp); check_CAimm =
    (Obj.magic arm_check_CAimm) }

(** val arm_linux_call_conv :
    (register, empty, empty, rflag, condt) calling_convention **)

let arm_linux_call_conv =
  { callee_saved =
    (map (fun x -> ARReg x)
      (R04 :: (R05 :: (R06 :: (R07 :: (R08 :: (R09 :: (R10 :: (R11 :: (SP :: []))))))))));
    call_reg_args = (R00 :: (R01 :: (R02 :: (R03 :: [])))); call_xreg_args =
    []; call_reg_ret = (R00 :: (R01 :: [])); call_xreg_ret = [] }

(** val is_expandable : coq_Z -> bool **)

let is_expandable n =
  match ei_kind n with
  | EI_none -> false
  | EI_shift -> false
  | _ -> true

(** val is_expandable_or_shift : coq_Z -> bool **)

let is_expandable_or_shift n =
  match ei_kind n with
  | EI_none -> false
  | _ -> true

(** val arm_internal_call_conv :
    (register, empty, empty, rflag, condt) internal_calling_convention **)

let arm_internal_call_conv =
  { icall_reg =
    (R00 :: (R01 :: (R02 :: (R03 :: (R04 :: (R05 :: (R06 :: (R07 :: (R08 :: (R09 :: (R10 :: (R11 :: (R12 :: [])))))))))))));
    icall_regx = []; icall_xreg = []; icall_rflag =
    (CF :: (NF :: (ZF :: (VF :: [])))) }
