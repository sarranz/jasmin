(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_params
open Arch_utils
open Asm_gen
open Compiler_util
open Eqtype
open Expr
open Fexpr
open Lea
open Linearization
open Operators
open Otbn_decl
open Otbn_extra
open Otbn_instr_decl
open Otbn_lower_addressing
open Otbn_lowering
open Otbn_params_core
open Seq
open Slh_lowering
open Sopn
open Ssrbool
open Ssrfun
open Ssrnat
open Stack_alloc_params
open Stack_zeroization
open Type
open Utils0
open Var0
open Word_ssrZ
open Wsize

module E :
 sig
  val pass : string

  val szp_cmd : pp_error_loc
 end

val add_imm_op :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  coq_Z -> otbn_extended_op * pexpr list

val mov_ofs :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> lval ->
  assgn_tag -> mov_kind -> pexpr -> pexpr -> (register, empty, wide_register,
  rflag, condition, otbn_op, extra_op) extended_op instr_r option

val immediate :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  coq_Z -> (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extended_op instr_r

val swap :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  assgn_tag -> var_i -> var_i -> var_i -> var_i -> (register, empty,
  wide_register, rflag, condition, otbn_op, extra_op) extended_op instr_r

val saparams :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op stack_alloc_params

val vtmp :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> Var.var

val vtmp2 :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> Var.var

val fopn_args_of_opn_args :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  OTBNFopn_core.opn_args -> (lexpr list * (register, empty, wide_register,
  rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list

val allocate_stack_frame :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i option -> coq_Z -> ((lexpr list * (register, empty, wide_register,
  rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list) list

val free_stack_frame :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i option -> coq_Z -> ((lexpr list * (register, empty, wide_register,
  rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list) list

val smart_addi : var_i -> var_i -> coq_Z -> OTBNFopn_core.opn_args list

val smart_subi : var_i -> var_i -> coq_Z -> OTBNFopn_core.opn_args list

val set_up_sp_register :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  coq_Z -> wsize -> var_i -> var_i -> ((lexpr list * (register, empty,
  wide_register, rflag, condition, otbn_op, extra_op) extended_op
  sopn) * rexpr list) list

val lmove :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i -> (lexpr list * (register, empty, wide_register, rflag, condition,
  otbn_op, extra_op) extended_op sopn) * rexpr list

val check_ws : Equality.sort -> bool

val lstore :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  coq_Z -> var_i -> (lexpr list * (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op sopn) * rexpr list

val lload :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i -> coq_Z -> (lexpr list * (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op sopn) * rexpr list

val smart_addi_fopn :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  var_i -> coq_Z -> ((lexpr list * (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op sopn) * rexpr list) list

val lstores :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  (Var.var * coq_Z) list -> ((lexpr list * (register, empty, wide_register,
  rflag, condition, otbn_op, extra_op) extended_op sopn) * rexpr list) list

val lloads :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> var_i ->
  (Var.var * coq_Z) list -> coq_Z -> ((lexpr list * (register, empty,
  wide_register, rflag, condition, otbn_op, extra_op) extended_op
  sopn) * rexpr list) list

val liparams :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op linearization_params

val loparams :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op lowering_params

val is_fzero : wsize -> fexpr -> bool

val is_fvar : fexpr -> var_i option

val condt_not :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> condition -> condition cexec

val sop2_is_eq : instr_info -> fexpr -> sop2 -> bool cexec

val oreg_of_fexpr :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> fexpr -> fexpr -> register option cexec

val assemble_cond_app2 :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> fexpr -> sop2 -> fexpr -> fexpr -> condition cexec

val assemble_cond :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> fexpr -> condition cexec

val is_valid_address :
  (register, empty, wide_register, rflag, condition) reg_address -> bool

val agparams :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  asm_gen_params

val laparams :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  lower_addressing_params

val shparams :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op sh_params

val szparams :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op stack_zeroization_params

val is_move_op :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op asm_op_t -> bool

val otbn_params :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  architecture_params
