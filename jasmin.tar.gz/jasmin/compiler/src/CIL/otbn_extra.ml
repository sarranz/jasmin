(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Arm_extra
open Compiler_util
open EqbOK
open Eqb_core_defs
open Eqtype
open Expr
open Fexpr
open Otbn
open Otbn_decl
open Otbn_instr_decl
open Otbn_options
open Otbn_params_core
open Sem_type
open Seq
open Sopn
open Ssralg
open Type
open Utils0
open Var0
open Word0
open Wsize

type __ = Obj.t

module E =
 struct
  (** val pass_name : string **)

  let pass_name =
    "assembly generation"

  (** val internal_error : string -> instr_info -> pp_error_loc **)

  let internal_error msg ii =
    pp_internal_error_s_at pass_name ii msg

  (** val internal_error_pp : pp_error -> instr_info -> pp_error_loc **)

  let internal_error_pp pp ii =
    pp_at_ii ii (pp_internal_error pass_name pp)

  (** val invalid_lexprs : instr_info -> pp_error_loc **)

  let invalid_lexprs =
    internal_error "invalid destination"

  (** val invalid_rexprs : instr_info -> pp_error_loc **)

  let invalid_rexprs =
    internal_error "invalid arguments"

  (** val invalid_args : instr_info -> pp_error_loc **)

  let invalid_args =
    internal_error "invalid destination or arguments"

  (** val bad_swap_lexprs : instr_info -> pp_error_loc **)

  let bad_swap_lexprs =
    internal_error "bad swap: invalid destinations"

  (** val bad_swap_rexprs : instr_info -> pp_error_loc **)

  let bad_swap_rexprs =
    internal_error "bad swap: invalid sources"

  (** val bad_swap_size : wsize -> instr_info -> pp_error_loc **)

  let bad_swap_size ws ii =
    internal_error_pp
      (pp_box ((PPEstring "bad swap: expected size") :: ((PPEstring
        (string_of_wsize otbn_decl.reg_size)) :: ((PPEstring
        "or") :: ((PPEstring
        (string_of_wsize otbn_decl.xreg_size)) :: ((PPEstring
        "but got") :: ((PPEstring (string_of_wsize ws)) :: [])))))))
      ii

  (** val bad_swap_dst_arg : instr_info -> pp_error_loc **)

  let bad_swap_dst_arg =
    internal_error
      "bad swap arguments: first destination should be different from last argument"

  (** val bad_swap_dsts : instr_info -> pp_error_loc **)

  let bad_swap_dsts =
    internal_error
      "bad swap arguments: destination registers should be different"

  (** val bad_swap_ty : instr_info -> pp_error_loc **)

  let bad_swap_ty =
    internal_error "bad swap: operands must be a register or a wide register"
 end

(** val asm_args_of_opn_args :
    OTBNFopn_core.opn_args list -> (((register, empty, wide_register, rflag,
    condition, otbn_op) asm_op_msb_t * lexpr list) * rexpr list) list **)

let asm_args_of_opn_args =
  map (fun pat ->
    let (y, res) = pat in let (les, aop) = y in (((None, aop), les), res))

type extra_op =
| Coq_set0 of wsize
| MOV
| SUBI
| ADD_LARGE_IMM
| SWAP of wsize

(** val extra_op_rect :
    (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> (wsize -> 'a1) -> extra_op -> 'a1 **)

let extra_op_rect f f0 f1 f2 f3 = function
| Coq_set0 w -> f w
| MOV -> f0
| SUBI -> f1
| ADD_LARGE_IMM -> f2
| SWAP w -> f3 w

(** val extra_op_rec :
    (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> (wsize -> 'a1) -> extra_op -> 'a1 **)

let extra_op_rec f f0 f1 f2 f3 = function
| Coq_set0 w -> f w
| MOV -> f0
| SUBI -> f1
| ADD_LARGE_IMM -> f2
| SWAP w -> f3 w

type is_extra_op =
| Coq_is_set0 of wsize * is_wsize
| Coq_is_MOV
| Coq_is_SUBI
| Coq_is_ADD_LARGE_IMM
| Coq_is_SWAP of wsize * is_wsize

(** val is_extra_op_rect :
    (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> (wsize -> is_wsize ->
    'a1) -> extra_op -> is_extra_op -> 'a1 **)

let is_extra_op_rect f f0 f1 f2 f3 _ = function
| Coq_is_set0 (w, p_) -> f w p_
| Coq_is_MOV -> f0
| Coq_is_SUBI -> f1
| Coq_is_ADD_LARGE_IMM -> f2
| Coq_is_SWAP (w, p_) -> f3 w p_

(** val is_extra_op_rec :
    (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> (wsize -> is_wsize ->
    'a1) -> extra_op -> is_extra_op -> 'a1 **)

let is_extra_op_rec f f0 f1 f2 f3 _ = function
| Coq_is_set0 (w, p_) -> f w p_
| Coq_is_MOV -> f0
| Coq_is_SUBI -> f1
| Coq_is_ADD_LARGE_IMM -> f2
| Coq_is_SWAP (w, p_) -> f3 w p_

(** val extra_op_tag : extra_op -> positive **)

let extra_op_tag = function
| Coq_set0 _ -> Coq_xH
| MOV -> Coq_xO Coq_xH
| SUBI -> Coq_xI Coq_xH
| ADD_LARGE_IMM -> Coq_xO (Coq_xO Coq_xH)
| SWAP _ -> Coq_xI (Coq_xO Coq_xH)

(** val is_extra_op_inhab : extra_op -> is_extra_op **)

let is_extra_op_inhab = function
| Coq_set0 h -> Coq_is_set0 (h, (is_wsize_inhab h))
| MOV -> Coq_is_MOV
| SUBI -> Coq_is_SUBI
| ADD_LARGE_IMM -> Coq_is_ADD_LARGE_IMM
| SWAP h -> Coq_is_SWAP (h, (is_wsize_inhab h))

(** val is_extra_op_functor : extra_op -> is_extra_op -> is_extra_op **)

let rec is_extra_op_functor _ x =
  x

type box_extra_op_set0 =
  wsize
  (* singleton inductive, whose constructor was Box_extra_op_set0 *)

(** val coq_Box_extra_op_set0_0 : box_extra_op_set0 -> wsize **)

let coq_Box_extra_op_set0_0 record =
  record

type box_extra_op_MOV =
| Box_extra_op_MOV

type extra_op_fields_t = __

(** val extra_op_fields : extra_op -> extra_op_fields_t **)

let extra_op_fields = function
| Coq_set0 h -> Obj.magic h
| SWAP h -> Obj.magic h
| _ -> Obj.magic Box_extra_op_MOV

(** val extra_op_construct :
    positive -> extra_op_fields_t -> extra_op option **)

let extra_op_construct p x =
  match p with
  | Coq_xI x0 ->
    (match x0 with
     | Coq_xI _ -> None
     | Coq_xO _ -> Some (SWAP (Obj.magic x))
     | Coq_xH -> Some SUBI)
  | Coq_xO x0 ->
    (match x0 with
     | Coq_xI _ -> None
     | Coq_xO _ -> Some ADD_LARGE_IMM
     | Coq_xH -> Some MOV)
  | Coq_xH -> Some (Coq_set0 (Obj.magic x))

(** val extra_op_induction :
    (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> (wsize -> is_wsize ->
    'a1) -> extra_op -> is_extra_op -> 'a1 **)

let extra_op_induction his_set0 his_MOV his_SUBI his_ADD_LARGE_IMM his_SWAP _ = function
| Coq_is_set0 (x0, p_) -> his_set0 x0 p_
| Coq_is_MOV -> his_MOV
| Coq_is_SUBI -> his_SUBI
| Coq_is_ADD_LARGE_IMM -> his_ADD_LARGE_IMM
| Coq_is_SWAP (x0, p_) -> his_SWAP x0 p_

(** val extra_op_eqb_fields :
    (extra_op -> extra_op -> bool) -> positive -> extra_op_fields_t ->
    extra_op_fields_t -> bool **)

let extra_op_eqb_fields _ x x0 x1 =
  match x with
  | Coq_xI x2 ->
    (match x2 with
     | Coq_xO _ -> (&&) (wsize_eqb (Obj.magic x0) (Obj.magic x1)) true
     | _ -> true)
  | Coq_xO _ -> true
  | Coq_xH -> (&&) (wsize_eqb (Obj.magic x0) (Obj.magic x1)) true

(** val extra_op_eqb : extra_op -> extra_op -> bool **)

let extra_op_eqb x1 x2 =
  match x1 with
  | Coq_set0 h ->
    eqb_body extra_op_tag extra_op_fields
      (Obj.magic extra_op_eqb_fields (fun _ _ -> true))
      (extra_op_tag (Coq_set0 h)) h x2
  | SWAP h ->
    eqb_body extra_op_tag extra_op_fields
      (Obj.magic extra_op_eqb_fields (fun _ _ -> true))
      (extra_op_tag (SWAP h)) h x2
  | x ->
    eqb_body extra_op_tag extra_op_fields
      (Obj.magic extra_op_eqb_fields (fun _ _ -> true)) (extra_op_tag x)
      Box_extra_op_MOV x2

(** val extra_op_eqb_OK : extra_op -> extra_op -> reflect **)

let extra_op_eqb_OK =
  iffP2 extra_op_eqb

(** val extra_op_eqb_OK_sumbool : extra_op -> extra_op -> bool **)

let extra_op_eqb_OK_sumbool =
  reflect_dec extra_op_eqb extra_op_eqb_OK

(** val coq_HB_unnamed_factory_1 : extra_op Coq_hasDecEq.axioms_ **)

let coq_HB_unnamed_factory_1 =
  { Coq_hasDecEq.eq_op = extra_op_eqb; Coq_hasDecEq.eqP = extra_op_eqb_OK }

(** val otbn_extra_extra_op__canonical__eqtype_Equality :
    Equality.coq_type **)

let otbn_extra_extra_op__canonical__eqtype_Equality =
  Obj.magic coq_HB_unnamed_factory_1

(** val eqTC_otbn_extra_op : extra_op eqTypeC **)

let eqTC_otbn_extra_op =
  { beq = extra_op_eqb; ceqP = extra_op_eqb_OK }

(** val string_of_extra_op : extra_op -> string **)

let string_of_extra_op = function
| Coq_set0 _ -> "set0"
| MOV -> "MOV"
| SUBI -> "SUBI"
| ADD_LARGE_IMM -> "add_large_imm"
| SWAP _ -> "swap"

(** val desc_set0_small :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instruction_desc **)

let desc_set0_small atoI =
  let acc_mod0 =
    map (to_var (Coq_lword otbn_decl.xreg_size) otbn_decl.toS_x atoI.toI_x)
      acc_mod
  in
  let e = fun n -> ADExplicit (n, (ACR_subset acc_mod0)) in
  { str = (pp_s (string_of_extra_op (Coq_set0 U8))); tin = []; i_in = [];
  tout = ((Coq_aword U32) :: []); i_out = ((e O) :: []); conflicts = [];
  semi =
  (sem_prod_ok (map eval_atype [])
    (GRing.zero (word_word__canonical__GRing_Nmodule U32)));
  i_valid = true; i_safe = []; i_doit = DOIT }

(** val desc_set0_large :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instruction_desc **)

let desc_set0_large atoI =
  let acc_mod0 =
    map (to_var (Coq_lword otbn_decl.xreg_size) otbn_decl.toS_x atoI.toI_x)
      acc_mod
  in
  let e = fun n -> ADExplicit (n, (ACR_subset acc_mod0)) in
  let f = fun f -> ADImplicit (to_var Coq_lbool otbn_decl.toS_f atoI.toI_f f)
  in
  let vf = Some false in
  let vt = Some true in
  { str = (pp_s (string_of_extra_op (Coq_set0 U8))); tin = []; i_in = [];
  tout = (Coq_abool :: (Coq_abool :: (Coq_abool :: ((Coq_aword
  U256) :: [])))); i_out =
  ((f MF0) :: ((f LF0) :: ((f ZF0) :: ((e O) :: [])))); conflicts = [];
  semi =
  (sem_prod_ok (map eval_atype [])
    (Obj.magic (vf, (vf, (vt,
      (GRing.zero (word_word__canonical__GRing_Nmodule U256)))))));
  i_valid = true; i_safe = []; i_doit = DOIT }

(** val desc_MOV :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instruction_desc **)

let desc_MOV atoI =
  let acc_mod0 =
    map (to_var (Coq_lword otbn_decl.xreg_size) otbn_decl.toS_x atoI.toI_x)
      acc_mod
  in
  let e = fun n -> ADExplicit (n, (ACR_subset acc_mod0)) in
  { str = (pp_s (string_of_extra_op MOV)); tin = ((Coq_aword U32) :: []);
  i_in = ((e (S O)) :: []); tout = ((Coq_aword U32) :: []); i_out =
  ((e O) :: []); conflicts = []; semi =
  (sem_prod_ok (map eval_atype ((Coq_aword U32) :: []))
    (Obj.magic (fun x -> x)));
  i_valid = true; i_safe = []; i_doit = DOIT }

(** val desc_SUBI :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instruction_desc **)

let desc_SUBI atoI =
  let acc_mod0 =
    map (to_var (Coq_lword otbn_decl.xreg_size) otbn_decl.toS_x atoI.toI_x)
      acc_mod
  in
  let e = fun n -> ADExplicit (n, (ACR_subset acc_mod0)) in
  { str = (pp_s (string_of_extra_op SUBI)); tin = ((Coq_aword
  U32) :: ((Coq_aword U32) :: [])); i_in =
  ((e (S O)) :: ((e (S (S O))) :: [])); tout = ((Coq_aword U32) :: []);
  i_out = ((e O) :: []); conflicts = []; semi =
  (sem_prod_ok (map eval_atype ((Coq_aword U32) :: ((Coq_aword U32) :: [])))
    (Obj.magic (fun x y ->
      GRing.add (word_word__canonical__GRing_Nmodule U32) x
        (GRing.opp (word_word__canonical__GRing_Zmodule U32) y))));
  i_valid = true; i_safe = []; i_doit = DOIT }

(** val desc_ADD_LARGE_IMM :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instruction_desc **)

let desc_ADD_LARGE_IMM atoI =
  let acc_mod0 =
    map (to_var (Coq_lword otbn_decl.xreg_size) otbn_decl.toS_x atoI.toI_x)
      acc_mod
  in
  let e = fun n -> ADExplicit (n, (ACR_subset acc_mod0)) in
  let ty = Coq_aword U32 in
  let cty = eval_atype ty in
  let ctin = cty :: (cty :: []) in
  let semi0 = fun x y ->
    GRing.add (word_word__canonical__GRing_Nmodule U32) x y
  in
  { str = (pp_s (string_of_extra_op ADD_LARGE_IMM)); tin =
  (ty :: (ty :: [])); i_in = ((e (S O)) :: ((e (S (S O))) :: [])); tout =
  (ty :: []); i_out = ((e O) :: []); conflicts = (((APout O), (APin
  O)) :: []); semi = (sem_prod_ok ctin (Obj.magic semi0)); i_valid = true;
  i_safe = []; i_doit = DOIT }

(** val desc_swap_large :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instruction_desc **)

let desc_swap_large atoI =
  let acc_mod0 =
    map (to_var (Coq_lword otbn_decl.xreg_size) otbn_decl.toS_x atoI.toI_x)
      acc_mod
  in
  let e = fun n -> ADExplicit (n, (ACR_subset acc_mod0)) in
  let f = fun f -> ADImplicit (to_var Coq_lbool otbn_decl.toS_f atoI.toI_f f)
  in
  { str = (pp_s (string_of_extra_op (SWAP U256))); tin = ((Coq_aword
  U256) :: ((Coq_aword U256) :: [])); i_in = ((e O) :: ((e (S O)) :: []));
  tout = (Coq_abool :: (Coq_abool :: (Coq_abool :: ((Coq_aword
  U256) :: ((Coq_aword U256) :: []))))); i_out =
  ((f MF1) :: ((f LF1) :: ((f ZF1) :: ((e O) :: ((e (S O)) :: [])))));
  conflicts = []; semi =
  (sem_prod_ok
    (map eval_atype ((Coq_aword U256) :: ((Coq_aword U256) :: [])))
    (Obj.magic (fun z w -> ((coq_MF_of_word w), ((coq_LF_of_word w),
      ((coq_ZF_of_word w), (w, z)))))));
  i_valid = true; i_safe = []; i_doit = DOIT }

(** val get_instr_desc :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    extra_op -> instruction_desc **)

let get_instr_desc atoI = function
| Coq_set0 ws ->
  if cmp_le wsize_cmp ws otbn_decl.reg_size
  then desc_set0_small atoI
  else desc_set0_large atoI
| MOV -> desc_MOV atoI
| SUBI -> desc_SUBI atoI
| ADD_LARGE_IMM -> desc_ADD_LARGE_IMM atoI
| SWAP ws ->
  if cmp_le wsize_cmp ws otbn_decl.reg_size
  then coq_Oswap_instr (Coq_aword ws)
  else desc_swap_large atoI

(** val prim_string : (string * extra_op prim_constructor) list **)

let prim_string =
  ((string_of_extra_op (Coq_set0 U8)),
    (prim_otbn_ws (fun x -> Coq_set0 x))) :: (((string_of_extra_op MOV),
    (prim_otbn_none MOV)) :: (((string_of_extra_op SUBI),
    (prim_otbn_none SUBI)) :: []))

(** val extra_op_decl :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    extra_op asmOp **)

let extra_op_decl atoI =
  { _eqT = eqTC_otbn_extra_op; asm_op_instr = (get_instr_desc atoI);
    Sopn.prim_string = prim_string }

(** val assemble_set0 :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> wsize
    -> lexpr list -> rexpr list -> (((register, empty, wide_register, rflag,
    condition, otbn_op) asm_op_msb_t * lexpr list) * rexpr list) list cexec **)

let assemble_set0 atoI ws les _ =
  if cmp_le wsize_cmp ws otbn_decl.reg_size
  then let op = RV32 XOR in
       let v =
         to_var (Coq_lword otbn_decl.reg_size) otbn_decl.toS_r atoI.toI_r X03
       in
       let x = rvar (mk_var_i v) in
       Ok ((((None, op), les), (x :: (x :: []))) :: [])
  else let op = BN_basic (BN_XOR, FG0) in
       let v =
         to_var (Coq_lword otbn_decl.xreg_size) otbn_decl.toS_x atoI.toI_x W01
       in
       let x = rvar (mk_var_i v) in
       Ok ((((None, op), les), (x :: (x :: []))) :: [])

(** val assemble_MOV :
    instr_info -> lexpr list -> rexpr list -> (((register, empty,
    wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
    list) * rexpr list) list cexec **)

let assemble_MOV ii =
  let uncons_LLvar0 = uncons_LLvar ii in
  let uncons_rvar0 = uncons_rvar ii in
  (fun les res ->
  match uncons_LLvar0 les with
  | Ok x ->
    let (x0, _) = x in
    (match uncons_rvar0 res with
     | Ok x1 ->
       let (y, _) = x1 in
       if convertible (Var.vtype x0.v_var) (Coq_aword U32)
       then Ok (asm_args_of_opn_args ((OTBNFopn_core.mov x0 y) :: []))
       else let s = E.internal_error "mov: bad register type" ii in Error s
     | Error s -> Error s)
  | Error s -> Error s)

(** val assemble_SUBI :
    instr_info -> lexpr list -> rexpr list -> (((register, empty,
    wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
    list) * rexpr list) list cexec **)

let assemble_SUBI ii =
  let uncons_LLvar0 = uncons_LLvar ii in
  let uncons_rvar0 = uncons_rvar ii in
  let uncons_wconst0 = uncons_wconst ii in
  (fun les res ->
  match uncons_LLvar0 les with
  | Ok x ->
    let (x0, _) = x in
    (match uncons_rvar0 res with
     | Ok x1 ->
       let (y, res0) = x1 in
       (match uncons_wconst0 res0 with
        | Ok x2 ->
          let (imm, _) = x2 in
          if convertible (Var.vtype x0.v_var) (Coq_aword U32)
          then if negb
                    ((&&) (Z.eqb imm Z0)
                      (eq_op Var.coq_MvMake_var__canonical__eqtype_Equality
                        (Obj.magic x0.v_var) (Obj.magic y.v_var)))
               then (match o2r (E.invalid_args ii)
                             (OTBNFopn_core.smart_subi x0 y imm) with
                     | Ok x3 -> Ok (asm_args_of_opn_args x3)
                     | Error s -> Error s)
               else let s = E.internal_error "subi: trivial no-op" ii in
                    Error s
          else let s = E.internal_error "subi: bad register type" ii in
               Error s
        | Error s -> Error s)
     | Error s -> Error s)
  | Error s -> Error s)

(** val assemble_ADD_LARGE_IMM :
    instr_info -> lexpr list -> rexpr list -> (((register, empty,
    wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
    list) * rexpr list) list cexec **)

let assemble_ADD_LARGE_IMM ii =
  let uncons_LLvar0 = uncons_LLvar ii in
  let uncons_rvar0 = uncons_rvar ii in
  let uncons_wconst0 = uncons_wconst ii in
  (fun les res ->
  match uncons_LLvar0 les with
  | Ok x ->
    let (x0, _) = x in
    (match uncons_rvar0 res with
     | Ok x1 ->
       let (y, res0) = x1 in
       (match uncons_wconst0 res0 with
        | Ok x2 ->
          let (imm, _) = x2 in
          if negb
               (eq_op Var.coq_MvMake_var__canonical__eqtype_Equality
                 (Obj.magic x0.v_var) (Obj.magic y.v_var))
          then if convertible (Var.vtype x0.v_var) (Coq_aword U32)
               then (match o2r (E.invalid_args ii)
                             (OTBNFopn_core.smart_addi x0 y imm) with
                     | Ok x3 -> Ok (asm_args_of_opn_args x3)
                     | Error s -> Error s)
               else let s =
                      E.internal_error "add_large_imm: bad register type" ii
                    in
                    Error s
          else let s = E.internal_error "add_large_imm: invalid register" ii
               in
               Error s
        | Error s -> Error s)
     | Error s -> Error s)
  | Error s -> Error s)

(** val assemble_swap :
    instr_info -> wsize -> lexpr list -> rexpr list -> (((register, empty,
    wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
    list) * rexpr list) list cexec **)

let assemble_swap ii ws les = function
| [] -> let s = E.bad_swap_rexprs ii in Error s
| r :: l ->
  (match r with
   | Load (_, _, _) -> let s = E.bad_swap_rexprs ii in Error s
   | Rexpr f ->
     (match f with
      | Fconst _ -> let s = E.bad_swap_rexprs ii in Error s
      | Fvar z ->
        (match l with
         | [] -> let s = E.bad_swap_rexprs ii in Error s
         | r0 :: l0 ->
           (match r0 with
            | Load (_, _, _) -> let s = E.bad_swap_rexprs ii in Error s
            | Rexpr f0 ->
              (match f0 with
               | Fconst _ -> let s = E.bad_swap_rexprs ii in Error s
               | Fvar w ->
                 (match l0 with
                  | [] ->
                    let x = (z, w) in
                    let (z0, w0) = x in
                    if eq_op wsize_wsize__canonical__eqtype_Equality
                         (Obj.magic ws) (Obj.magic otbn_decl.reg_size)
                    then (match les with
                          | [] -> let s = E.bad_swap_lexprs ii in Error s
                          | l1 :: l2 ->
                            (match l1 with
                             | Store (_, _, _) ->
                               let s = E.bad_swap_lexprs ii in Error s
                             | LLvar x0 ->
                               (match l2 with
                                | [] ->
                                  let s = E.bad_swap_lexprs ii in Error s
                                | l3 :: l4 ->
                                  (match l3 with
                                   | Store (_, _, _) ->
                                     let s = E.bad_swap_lexprs ii in Error s
                                   | LLvar y ->
                                     (match l4 with
                                      | [] ->
                                        let x1 = ((((RV32 XOR), []), x0), y)
                                        in
                                        let (y0, y1) = x1 in
                                        let (y2, x2) = y0 in
                                        let (op, fl) = y2 in
                                        if negb
                                             (eq_op
                                               Var.coq_MvMake_var__canonical__eqtype_Equality
                                               (Obj.magic x2.v_var)
                                               (Obj.magic w0.v_var))
                                        then if negb
                                                  (eq_op
                                                    Var.coq_MvMake_var__canonical__eqtype_Equality
                                                    (Obj.magic y1.v_var)
                                                    (Obj.magic x2.v_var))
                                             then if all (fun v ->
                                                       convertible
                                                         (Var.vtype v.v_var)
                                                         (Coq_aword ws))
                                                       (x2 :: (y1 :: (z0 :: (w0 :: []))))
                                                  then let xor = fun d a b ->
                                                         (((None, op),
                                                         (cat fl ((LLvar
                                                           d) :: []))),
                                                         ((Rexpr (Fvar
                                                         a)) :: ((Rexpr (Fvar
                                                         b)) :: [])))
                                                       in
                                                       Ok
                                                       ((xor x2 z0 w0) :: (
                                                       (xor y1 x2 w0) :: (
                                                       (xor x2 x2 y1) :: [])))
                                                  else let s =
                                                         E.bad_swap_ty ii
                                                       in
                                                       Error s
                                             else let s = E.bad_swap_dsts ii
                                                  in
                                                  Error s
                                        else let s = E.bad_swap_dst_arg ii in
                                             Error s
                                      | _ :: _ ->
                                        let s = E.bad_swap_lexprs ii in
                                        Error s)))))
                    else if eq_op wsize_wsize__canonical__eqtype_Equality
                              (Obj.magic ws) (Obj.magic otbn_decl.xreg_size)
                         then (match les with
                               | [] -> let s = E.bad_swap_lexprs ii in Error s
                               | fM :: l1 ->
                                 (match l1 with
                                  | [] ->
                                    let s = E.bad_swap_lexprs ii in Error s
                                  | fL :: l2 ->
                                    (match l2 with
                                     | [] ->
                                       let s = E.bad_swap_lexprs ii in Error s
                                     | fZ :: l3 ->
                                       (match l3 with
                                        | [] ->
                                          let s = E.bad_swap_lexprs ii in
                                          Error s
                                        | l4 :: l5 ->
                                          (match l4 with
                                           | Store (_, _, _) ->
                                             let s = E.bad_swap_lexprs ii in
                                             Error s
                                           | LLvar x0 ->
                                             (match l5 with
                                              | [] ->
                                                let s = E.bad_swap_lexprs ii
                                                in
                                                Error s
                                              | l6 :: l7 ->
                                                (match l6 with
                                                 | Store (_, _, _) ->
                                                   let s =
                                                     E.bad_swap_lexprs ii
                                                   in
                                                   Error s
                                                 | LLvar y ->
                                                   (match l7 with
                                                    | [] ->
                                                      let x1 = ((((BN_basic
                                                        (BN_XOR, FG1)),
                                                        (fM :: (fL :: (fZ :: [])))),
                                                        x0), y)
                                                      in
                                                      let (y0, y1) = x1 in
                                                      let (y2, x2) = y0 in
                                                      let (op, fl) = y2 in
                                                      if negb
                                                           (eq_op
                                                             Var.coq_MvMake_var__canonical__eqtype_Equality
                                                             (Obj.magic
                                                               x2.v_var)
                                                             (Obj.magic
                                                               w0.v_var))
                                                      then if negb
                                                                (eq_op
                                                                  Var.coq_MvMake_var__canonical__eqtype_Equality
                                                                  (Obj.magic
                                                                    y1.v_var)
                                                                  (Obj.magic
                                                                    x2.v_var))
                                                           then if all
                                                                    (fun v ->
                                                                    convertible
                                                                    (Var.vtype
                                                                    v.v_var)
                                                                    (Coq_aword
                                                                    ws))
                                                                    (x2 :: (y1 :: (z0 :: (w0 :: []))))
                                                                then 
                                                                  let xor =
                                                                    fun d a b ->
                                                                    (((None,
                                                                    op),
                                                                    (cat fl
                                                                    ((LLvar
                                                                    d) :: []))),
                                                                    ((Rexpr
                                                                    (Fvar
                                                                    a)) :: ((Rexpr
                                                                    (Fvar
                                                                    b)) :: [])))
                                                                  in
                                                                  Ok
                                                                  ((xor x2 z0
                                                                    w0) :: (
                                                                  (xor y1 x2
                                                                    w0) :: (
                                                                  (xor x2 x2
                                                                    y1) :: [])))
                                                                else 
                                                                  let s =
                                                                    E.bad_swap_ty
                                                                    ii
                                                                  in
                                                                  Error s
                                                           else let s =
                                                                  E.bad_swap_dsts
                                                                    ii
                                                                in
                                                                Error s
                                                      else let s =
                                                             E.bad_swap_dst_arg
                                                               ii
                                                           in
                                                           Error s
                                                    | _ :: _ ->
                                                      let s =
                                                        E.bad_swap_lexprs ii
                                                      in
                                                      Error s))))))))
                         else let s = E.bad_swap_size ws ii in Error s
                  | _ :: _ -> let s = E.bad_swap_rexprs ii in Error s)
               | _ -> let s = E.bad_swap_rexprs ii in Error s)))
      | _ -> let s = E.bad_swap_rexprs ii in Error s))

(** val assemble_extra :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> extra_op -> lexpr list -> rexpr list -> (((register, empty,
    wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
    list) * rexpr list) list cexec **)

let assemble_extra atoI ii eo les res =
  match eo with
  | Coq_set0 ws -> assemble_set0 atoI ws les res
  | MOV -> assemble_MOV ii les res
  | SUBI -> assemble_SUBI ii les res
  | ADD_LARGE_IMM -> assemble_ADD_LARGE_IMM ii les res
  | SWAP ws -> assemble_swap ii ws les res

(** val otbn_extra :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    asm_extra **)

let otbn_extra atoI =
  { _asm = otbn; _atoI = atoI; _extra = (extra_op_decl atoI); to_asm =
    (assemble_extra atoI) }

type otbn_extended_op =
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op

(** val coq_Ootbn :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    otbn_op -> (register, empty, wide_register, rflag, condition, otbn_op,
    extra_op) extended_op sopn **)

let coq_Ootbn _ o =
  Oasm (BaseOp (None, o))
