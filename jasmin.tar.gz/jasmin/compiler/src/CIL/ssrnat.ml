(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Nat0
open Eqtype
open Ssrbool

(** val eqn : nat -> nat -> bool **)

let rec eqn m n =
  match m with
  | O -> (match n with
          | O -> true
          | S _ -> false)
  | S m' -> (match n with
             | O -> false
             | S n' -> eqn m' n')

(** val eqnP : nat eq_axiom **)

let eqnP n m =
  iffP (eqn n m) (if eqn n m then ReflectT else ReflectF)

(** val coq_HB_unnamed_factory_1 : nat Coq_hasDecEq.axioms_ **)

let coq_HB_unnamed_factory_1 =
  { Coq_hasDecEq.eq_op = eqn; Coq_hasDecEq.eqP = eqnP }

(** val coq_Datatypes_nat__canonical__eqtype_Equality : Equality.coq_type **)

let coq_Datatypes_nat__canonical__eqtype_Equality =
  Obj.magic coq_HB_unnamed_factory_1

(** val addn : nat -> nat -> nat **)

let addn =
  add

(** val subn : nat -> nat -> nat **)

let subn =
  sub

(** val leq : nat -> nat -> bool **)

let leq m n =
  eq_op coq_Datatypes_nat__canonical__eqtype_Equality (Obj.magic subn m n)
    (Obj.magic O)

(** val iter : nat -> ('a1 -> 'a1) -> 'a1 -> 'a1 **)

let rec iter n f x =
  match n with
  | O -> x
  | S i -> f (iter i f x)

(** val iteri : nat -> (nat -> 'a1 -> 'a1) -> 'a1 -> 'a1 **)

let rec iteri n f x =
  match n with
  | O -> x
  | S i -> f i (iteri i f x)

(** val iterop : nat -> ('a1 -> 'a1 -> 'a1) -> 'a1 -> 'a1 -> 'a1 **)

let iterop n op x =
  let f = fun i y -> match i with
                     | O -> x
                     | S _ -> op x y in iteri n f

(** val muln : nat -> nat -> nat **)

let muln =
  mul

(** val expn : nat -> nat -> nat **)

let expn m n =
  iterop n muln m (S O)

(** val nat_of_bool : bool -> nat **)

let nat_of_bool = function
| true -> S O
| false -> O

(** val double : nat -> nat **)

let rec double = function
| O -> O
| S n' -> S (S (double n'))

(** val half : nat -> nat **)

let rec half n = match n with
| O -> n
| S n' -> uphalf n'

(** val uphalf : nat -> nat **)

and uphalf n = match n with
| O -> n
| S n' -> S (half n')

module NatTrec =
 struct
  (** val add : nat -> nat -> nat **)

  let rec add m n =
    match m with
    | O -> n
    | S m' -> add m' (S n)

  (** val double : nat -> nat **)

  let double n = match n with
  | O -> O
  | S n' -> add n' (S n)
 end

(** val nat_of_pos : positive -> nat **)

let rec nat_of_pos = function
| Coq_xI p -> S (NatTrec.double (nat_of_pos p))
| Coq_xO p -> NatTrec.double (nat_of_pos p)
| Coq_xH -> S O

(** val nat_of_bin : coq_N -> nat **)

let nat_of_bin = function
| N0 -> O
| Npos p -> nat_of_pos p
