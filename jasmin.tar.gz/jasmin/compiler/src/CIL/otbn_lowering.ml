(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Compiler_util
open Eqtype
open Expr
open Lowering
open Operators
open Otbn_decl
open Otbn_extra
open Otbn_instr_decl
open Otbn_options
open Otbn_params_core
open Pseudo_operator
open Seq
open Sopn
open Ssralg
open Ssrbool
open Ssrfun
open Type
open Utils0
open Var0
open Word0
open Word_ssrZ
open Wsize

module E =
 struct
  (** val pass_name : string **)

  let pass_name =
    "lowering"

  (** val internal_error : string -> instr_info -> pp_error_loc **)

  let internal_error msg ii =
    pp_internal_error_s_at pass_name ii msg

  (** val user_error : pp_error -> instr_info -> pp_error_loc **)

  let user_error err ii =
    { pel_msg = err; pel_fn = None; pel_fi = None; pel_ii = (Some ii);
      pel_vi = None; pel_pass = (Some pass_name); pel_internal = false }

  (** val user_error_s : string -> instr_info -> pp_error_loc **)

  let user_error_s msg =
    user_error (PPEstring msg)

  (** val invalid_wsize : instr_info -> pp_error_loc **)

  let invalid_wsize =
    internal_error "invalid wsize"

  (** val not_implemented : instr_info -> pp_error_loc **)

  let not_implemented =
    user_error_s "not implemented"

  (** val invalid_expr : instr_info -> pp_error_loc **)

  let invalid_expr =
    user_error_s "can't lower expression"

  (** val invalid_carry_lvals : instr_info -> pp_error_loc **)

  let invalid_carry_lvals =
    user_error_s "invalid carry destination"

  (** val invalid_carry_pexprs : instr_info -> pp_error_loc **)

  let invalid_carry_pexprs =
    user_error_s "invalid carry arguments"

  (** val cant_lower_mulu : instr_info -> pp_error_loc **)

  let cant_lower_mulu =
    user_error_s "can't lower MULU"

  (** val invalid_sham : instr_info -> pexpr -> pp_error_loc **)

  let invalid_sham ii e =
    let err =
      pp_box ((PPEstring "invalid shift amount:") :: ((PPEexpr
        e) :: ((PPEstring
        ". Must be in the range [0, 31] or masked with 0x1f.") :: [])))
    in
    user_error err ii

  (** val imm_out_of_range : instr_info -> wsize -> word -> pp_error_loc **)

  let imm_out_of_range ii ws w =
    let err =
      pp_box ((PPEstring "immediate out of range:") :: ((PPEexpr
        (wconst ws w)) :: []))
    in
    user_error err ii

  (** val invalid_arguments : instr_info -> pexpr list -> pp_error_loc **)

  let invalid_arguments ii es =
    let err =
      pp_box ((PPEstring "invalid argumens") :: (map (fun x -> PPEexpr x) es))
    in
    user_error err ii
 end

type 'a lresult = 'a option cexec

(** val issue : 'a1 -> 'a1 lresult **)

let issue a =
  Ok (Some a)

(** val skip : 'a1 lresult **)

let skip =
  Ok None

(** val lassert : bool -> pp_error_loc -> unit lresult **)

let lassert b e =
  if b then issue () else Error e

type otbn_args =
  (lval list * (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extended_op) * pexpr list

type low_instr = otbn_args lresult

(** val li_sissue :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> lval
    list -> (register, empty, wide_register, rflag, condition, otbn_op,
    extra_op) extended_op -> pexpr list -> low_instr **)

let li_sissue _ lvs op es =
  issue ((lvs, op), es)

(** val li_issue :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> lval
    list -> (register, empty, wide_register, rflag, condition, otbn_op)
    asm_op_t' -> pexpr list -> low_instr **)

let li_issue atoI lvs op es =
  li_sissue atoI lvs (BaseOp (None, op)) es

(** val li_xissue :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> lval
    list -> (register, empty, wide_register, rflag, condition, otbn_op,
    extra_op) extra_op_t -> pexpr list -> low_instr **)

let li_xissue atoI lvs op es =
  li_sissue atoI lvs (ExtOp op) es

(** val li_ssimple :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op -> pexpr list -> low_instr **)

let li_ssimple atoI =
  li_sissue atoI []

(** val li_simple :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op) asm_op_t' ->
    pexpr list -> low_instr **)

let li_simple atoI =
  li_issue atoI []

type low_cmd =
  (((otbn_args list * lval list) * (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op) * pexpr list) lresult

(** val lc_sissue :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    otbn_args list -> lval list -> (register, empty, wide_register, rflag,
    condition, otbn_op, extra_op) extended_op -> pexpr list -> low_cmd **)

let lc_sissue _ pre lvs op es =
  issue (((pre, lvs), op), es)

(** val no_pre :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    low_instr -> low_cmd **)

let no_pre atoI = function
| Ok x ->
  (match x with
   | Some y ->
     let (y0, es) = y in let (lvs, op) = y0 in lc_sissue atoI [] lvs op es
   | None -> skip)
| Error s -> Error s

(** val with_pre :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    otbn_args list -> low_instr -> low_cmd **)

let with_pre atoI pre = function
| Ok x ->
  (match x with
   | Some y ->
     let (y0, es) = y in let (lvs, op) = y0 in lc_sissue atoI pre lvs op es
   | None -> skip)
| Error s -> Error s

(** val lnoneb : lval **)

let lnoneb =
  coq_Lnone_b dummy_var_info

(** val lnone_mlz : lval list **)

let lnone_mlz =
  nseq (S (S (S O))) lnoneb

(** val lnone_cmlz : lval list **)

let lnone_cmlz =
  nseq (S (S (S (S O)))) lnoneb

(** val chk_xreg_ws : instr_info -> wsize -> (pp_error_loc, unit) result **)

let chk_xreg_ws ii =
  let ws = otbn_decl.xreg_size in
  (fun ws' ->
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws')
       (Obj.magic ws)
  then Ok ()
  else Error (E.invalid_wsize ii))

(** val chk_bn_shift : instr_info -> coq_Z -> unit cexec **)

let chk_bn_shift ii z =
  if check_bn_shift z then Ok () else Error (E.invalid_sham ii (Pconst z))

(** val chk_address_displacement :
    instr_info -> wsize -> word -> unit cexec **)

let chk_address_displacement ii ws w =
  if check_nbits Signed (Coq_xO (Coq_xO (Coq_xI Coq_xH))) ws w
  then Ok ()
  else Error (E.imm_out_of_range ii ws w)

(** val check_bn_displacement : coq_Z -> bool **)

let check_bn_displacement i =
  (&&)
    (Z.leb (Zneg (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
      (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
      Coq_xH))))))))))))))) i)
    ((&&)
      (Z.leb i (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xI (Coq_xI
        (Coq_xI (Coq_xI (Coq_xI (Coq_xI (Coq_xI (Coq_xI Coq_xH)))))))))))))))
      (eq_op coq_BinNums_Z__canonical__eqtype_Equality
        (Obj.magic Z.modulo i (Zpos (Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO
          Coq_xH)))))))
        (Obj.magic Z0)))

(** val chk_bn_address_displacement :
    instr_info -> wsize -> word -> unit cexec **)

let chk_bn_address_displacement ii ws w =
  if check_bn_displacement (wsigned ws w)
  then Ok ()
  else Error (E.imm_out_of_range ii ws w)

(** val reg_shift_of_sop2 :
    instr_info -> wsize -> sop2 -> bn_register_shift lresult **)

let reg_shift_of_sop2 ii ws op =
  match chk_xreg_ws ii ws with
  | Ok _ ->
    (match op with
     | Olsr w -> (match w with
                  | U256 -> issue RS_right
                  | _ -> skip)
     | Olsl o ->
       (match o with
        | Op_int -> skip
        | Op_w w -> (match w with
                     | U256 -> issue RS_left
                     | _ -> skip))
     | _ -> skip)
  | Error s -> Error s

(** val get_arg_shift :
    instr_info -> wsize -> pexpr -> ((pexpr * bn_register_shift) * pexpr)
    lresult **)

let get_arg_shift ii ws = function
| Papp2 (op, p, p0) ->
  (match p with
   | Pvar x ->
     (match p0 with
      | Papp1 (s, p1) ->
        (match s with
         | Oword_of_int w ->
           (match w with
            | U8 ->
              (match p1 with
               | Pconst z ->
                 (match reg_shift_of_sop2 ii ws op with
                  | Ok x0 ->
                    (match x0 with
                     | Some sh ->
                       (match chk_bn_shift ii z with
                        | Ok _ ->
                          issue (((Pvar x), sh), (Papp1 ((Oword_of_int U8),
                            (Pconst z))))
                        | Error s0 -> Error s0)
                     | None -> skip)
                  | Error s0 -> Error s0)
               | _ -> skip)
            | _ -> skip)
         | _ -> skip)
      | _ -> skip)
   | _ -> skip)
| _ -> skip

(** val rsnoc : 'a1 -> 'a2 list -> ('a1, 'a2 * 'a2 list) result **)

let rsnoc e = function
| [] -> Error e
| x :: xs0 -> Ok (x, xs0)

(** val rsnoc2 : 'a1 -> 'a2 list -> ('a1, ('a2 * 'a2) * 'a2 list) result **)

let rsnoc2 e xs =
  match rsnoc e xs with
  | Ok x ->
    let (x0, xs0) = x in
    (match rsnoc e xs0 with
     | Ok x1 -> let (y, xs1) = x1 in Ok ((x0, y), xs1)
     | Error s -> Error s)
  | Error s -> Error s

(** val rsnoc3 :
    'a1 -> 'a2 list -> ('a1, (('a2 * 'a2) * 'a2) * 'a2 list) result **)

let rsnoc3 e xs =
  match rsnoc2 e xs with
  | Ok x ->
    let (y0, xs0) = x in
    (match rsnoc e xs0 with
     | Ok x0 -> let (z, xs1) = x0 in Ok ((y0, z), xs1)
     | Error s -> Error s)
  | Error s -> Error s

(** val lower_basic_shift :
    instr_info -> bn_basic_mnemonic -> pexpr list ->
    (bn_register_shift * pexpr list) lresult **)

let lower_basic_shift ii mn es =
  let err = E.invalid_arguments ii es in
  (match mn with
   | BN_ADD ->
     (match rsnoc2 err es with
      | Ok x ->
        let (y0, rest) = x in
        let (x0, y) = y0 in
        let x1 = (((x0 :: []), y), rest) in
        let (y1, pos) = x1 in
        let (pre, e) = y1 in
        (match get_arg_shift ii otbn_decl.xreg_size e with
         | Ok x2 ->
           (match x2 with
            | Some y2 ->
              let (y3, esham) = y2 in
              let (ebase, sh) = y3 in
              issue (sh, (cat pre (ebase :: (cat pos (esham :: [])))))
            | None -> skip)
         | Error s -> Error s)
      | Error s -> Error s)
   | BN_ADDC ->
     (match rsnoc3 err es with
      | Ok x ->
        let (y0, rest) = x in
        let (y1, cf) = y0 in
        let (x0, y) = y1 in
        let x1 = (((x0 :: []), y), (cf :: rest)) in
        let (y2, pos) = x1 in
        let (pre, e) = y2 in
        (match get_arg_shift ii otbn_decl.xreg_size e with
         | Ok x2 ->
           (match x2 with
            | Some y3 ->
              let (y4, esham) = y3 in
              let (ebase, sh) = y4 in
              issue (sh, (cat pre (ebase :: (cat pos (esham :: [])))))
            | None -> skip)
         | Error s -> Error s)
      | Error s -> Error s)
   | BN_SUBB ->
     (match rsnoc3 err es with
      | Ok x ->
        let (y0, rest) = x in
        let (y1, cf) = y0 in
        let (x0, y) = y1 in
        let x1 = (((x0 :: []), y), (cf :: rest)) in
        let (y2, pos) = x1 in
        let (pre, e) = y2 in
        (match get_arg_shift ii otbn_decl.xreg_size e with
         | Ok x2 ->
           (match x2 with
            | Some y3 ->
              let (y4, esham) = y3 in
              let (ebase, sh) = y4 in
              issue (sh, (cat pre (ebase :: (cat pos (esham :: [])))))
            | None -> skip)
         | Error s -> Error s)
      | Error s -> Error s)
   | BN_NOT ->
     (match rsnoc err es with
      | Ok x ->
        let (x0, rest) = x in
        let x1 = (([], x0), rest) in
        let (y, pos) = x1 in
        let (pre, e) = y in
        (match get_arg_shift ii otbn_decl.xreg_size e with
         | Ok x2 ->
           (match x2 with
            | Some y0 ->
              let (y1, esham) = y0 in
              let (ebase, sh) = y1 in
              issue (sh, (cat pre (ebase :: (cat pos (esham :: [])))))
            | None -> skip)
         | Error s -> Error s)
      | Error s -> Error s)
   | _ ->
     (match rsnoc2 err es with
      | Ok x ->
        let (y0, rest) = x in
        let (x0, y) = y0 in
        let x1 = (((x0 :: []), y), rest) in
        let (y1, pos) = x1 in
        let (pre, e) = y1 in
        (match get_arg_shift ii otbn_decl.xreg_size e with
         | Ok x2 ->
           (match x2 with
            | Some y2 ->
              let (y3, esham) = y2 in
              let (ebase, sh) = y3 in
              issue (sh, (cat pre (ebase :: (cat pos (esham :: [])))))
            | None -> skip)
         | Error s -> Error s)
      | Error s -> Error s))

(** val lower_base_op :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> lval list -> otbn_op -> pexpr list -> low_instr **)

let lower_base_op atoI ii lvs op es =
  match op with
  | RV32 _ -> li_issue atoI lvs op es
  | BN_basic (mn, fg) ->
    (match lower_basic_shift ii mn es with
     | Ok x ->
       (match x with
        | Some y ->
          let (sh, es') = y in
          li_issue atoI lvs (BN_basic_shift (mn, fg, sh)) es'
        | None -> skip)
     | Error s -> Error s)
  | _ -> skip

(** val get_carry_lvals : instr_info -> lval list -> lval list cexec **)

let get_carry_lvals ii lvs =
  match rsnoc2 (E.invalid_carry_lvals ii) lvs with
  | Ok x ->
    let (y, _) = x in
    let (cf, r) = y in
    Ok (cf :: (lnoneb :: (lnoneb :: (lnoneb :: (r :: [])))))
  | Error s -> Error s

(** val get_carry_pexprs :
    instr_info -> pexpr list -> (bool * pexpr list) cexec **)

let get_carry_pexprs ii es =
  match rsnoc3 (E.invalid_carry_pexprs ii) es with
  | Ok x ->
    let (y, _) = x in
    let (y1, cf) = y in
    let (e0, e1) = y1 in
    (match cf with
     | Pbool b ->
       if b
       then Error (E.invalid_carry_pexprs ii)
       else Ok (false, (e0 :: (e1 :: [])))
     | Pvar _ -> Ok (true, (e0 :: (e1 :: (cf :: []))))
     | _ -> Error (E.invalid_carry_pexprs ii))
  | Error s -> Error s

(** val carry_op : bool -> bool -> bn_basic_mnemonic **)

let carry_op is_add has_carry =
  if is_add
  then if has_carry then BN_ADDC else BN_ADD
  else if has_carry then BN_SUBB else BN_SUB

(** val lower_carry_op :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> bool -> wsize -> lval list -> pexpr list -> low_instr **)

let lower_carry_op atoI ii is_add sz lvs es =
  match chk_xreg_ws ii sz with
  | Ok _ ->
    (match get_carry_lvals ii lvs with
     | Ok x ->
       (match get_carry_pexprs ii es with
        | Ok x0 ->
          let (has_carry, es') = x0 in
          let op = carry_op is_add has_carry in
          li_issue atoI x (BN_basic (op, FG1)) es'
        | Error s -> Error s)
     | Error s -> Error s)
  | Error s -> Error s

(** val lower_swap :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> atype -> lval list -> pexpr list -> low_instr **)

let lower_swap atoI ii ty lvs es =
  match ty with
  | Coq_aword sz ->
    if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic sz)
         (Obj.magic otbn_decl.reg_size)
    then let x = Some lvs in
         (match x with
          | Some lvs0 -> li_xissue atoI lvs0 (SWAP sz) es
          | None -> skip)
    else if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic sz)
              (Obj.magic otbn_decl.xreg_size)
         then let x = Some (cat lnone_mlz lvs) in
              (match x with
               | Some lvs0 -> li_xissue atoI lvs0 (SWAP sz) es
               | None -> skip)
         else let s = E.not_implemented ii in Error s
  | _ -> skip

(** val lower_pseudo_operator :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> lval list -> pseudo_operator -> pexpr list -> low_instr **)

let lower_pseudo_operator atoI ii lvs op es =
  match match op with
        | Omulu _ -> Error (E.cant_lower_mulu ii)
        | Oaddcarry sz -> lower_carry_op atoI ii true sz lvs es
        | Osubcarry sz -> lower_carry_op atoI ii false sz lvs es
        | Oswap ty -> lower_swap atoI ii ty lvs es
        | _ -> skip with
  | Ok x ->
    (match x with
     | Some y ->
       let (y0, es') = y in
       let (lvs', op') = y0 in li_sissue atoI lvs' op' es'
     | None -> skip)
  | Error s -> Error s

(** val lower_copn :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> lval list -> (register, empty, wide_register, rflag,
    condition, otbn_op, extra_op) extended_op sopn -> pexpr list -> low_instr **)

let lower_copn atoI ii lvs op es =
  match op with
  | Opseudo_op pop -> lower_pseudo_operator atoI ii lvs pop es
  | Oslh _ -> skip
  | Oasm a ->
    (match a with
     | BaseOp a0 ->
       let (o, op0) = a0 in
       (match o with
        | Some _ -> skip
        | None -> lower_base_op atoI ii lvs op0 es)
     | ExtOp _ -> skip)

(** val lower_condition :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> pexpr -> (otbn_args list * pexpr) cexec **)

let lower_condition _ ii econd = match econd with
| Pvar _ -> Ok ([], econd)
| _ -> Error (E.not_implemented ii)

(** val lower_Pvar :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> wsize
    -> gvar -> low_instr **)

let lower_Pvar atoI ws v =
  match if is_var_in_memory v.gv.v_var
        then if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
                  (Obj.magic otbn_decl.reg_size)
             then issue (BaseOp (None, (RV32 LW)))
             else if eq_op wsize_wsize__canonical__eqtype_Equality
                       (Obj.magic ws) (Obj.magic otbn_decl.xreg_size)
                  then issue (BaseOp (None, BN_LD))
                  else skip
        else if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
                  (Obj.magic otbn_decl.reg_size)
             then issue (ExtOp MOV)
             else if eq_op wsize_wsize__canonical__eqtype_Equality
                       (Obj.magic ws) (Obj.magic otbn_decl.xreg_size)
                  then issue (BaseOp (None, BN_MOV))
                  else skip with
  | Ok x ->
    (match x with
     | Some op -> li_ssimple atoI op ((Pvar v) :: [])
     | None -> skip)
  | Error s -> Error s

(** val get_mem_disp :
    pexpr -> (register, empty, wide_register, rflag, condition) wreg option **)

let get_mem_disp = function
| Pget (_, _, ws, _, e') ->
  (match is_const e' with
   | Some z ->
     Some (Obj.magic wrepr otbn_decl.reg_size (Z.mul z (wsize_size ws)))
   | None -> None)
| Pload (_, _, e0) -> Obj.magic is_wconst otbn_decl.reg_size e0
| _ -> None

(** val lower_load :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> pexpr -> low_instr **)

let lower_load atoI ii ws e =
  match if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
             (Obj.magic otbn_decl.reg_size)
        then (match match get_mem_disp e with
                    | Some wdisp ->
                      chk_address_displacement ii otbn_decl.reg_size
                        (Obj.magic wdisp)
                    | None -> Ok () with
              | Ok _ -> issue (RV32 LW)
              | Error s -> Error s)
        else if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
                  (Obj.magic otbn_decl.xreg_size)
             then (match match get_mem_disp e with
                         | Some wdisp ->
                           chk_bn_address_displacement ii otbn_decl.reg_size
                             (Obj.magic wdisp)
                         | None -> Ok () with
                   | Ok _ -> issue BN_LD
                   | Error s -> Error s)
             else skip with
  | Ok x ->
    (match x with
     | Some op -> li_simple atoI op (e :: [])
     | None -> skip)
  | Error s -> Error s

(** val lower_Papp1 :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> sop1 -> pexpr -> low_instr **)

let lower_Papp1 atoI ii ws op e =
  match op with
  | Oword_of_int _ ->
    if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
         (Obj.magic otbn_decl.reg_size)
    then li_simple atoI (RV32 LI) ((Papp1 (op, e)) :: [])
    else skip
  | Olnot _ ->
    if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
         (Obj.magic otbn_decl.xreg_size)
    then li_issue atoI lnone_mlz (BN_basic (BN_NOT, FG1)) (e :: [])
    else if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
              (Obj.magic otbn_decl.reg_size)
         then li_xissue atoI [] NOT (e :: [])
         else skip
  | Oneg o ->
    (match o with
     | Op_int -> Error (E.not_implemented ii)
     | Op_w _ ->
       if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
            (Obj.magic otbn_decl.reg_size)
       then li_simple atoI (RV32 NEG) (e :: [])
       else skip)
  | _ -> Error (E.not_implemented ii)

(** val rv_expected_Imn_size : sop2 -> wsize option **)

let rv_expected_Imn_size = function
| Oadd _ -> Some U32
| Osub _ -> Some U32
| Oland _ -> Some U32
| Olor _ -> Some U32
| Olxor _ -> Some U32
| _ -> None

(** val rv_Imn_of_op2 :
    instr_info -> sop2 -> wsize -> word -> pexpr -> (rv_mnemonic * pexpr)
    lresult **)

let rv_Imn_of_op2 ii op ws w e =
  let mk = fun mn ->
    match lassert (is_arith_small (wsigned ws w)) (E.imm_out_of_range ii ws w) with
    | Ok x -> (match x with
               | Some _ -> issue (mn, e)
               | None -> skip)
    | Error s -> Error s
  in
  (match op with
   | Oadd o -> (match o with
                | Op_int -> skip
                | Op_w _ -> mk ADDI)
   | Osub o ->
     (match o with
      | Op_int -> skip
      | Op_w _ ->
        (match lassert
                 (is_arith_small
                   (wsigned ws
                     (Obj.magic GRing.opp
                       (word_word__canonical__GRing_Zmodule ws) w)))
                 (E.imm_out_of_range ii ws w) with
         | Ok x ->
           (match x with
            | Some _ ->
              (match insert_minus e with
               | Some e' -> issue (ADDI, e')
               | None -> Error (E.invalid_expr ii))
            | None -> skip)
         | Error s -> Error s))
   | Oland _ -> mk ANDI
   | Olor _ -> mk ORI
   | Olxor _ -> mk XORI
   | _ -> skip)

(** val rv_mn_of_op2 : sop2 -> pexpr -> (rv_mnemonic * pexpr) lresult **)

let rv_mn_of_op2 op e =
  let mk = fun mn -> issue (mn, e) in
  (match op with
   | Oadd o -> (match o with
                | Op_int -> skip
                | Op_w _ -> mk ADD)
   | Osub o -> (match o with
                | Op_int -> skip
                | Op_w _ -> mk SUB)
   | Oland _ -> mk AND
   | Olor _ -> mk OR
   | Olxor _ -> mk XOR
   | _ -> skip)

(** val check_shift_amount : pexpr -> pexpr option **)

let check_shift_amount e =
  let mask = wrepr U8 (Zpos (Coq_xI (Coq_xI (Coq_xI (Coq_xI Coq_xH))))) in
  (match is_wconst U8 e with
   | Some n ->
     (match oassert
              (eq_op (word_word__canonical__eqtype_Equality U8) (Obj.magic n)
                (Obj.magic wand U8 n mask)) with
      | Some _ -> Some e
      | None -> None)
   | None ->
     (match e with
      | Papp2 (s, a, b) ->
        (match s with
         | Oland _ ->
           (match is_wconst U8 b with
            | Some n ->
              (match oassert
                       (eq_op (word_word__canonical__eqtype_Equality U8)
                         (Obj.magic n) (Obj.magic mask)) with
               | Some _ -> Some a
               | None -> None)
            | None -> None)
         | _ -> None)
      | _ -> None))

(** val lower_shift :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> rv_mnemonic -> rv_mnemonic -> pexpr -> pexpr -> low_instr **)

let lower_shift atoI ii mn_imm mn_reg e0 e1 =
  match check_shift_amount e1 with
  | Some e1' ->
    let mn = if isSome (is_wconst U8 e1') then mn_imm else mn_reg in
    li_simple atoI (RV32 mn) (e0 :: (e1' :: []))
  | None -> Error (E.invalid_sham ii e1)

(** val lower_Papp2_small :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> sop2 -> pexpr -> pexpr -> low_instr **)

let lower_Papp2_small atoI ii _ op e0 e1 =
  match op with
  | Olsr w ->
    (match w with
     | U32 -> lower_shift atoI ii SRLI SRL e0 e1
     | _ ->
       (match match rv_expected_Imn_size op with
              | Some ws ->
                (match is_wconst ws e1 with
                 | Some w0 -> rv_Imn_of_op2 ii op ws w0 e1
                 | None -> rv_mn_of_op2 op e1)
              | None -> rv_mn_of_op2 op e1 with
        | Ok x ->
          (match x with
           | Some y ->
             let (op0, e1') = y in
             li_simple atoI (RV32 op0) (e0 :: (e1' :: []))
           | None -> skip)
        | Error s -> Error s))
  | Olsl o ->
    (match o with
     | Op_int ->
       (match match rv_expected_Imn_size op with
              | Some ws ->
                (match is_wconst ws e1 with
                 | Some w -> rv_Imn_of_op2 ii op ws w e1
                 | None -> rv_mn_of_op2 op e1)
              | None -> rv_mn_of_op2 op e1 with
        | Ok x ->
          (match x with
           | Some y ->
             let (op0, e1') = y in
             li_simple atoI (RV32 op0) (e0 :: (e1' :: []))
           | None -> skip)
        | Error s -> Error s)
     | Op_w _ -> lower_shift atoI ii SLLI SLL e0 e1)
  | Oasr o ->
    (match o with
     | Op_int ->
       (match match rv_expected_Imn_size op with
              | Some ws ->
                (match is_wconst ws e1 with
                 | Some w -> rv_Imn_of_op2 ii op ws w e1
                 | None -> rv_mn_of_op2 op e1)
              | None -> rv_mn_of_op2 op e1 with
        | Ok x ->
          (match x with
           | Some y ->
             let (op0, e1') = y in
             li_simple atoI (RV32 op0) (e0 :: (e1' :: []))
           | None -> skip)
        | Error s -> Error s)
     | Op_w w ->
       (match w with
        | U32 -> lower_shift atoI ii SRAI SRA e0 e1
        | _ ->
          (match match rv_expected_Imn_size op with
                 | Some ws ->
                   (match is_wconst ws e1 with
                    | Some w0 -> rv_Imn_of_op2 ii op ws w0 e1
                    | None -> rv_mn_of_op2 op e1)
                 | None -> rv_mn_of_op2 op e1 with
           | Ok x ->
             (match x with
              | Some y ->
                let (op0, e1') = y in
                li_simple atoI (RV32 op0) (e0 :: (e1' :: []))
              | None -> skip)
           | Error s -> Error s)))
  | _ ->
    (match match rv_expected_Imn_size op with
           | Some ws ->
             (match is_wconst ws e1 with
              | Some w -> rv_Imn_of_op2 ii op ws w e1
              | None -> rv_mn_of_op2 op e1)
           | None -> rv_mn_of_op2 op e1 with
     | Ok x ->
       (match x with
        | Some y ->
          let (op0, e1') = y in li_simple atoI (RV32 op0) (e0 :: (e1' :: []))
        | None -> skip)
     | Error s -> Error s)

(** val otbn_Iop_of_op2 :
    sop2 -> bn_flag_group -> (lval list * otbn_op) lresult **)

let otbn_Iop_of_op2 op fg =
  match op with
  | Oadd o ->
    (match o with
     | Op_int -> skip
     | Op_w _ -> issue (lnone_cmlz, (BN_ADDI fg)))
  | Osub o ->
    (match o with
     | Op_int -> skip
     | Op_w _ -> issue (lnone_cmlz, (BN_SUBI fg)))
  | _ -> skip

(** val otbn_op_of_op2 :
    sop2 -> bn_flag_group -> (lval list * otbn_op) lresult **)

let otbn_op_of_op2 op fg =
  let mk = fun mn -> BN_basic (mn, fg) in
  (match op with
   | Oadd o ->
     (match o with
      | Op_int -> skip
      | Op_w _ -> issue (lnone_cmlz, (mk BN_ADD)))
   | Osub o ->
     (match o with
      | Op_int -> skip
      | Op_w _ -> issue (lnone_cmlz, (mk BN_SUB)))
   | Oland _ -> issue (lnone_mlz, (mk BN_AND))
   | Olor _ -> issue (lnone_mlz, (mk BN_OR))
   | Olxor _ -> issue (lnone_mlz, (mk BN_XOR))
   | _ -> skip)

(** val lower_Papp2_large :
    (register, empty, wide_register, rflag, condition) arch_toIdent -> wsize
    -> sop2 -> pexpr -> pexpr -> low_instr **)

let lower_Papp2_large atoI ws op e0 e1 =
  match if isSome (is_wconst ws e1)
        then otbn_Iop_of_op2 op FG0
        else otbn_op_of_op2 op FG0 with
  | Ok x ->
    (match x with
     | Some y ->
       let (lvs, op0) = y in li_issue atoI lvs op0 (e0 :: (e1 :: []))
     | None -> skip)
  | Error s -> Error s

(** val lower_Papp2 :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> sop2 -> pexpr -> pexpr -> low_instr **)

let lower_Papp2 atoI ii ws op e0 e1 =
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
       (Obj.magic otbn_decl.reg_size)
  then lower_Papp2_small atoI ii ws op e0 e1
  else if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
            (Obj.magic otbn_decl.xreg_size)
       then lower_Papp2_large atoI ws op e0 e1
       else Error (E.invalid_wsize ii)

(** val lower_pexpr_aux :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> pexpr -> low_instr **)

let lower_pexpr_aux atoI ii ws e = match e with
| Pvar v -> lower_Pvar atoI ws v
| Pget (_, _, _, _, _) -> lower_load atoI ii ws e
| Pload (_, _, _) -> lower_load atoI ii ws e
| Papp1 (op, e0) -> lower_Papp1 atoI ii ws op e0
| Papp2 (op, a, b) -> lower_Papp2 atoI ii ws op a b
| _ -> skip

(** val lower_Pif :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> pexpr -> pexpr -> pexpr -> low_instr **)

let lower_Pif atoI ii ws econd e0 e1 =
  match chk_xreg_ws ii ws with
  | Ok _ -> li_simple atoI (BN_SEL FG0) (e0 :: (e1 :: (econd :: [])))
  | Error s -> Error s

(** val lower_pexpr :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> pexpr -> low_cmd **)

let lower_pexpr atoI ii ws e = match e with
| Pif (a, econd, e0, e1) ->
  (match a with
   | Coq_aword ws' ->
     if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
          (Obj.magic ws')
     then (match lower_condition atoI ii econd with
           | Ok x ->
             let (pre, econd') = x in
             with_pre atoI pre (lower_Pif atoI ii ws econd' e0 e1)
           | Error s -> Error s)
     else let s = E.invalid_wsize ii in Error s
   | _ -> no_pre atoI (lower_pexpr_aux atoI ii ws e))
| _ -> no_pre atoI (lower_pexpr_aux atoI ii ws e)

(** val destruct_Lmem :
    pexpr -> (var_i * (register, empty, wide_register, rflag, condition)
    wreg) option **)

let destruct_Lmem e = match e with
| Papp2 (s, p, _) ->
  (match s with
   | Oadd _ ->
     (match p with
      | Pvar x ->
        (match is_wconst otbn_decl.reg_size e with
         | Some w -> Some (x.gv, (Obj.magic w))
         | None -> None)
      | _ -> None)
   | Osub _ ->
     (match p with
      | Pvar x ->
        (match is_wconst otbn_decl.reg_size e with
         | Some w -> Some (x.gv, (Obj.magic w))
         | None -> None)
      | _ -> None)
   | _ -> None)
| _ -> None

(** val get_lval_memory_access :
    lval -> (var_i * (register, empty, wide_register, rflag, condition) wreg)
    option **)

let get_lval_memory_access = function
| Lvar x ->
  Some (x,
    (GRing.zero (word_word__canonical__GRing_Nmodule otbn_decl.reg_size)))
| Lmem (_, _, _, e) -> destruct_Lmem e
| Laset (_, _, ws, x, e) ->
  (match is_const e with
   | Some z ->
     Some (x, (Obj.magic wrepr otbn_decl.reg_size (Z.mul z (wsize_size ws))))
   | None -> None)
| _ -> None

(** val lower_store :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> wsize -> pexpr -> low_instr **)

let lower_store atoI ii ws e =
  if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
       (Obj.magic otbn_decl.reg_size)
  then li_simple atoI (RV32 SW) (e :: [])
  else if eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic ws)
            (Obj.magic otbn_decl.xreg_size)
       then li_simple atoI BN_SD (e :: [])
       else Error (E.invalid_wsize ii)

(** val chk_lower_store : instr_info -> wsize -> lval -> unit cexec **)

let chk_lower_store ii ws lv =
  match get_lval_memory_access lv with
  | Some p ->
    let (_, wdisp) = p in
    if cmp_le wsize_cmp ws otbn_decl.reg_size
    then chk_address_displacement ii otbn_decl.reg_size (Obj.magic wdisp)
    else chk_bn_address_displacement ii otbn_decl.reg_size (Obj.magic wdisp)
  | None -> Ok ()

(** val lower_cassgn_word :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    instr_info -> lval -> wsize -> pexpr -> low_cmd **)

let lower_cassgn_word atoI ii lv ws e =
  match if is_lval_in_memory lv
        then (match chk_lower_store ii ws lv with
              | Ok _ -> no_pre atoI (lower_store atoI ii ws e)
              | Error s -> Error s)
        else lower_pexpr atoI ii ws e with
  | Ok x ->
    (match x with
     | Some y ->
       let (y0, es) = y in
       let (y1, op) = y0 in
       let (pre, lvs) = y1 in issue (((pre, (cat lvs (lv :: []))), op), es)
     | None -> skip)
  | Error s -> Error s

(** val lower_i :
    (register, empty, wide_register, rflag, condition) arch_toIdent ->
    (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
    extended_op instr -> (register, empty, wide_register, rflag, condition,
    otbn_op, extra_op) extended_op instr list cexec **)

let lower_i atoI =
  let i_of_low_instr = fun ii tag pat ->
    let (y, es) = pat in
    let (lvs, op) = y in
    MkI (ii,
    (instr_of_copn_args (asm_opI (otbn_extra atoI)) tag ((lvs, (Oasm op)),
      es)))
  in
  let c_of_low_cmd = fun ii tag pat ->
    let (y, es) = pat in
    let (y0, op) = y in
    let (pre, lvs) = y0 in
    map (i_of_low_instr ii tag) (rcons pre ((lvs, op), es))
  in
  let rec lower_i0 i = match i with
  | MkI (ii, ir) ->
    (match ir with
     | Cassgn (lv, tag, ty, e) ->
       (match OtherDefs.is_word_type ty with
        | Some ws ->
          (match lower_cassgn_word atoI ii lv ws e with
           | Ok x -> Ok (Option.apply (c_of_low_cmd ii tag) (i :: []) x)
           | Error s -> Error s)
        | None -> Ok (i :: []))
     | Copn (lvs, tag, op, es) ->
       (match lower_copn atoI ii lvs op es with
        | Ok x -> Ok ((Option.apply (i_of_low_instr ii tag) i x) :: [])
        | Error s -> Error s)
     | Cif (e, c1, c2) ->
       (match conc_mapM lower_i0 c1 with
        | Ok x ->
          (match conc_mapM lower_i0 c2 with
           | Ok x0 -> Ok ((MkI (ii, (Cif (e, x, x0)))) :: [])
           | Error s -> Error s)
        | Error s -> Error s)
     | Cfor (fi, c) ->
       (match conc_mapM lower_i0 c with
        | Ok x -> Ok ((MkI (ii, (Cfor (fi, x)))) :: [])
        | Error s -> Error s)
     | Cwhile (a, c0, e, ii0, c1) ->
       (match conc_mapM lower_i0 c0 with
        | Ok x ->
          (match conc_mapM lower_i0 c1 with
           | Ok x0 -> Ok ((MkI (ii0, (Cwhile (a, x, e, ii0, x0)))) :: [])
           | Error s -> Error s)
        | Error s -> Error s)
     | _ -> Ok (i :: []))
  in lower_i0
