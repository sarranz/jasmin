(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Decimal

module NilEmpty :
 sig
  val string_of_uint : uint -> string
 end

module NilZero :
 sig
  val string_of_uint : uint -> string

  val string_of_int : signed_int -> string
 end
