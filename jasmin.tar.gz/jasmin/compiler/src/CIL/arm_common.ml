(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Datatypes
open Arch_decl
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Flag_combination
open Utils0

type __ = Obj.t

type rflag =
| NF
| ZF
| CF
| VF

(** val rflag_rect : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1 **)

let rflag_rect f f0 f1 f2 = function
| NF -> f
| ZF -> f0
| CF -> f1
| VF -> f2

(** val rflag_rec : 'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> 'a1 **)

let rflag_rec f f0 f1 f2 = function
| NF -> f
| ZF -> f0
| CF -> f1
| VF -> f2

type is_rflag =
| Coq_is_NF
| Coq_is_ZF
| Coq_is_CF
| Coq_is_VF

(** val is_rflag_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1 **)

let is_rflag_rect f f0 f1 f2 _ = function
| Coq_is_NF -> f
| Coq_is_ZF -> f0
| Coq_is_CF -> f1
| Coq_is_VF -> f2

(** val is_rflag_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1 **)

let is_rflag_rec f f0 f1 f2 _ = function
| Coq_is_NF -> f
| Coq_is_ZF -> f0
| Coq_is_CF -> f1
| Coq_is_VF -> f2

(** val rflag_tag : rflag -> positive **)

let rflag_tag = function
| NF -> Coq_xH
| ZF -> Coq_xO Coq_xH
| CF -> Coq_xI Coq_xH
| VF -> Coq_xO (Coq_xO Coq_xH)

(** val is_rflag_inhab : rflag -> is_rflag **)

let is_rflag_inhab = function
| NF -> Coq_is_NF
| ZF -> Coq_is_ZF
| CF -> Coq_is_CF
| VF -> Coq_is_VF

(** val is_rflag_functor : rflag -> is_rflag -> is_rflag **)

let rec is_rflag_functor _ x =
  x

type box_rflag_NF =
| Box_rflag_NF

type rflag_fields_t = __

(** val rflag_fields : rflag -> rflag_fields_t **)

let rflag_fields _ =
  Obj.magic Box_rflag_NF

(** val rflag_construct : positive -> rflag_fields_t -> rflag option **)

let rflag_construct p _ =
  match p with
  | Coq_xI _ -> Some CF
  | Coq_xO x ->
    (match x with
     | Coq_xI _ -> None
     | Coq_xO _ -> Some VF
     | Coq_xH -> Some ZF)
  | Coq_xH -> Some NF

(** val rflag_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> rflag -> is_rflag -> 'a1 **)

let rflag_induction his_NF his_ZF his_CF his_VF _ = function
| Coq_is_NF -> his_NF
| Coq_is_ZF -> his_ZF
| Coq_is_CF -> his_CF
| Coq_is_VF -> his_VF

(** val rflag_eqb_fields :
    (rflag -> rflag -> bool) -> positive -> rflag_fields_t -> rflag_fields_t
    -> bool **)

let rflag_eqb_fields _ _ _ _ =
  true

(** val rflag_eqb : rflag -> rflag -> bool **)

let rflag_eqb x1 x2 =
  eqb_body rflag_tag rflag_fields
    (Obj.magic rflag_eqb_fields (fun _ _ -> true)) (rflag_tag x1)
    Box_rflag_NF x2

(** val rflag_eqb_OK : rflag -> rflag -> reflect **)

let rflag_eqb_OK =
  iffP2 rflag_eqb

(** val rflag_eqb_OK_sumbool : rflag -> rflag -> bool **)

let rflag_eqb_OK_sumbool =
  reflect_dec rflag_eqb rflag_eqb_OK

(** val eqTC_rflag : rflag eqTypeC **)

let eqTC_rflag =
  { beq = rflag_eqb; ceqP = rflag_eqb_OK }

(** val rflag_eqType : Equality.coq_type **)

let rflag_eqType =
  ceqT_eqType eqTC_rflag

(** val rflags : rflag list **)

let rflags =
  NF :: (ZF :: (CF :: (VF :: [])))

(** val finTC_rflag : rflag finTypeC **)

let finTC_rflag =
  { _eqC = eqTC_rflag; cenum = rflags }

(** val rflag_finType : Finite.coq_type **)

let rflag_finType =
  cfinT_finType finTC_rflag

(** val flag_to_string : rflag -> string **)

let flag_to_string = function
| NF -> "NF"
| ZF -> "ZF"
| CF -> "CF"
| VF -> "VF"

(** val rflag_toS : rflag coq_ToString **)

let rflag_toS =
  { category = "rflag"; _finC = finTC_rflag; to_string = flag_to_string }

type condt =
| EQ_ct
| NE_ct
| CS_ct
| CC_ct
| MI_ct
| PL_ct
| VS_ct
| VC_ct
| HI_ct
| LS_ct
| GE_ct
| LT_ct
| GT_ct
| LE_ct

(** val condt_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> 'a1 **)

let condt_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 = function
| EQ_ct -> f
| NE_ct -> f0
| CS_ct -> f1
| CC_ct -> f2
| MI_ct -> f3
| PL_ct -> f4
| VS_ct -> f5
| VC_ct -> f6
| HI_ct -> f7
| LS_ct -> f8
| GE_ct -> f9
| LT_ct -> f10
| GT_ct -> f11
| LE_ct -> f12

(** val condt_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> 'a1 **)

let condt_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 = function
| EQ_ct -> f
| NE_ct -> f0
| CS_ct -> f1
| CC_ct -> f2
| MI_ct -> f3
| PL_ct -> f4
| VS_ct -> f5
| VC_ct -> f6
| HI_ct -> f7
| LS_ct -> f8
| GE_ct -> f9
| LT_ct -> f10
| GT_ct -> f11
| LE_ct -> f12

type is_condt =
| Coq_is_EQ_ct
| Coq_is_NE_ct
| Coq_is_CS_ct
| Coq_is_CC_ct
| Coq_is_MI_ct
| Coq_is_PL_ct
| Coq_is_VS_ct
| Coq_is_VC_ct
| Coq_is_HI_ct
| Coq_is_LS_ct
| Coq_is_GE_ct
| Coq_is_LT_ct
| Coq_is_GT_ct
| Coq_is_LE_ct

(** val is_condt_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1 **)

let is_condt_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 _ = function
| Coq_is_EQ_ct -> f
| Coq_is_NE_ct -> f0
| Coq_is_CS_ct -> f1
| Coq_is_CC_ct -> f2
| Coq_is_MI_ct -> f3
| Coq_is_PL_ct -> f4
| Coq_is_VS_ct -> f5
| Coq_is_VC_ct -> f6
| Coq_is_HI_ct -> f7
| Coq_is_LS_ct -> f8
| Coq_is_GE_ct -> f9
| Coq_is_LT_ct -> f10
| Coq_is_GT_ct -> f11
| Coq_is_LE_ct -> f12

(** val is_condt_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1 **)

let is_condt_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 _ = function
| Coq_is_EQ_ct -> f
| Coq_is_NE_ct -> f0
| Coq_is_CS_ct -> f1
| Coq_is_CC_ct -> f2
| Coq_is_MI_ct -> f3
| Coq_is_PL_ct -> f4
| Coq_is_VS_ct -> f5
| Coq_is_VC_ct -> f6
| Coq_is_HI_ct -> f7
| Coq_is_LS_ct -> f8
| Coq_is_GE_ct -> f9
| Coq_is_LT_ct -> f10
| Coq_is_GT_ct -> f11
| Coq_is_LE_ct -> f12

(** val condt_tag : condt -> positive **)

let condt_tag = function
| EQ_ct -> Coq_xH
| NE_ct -> Coq_xO Coq_xH
| CS_ct -> Coq_xI Coq_xH
| CC_ct -> Coq_xO (Coq_xO Coq_xH)
| MI_ct -> Coq_xI (Coq_xO Coq_xH)
| PL_ct -> Coq_xO (Coq_xI Coq_xH)
| VS_ct -> Coq_xI (Coq_xI Coq_xH)
| VC_ct -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| HI_ct -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| LS_ct -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| GE_ct -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| LT_ct -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| GT_ct -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| LE_ct -> Coq_xO (Coq_xI (Coq_xI Coq_xH))

(** val is_condt_inhab : condt -> is_condt **)

let is_condt_inhab = function
| EQ_ct -> Coq_is_EQ_ct
| NE_ct -> Coq_is_NE_ct
| CS_ct -> Coq_is_CS_ct
| CC_ct -> Coq_is_CC_ct
| MI_ct -> Coq_is_MI_ct
| PL_ct -> Coq_is_PL_ct
| VS_ct -> Coq_is_VS_ct
| VC_ct -> Coq_is_VC_ct
| HI_ct -> Coq_is_HI_ct
| LS_ct -> Coq_is_LS_ct
| GE_ct -> Coq_is_GE_ct
| LT_ct -> Coq_is_LT_ct
| GT_ct -> Coq_is_GT_ct
| LE_ct -> Coq_is_LE_ct

(** val is_condt_functor : condt -> is_condt -> is_condt **)

let rec is_condt_functor _ x =
  x

type box_condt_EQ_ct =
| Box_condt_EQ_ct

type condt_fields_t = __

(** val condt_fields : condt -> condt_fields_t **)

let condt_fields _ =
  Obj.magic Box_condt_EQ_ct

(** val condt_construct : positive -> condt_fields_t -> condt option **)

let condt_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> None
        | Coq_xO _ -> Some GE_ct
        | Coq_xH -> Some VS_ct)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> Some GT_ct
        | Coq_xO _ -> Some HI_ct
        | Coq_xH -> Some MI_ct)
     | Coq_xH -> Some CS_ct)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI _ -> Some LE_ct
        | Coq_xO _ -> Some LS_ct
        | Coq_xH -> Some PL_ct)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI _ -> Some LT_ct
        | Coq_xO _ -> Some VC_ct
        | Coq_xH -> Some CC_ct)
     | Coq_xH -> Some NE_ct)
  | Coq_xH -> Some EQ_ct

(** val condt_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> condt -> is_condt -> 'a1 **)

let condt_induction his_EQ_ct his_NE_ct his_CS_ct his_CC_ct his_MI_ct his_PL_ct his_VS_ct his_VC_ct his_HI_ct his_LS_ct his_GE_ct his_LT_ct his_GT_ct his_LE_ct _ = function
| Coq_is_EQ_ct -> his_EQ_ct
| Coq_is_NE_ct -> his_NE_ct
| Coq_is_CS_ct -> his_CS_ct
| Coq_is_CC_ct -> his_CC_ct
| Coq_is_MI_ct -> his_MI_ct
| Coq_is_PL_ct -> his_PL_ct
| Coq_is_VS_ct -> his_VS_ct
| Coq_is_VC_ct -> his_VC_ct
| Coq_is_HI_ct -> his_HI_ct
| Coq_is_LS_ct -> his_LS_ct
| Coq_is_GE_ct -> his_GE_ct
| Coq_is_LT_ct -> his_LT_ct
| Coq_is_GT_ct -> his_GT_ct
| Coq_is_LE_ct -> his_LE_ct

(** val condt_eqb_fields :
    (condt -> condt -> bool) -> positive -> condt_fields_t -> condt_fields_t
    -> bool **)

let condt_eqb_fields _ _ _ _ =
  true

(** val condt_eqb : condt -> condt -> bool **)

let condt_eqb x1 x2 =
  eqb_body condt_tag condt_fields
    (Obj.magic condt_eqb_fields (fun _ _ -> true)) (condt_tag x1)
    Box_condt_EQ_ct x2

(** val condt_eqb_OK : condt -> condt -> reflect **)

let condt_eqb_OK =
  iffP2 condt_eqb

(** val condt_eqb_OK_sumbool : condt -> condt -> bool **)

let condt_eqb_OK_sumbool =
  reflect_dec condt_eqb condt_eqb_OK

(** val eqTC_condt : condt eqTypeC **)

let eqTC_condt =
  { beq = condt_eqb; ceqP = condt_eqb_OK }

(** val condt_eqType : Equality.coq_type **)

let condt_eqType =
  ceqT_eqType eqTC_condt

(** val condts : condt list **)

let condts =
  EQ_ct :: (NE_ct :: (CS_ct :: (CC_ct :: (MI_ct :: (PL_ct :: (VS_ct :: (VC_ct :: (HI_ct :: (LS_ct :: (GE_ct :: (LT_ct :: (GT_ct :: (LE_ct :: [])))))))))))))

(** val finTC_condt : condt finTypeC **)

let finTC_condt =
  { _eqC = eqTC_condt; cenum = condts }

(** val condt_finType : Finite.coq_type **)

let condt_finType =
  cfinT_finType finTC_condt

(** val string_of_condt : condt -> string **)

let string_of_condt = function
| EQ_ct -> "eq"
| NE_ct -> "ne"
| CS_ct -> "cs"
| CC_ct -> "cc"
| MI_ct -> "mi"
| PL_ct -> "pl"
| VS_ct -> "vs"
| VC_ct -> "vc"
| HI_ct -> "hi"
| LS_ct -> "ls"
| GE_ct -> "ge"
| LT_ct -> "lt"
| GT_ct -> "gt"
| LE_ct -> "le"

(** val arm_eval_cond :
    (rflag -> (error, bool) result) -> condt -> (error, bool) result **)

let arm_eval_cond get = function
| EQ_ct -> get ZF
| NE_ct -> (match get ZF with
            | Ok x -> Ok (negb x)
            | Error s -> Error s)
| CS_ct -> get CF
| CC_ct -> (match get CF with
            | Ok x -> Ok (negb x)
            | Error s -> Error s)
| MI_ct -> get NF
| PL_ct -> (match get NF with
            | Ok x -> Ok (negb x)
            | Error s -> Error s)
| VS_ct -> get VF
| VC_ct -> (match get VF with
            | Ok x -> Ok (negb x)
            | Error s -> Error s)
| HI_ct ->
  (match get CF with
   | Ok x ->
     (match get ZF with
      | Ok x0 -> Ok ((&&) x (negb x0))
      | Error s -> Error s)
   | Error s -> Error s)
| LS_ct ->
  (match get CF with
   | Ok x ->
     (match get ZF with
      | Ok x0 -> Ok ((||) (negb x) x0)
      | Error s -> Error s)
   | Error s -> Error s)
| GE_ct ->
  (match get NF with
   | Ok x ->
     (match get VF with
      | Ok x0 ->
        Ok
          (eq_op coq_Datatypes_bool__canonical__eqtype_Equality (Obj.magic x)
            (Obj.magic x0))
      | Error s -> Error s)
   | Error s -> Error s)
| LT_ct ->
  (match get NF with
   | Ok x ->
     (match get VF with
      | Ok x0 ->
        Ok
          (negb
            (eq_op coq_Datatypes_bool__canonical__eqtype_Equality
              (Obj.magic x) (Obj.magic x0)))
      | Error s -> Error s)
   | Error s -> Error s)
| GT_ct ->
  (match get ZF with
   | Ok x ->
     (match get NF with
      | Ok x0 ->
        (match get VF with
         | Ok x1 ->
           Ok
             ((&&) (negb x)
               (eq_op coq_Datatypes_bool__canonical__eqtype_Equality
                 (Obj.magic x0) (Obj.magic x1)))
         | Error s -> Error s)
      | Error s -> Error s)
   | Error s -> Error s)
| LE_ct ->
  (match get ZF with
   | Ok x ->
     (match get NF with
      | Ok x0 ->
        (match get VF with
         | Ok x1 ->
           Ok
             ((||) x
               (negb
                 (eq_op coq_Datatypes_bool__canonical__eqtype_Equality
                   (Obj.magic x0) (Obj.magic x1))))
         | Error s -> Error s)
      | Error s -> Error s)
   | Error s -> Error s)

(** val arm_fc_of_cfc : combine_flags_core -> flag_combination **)

let arm_fc_of_cfc cfc =
  let vnf = FCVar0 in
  let vzf = FCVar1 in
  let vcf = FCVar2 in
  let vvf = FCVar3 in
  (match cfc with
   | CFC_B -> FCNot vcf
   | CFC_E -> vzf
   | CFC_L -> FCNot (FCEq (vnf, vvf))
   | CFC_BE -> FCOr ((FCNot vcf), vzf)
   | CFC_LE -> FCOr (vzf, (FCNot (FCEq (vnf, vvf)))))

(** val arm_fcp : coq_FlagCombinationParams **)

let arm_fcp =
  arm_fc_of_cfc
