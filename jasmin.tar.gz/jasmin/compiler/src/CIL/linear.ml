(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Expr
open Fexpr
open Label
open Sopn
open Type
open Var0
open Word0
open Wsize

type 'a gen_linstr = { li_ii : instr_info; li_i : 'a }

type lcall_kind =
| OnStack
| InReg of var_i
| OnHWCallStack

type 'asm_op linstr_r =
| Lopn of lexpr list * 'asm_op sopn * rexpr list
| Lsyscall of (Wsize.wsize * BinNums.coq_Z) Syscall_t.syscall_t
| Lcall of lcall_kind * remote_label
| Lret
| Lret_hwcallstack
| Lalign
| Llabel of label_kind * label
| Lgoto of remote_label
| Ligoto of rexpr
| LstoreLabel of Var.var * label
| Lcond of fexpr * label
| Lrepeat_loop of (var_i, coq_Z) sum * 'asm_op linstr_r gen_linstr list

type 'asm_op lcmd = 'asm_op linstr_r gen_linstr list

type 'asm_op lfundef = { lfd_info : fun_info; lfd_align : wsize;
                         lfd_tyin : ltype list; lfd_arg : var_i list;
                         lfd_body : 'asm_op lcmd; lfd_tyout : ltype list;
                         lfd_res : var_i list; lfd_export : bool;
                         lfd_callee_saved : Var.var list;
                         lfd_stk_max : coq_Z; lfd_frame_size : coq_Z;
                         lfd_align_args : wsize list }

(** val lfd_total_stack : 'a1 asmOp -> 'a1 lfundef -> coq_Z **)

let lfd_total_stack _ lfd =
  if lfd.lfd_export
  then Z.sub (Z.add lfd.lfd_stk_max (wsize_size lfd.lfd_align)) (Zpos Coq_xH)
  else lfd.lfd_stk_max

type 'asm_op lprog = { lp_rip : Ident.Ident.ident;
                       lp_rsp : Ident.Ident.ident; lp_globs : word list;
                       lp_glob_names : ((Var.var * wsize) * coq_Z) list;
                       lp_funcs : (funname * 'asm_op lfundef) list }

(** val li_of_fopn_args :
    'a1 asmOp -> instr_info -> ((lexpr list * 'a1 sopn) * rexpr list) -> 'a1
    linstr_r gen_linstr **)

let li_of_fopn_args _ ii p =
  { li_ii = ii; li_i = (Lopn ((fst (fst p)), (snd (fst p)), (snd p))) }
