(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinNums
open Eqb_core_defs

type __ = Obj.t

type bn_flag_group =
| FG0
| FG1

type is_bn_flag_group =
| Coq_is_FG0
| Coq_is_FG1

val bn_flag_group_tag : bn_flag_group -> positive

val is_bn_flag_group_inhab : bn_flag_group -> is_bn_flag_group

type box_bn_flag_group_FG0 =
| Box_bn_flag_group_FG0

type bn_flag_group_fields_t = __

val bn_flag_group_fields : bn_flag_group -> bn_flag_group_fields_t

val bn_flag_group_eqb_fields :
  (bn_flag_group -> bn_flag_group -> bool) -> positive ->
  bn_flag_group_fields_t -> bn_flag_group_fields_t -> bool

val bn_flag_group_eqb : bn_flag_group -> bn_flag_group -> bool

type bn_register_shift =
| RS_left
| RS_right

type is_bn_register_shift =
| Coq_is_RS_left
| Coq_is_RS_right

val bn_register_shift_tag : bn_register_shift -> positive

val is_bn_register_shift_inhab : bn_register_shift -> is_bn_register_shift

type box_bn_register_shift_RS_left =
| Box_bn_register_shift_RS_left

type bn_register_shift_fields_t = __

val bn_register_shift_fields : bn_register_shift -> bn_register_shift_fields_t

val bn_register_shift_eqb_fields :
  (bn_register_shift -> bn_register_shift -> bool) -> positive ->
  bn_register_shift_fields_t -> bn_register_shift_fields_t -> bool

val bn_register_shift_eqb : bn_register_shift -> bn_register_shift -> bool

type bn_halfword_writeback =
| WB_upper
| WB_lower

type is_bn_halfword_writeback =
| Coq_is_WB_upper
| Coq_is_WB_lower

val bn_halfword_writeback_tag : bn_halfword_writeback -> positive

val is_bn_halfword_writeback_inhab :
  bn_halfword_writeback -> is_bn_halfword_writeback

type box_bn_halfword_writeback_WB_upper =
| Box_bn_halfword_writeback_WB_upper

type bn_halfword_writeback_fields_t = __

val bn_halfword_writeback_fields :
  bn_halfword_writeback -> bn_halfword_writeback_fields_t

val bn_halfword_writeback_eqb_fields :
  (bn_halfword_writeback -> bn_halfword_writeback -> bool) -> positive ->
  bn_halfword_writeback_fields_t -> bn_halfword_writeback_fields_t -> bool

val bn_halfword_writeback_eqb :
  bn_halfword_writeback -> bn_halfword_writeback -> bool
