(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Compiler_util
open Eqtype
open Expr
open Lowering
open Operators
open Otbn_decl
open Otbn_extra
open Otbn_instr_decl
open Otbn_options
open Otbn_params_core
open Pseudo_operator
open Seq
open Sopn
open Ssralg
open Ssrbool
open Ssrfun
open Type
open Utils0
open Var0
open Word0
open Word_ssrZ
open Wsize

module E :
 sig
  val pass_name : string

  val internal_error : string -> instr_info -> pp_error_loc

  val user_error : pp_error -> instr_info -> pp_error_loc

  val user_error_s : string -> instr_info -> pp_error_loc

  val invalid_wsize : instr_info -> pp_error_loc

  val not_implemented : instr_info -> pp_error_loc

  val invalid_expr : instr_info -> pp_error_loc

  val invalid_carry_lvals : instr_info -> pp_error_loc

  val invalid_carry_pexprs : instr_info -> pp_error_loc

  val cant_lower_mulu : instr_info -> pp_error_loc

  val invalid_sham : instr_info -> pexpr -> pp_error_loc

  val imm_out_of_range : instr_info -> wsize -> word -> pp_error_loc

  val invalid_arguments : instr_info -> pexpr list -> pp_error_loc
 end

type 'a lresult = 'a option cexec

val issue : 'a1 -> 'a1 lresult

val skip : 'a1 lresult

val lassert : bool -> pp_error_loc -> unit lresult

type otbn_args =
  (lval list * (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extended_op) * pexpr list

type low_instr = otbn_args lresult

val li_sissue :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> lval
  list -> (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extended_op -> pexpr list -> low_instr

val li_issue :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> lval
  list -> (register, empty, wide_register, rflag, condition, otbn_op)
  asm_op_t' -> pexpr list -> low_instr

val li_xissue :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> lval
  list -> (register, empty, wide_register, rflag, condition, otbn_op,
  extra_op) extra_op_t -> pexpr list -> low_instr

val li_ssimple :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op -> pexpr list -> low_instr

val li_simple :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op) asm_op_t' ->
  pexpr list -> low_instr

type low_cmd =
  (((otbn_args list * lval list) * (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op) * pexpr list) lresult

val lc_sissue :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  otbn_args list -> lval list -> (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op -> pexpr list -> low_cmd

val no_pre :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  low_instr -> low_cmd

val with_pre :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  otbn_args list -> low_instr -> low_cmd

val lnoneb : lval

val lnone_mlz : lval list

val lnone_cmlz : lval list

val chk_xreg_ws : instr_info -> wsize -> (pp_error_loc, unit) result

val chk_bn_shift : instr_info -> coq_Z -> unit cexec

val chk_address_displacement : instr_info -> wsize -> word -> unit cexec

val check_bn_displacement : coq_Z -> bool

val chk_bn_address_displacement : instr_info -> wsize -> word -> unit cexec

val reg_shift_of_sop2 :
  instr_info -> wsize -> sop2 -> bn_register_shift lresult

val get_arg_shift :
  instr_info -> wsize -> pexpr -> ((pexpr * bn_register_shift) * pexpr)
  lresult

val rsnoc : 'a1 -> 'a2 list -> ('a1, 'a2 * 'a2 list) result

val rsnoc2 : 'a1 -> 'a2 list -> ('a1, ('a2 * 'a2) * 'a2 list) result

val rsnoc3 : 'a1 -> 'a2 list -> ('a1, (('a2 * 'a2) * 'a2) * 'a2 list) result

val lower_basic_shift :
  instr_info -> bn_basic_mnemonic -> pexpr list -> (bn_register_shift * pexpr
  list) lresult

val lower_base_op :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> lval list -> otbn_op -> pexpr list -> low_instr

val get_carry_lvals : instr_info -> lval list -> lval list cexec

val get_carry_pexprs : instr_info -> pexpr list -> (bool * pexpr list) cexec

val carry_op : bool -> bool -> bn_basic_mnemonic

val lower_carry_op :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> bool -> wsize -> lval list -> pexpr list -> low_instr

val lower_swap :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> atype -> lval list -> pexpr list -> low_instr

val lower_pseudo_operator :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> lval list -> pseudo_operator -> pexpr list -> low_instr

val lower_copn :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> lval list -> (register, empty, wide_register, rflag,
  condition, otbn_op, extra_op) extended_op sopn -> pexpr list -> low_instr

val lower_condition :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> pexpr -> (otbn_args list * pexpr) cexec

val lower_Pvar :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> wsize ->
  gvar -> low_instr

val get_mem_disp :
  pexpr -> (register, empty, wide_register, rflag, condition) wreg option

val lower_load :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> pexpr -> low_instr

val lower_Papp1 :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> sop1 -> pexpr -> low_instr

val rv_expected_Imn_size : sop2 -> wsize option

val rv_Imn_of_op2 :
  instr_info -> sop2 -> wsize -> word -> pexpr -> (rv_mnemonic * pexpr)
  lresult

val rv_mn_of_op2 : sop2 -> pexpr -> (rv_mnemonic * pexpr) lresult

val check_shift_amount : pexpr -> pexpr option

val lower_shift :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> rv_mnemonic -> rv_mnemonic -> pexpr -> pexpr -> low_instr

val lower_Papp2_small :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> sop2 -> pexpr -> pexpr -> low_instr

val otbn_Iop_of_op2 : sop2 -> bn_flag_group -> (lval list * otbn_op) lresult

val otbn_op_of_op2 : sop2 -> bn_flag_group -> (lval list * otbn_op) lresult

val lower_Papp2_large :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> wsize ->
  sop2 -> pexpr -> pexpr -> low_instr

val lower_Papp2 :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> sop2 -> pexpr -> pexpr -> low_instr

val lower_pexpr_aux :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> pexpr -> low_instr

val lower_Pif :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> pexpr -> pexpr -> pexpr -> low_instr

val lower_pexpr :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> pexpr -> low_cmd

val destruct_Lmem :
  pexpr -> (var_i * (register, empty, wide_register, rflag, condition) wreg)
  option

val get_lval_memory_access :
  lval -> (var_i * (register, empty, wide_register, rflag, condition) wreg)
  option

val lower_store :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> wsize -> pexpr -> low_instr

val chk_lower_store : instr_info -> wsize -> lval -> unit cexec

val lower_cassgn_word :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> lval -> wsize -> pexpr -> low_cmd

val lower_i :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op instr -> (register, empty, wide_register, rflag, condition,
  otbn_op, extra_op) extended_op instr list cexec
