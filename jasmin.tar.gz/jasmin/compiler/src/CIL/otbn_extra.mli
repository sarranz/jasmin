(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_extra
open Arch_utils
open Arm_extra
open Compiler_util
open EqbOK
open Eqb_core_defs
open Eqtype
open Expr
open Fexpr
open Otbn
open Otbn_decl
open Otbn_instr_decl
open Otbn_options
open Otbn_params_core
open Sem_type
open Seq
open Sopn
open Ssralg
open Type
open Utils0
open Var0
open Word0
open Wsize

type __ = Obj.t

module E :
 sig
  val pass_name : string

  val internal_error : string -> instr_info -> pp_error_loc

  val internal_error_pp : pp_error -> instr_info -> pp_error_loc

  val invalid_lexprs : instr_info -> pp_error_loc

  val invalid_rexprs : instr_info -> pp_error_loc

  val invalid_args : instr_info -> pp_error_loc

  val bad_swap_lexprs : instr_info -> pp_error_loc

  val bad_swap_rexprs : instr_info -> pp_error_loc

  val bad_swap_size : wsize -> instr_info -> pp_error_loc

  val bad_swap_dst_arg : instr_info -> pp_error_loc

  val bad_swap_dsts : instr_info -> pp_error_loc

  val bad_swap_ty : instr_info -> pp_error_loc
 end

val asm_args_of_opn_args :
  OTBNFopn_core.opn_args list -> (((register, empty, wide_register, rflag,
  condition, otbn_op) asm_op_msb_t * lexpr list) * rexpr list) list

type extra_op =
| Coq_set0 of wsize
| MOV
| NOT
| SUBI
| ADD_LARGE_IMM
| SWAP of wsize

val extra_op_rect :
  (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize -> 'a1) -> extra_op ->
  'a1

val extra_op_rec :
  (wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize -> 'a1) -> extra_op ->
  'a1

type is_extra_op =
| Coq_is_set0 of wsize * is_wsize
| Coq_is_MOV
| Coq_is_NOT
| Coq_is_SUBI
| Coq_is_ADD_LARGE_IMM
| Coq_is_SWAP of wsize * is_wsize

val is_extra_op_rect :
  (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize ->
  is_wsize -> 'a1) -> extra_op -> is_extra_op -> 'a1

val is_extra_op_rec :
  (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize ->
  is_wsize -> 'a1) -> extra_op -> is_extra_op -> 'a1

val extra_op_tag : extra_op -> positive

val is_extra_op_inhab : extra_op -> is_extra_op

val is_extra_op_functor : extra_op -> is_extra_op -> is_extra_op

type box_extra_op_set0 =
  wsize
  (* singleton inductive, whose constructor was Box_extra_op_set0 *)

val coq_Box_extra_op_set0_0 : box_extra_op_set0 -> wsize

type box_extra_op_MOV =
| Box_extra_op_MOV

type extra_op_fields_t = __

val extra_op_fields : extra_op -> extra_op_fields_t

val extra_op_construct : positive -> extra_op_fields_t -> extra_op option

val extra_op_induction :
  (wsize -> is_wsize -> 'a1) -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> (wsize ->
  is_wsize -> 'a1) -> extra_op -> is_extra_op -> 'a1

val extra_op_eqb_fields :
  (extra_op -> extra_op -> bool) -> positive -> extra_op_fields_t ->
  extra_op_fields_t -> bool

val extra_op_eqb : extra_op -> extra_op -> bool

val extra_op_eqb_OK : extra_op -> extra_op -> reflect

val extra_op_eqb_OK_sumbool : extra_op -> extra_op -> bool

val coq_HB_unnamed_factory_1 : extra_op Coq_hasDecEq.axioms_

val otbn_extra_extra_op__canonical__eqtype_Equality : Equality.coq_type

val eqTC_otbn_extra_op : extra_op eqTypeC

val string_of_extra_op : extra_op -> string

val desc_set0_small :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instruction_desc

val desc_set0_large :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instruction_desc

val desc_MOV :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instruction_desc

val desc_NOT :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instruction_desc

val desc_SUBI :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instruction_desc

val desc_ADD_LARGE_IMM :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instruction_desc

val desc_swap_large :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instruction_desc

val get_instr_desc :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> extra_op
  -> instruction_desc

val prim_string : (string * extra_op prim_constructor) list

val extra_op_decl :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> extra_op
  asmOp

val assemble_set0 :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> wsize ->
  lexpr list -> rexpr list -> (((register, empty, wide_register, rflag,
  condition, otbn_op) asm_op_msb_t * lexpr list) * rexpr list) list cexec

val assemble_MOV :
  instr_info -> lexpr list -> rexpr list -> (((register, empty,
  wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
  list) * rexpr list) list cexec

val assemble_NOT :
  instr_info -> lexpr list -> rexpr list -> (((register, empty,
  wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
  list) * rexpr list) list cexec

val assemble_SUBI :
  instr_info -> lexpr list -> rexpr list -> (((register, empty,
  wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
  list) * rexpr list) list cexec

val assemble_ADD_LARGE_IMM :
  instr_info -> lexpr list -> rexpr list -> (((register, empty,
  wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
  list) * rexpr list) list cexec

val assemble_swap :
  instr_info -> wsize -> lexpr list -> rexpr list -> (((register, empty,
  wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
  list) * rexpr list) list cexec

val assemble_extra :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  instr_info -> extra_op -> lexpr list -> rexpr list -> (((register, empty,
  wide_register, rflag, condition, otbn_op) asm_op_msb_t * lexpr
  list) * rexpr list) list cexec

val otbn_extra :
  (register, empty, wide_register, rflag, condition) arch_toIdent ->
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  asm_extra

type otbn_extended_op =
  (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op

val coq_Ootbn :
  (register, empty, wide_register, rflag, condition) arch_toIdent -> otbn_op
  -> (register, empty, wide_register, rflag, condition, otbn_op, extra_op)
  extended_op sopn
