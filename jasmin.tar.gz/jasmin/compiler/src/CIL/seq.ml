(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open Datatypes
open Eqtype
open Ssrbool
open Ssreflect
open Ssrfun
open Ssrnat

let __ = let rec f _ = Obj.repr f in Obj.repr f

(** val size : 'a1 list -> nat **)

let rec size = function
| [] -> O
| _ :: s' -> S (size s')

(** val nilp : 'a1 list -> bool **)

let nilp s =
  eq_op coq_Datatypes_nat__canonical__eqtype_Equality (Obj.magic size s)
    (Obj.magic O)

(** val ohead : 'a1 list -> 'a1 option **)

let ohead = function
| [] -> None
| x :: _ -> Some x

(** val head : 'a1 -> 'a1 list -> 'a1 **)

let head x0 = function
| [] -> x0
| x :: _ -> x

(** val behead : 'a1 list -> 'a1 list **)

let behead = function
| [] -> []
| _ :: s' -> s'

(** val ncons : nat -> 'a1 -> 'a1 list -> 'a1 list **)

let ncons n x =
  iter n (fun x0 -> x :: x0)

(** val nseq : nat -> 'a1 -> 'a1 list **)

let nseq n x =
  ncons n x []

(** val cat : 'a1 list -> 'a1 list -> 'a1 list **)

let rec cat s1 s2 =
  match s1 with
  | [] -> s2
  | x :: s1' -> x :: (cat s1' s2)

(** val rcons : 'a1 list -> 'a1 -> 'a1 list **)

let rec rcons s z =
  match s with
  | [] -> z :: []
  | x :: s' -> x :: (rcons s' z)

(** val nth : 'a1 -> 'a1 list -> nat -> 'a1 **)

let rec nth x0 s n =
  match s with
  | [] -> x0
  | x :: s' -> (match n with
                | O -> x
                | S n' -> nth x0 s' n')

(** val find : 'a1 pred -> 'a1 list -> nat **)

let rec find a = function
| [] -> O
| x :: s' -> if a x then O else S (find a s')

(** val filter : 'a1 pred -> 'a1 list -> 'a1 list **)

let rec filter a = function
| [] -> []
| x :: s' -> if a x then x :: (filter a s') else filter a s'

(** val count : 'a1 pred -> 'a1 list -> nat **)

let rec count a = function
| [] -> O
| x :: s' -> addn (nat_of_bool (a x)) (count a s')

(** val has : 'a1 pred -> 'a1 list -> bool **)

let rec has a = function
| [] -> false
| x :: s' -> (||) (a x) (has a s')

(** val all : 'a1 pred -> 'a1 list -> bool **)

let rec all a = function
| [] -> true
| x :: s' -> (&&) (a x) (all a s')

(** val drop : nat -> 'a1 list -> 'a1 list **)

let rec drop n s = match s with
| [] -> s
| _ :: s' -> (match n with
              | O -> s
              | S n' -> drop n' s')

(** val take : nat -> 'a1 list -> 'a1 list **)

let rec take n = function
| [] -> []
| x :: s' -> (match n with
              | O -> []
              | S n' -> x :: (take n' s'))

(** val catrev : 'a1 list -> 'a1 list -> 'a1 list **)

let rec catrev s1 s2 =
  match s1 with
  | [] -> s2
  | x :: s1' -> catrev s1' (x :: s2)

(** val rev : 'a1 list -> 'a1 list **)

let rev s =
  catrev s []

(** val eqseq :
    Equality.coq_type -> Equality.sort list -> Equality.sort list -> bool **)

let rec eqseq t s1 s2 =
  match s1 with
  | [] -> (match s2 with
           | [] -> true
           | _ :: _ -> false)
  | x1 :: s1' ->
    (match s2 with
     | [] -> false
     | x2 :: s2' -> (&&) (eq_op t x1 x2) (eqseq t s1' s2'))

(** val eqseqP : Equality.coq_type -> Equality.sort list eq_axiom **)

let eqseqP t _top_assumption_ =
  let _evar_0_ = fun __top_assumption_ ->
    let _evar_0_ = ReflectT in
    let _evar_0_0 = fun _ _ -> ReflectF in
    (match __top_assumption_ with
     | [] -> _evar_0_
     | a :: l -> _evar_0_0 a l)
  in
  let _evar_0_0 = fun x1 s1 iHs __top_assumption_ ->
    let _evar_0_0 = ReflectF in
    let _evar_0_1 = fun x2 s2 ->
      ssr_have_upoly (eqP t x1 x2) (fun __top_assumption_0 ->
        let _evar_0_1 = fun _ -> iffP (eqseq t s1 s2) (iHs s2) in
        let _evar_0_2 = fun _ -> ReflectF in
        (match __top_assumption_0 with
         | ReflectT -> _evar_0_1 __
         | ReflectF -> _evar_0_2 __))
    in
    (match __top_assumption_ with
     | [] -> _evar_0_0
     | a :: l -> _evar_0_1 a l)
  in
  let rec f = function
  | [] -> _evar_0_
  | y :: l0 -> _evar_0_0 y l0 (f l0)
  in f _top_assumption_

(** val coq_HB_unnamed_factory_1 :
    Equality.coq_type -> Equality.sort list Coq_hasDecEq.axioms_ **)

let coq_HB_unnamed_factory_1 t =
  { Coq_hasDecEq.eq_op = (eqseq t); Coq_hasDecEq.eqP = (eqseqP t) }

(** val coq_Datatypes_list__canonical__eqtype_Equality :
    Equality.coq_type -> Equality.coq_type **)

let coq_Datatypes_list__canonical__eqtype_Equality t =
  Obj.magic coq_HB_unnamed_factory_1 t

(** val mem_seq :
    Equality.coq_type -> Equality.sort list -> Equality.sort -> bool **)

let rec mem_seq t = function
| [] -> (fun _ -> false)
| y :: s' -> let p = mem_seq t s' in (fun x -> (||) (eq_op t x y) (p x))

type seq_eqclass = Equality.sort list

(** val pred_of_seq :
    Equality.coq_type -> seq_eqclass -> Equality.sort pred_sort **)

let pred_of_seq t s =
  Obj.magic mem_seq t s

(** val seq_predType : Equality.coq_type -> Equality.sort predType **)

let seq_predType t =
  Obj.magic pred_of_seq t

(** val allP :
    Equality.coq_type -> Equality.sort pred -> Equality.sort list -> reflect **)

let allP _ a s =
  let _evar_0_ = ReflectT in
  let _evar_0_0 = fun y s0 iHs ->
    equivP ((&&) (a y) (all a s0))
      (andPP (a y) (all a s0) (if a y then ReflectT else ReflectF) iHs)
  in
  let rec f = function
  | [] -> _evar_0_
  | y :: l0 -> _evar_0_0 y l0 (f l0)
  in f s

(** val uniq : Equality.coq_type -> Equality.sort list -> bool **)

let rec uniq t = function
| [] -> true
| x :: s' ->
  (&&) (negb (in_mem x (mem (seq_predType t) (Obj.magic s')))) (uniq t s')

(** val index :
    Equality.coq_type -> Equality.sort -> Equality.sort list -> nat **)

let index t x =
  find (PredOfSimpl.coerce (pred1 t x))

type bitseq = bool list

(** val mask : bitseq -> 'a1 list -> 'a1 list **)

let rec mask m s =
  match m with
  | [] -> []
  | b :: m' ->
    (match s with
     | [] -> []
     | x :: s' -> if b then x :: (mask m' s') else mask m' s')

(** val rem :
    Equality.coq_type -> Equality.sort -> Equality.sort list -> Equality.sort
    list **)

let rec rem t x s = match s with
| [] -> s
| y :: t0 -> if eq_op t y x then t0 else y :: (rem t x t0)

(** val map : ('a1 -> 'a2) -> 'a1 list -> 'a2 list **)

let rec map f = function
| [] -> []
| x :: s' -> (f x) :: (map f s')

(** val pmap : ('a1 -> 'a2 option) -> 'a1 list -> 'a2 list **)

let rec pmap f = function
| [] -> []
| x :: s' -> let r = pmap f s' in Option.apply (fun x0 -> x0 :: r) r (f x)

(** val iota : nat -> nat -> nat list **)

let rec iota m = function
| O -> []
| S n' -> m :: (iota (S m) n')

(** val foldr : ('a1 -> 'a2 -> 'a2) -> 'a2 -> 'a1 list -> 'a2 **)

let rec foldr f z0 = function
| [] -> z0
| x :: s' -> f x (foldr f z0 s')

(** val foldl : ('a2 -> 'a1 -> 'a2) -> 'a2 -> 'a1 list -> 'a2 **)

let rec foldl f z = function
| [] -> z
| x :: s' -> foldl f (f z x) s'

(** val zip : 'a1 list -> 'a2 list -> ('a1 * 'a2) list **)

let rec zip s t =
  match s with
  | [] -> []
  | x :: s' -> (match t with
                | [] -> []
                | y :: t' -> (x, y) :: (zip s' t'))

(** val unzip1 : ('a1 * 'a2) list -> 'a1 list **)

let unzip1 s =
  map fst s

(** val unzip2 : ('a1 * 'a2) list -> 'a2 list **)

let unzip2 s =
  map snd s

(** val all2 : ('a1 -> 'a2 -> bool) -> 'a1 list -> 'a2 list -> bool **)

let rec all2 r s t =
  match s with
  | [] -> (match t with
           | [] -> true
           | _ :: _ -> false)
  | x :: s0 ->
    (match t with
     | [] -> false
     | y :: t0 -> (&&) (r x y) (all2 r s0 t0))

(** val flatten : 'a1 list list -> 'a1 list **)

let flatten s =
  foldr cat [] s
