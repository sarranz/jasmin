(* This prelude is added at extraction time. See lang/extraction.v. *)
   [@@@ocaml.warning "-9-20-27-32-33-34-37-39-50-67"] (* End of prelude. *)

open BinInt
open BinNums
open Datatypes
open Arch_decl
open Arch_utils
open Arm_common
open Armv8a_decl
open EqbOK
open Eqb_core_defs
open Eqtype
open Fintype
open Sem_type
open Seq
open Shift_kind
open Sopn
open Ssrbool
open Std
open Type
open Utils0
open Word0
open Word_ssrZ
open Wsize
open Xseq

type __ = Obj.t
let __ = let rec f _ = Obj.repr f in Obj.repr f

module E =
 struct
  (** val no_semantics : error **)

  let no_semantics =
    ErrSemUndef
 end

type armv8a_options = { has_shift : shift_kind option; opts_size : wsize }

(** val has_shift : armv8a_options -> shift_kind option **)

let has_shift record =
  record.has_shift

(** val opts_size : armv8a_options -> wsize **)

let opts_size record =
  record.opts_size

type is_armv8a_options =
| Coq_is_Build_armv8a_options of shift_kind option
   * (shift_kind, is_shift_kind) Prelude.is_option * wsize * is_wsize

(** val is_armv8a_options_rect :
    (shift_kind option -> (shift_kind, is_shift_kind) Prelude.is_option ->
    wsize -> is_wsize -> 'a1) -> armv8a_options -> is_armv8a_options -> 'a1 **)

let is_armv8a_options_rect f _ = function
| Coq_is_Build_armv8a_options (has_shift0, phas_shift, opts_size0, popts_size) ->
  f has_shift0 phas_shift opts_size0 popts_size

(** val is_armv8a_options_rec :
    (shift_kind option -> (shift_kind, is_shift_kind) Prelude.is_option ->
    wsize -> is_wsize -> 'a1) -> armv8a_options -> is_armv8a_options -> 'a1 **)

let is_armv8a_options_rec f _ = function
| Coq_is_Build_armv8a_options (has_shift0, phas_shift, opts_size0, popts_size) ->
  f has_shift0 phas_shift opts_size0 popts_size

(** val armv8a_options_tag : armv8a_options -> positive **)

let armv8a_options_tag _ =
  Coq_xH

(** val is_armv8a_options_inhab : armv8a_options -> is_armv8a_options **)

let is_armv8a_options_inhab x =
  let { has_shift = has_shift0; opts_size = opts_size0 } = x in
  Coq_is_Build_armv8a_options (has_shift0,
  (Prelude.is_option_inhab is_shift_kind_inhab has_shift0), opts_size0,
  (is_wsize_inhab opts_size0))

(** val is_armv8a_options_functor :
    armv8a_options -> is_armv8a_options -> is_armv8a_options **)

let rec is_armv8a_options_functor _ x =
  x

type box_armv8a_options_Build_armv8a_options = { coq_Box_armv8a_options_Build_armv8a_options_0 : 
                                                 shift_kind option;
                                                 coq_Box_armv8a_options_Build_armv8a_options_1 : 
                                                 wsize }

(** val coq_Box_armv8a_options_Build_armv8a_options_0 :
    box_armv8a_options_Build_armv8a_options -> shift_kind option **)

let coq_Box_armv8a_options_Build_armv8a_options_0 record =
  record.coq_Box_armv8a_options_Build_armv8a_options_0

(** val coq_Box_armv8a_options_Build_armv8a_options_1 :
    box_armv8a_options_Build_armv8a_options -> wsize **)

let coq_Box_armv8a_options_Build_armv8a_options_1 record =
  record.coq_Box_armv8a_options_Build_armv8a_options_1

type armv8a_options_fields_t = box_armv8a_options_Build_armv8a_options

(** val armv8a_options_fields : armv8a_options -> armv8a_options_fields_t **)

let armv8a_options_fields i =
  let { has_shift = has_shift0; opts_size = opts_size0 } = i in
  { coq_Box_armv8a_options_Build_armv8a_options_0 = has_shift0;
  coq_Box_armv8a_options_Build_armv8a_options_1 = opts_size0 }

(** val armv8a_options_construct :
    positive -> box_armv8a_options_Build_armv8a_options -> armv8a_options
    option **)

let armv8a_options_construct _ b =
  let { coq_Box_armv8a_options_Build_armv8a_options_0 =
    box_armv8a_options_Build_armv8a_options_0;
    coq_Box_armv8a_options_Build_armv8a_options_1 =
    box_armv8a_options_Build_armv8a_options_1 } = b
  in
  Some { has_shift = box_armv8a_options_Build_armv8a_options_0; opts_size =
  box_armv8a_options_Build_armv8a_options_1 }

(** val armv8a_options_induction :
    (shift_kind option -> (shift_kind, is_shift_kind) Prelude.is_option ->
    wsize -> is_wsize -> 'a1) -> armv8a_options -> is_armv8a_options -> 'a1 **)

let armv8a_options_induction his_Build_armv8a_options _ = function
| Coq_is_Build_armv8a_options (has_shift0, phas_shift, opts_size0, popts_size) ->
  his_Build_armv8a_options has_shift0 phas_shift opts_size0 popts_size

(** val armv8a_options_eqb_fields :
    (armv8a_options -> armv8a_options -> bool) -> positive ->
    box_armv8a_options_Build_armv8a_options ->
    box_armv8a_options_Build_armv8a_options -> bool **)

let armv8a_options_eqb_fields _ _ a b =
  let { coq_Box_armv8a_options_Build_armv8a_options_0 =
    box_armv8a_options_Build_armv8a_options_0;
    coq_Box_armv8a_options_Build_armv8a_options_1 =
    box_armv8a_options_Build_armv8a_options_1 } = a
  in
  let { coq_Box_armv8a_options_Build_armv8a_options_0 =
    box_armv8a_options_Build_armv8a_options_2;
    coq_Box_armv8a_options_Build_armv8a_options_1 =
    box_armv8a_options_Build_armv8a_options_3 } = b
  in
  (&&)
    (Prelude.option_eqb shift_kind_eqb
      box_armv8a_options_Build_armv8a_options_0
      box_armv8a_options_Build_armv8a_options_2)
    ((&&)
      (wsize_eqb box_armv8a_options_Build_armv8a_options_1
        box_armv8a_options_Build_armv8a_options_3)
      true)

(** val armv8a_options_eqb : armv8a_options -> armv8a_options -> bool **)

let armv8a_options_eqb x1 x2 =
  let { has_shift = has_shift0; opts_size = opts_size0 } = x1 in
  eqb_body armv8a_options_tag armv8a_options_fields
    (armv8a_options_eqb_fields (fun _ _ -> true))
    (armv8a_options_tag { has_shift = has_shift0; opts_size = opts_size0 })
    { coq_Box_armv8a_options_Build_armv8a_options_0 = has_shift0;
    coq_Box_armv8a_options_Build_armv8a_options_1 = opts_size0 } x2

(** val armv8a_options_eqb_OK :
    armv8a_options -> armv8a_options -> reflect **)

let armv8a_options_eqb_OK =
  iffP2 armv8a_options_eqb

(** val armv8a_options_eqb_OK_sumbool :
    armv8a_options -> armv8a_options -> bool **)

let armv8a_options_eqb_OK_sumbool =
  reflect_dec armv8a_options_eqb armv8a_options_eqb_OK

(** val eqTC_armv8a_options : armv8a_options eqTypeC **)

let eqTC_armv8a_options =
  { beq = armv8a_options_eqb; ceqP = armv8a_options_eqb_OK }

(** val armv8a_options_eqType : Equality.coq_type **)

let armv8a_options_eqType =
  ceqT_eqType eqTC_armv8a_options

(** val default_opts : armv8a_options **)

let default_opts =
  { has_shift = None; opts_size = U64 }

(** val opts_at : wsize -> armv8a_options **)

let opts_at ws =
  { has_shift = None; opts_size = ws }

type armv8a_mnemonic =
| ADD
| ADDS
| ADC
| ADCS
| SUB
| SUBS
| NEG
| MUL
| MADD
| MSUB
| SDIV
| UDIV
| AND
| ORR
| EOR
| MVN
| ASR
| LSL
| LSR
| ROR
| MOV
| MOVN
| MOVZ
| MOVK
| ADR
| SXTB
| SXTH
| SXTW
| UXTB
| UXTH
| UXTW
| CMP
| TST
| CSEL
| LDR
| LDRB
| LDRH
| LDRSB
| LDRSH
| LDRSW
| STR
| STRB
| STRH

(** val armv8a_mnemonic_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> armv8a_mnemonic -> 'a1 **)

let armv8a_mnemonic_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 f33 f34 f35 f36 f37 f38 f39 f40 f41 = function
| ADD -> f
| ADDS -> f0
| ADC -> f1
| ADCS -> f2
| SUB -> f3
| SUBS -> f4
| NEG -> f5
| MUL -> f6
| MADD -> f7
| MSUB -> f8
| SDIV -> f9
| UDIV -> f10
| AND -> f11
| ORR -> f12
| EOR -> f13
| MVN -> f14
| ASR -> f15
| LSL -> f16
| LSR -> f17
| ROR -> f18
| MOV -> f19
| MOVN -> f20
| MOVZ -> f21
| MOVK -> f22
| ADR -> f23
| SXTB -> f24
| SXTH -> f25
| SXTW -> f26
| UXTB -> f27
| UXTH -> f28
| UXTW -> f29
| CMP -> f30
| TST -> f31
| CSEL -> f32
| LDR -> f33
| LDRB -> f34
| LDRH -> f35
| LDRSB -> f36
| LDRSH -> f37
| LDRSW -> f38
| STR -> f39
| STRB -> f40
| STRH -> f41

(** val armv8a_mnemonic_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> armv8a_mnemonic -> 'a1 **)

let armv8a_mnemonic_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 f33 f34 f35 f36 f37 f38 f39 f40 f41 = function
| ADD -> f
| ADDS -> f0
| ADC -> f1
| ADCS -> f2
| SUB -> f3
| SUBS -> f4
| NEG -> f5
| MUL -> f6
| MADD -> f7
| MSUB -> f8
| SDIV -> f9
| UDIV -> f10
| AND -> f11
| ORR -> f12
| EOR -> f13
| MVN -> f14
| ASR -> f15
| LSL -> f16
| LSR -> f17
| ROR -> f18
| MOV -> f19
| MOVN -> f20
| MOVZ -> f21
| MOVK -> f22
| ADR -> f23
| SXTB -> f24
| SXTH -> f25
| SXTW -> f26
| UXTB -> f27
| UXTH -> f28
| UXTW -> f29
| CMP -> f30
| TST -> f31
| CSEL -> f32
| LDR -> f33
| LDRB -> f34
| LDRH -> f35
| LDRSB -> f36
| LDRSH -> f37
| LDRSW -> f38
| STR -> f39
| STRB -> f40
| STRH -> f41

type is_armv8a_mnemonic =
| Coq_is_ADD
| Coq_is_ADDS
| Coq_is_ADC
| Coq_is_ADCS
| Coq_is_SUB
| Coq_is_SUBS
| Coq_is_NEG
| Coq_is_MUL
| Coq_is_MADD
| Coq_is_MSUB
| Coq_is_SDIV
| Coq_is_UDIV
| Coq_is_AND
| Coq_is_ORR
| Coq_is_EOR
| Coq_is_MVN
| Coq_is_ASR
| Coq_is_LSL
| Coq_is_LSR
| Coq_is_ROR
| Coq_is_MOV
| Coq_is_MOVN
| Coq_is_MOVZ
| Coq_is_MOVK
| Coq_is_ADR
| Coq_is_SXTB
| Coq_is_SXTH
| Coq_is_SXTW
| Coq_is_UXTB
| Coq_is_UXTH
| Coq_is_UXTW
| Coq_is_CMP
| Coq_is_TST
| Coq_is_CSEL
| Coq_is_LDR
| Coq_is_LDRB
| Coq_is_LDRH
| Coq_is_LDRSB
| Coq_is_LDRSH
| Coq_is_LDRSW
| Coq_is_STR
| Coq_is_STRB
| Coq_is_STRH

(** val is_armv8a_mnemonic_rect :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> armv8a_mnemonic -> is_armv8a_mnemonic -> 'a1 **)

let is_armv8a_mnemonic_rect f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 f33 f34 f35 f36 f37 f38 f39 f40 f41 _ = function
| Coq_is_ADD -> f
| Coq_is_ADDS -> f0
| Coq_is_ADC -> f1
| Coq_is_ADCS -> f2
| Coq_is_SUB -> f3
| Coq_is_SUBS -> f4
| Coq_is_NEG -> f5
| Coq_is_MUL -> f6
| Coq_is_MADD -> f7
| Coq_is_MSUB -> f8
| Coq_is_SDIV -> f9
| Coq_is_UDIV -> f10
| Coq_is_AND -> f11
| Coq_is_ORR -> f12
| Coq_is_EOR -> f13
| Coq_is_MVN -> f14
| Coq_is_ASR -> f15
| Coq_is_LSL -> f16
| Coq_is_LSR -> f17
| Coq_is_ROR -> f18
| Coq_is_MOV -> f19
| Coq_is_MOVN -> f20
| Coq_is_MOVZ -> f21
| Coq_is_MOVK -> f22
| Coq_is_ADR -> f23
| Coq_is_SXTB -> f24
| Coq_is_SXTH -> f25
| Coq_is_SXTW -> f26
| Coq_is_UXTB -> f27
| Coq_is_UXTH -> f28
| Coq_is_UXTW -> f29
| Coq_is_CMP -> f30
| Coq_is_TST -> f31
| Coq_is_CSEL -> f32
| Coq_is_LDR -> f33
| Coq_is_LDRB -> f34
| Coq_is_LDRH -> f35
| Coq_is_LDRSB -> f36
| Coq_is_LDRSH -> f37
| Coq_is_LDRSW -> f38
| Coq_is_STR -> f39
| Coq_is_STRB -> f40
| Coq_is_STRH -> f41

(** val is_armv8a_mnemonic_rec :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> armv8a_mnemonic -> is_armv8a_mnemonic -> 'a1 **)

let is_armv8a_mnemonic_rec f f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 f33 f34 f35 f36 f37 f38 f39 f40 f41 _ = function
| Coq_is_ADD -> f
| Coq_is_ADDS -> f0
| Coq_is_ADC -> f1
| Coq_is_ADCS -> f2
| Coq_is_SUB -> f3
| Coq_is_SUBS -> f4
| Coq_is_NEG -> f5
| Coq_is_MUL -> f6
| Coq_is_MADD -> f7
| Coq_is_MSUB -> f8
| Coq_is_SDIV -> f9
| Coq_is_UDIV -> f10
| Coq_is_AND -> f11
| Coq_is_ORR -> f12
| Coq_is_EOR -> f13
| Coq_is_MVN -> f14
| Coq_is_ASR -> f15
| Coq_is_LSL -> f16
| Coq_is_LSR -> f17
| Coq_is_ROR -> f18
| Coq_is_MOV -> f19
| Coq_is_MOVN -> f20
| Coq_is_MOVZ -> f21
| Coq_is_MOVK -> f22
| Coq_is_ADR -> f23
| Coq_is_SXTB -> f24
| Coq_is_SXTH -> f25
| Coq_is_SXTW -> f26
| Coq_is_UXTB -> f27
| Coq_is_UXTH -> f28
| Coq_is_UXTW -> f29
| Coq_is_CMP -> f30
| Coq_is_TST -> f31
| Coq_is_CSEL -> f32
| Coq_is_LDR -> f33
| Coq_is_LDRB -> f34
| Coq_is_LDRH -> f35
| Coq_is_LDRSB -> f36
| Coq_is_LDRSH -> f37
| Coq_is_LDRSW -> f38
| Coq_is_STR -> f39
| Coq_is_STRB -> f40
| Coq_is_STRH -> f41

(** val armv8a_mnemonic_tag : armv8a_mnemonic -> positive **)

let armv8a_mnemonic_tag = function
| ADD -> Coq_xH
| ADDS -> Coq_xO Coq_xH
| ADC -> Coq_xI Coq_xH
| ADCS -> Coq_xO (Coq_xO Coq_xH)
| SUB -> Coq_xI (Coq_xO Coq_xH)
| SUBS -> Coq_xO (Coq_xI Coq_xH)
| NEG -> Coq_xI (Coq_xI Coq_xH)
| MUL -> Coq_xO (Coq_xO (Coq_xO Coq_xH))
| MADD -> Coq_xI (Coq_xO (Coq_xO Coq_xH))
| MSUB -> Coq_xO (Coq_xI (Coq_xO Coq_xH))
| SDIV -> Coq_xI (Coq_xI (Coq_xO Coq_xH))
| UDIV -> Coq_xO (Coq_xO (Coq_xI Coq_xH))
| AND -> Coq_xI (Coq_xO (Coq_xI Coq_xH))
| ORR -> Coq_xO (Coq_xI (Coq_xI Coq_xH))
| EOR -> Coq_xI (Coq_xI (Coq_xI Coq_xH))
| MVN -> Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| ASR -> Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH)))
| LSL -> Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| LSR -> Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH)))
| ROR -> Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| MOV -> Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH)))
| MOVN -> Coq_xO (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| MOVZ -> Coq_xI (Coq_xI (Coq_xI (Coq_xO Coq_xH)))
| MOVK -> Coq_xO (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| ADR -> Coq_xI (Coq_xO (Coq_xO (Coq_xI Coq_xH)))
| SXTB -> Coq_xO (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| SXTH -> Coq_xI (Coq_xI (Coq_xO (Coq_xI Coq_xH)))
| SXTW -> Coq_xO (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| UXTB -> Coq_xI (Coq_xO (Coq_xI (Coq_xI Coq_xH)))
| UXTH -> Coq_xO (Coq_xI (Coq_xI (Coq_xI Coq_xH)))
| UXTW -> Coq_xI (Coq_xI (Coq_xI (Coq_xI Coq_xH)))
| CMP -> Coq_xO (Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH))))
| TST -> Coq_xI (Coq_xO (Coq_xO (Coq_xO (Coq_xO Coq_xH))))
| CSEL -> Coq_xO (Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH))))
| LDR -> Coq_xI (Coq_xI (Coq_xO (Coq_xO (Coq_xO Coq_xH))))
| LDRB -> Coq_xO (Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH))))
| LDRH -> Coq_xI (Coq_xO (Coq_xI (Coq_xO (Coq_xO Coq_xH))))
| LDRSB -> Coq_xO (Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH))))
| LDRSH -> Coq_xI (Coq_xI (Coq_xI (Coq_xO (Coq_xO Coq_xH))))
| LDRSW -> Coq_xO (Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH))))
| STR -> Coq_xI (Coq_xO (Coq_xO (Coq_xI (Coq_xO Coq_xH))))
| STRB -> Coq_xO (Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH))))
| STRH -> Coq_xI (Coq_xI (Coq_xO (Coq_xI (Coq_xO Coq_xH))))

(** val is_armv8a_mnemonic_inhab : armv8a_mnemonic -> is_armv8a_mnemonic **)

let is_armv8a_mnemonic_inhab = function
| ADD -> Coq_is_ADD
| ADDS -> Coq_is_ADDS
| ADC -> Coq_is_ADC
| ADCS -> Coq_is_ADCS
| SUB -> Coq_is_SUB
| SUBS -> Coq_is_SUBS
| NEG -> Coq_is_NEG
| MUL -> Coq_is_MUL
| MADD -> Coq_is_MADD
| MSUB -> Coq_is_MSUB
| SDIV -> Coq_is_SDIV
| UDIV -> Coq_is_UDIV
| AND -> Coq_is_AND
| ORR -> Coq_is_ORR
| EOR -> Coq_is_EOR
| MVN -> Coq_is_MVN
| ASR -> Coq_is_ASR
| LSL -> Coq_is_LSL
| LSR -> Coq_is_LSR
| ROR -> Coq_is_ROR
| MOV -> Coq_is_MOV
| MOVN -> Coq_is_MOVN
| MOVZ -> Coq_is_MOVZ
| MOVK -> Coq_is_MOVK
| ADR -> Coq_is_ADR
| SXTB -> Coq_is_SXTB
| SXTH -> Coq_is_SXTH
| SXTW -> Coq_is_SXTW
| UXTB -> Coq_is_UXTB
| UXTH -> Coq_is_UXTH
| UXTW -> Coq_is_UXTW
| CMP -> Coq_is_CMP
| TST -> Coq_is_TST
| CSEL -> Coq_is_CSEL
| LDR -> Coq_is_LDR
| LDRB -> Coq_is_LDRB
| LDRH -> Coq_is_LDRH
| LDRSB -> Coq_is_LDRSB
| LDRSH -> Coq_is_LDRSH
| LDRSW -> Coq_is_LDRSW
| STR -> Coq_is_STR
| STRB -> Coq_is_STRB
| STRH -> Coq_is_STRH

(** val is_armv8a_mnemonic_functor :
    armv8a_mnemonic -> is_armv8a_mnemonic -> is_armv8a_mnemonic **)

let rec is_armv8a_mnemonic_functor _ x =
  x

type box_armv8a_mnemonic_ADD =
| Box_armv8a_mnemonic_ADD

type armv8a_mnemonic_fields_t = __

(** val armv8a_mnemonic_fields :
    armv8a_mnemonic -> armv8a_mnemonic_fields_t **)

let armv8a_mnemonic_fields _ =
  Obj.magic Box_armv8a_mnemonic_ADD

(** val armv8a_mnemonic_construct :
    positive -> armv8a_mnemonic_fields_t -> armv8a_mnemonic option **)

let armv8a_mnemonic_construct p _ =
  match p with
  | Coq_xI x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some UXTW
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some LDRSH
              | Coq_xH -> Some MOVZ)
           | Coq_xH -> Some EOR)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some STRH
              | Coq_xH -> Some SXTH)
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some LDR
              | Coq_xH -> Some LSR)
           | Coq_xH -> Some SDIV)
        | Coq_xH -> Some NEG)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some UXTB
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some LDRH
              | Coq_xH -> Some MOV)
           | Coq_xH -> Some AND)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some STR
              | Coq_xH -> Some ADR)
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some TST
              | Coq_xH -> Some ASR)
           | Coq_xH -> Some MADD)
        | Coq_xH -> Some SUB)
     | Coq_xH -> Some ADC)
  | Coq_xO x ->
    (match x with
     | Coq_xI x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some UXTH
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some LDRSB
              | Coq_xH -> Some MOVN)
           | Coq_xH -> Some ORR)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some STRB
              | Coq_xH -> Some SXTB)
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some CSEL
              | Coq_xH -> Some LSL)
           | Coq_xH -> Some MSUB)
        | Coq_xH -> Some SUBS)
     | Coq_xO x0 ->
       (match x0 with
        | Coq_xI x1 ->
          (match x1 with
           | Coq_xI _ -> Some SXTW
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some LDRB
              | Coq_xH -> Some ROR)
           | Coq_xH -> Some UDIV)
        | Coq_xO x1 ->
          (match x1 with
           | Coq_xI x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some LDRSW
              | Coq_xH -> Some MOVK)
           | Coq_xO x2 ->
             (match x2 with
              | Coq_xI _ -> None
              | Coq_xO _ -> Some CMP
              | Coq_xH -> Some MVN)
           | Coq_xH -> Some MUL)
        | Coq_xH -> Some ADCS)
     | Coq_xH -> Some ADDS)
  | Coq_xH -> Some ADD

(** val armv8a_mnemonic_induction :
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1
    -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 -> 'a1 ->
    'a1 -> armv8a_mnemonic -> is_armv8a_mnemonic -> 'a1 **)

let armv8a_mnemonic_induction his_ADD his_ADDS his_ADC his_ADCS his_SUB his_SUBS his_NEG his_MUL his_MADD his_MSUB his_SDIV his_UDIV his_AND his_ORR his_EOR his_MVN his_ASR his_LSL his_LSR his_ROR his_MOV his_MOVN his_MOVZ his_MOVK his_ADR his_SXTB his_SXTH his_SXTW his_UXTB his_UXTH his_UXTW his_CMP his_TST his_CSEL his_LDR his_LDRB his_LDRH his_LDRSB his_LDRSH his_LDRSW his_STR his_STRB his_STRH _ = function
| Coq_is_ADD -> his_ADD
| Coq_is_ADDS -> his_ADDS
| Coq_is_ADC -> his_ADC
| Coq_is_ADCS -> his_ADCS
| Coq_is_SUB -> his_SUB
| Coq_is_SUBS -> his_SUBS
| Coq_is_NEG -> his_NEG
| Coq_is_MUL -> his_MUL
| Coq_is_MADD -> his_MADD
| Coq_is_MSUB -> his_MSUB
| Coq_is_SDIV -> his_SDIV
| Coq_is_UDIV -> his_UDIV
| Coq_is_AND -> his_AND
| Coq_is_ORR -> his_ORR
| Coq_is_EOR -> his_EOR
| Coq_is_MVN -> his_MVN
| Coq_is_ASR -> his_ASR
| Coq_is_LSL -> his_LSL
| Coq_is_LSR -> his_LSR
| Coq_is_ROR -> his_ROR
| Coq_is_MOV -> his_MOV
| Coq_is_MOVN -> his_MOVN
| Coq_is_MOVZ -> his_MOVZ
| Coq_is_MOVK -> his_MOVK
| Coq_is_ADR -> his_ADR
| Coq_is_SXTB -> his_SXTB
| Coq_is_SXTH -> his_SXTH
| Coq_is_SXTW -> his_SXTW
| Coq_is_UXTB -> his_UXTB
| Coq_is_UXTH -> his_UXTH
| Coq_is_UXTW -> his_UXTW
| Coq_is_CMP -> his_CMP
| Coq_is_TST -> his_TST
| Coq_is_CSEL -> his_CSEL
| Coq_is_LDR -> his_LDR
| Coq_is_LDRB -> his_LDRB
| Coq_is_LDRH -> his_LDRH
| Coq_is_LDRSB -> his_LDRSB
| Coq_is_LDRSH -> his_LDRSH
| Coq_is_LDRSW -> his_LDRSW
| Coq_is_STR -> his_STR
| Coq_is_STRB -> his_STRB
| Coq_is_STRH -> his_STRH

(** val armv8a_mnemonic_eqb_fields :
    (armv8a_mnemonic -> armv8a_mnemonic -> bool) -> positive ->
    armv8a_mnemonic_fields_t -> armv8a_mnemonic_fields_t -> bool **)

let armv8a_mnemonic_eqb_fields _ _ _ _ =
  true

(** val armv8a_mnemonic_eqb : armv8a_mnemonic -> armv8a_mnemonic -> bool **)

let armv8a_mnemonic_eqb x1 x2 =
  eqb_body armv8a_mnemonic_tag armv8a_mnemonic_fields
    (Obj.magic armv8a_mnemonic_eqb_fields (fun _ _ -> true))
    (armv8a_mnemonic_tag x1) Box_armv8a_mnemonic_ADD x2

(** val armv8a_mnemonic_eqb_OK :
    armv8a_mnemonic -> armv8a_mnemonic -> reflect **)

let armv8a_mnemonic_eqb_OK =
  iffP2 armv8a_mnemonic_eqb

(** val armv8a_mnemonic_eqb_OK_sumbool :
    armv8a_mnemonic -> armv8a_mnemonic -> bool **)

let armv8a_mnemonic_eqb_OK_sumbool =
  reflect_dec armv8a_mnemonic_eqb armv8a_mnemonic_eqb_OK

(** val eqTC_armv8a_mnemonic : armv8a_mnemonic eqTypeC **)

let eqTC_armv8a_mnemonic =
  { beq = armv8a_mnemonic_eqb; ceqP = armv8a_mnemonic_eqb_OK }

(** val armv8a_mnemonic_eqType : Equality.coq_type **)

let armv8a_mnemonic_eqType =
  ceqT_eqType eqTC_armv8a_mnemonic

(** val armv8a_mnemonics : armv8a_mnemonic list **)

let armv8a_mnemonics =
  ADD :: (ADDS :: (ADC :: (ADCS :: (SUB :: (SUBS :: (NEG :: (MUL :: (MADD :: (MSUB :: (SDIV :: (UDIV :: (AND :: (ORR :: (EOR :: (MVN :: (ASR :: (LSL :: (LSR :: (ROR :: (MOV :: (MOVN :: (MOVZ :: (MOVK :: (ADR :: (SXTB :: (SXTH :: (SXTW :: (UXTB :: (UXTH :: (UXTW :: (CMP :: (TST :: (CSEL :: (LDR :: (LDRB :: (LDRH :: (LDRSB :: (LDRSH :: (LDRSW :: (STR :: (STRB :: (STRH :: []))))))))))))))))))))))))))))))))))))))))))

(** val finTC_armv8a_mnemonic : armv8a_mnemonic finTypeC **)

let finTC_armv8a_mnemonic =
  { _eqC = eqTC_armv8a_mnemonic; cenum = armv8a_mnemonics }

(** val armv8a_mnemonic_finType : Finite.coq_type **)

let armv8a_mnemonic_finType =
  cfinT_finType finTC_armv8a_mnemonic

(** val has_shift_mnemonics : armv8a_mnemonic list **)

let has_shift_mnemonics =
  ADD :: (ADDS :: (SUB :: (SUBS :: (NEG :: (AND :: (ORR :: (EOR :: (MVN :: (CMP :: (TST :: []))))))))))

(** val ror_shift_mnemonics : armv8a_mnemonic list **)

let ror_shift_mnemonics =
  AND :: (ORR :: (EOR :: (MVN :: (TST :: []))))

(** val shift_allowed : armv8a_mnemonic -> shift_kind -> bool **)

let shift_allowed mn = function
| SROR ->
  in_mem (Obj.magic mn)
    (mem (seq_predType armv8a_mnemonic_eqType)
      (Obj.magic ror_shift_mnemonics))
| _ -> true

(** val sized_mnemonics : armv8a_mnemonic list **)

let sized_mnemonics =
  ADD :: (ADDS :: (ADC :: (ADCS :: (SUB :: (SUBS :: (NEG :: (MUL :: (MADD :: (MSUB :: (SDIV :: (UDIV :: (AND :: (ORR :: (EOR :: (MVN :: (ASR :: (LSL :: (LSR :: (ROR :: (MOV :: (MOVN :: (MOVZ :: (MOVK :: (SXTB :: (SXTH :: (UXTB :: (UXTH :: (CMP :: (TST :: (CSEL :: (LDR :: (LDRB :: (LDRH :: (LDRSB :: (LDRSH :: (STR :: (STRB :: (STRH :: []))))))))))))))))))))))))))))))))))))))

(** val wsize_uload_mn : (wsize * armv8a_mnemonic) list **)

let wsize_uload_mn =
  (U8, LDRB) :: ((U16, LDRH) :: ((U32, LDR) :: ((U64, LDR) :: [])))

(** val uload_mn_of_wsize : wsize -> armv8a_mnemonic option **)

let uload_mn_of_wsize ws =
  assoc wsize_wsize__canonical__eqtype_Equality (Obj.magic wsize_uload_mn)
    (Obj.magic ws)

(** val wsize_sload_mn : (wsize * armv8a_mnemonic) list **)

let wsize_sload_mn =
  (U8, LDRSB) :: ((U16, LDRSH) :: ((U32, LDRSW) :: []))

(** val sload_mn_of_wsize : wsize -> armv8a_mnemonic option **)

let sload_mn_of_wsize ws =
  assoc wsize_wsize__canonical__eqtype_Equality (Obj.magic wsize_sload_mn)
    (Obj.magic ws)

(** val wsize_of_sload_mn : armv8a_mnemonic -> wsize option **)

let wsize_of_sload_mn mn =
  assoc armv8a_mnemonic_eqType
    (map (fun x -> ((snd (Obj.magic x)), (fst x))) wsize_sload_mn)
    (Obj.magic mn)

(** val wsize_of_narrow_load_mn : armv8a_mnemonic -> wsize option **)

let wsize_of_narrow_load_mn = function
| LDRB -> Some U8
| LDRH -> Some U16
| LDRSB -> Some U8
| LDRSH -> Some U16
| LDRSW -> Some U32
| _ -> None

(** val wsize_store_mn : (wsize * armv8a_mnemonic) list **)

let wsize_store_mn =
  (U8, STRB) :: ((U16, STRH) :: ((U32, STR) :: ((U64, STR) :: [])))

(** val store_mn_of_wsize : wsize -> armv8a_mnemonic option **)

let store_mn_of_wsize ws =
  assoc wsize_wsize__canonical__eqtype_Equality (Obj.magic wsize_store_mn)
    (Obj.magic ws)

(** val wsize_of_narrow_store_mn : armv8a_mnemonic -> wsize option **)

let wsize_of_narrow_store_mn = function
| STRB -> Some U8
| STRH -> Some U16
| _ -> None

(** val string_of_armv8a_mnemonic : armv8a_mnemonic -> string **)

let string_of_armv8a_mnemonic = function
| ADD -> "ADD"
| ADDS -> "ADDS"
| ADC -> "ADC"
| ADCS -> "ADCS"
| SUB -> "SUB"
| SUBS -> "SUBS"
| NEG -> "NEG"
| MUL -> "MUL"
| MADD -> "MADD"
| MSUB -> "MSUB"
| SDIV -> "SDIV"
| UDIV -> "UDIV"
| AND -> "AND"
| ORR -> "ORR"
| EOR -> "EOR"
| MVN -> "MVN"
| ASR -> "ASR"
| LSL -> "LSL"
| LSR -> "LSR"
| ROR -> "ROR"
| MOV -> "MOV"
| MOVN -> "MOVN"
| MOVZ -> "MOVZ"
| MOVK -> "MOVK"
| ADR -> "ADR"
| SXTB -> "SXTB"
| SXTH -> "SXTH"
| SXTW -> "SXTW"
| UXTB -> "UXTB"
| UXTH -> "UXTH"
| UXTW -> "UXTW"
| CMP -> "CMP"
| TST -> "TST"
| CSEL -> "CSEL"
| LDR -> "LDR"
| LDRB -> "LDRB"
| LDRH -> "LDRH"
| LDRSB -> "LDRSB"
| LDRSH -> "LDRSH"
| LDRSW -> "LDRSW"
| STR -> "STR"
| STRB -> "STRB"
| STRH -> "STRH"

type armv8a_asm_op =
| ARMv8A_op of armv8a_mnemonic * armv8a_options

(** val armv8a_asm_op_rect :
    (armv8a_mnemonic -> armv8a_options -> 'a1) -> armv8a_asm_op -> 'a1 **)

let armv8a_asm_op_rect f = function
| ARMv8A_op (a0, a1) -> f a0 a1

(** val armv8a_asm_op_rec :
    (armv8a_mnemonic -> armv8a_options -> 'a1) -> armv8a_asm_op -> 'a1 **)

let armv8a_asm_op_rec f = function
| ARMv8A_op (a0, a1) -> f a0 a1

type is_armv8a_asm_op =
| Coq_is_ARMv8A_op of armv8a_mnemonic * is_armv8a_mnemonic * armv8a_options
   * is_armv8a_options

(** val is_armv8a_asm_op_rect :
    (armv8a_mnemonic -> is_armv8a_mnemonic -> armv8a_options ->
    is_armv8a_options -> 'a1) -> armv8a_asm_op -> is_armv8a_asm_op -> 'a1 **)

let is_armv8a_asm_op_rect f _ = function
| Coq_is_ARMv8A_op (a, p_, a0, p_0) -> f a p_ a0 p_0

(** val is_armv8a_asm_op_rec :
    (armv8a_mnemonic -> is_armv8a_mnemonic -> armv8a_options ->
    is_armv8a_options -> 'a1) -> armv8a_asm_op -> is_armv8a_asm_op -> 'a1 **)

let is_armv8a_asm_op_rec f _ = function
| Coq_is_ARMv8A_op (a, p_, a0, p_0) -> f a p_ a0 p_0

(** val armv8a_asm_op_tag : armv8a_asm_op -> positive **)

let armv8a_asm_op_tag _ =
  Coq_xH

(** val is_armv8a_asm_op_inhab : armv8a_asm_op -> is_armv8a_asm_op **)

let is_armv8a_asm_op_inhab = function
| ARMv8A_op (h, h0) ->
  Coq_is_ARMv8A_op (h, (is_armv8a_mnemonic_inhab h), h0,
    (is_armv8a_options_inhab h0))

(** val is_armv8a_asm_op_functor :
    armv8a_asm_op -> is_armv8a_asm_op -> is_armv8a_asm_op **)

let rec is_armv8a_asm_op_functor _ x =
  x

type box_armv8a_asm_op_ARMv8A_op = { coq_Box_armv8a_asm_op_ARMv8A_op_0 : 
                                     armv8a_mnemonic;
                                     coq_Box_armv8a_asm_op_ARMv8A_op_1 : 
                                     armv8a_options }

(** val coq_Box_armv8a_asm_op_ARMv8A_op_0 :
    box_armv8a_asm_op_ARMv8A_op -> armv8a_mnemonic **)

let coq_Box_armv8a_asm_op_ARMv8A_op_0 record =
  record.coq_Box_armv8a_asm_op_ARMv8A_op_0

(** val coq_Box_armv8a_asm_op_ARMv8A_op_1 :
    box_armv8a_asm_op_ARMv8A_op -> armv8a_options **)

let coq_Box_armv8a_asm_op_ARMv8A_op_1 record =
  record.coq_Box_armv8a_asm_op_ARMv8A_op_1

type armv8a_asm_op_fields_t = box_armv8a_asm_op_ARMv8A_op

(** val armv8a_asm_op_fields : armv8a_asm_op -> armv8a_asm_op_fields_t **)

let armv8a_asm_op_fields = function
| ARMv8A_op (h, h0) ->
  { coq_Box_armv8a_asm_op_ARMv8A_op_0 = h;
    coq_Box_armv8a_asm_op_ARMv8A_op_1 = h0 }

(** val armv8a_asm_op_construct :
    positive -> box_armv8a_asm_op_ARMv8A_op -> armv8a_asm_op option **)

let armv8a_asm_op_construct _ b =
  let { coq_Box_armv8a_asm_op_ARMv8A_op_0 = box_armv8a_asm_op_ARMv8A_op_0;
    coq_Box_armv8a_asm_op_ARMv8A_op_1 = box_armv8a_asm_op_ARMv8A_op_1 } = b
  in
  Some (ARMv8A_op (box_armv8a_asm_op_ARMv8A_op_0,
  box_armv8a_asm_op_ARMv8A_op_1))

(** val armv8a_asm_op_induction :
    (armv8a_mnemonic -> is_armv8a_mnemonic -> armv8a_options ->
    is_armv8a_options -> 'a1) -> armv8a_asm_op -> is_armv8a_asm_op -> 'a1 **)

let armv8a_asm_op_induction his_ARMv8A_op _ = function
| Coq_is_ARMv8A_op (x0, p_, x1, p_0) -> his_ARMv8A_op x0 p_ x1 p_0

(** val armv8a_asm_op_eqb_fields :
    (armv8a_asm_op -> armv8a_asm_op -> bool) -> positive ->
    box_armv8a_asm_op_ARMv8A_op -> box_armv8a_asm_op_ARMv8A_op -> bool **)

let armv8a_asm_op_eqb_fields _ _ a b =
  let { coq_Box_armv8a_asm_op_ARMv8A_op_0 = box_armv8a_asm_op_ARMv8A_op_0;
    coq_Box_armv8a_asm_op_ARMv8A_op_1 = box_armv8a_asm_op_ARMv8A_op_1 } = a
  in
  let { coq_Box_armv8a_asm_op_ARMv8A_op_0 = box_armv8a_asm_op_ARMv8A_op_2;
    coq_Box_armv8a_asm_op_ARMv8A_op_1 = box_armv8a_asm_op_ARMv8A_op_3 } = b
  in
  (&&)
    (armv8a_mnemonic_eqb box_armv8a_asm_op_ARMv8A_op_0
      box_armv8a_asm_op_ARMv8A_op_2)
    ((&&)
      (armv8a_options_eqb box_armv8a_asm_op_ARMv8A_op_1
        box_armv8a_asm_op_ARMv8A_op_3)
      true)

(** val armv8a_asm_op_eqb : armv8a_asm_op -> armv8a_asm_op -> bool **)

let armv8a_asm_op_eqb x1 x2 =
  let ARMv8A_op (h, h0) = x1 in
  eqb_body armv8a_asm_op_tag armv8a_asm_op_fields
    (armv8a_asm_op_eqb_fields (fun _ _ -> true))
    (armv8a_asm_op_tag (ARMv8A_op (h, h0)))
    { coq_Box_armv8a_asm_op_ARMv8A_op_0 = h;
    coq_Box_armv8a_asm_op_ARMv8A_op_1 = h0 } x2

(** val armv8a_asm_op_eqb_OK : armv8a_asm_op -> armv8a_asm_op -> reflect **)

let armv8a_asm_op_eqb_OK =
  iffP2 armv8a_asm_op_eqb

(** val armv8a_asm_op_eqb_OK_sumbool :
    armv8a_asm_op -> armv8a_asm_op -> bool **)

let armv8a_asm_op_eqb_OK_sumbool =
  reflect_dec armv8a_asm_op_eqb armv8a_asm_op_eqb_OK

(** val eqTC_armv8a_asm_op : armv8a_asm_op eqTypeC **)

let eqTC_armv8a_asm_op =
  { beq = armv8a_asm_op_eqb; ceqP = armv8a_asm_op_eqb_OK }

(** val armv8a_asm_op_eqType : Equality.coq_type **)

let armv8a_asm_op_eqType =
  ceqT_eqType eqTC_armv8a_asm_op

(** val ad_nzcv :
    (register, empty, empty, rflag, condt) Arch_decl.arg_desc list **)

let ad_nzcv =
  map (coq_F armv8a_decl) (NF :: (ZF :: (CF :: (VF :: []))))

(** val coq_NF_of_word : wsize -> word -> bool **)

let coq_NF_of_word =
  msb

(** val coq_ZF_of_word : wsize -> word -> bool **)

let coq_ZF_of_word ws w =
  eq_op (word_word__canonical__eqtype_Equality ws) (Obj.magic w)
    (Obj.magic word0 ws)

(** val nzcv_of_aluop : wsize -> word -> coq_Z -> coq_Z -> sem_tuple **)

let nzcv_of_aluop ws res res_unsigned res_signed =
  Obj.magic ((Some (coq_NF_of_word ws res)), ((Some (coq_ZF_of_word ws res)),
    ((Some
    (negb
      (eq_op coq_BinNums_Z__canonical__eqtype_Equality
        (Obj.magic wunsigned ws res) (Obj.magic res_unsigned)))),
    (Some
    (negb
      (eq_op coq_BinNums_Z__canonical__eqtype_Equality
        (Obj.magic wsigned ws res) (Obj.magic res_signed)))))))

(** val nzcv_of_logop : wsize -> word -> sem_tuple **)

let nzcv_of_logop ws res =
  Obj.magic ((Some (coq_NF_of_word ws res)), ((Some (coq_ZF_of_word ws res)),
    ((Some false), (Some false))))

(** val nzcv_w_of_aluop : wsize -> word -> coq_Z -> coq_Z -> ltuple **)

let nzcv_w_of_aluop ws w wun wsi =
  merge_tuple
    (map (Obj.magic __)
      (map eval_ltype
        (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: []))))))
    (map (Obj.magic __) (map eval_ltype ((Coq_lword ws) :: [])))
    (nzcv_of_aluop ws w wun wsi) (Obj.magic w)

(** val nzcv_w_of_logop : wsize -> word -> ltuple **)

let nzcv_w_of_logop ws w =
  merge_tuple
    (map (Obj.magic __)
      (map eval_ltype
        (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: []))))))
    (map (Obj.magic __) (map eval_ltype ((Coq_lword ws) :: [])))
    (nzcv_of_logop ws w) (Obj.magic w)

(** val mk_semi1_shifted :
    wsize -> shift_kind -> 'a1 exec sem_prod -> 'a1 exec sem_prod **)

let mk_semi1_shifted ws sk semi =
  Obj.magic (fun wn shift_amount ->
    let sham = wunsigned U8 shift_amount in
    Obj.magic semi (shift_op sk ws wn sham))

(** val mk_semi2_2_shifted :
    ltype -> wsize -> shift_kind -> 'a1 exec sem_prod -> 'a1 exec sem_prod **)

let mk_semi2_2_shifted _ ws sk semi =
  Obj.magic (fun x wm shift_amount ->
    let sham = wunsigned U8 shift_amount in
    Obj.magic semi x (shift_op sk ws wm sham))

(** val args_kinds_no_imm :
    (register, empty, empty, rflag, condt) args_kinds -> bool **)

let args_kinds_no_imm x =
  negb (has (has (fun k -> match k with
                           | CAimm (_, _) -> true
                           | _ -> false)) x)

(** val mk_shifted :
    wsize -> shift_kind -> armv8a_mnemonic -> (register, empty, empty, rflag,
    condt) instr_desc_t -> semi_type -> (register, empty, empty, rflag,
    condt) instr_desc_t **)

let mk_shifted ws sk mn idt semi' =
  { id_valid = ((&&) idt.id_valid (shift_allowed mn sk)); id_msb_flag =
    idt.id_msb_flag; id_tin = (cat idt.id_tin ((Coq_lword U8) :: []));
    id_in = (cat idt.id_in ((coq_Ea armv8a_decl idt.id_nargs) :: []));
    id_tout = idt.id_tout; id_out = idt.id_out; id_semi = semi';
    id_args_kinds =
    (map (fun x ->
      cat x (((CAimm ((Some (Obj.magic (CAimmC_armv8a_shift_amount ws))),
        U8)) :: []) :: []))
      (filter args_kinds_no_imm idt.id_args_kinds));
    id_nargs = (S idt.id_nargs); id_str_jas = idt.id_str_jas; id_safe =
    idt.id_safe; id_doit = idt.id_doit; id_pp_asm = idt.id_pp_asm }

(** val pp_armv8a_op :
    armv8a_mnemonic -> armv8a_options -> (register, empty, empty, rflag,
    condt) asm_arg list -> (register, empty, empty, rflag, condt) pp_asm_op **)

let pp_armv8a_op mn opts args =
  { pp_aop_name = (string_of_armv8a_mnemonic mn); pp_aop_ext = PP_name;
    pp_aop_args = (map (fun a -> (opts.opts_size, a)) args) }

(** val pp_armv8a_op_szs :
    armv8a_mnemonic -> wsize list -> (register, empty, empty, rflag, condt)
    asm_arg list -> (register, empty, empty, rflag, condt) pp_asm_op **)

let pp_armv8a_op_szs mn szs args =
  { pp_aop_name = (string_of_armv8a_mnemonic mn); pp_aop_ext = PP_name;
    pp_aop_args = (zip szs args) }

(** val mk_arith_instr :
    armv8a_options -> armv8a_mnemonic -> armv8a_caimm_cond option -> (word ->
    word -> sem_tuple) -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_arith_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrr_or_imm = fun ick ->
    match ick with
    | Some ic ->
      cat (ak_reg_reg_reg armv8a_decl)
        (((CAreg :: []) :: ((CAreg :: []) :: (((CAimm ((Some ic),
        opts.opts_size)) :: []) :: []))) :: [])
    | None -> ak_reg_reg_reg armv8a_decl
  in
  (fun mn ick semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword opts.opts_size) :: [])
  in
  let x = { id_valid =
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)));
    id_msb_flag =
    (if eq_op wsize_wsize__canonical__eqtype_Equality
          (Obj.magic opts.opts_size) (Obj.magic U64)
     then MSB_MERGE
     else MSB_CLEAR);
    id_tin = tin; id_in =
    ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: []));
    id_tout = ((Coq_lword opts.opts_size) :: []); id_out =
    ((coq_Ea armv8a_decl O) :: []); id_semi =
    (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
    (Obj.magic ak_rrr_or_imm ick); id_nargs = (S (S (S O))); id_str_jas =
    (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
    (pp_armv8a_op mn opts) }
  in
  (match opts.has_shift with
   | Some sk ->
     mk_shifted opts.opts_size sk mn x
       (mk_semi2_2_shifted (Coq_lword opts.opts_size) opts.opts_size sk
         x.id_semi)
   | None -> x))

(** val mk_ariths_instr :
    armv8a_options -> armv8a_mnemonic -> armv8a_caimm_cond option -> (word ->
    word -> sem_tuple) -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_ariths_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrr_or_imm = fun ick ->
    match ick with
    | Some ic ->
      cat (ak_reg_reg_reg armv8a_decl)
        (((CAreg :: []) :: ((CAreg :: []) :: (((CAimm ((Some ic),
        opts.opts_size)) :: []) :: []))) :: [])
    | None -> ak_reg_reg_reg armv8a_decl
  in
  (fun mn ick semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword opts.opts_size) :: [])
  in
  let x = { id_valid =
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)));
    id_msb_flag =
    (if eq_op wsize_wsize__canonical__eqtype_Equality
          (Obj.magic opts.opts_size) (Obj.magic U64)
     then MSB_MERGE
     else MSB_CLEAR);
    id_tin = tin; id_in =
    ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: []));
    id_tout =
    (cat (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: []))))
      ((Coq_lword opts.opts_size) :: []));
    id_out = (cat ad_nzcv ((coq_Ea armv8a_decl O) :: [])); id_semi =
    (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
    (Obj.magic ak_rrr_or_imm ick); id_nargs = (S (S (S O))); id_str_jas =
    (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
    (pp_armv8a_op mn opts) }
  in
  (match opts.has_shift with
   | Some sk ->
     mk_shifted opts.opts_size sk mn x
       (mk_semi2_2_shifted (Coq_lword opts.opts_size) opts.opts_size sk
         x.id_semi)
   | None -> x))

(** val armv8a_ADD_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_ADD_semi ws wn wm =
  Obj.magic add_word ws wn wm

(** val armv8a_ADD_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ADD_instr opts =
  mk_arith_instr opts ADD (Some CAimmC_armv8a_arith_imm)
    (armv8a_ADD_semi opts.opts_size)

(** val armv8a_ADDS_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_ADDS_semi ws wn wm =
  nzcv_w_of_aluop ws (add_word ws wn wm)
    (Z.add (wunsigned ws wn) (wunsigned ws wm))
    (Z.add (wsigned ws wn) (wsigned ws wm))

(** val armv8a_ADDS_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ADDS_instr opts =
  mk_ariths_instr opts ADDS (Some CAimmC_armv8a_arith_imm)
    (armv8a_ADDS_semi opts.opts_size)

(** val armv8a_SUB_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_SUB_semi ws wn wm =
  Obj.magic sub_word ws wn wm

(** val armv8a_SUB_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_SUB_instr opts =
  mk_arith_instr opts SUB (Some CAimmC_armv8a_arith_imm)
    (armv8a_SUB_semi opts.opts_size)

(** val armv8a_SUBS_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_SUBS_semi ws wn wm =
  let wmnot = wnot ws wm in
  nzcv_w_of_aluop ws (add_word ws (add_word ws wn wmnot) (word1 ws))
    (Z.add (Z.add (wunsigned ws wn) (wunsigned ws wmnot)) (Zpos Coq_xH))
    (Z.add (Z.add (wsigned ws wn) (wsigned ws wmnot)) (Zpos Coq_xH))

(** val armv8a_SUBS_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_SUBS_instr opts =
  mk_ariths_instr opts SUBS (Some CAimmC_armv8a_arith_imm)
    (armv8a_SUBS_semi opts.opts_size)

(** val mk_carry_instr :
    armv8a_options -> armv8a_mnemonic -> (word -> word -> bool -> sem_tuple)
    -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_carry_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrr = ak_reg_reg_reg armv8a_decl in
  (fun mn semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword
    opts.opts_size) :: (Coq_lbool :: []))
  in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: (
  (coq_F armv8a_decl CF) :: []))); id_tout = ((Coq_lword
  opts.opts_size) :: []); id_out = ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  ak_rrr; id_nargs = (S (S (S O))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op mn opts) })

(** val mk_carrys_instr :
    armv8a_options -> armv8a_mnemonic -> (word -> word -> bool -> sem_tuple)
    -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_carrys_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrr = ak_reg_reg_reg armv8a_decl in
  (fun mn semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword
    opts.opts_size) :: (Coq_lbool :: []))
  in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: (
  (coq_F armv8a_decl CF) :: []))); id_tout =
  (cat (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: []))))
    ((Coq_lword opts.opts_size) :: []));
  id_out = (cat ad_nzcv ((coq_Ea armv8a_decl O) :: [])); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  ak_rrr; id_nargs = (S (S (S O))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op mn opts) })

(** val armv8a_ADC_semi : wsize -> word -> word -> bool -> sem_tuple **)

let armv8a_ADC_semi ws wn wm cf =
  let c = Z.b2z cf in Obj.magic add_word ws (add_word ws wn wm) (wrepr ws c)

(** val armv8a_ADC_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ADC_instr opts =
  mk_carry_instr opts ADC (armv8a_ADC_semi opts.opts_size)

(** val armv8a_ADCS_semi : wsize -> word -> word -> bool -> sem_tuple **)

let armv8a_ADCS_semi ws wn wm cf =
  let c = Z.b2z cf in
  nzcv_w_of_aluop ws (add_word ws (add_word ws wn wm) (wrepr ws c))
    (Z.add (Z.add (wunsigned ws wn) (wunsigned ws wm)) c)
    (Z.add (Z.add (wsigned ws wn) (wsigned ws wm)) c)

(** val armv8a_ADCS_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ADCS_instr opts =
  mk_carrys_instr opts ADCS (armv8a_ADCS_semi opts.opts_size)

(** val armv8a_NEG_semi : wsize -> word -> sem_tuple **)

let armv8a_NEG_semi ws wm =
  Obj.magic add_word ws (wnot ws wm) (word1 ws)

(** val armv8a_NEG_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_NEG_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rr = ak_reg_reg armv8a_decl in
  let mn = NEG in
  let tin = (Coq_lword opts.opts_size) :: [] in
  let semi = armv8a_NEG_semi opts.opts_size in
  let x = { id_valid =
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)));
    id_msb_flag =
    (if eq_op wsize_wsize__canonical__eqtype_Equality
          (Obj.magic opts.opts_size) (Obj.magic U64)
     then MSB_MERGE
     else MSB_CLEAR);
    id_tin = tin; id_in = ((coq_Ea armv8a_decl (S O)) :: []); id_tout =
    ((Coq_lword opts.opts_size) :: []); id_out =
    ((coq_Ea armv8a_decl O) :: []); id_semi =
    (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
    ak_rr; id_nargs = (S (S O)); id_str_jas = (Obj.magic armv8a_mn_str mn);
    id_safe = []; id_doit = DOIT; id_pp_asm = (pp_armv8a_op mn opts) }
  in
  (match opts.has_shift with
   | Some sk ->
     mk_shifted opts.opts_size sk mn x
       (mk_semi1_shifted opts.opts_size sk x.id_semi)
   | None -> x)

(** val mk_rrr_instr :
    armv8a_options -> armv8a_mnemonic -> doit_t -> (word -> word ->
    sem_tuple) -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_rrr_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrr = ak_reg_reg_reg armv8a_decl in
  (fun mn doit_v semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword opts.opts_size) :: [])
  in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: []));
  id_tout = ((Coq_lword opts.opts_size) :: []); id_out =
  ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  ak_rrr; id_nargs = (S (S (S O))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = doit_v; id_pp_asm =
  (pp_armv8a_op mn opts) })

(** val armv8a_MUL_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_MUL_semi ws wn wm =
  Obj.magic mul_word ws wn wm

(** val armv8a_MUL_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MUL_instr opts =
  mk_rrr_instr opts MUL DOIT (armv8a_MUL_semi opts.opts_size)

(** val armv8a_SDIV_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_SDIV_semi ws wn wm =
  Obj.magic wdivi ws wn wm

(** val armv8a_SDIV_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_SDIV_instr opts =
  mk_rrr_instr opts SDIV NOT_DOIT (armv8a_SDIV_semi opts.opts_size)

(** val armv8a_UDIV_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_UDIV_semi ws wn wm =
  Obj.magic wdiv ws wn wm

(** val armv8a_UDIV_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_UDIV_instr opts =
  mk_rrr_instr opts UDIV NOT_DOIT (armv8a_UDIV_semi opts.opts_size)

(** val mk_madd_instr :
    armv8a_options -> armv8a_mnemonic -> (word -> word -> word -> sem_tuple)
    -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_madd_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrrr = ak_reg_reg_reg_reg armv8a_decl in
  (fun mn semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword
    opts.opts_size) :: ((Coq_lword opts.opts_size) :: []))
  in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: (
  (coq_Ea armv8a_decl (S (S (S O)))) :: []))); id_tout = ((Coq_lword
  opts.opts_size) :: []); id_out = ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  ak_rrrr; id_nargs = (S (S (S (S O)))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op mn opts) })

(** val armv8a_MADD_semi : wsize -> word -> word -> word -> sem_tuple **)

let armv8a_MADD_semi ws wn wm wa =
  Obj.magic add_word ws wa (mul_word ws wn wm)

(** val armv8a_MADD_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MADD_instr opts =
  mk_madd_instr opts MADD (armv8a_MADD_semi opts.opts_size)

(** val armv8a_MSUB_semi : wsize -> word -> word -> word -> sem_tuple **)

let armv8a_MSUB_semi ws wn wm wa =
  Obj.magic sub_word ws wa (mul_word ws wn wm)

(** val armv8a_MSUB_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MSUB_instr opts =
  mk_madd_instr opts MSUB (armv8a_MSUB_semi opts.opts_size)

(** val armv8a_bitwise_semi :
    wsize -> (word -> word) -> (word -> word) -> (word -> word -> word) ->
    word -> word -> sem_tuple **)

let armv8a_bitwise_semi _ op0 op1 op wn wm =
  Obj.magic op (op0 wn) (op1 wm)

(** val armv8a_AND_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_AND_instr opts =
  mk_arith_instr opts AND (Some CAimmC_armv8a_bitmask_imm)
    (armv8a_bitwise_semi opts.opts_size (fun x -> x) (fun x -> x)
      (wand opts.opts_size))

(** val armv8a_ORR_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ORR_instr opts =
  mk_arith_instr opts ORR (Some CAimmC_armv8a_bitmask_imm)
    (armv8a_bitwise_semi opts.opts_size (fun x -> x) (fun x -> x)
      (wor opts.opts_size))

(** val armv8a_EOR_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_EOR_instr opts =
  mk_arith_instr opts EOR (Some CAimmC_armv8a_bitmask_imm)
    (armv8a_bitwise_semi opts.opts_size (fun x -> x) (fun x -> x)
      (wxor opts.opts_size))

(** val armv8a_MVN_semi : wsize -> word -> sem_tuple **)

let armv8a_MVN_semi ws wm =
  Obj.magic wnot ws wm

(** val armv8a_MVN_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MVN_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rr = ak_reg_reg armv8a_decl in
  let mn = MVN in
  let tin = (Coq_lword opts.opts_size) :: [] in
  let semi = armv8a_MVN_semi opts.opts_size in
  let x = { id_valid =
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)));
    id_msb_flag =
    (if eq_op wsize_wsize__canonical__eqtype_Equality
          (Obj.magic opts.opts_size) (Obj.magic U64)
     then MSB_MERGE
     else MSB_CLEAR);
    id_tin = tin; id_in = ((coq_Ea armv8a_decl (S O)) :: []); id_tout =
    ((Coq_lword opts.opts_size) :: []); id_out =
    ((coq_Ea armv8a_decl O) :: []); id_semi =
    (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
    ak_rr; id_nargs = (S (S O)); id_str_jas = (Obj.magic armv8a_mn_str mn);
    id_safe = []; id_doit = DOIT; id_pp_asm = (pp_armv8a_op mn opts) }
  in
  (match opts.has_shift with
   | Some sk ->
     mk_shifted opts.opts_size sk mn x
       (mk_semi1_shifted opts.opts_size sk x.id_semi)
   | None -> x)

(** val armv8a_shift_semi :
    wsize -> (wsize -> word -> coq_Z -> word) -> word -> word -> sem_tuple **)

let armv8a_shift_semi ws op wn wsham =
  let sham = Z.modulo (wunsigned U8 wsham) (wsize_bits ws) in
  Obj.magic op ws wn sham

(** val mk_shift_instr :
    armv8a_options -> armv8a_mnemonic -> (wsize -> word -> coq_Z -> word) ->
    (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_shift_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrr = ak_reg_reg_reg armv8a_decl in
  let ak_rr_imm_shift = ((CAreg :: []) :: ((CAreg :: []) :: (((CAimm ((Some
    (Obj.magic (CAimmC_armv8a_shift_amount opts.opts_size))),
    U8)) :: []) :: []))) :: []
  in
  (fun mn op ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword U8) :: []) in
  let semi = armv8a_shift_semi opts.opts_size op in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: []));
  id_tout = ((Coq_lword opts.opts_size) :: []); id_out =
  ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  (cat ak_rrr ak_rr_imm_shift); id_nargs = (S (S (S O))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op mn opts) })

(** val armv8a_ASR_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ASR_instr opts =
  mk_shift_instr opts ASR wsar

(** val armv8a_LSL_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_LSL_instr opts =
  mk_shift_instr opts LSL wshl

(** val armv8a_LSR_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_LSR_instr opts =
  mk_shift_instr opts LSR wshr

(** val armv8a_ROR_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ROR_instr opts =
  mk_shift_instr opts ROR wror

(** val armv8a_MOV_semi : wsize -> word -> sem_tuple **)

let armv8a_MOV_semi _ wn =
  Obj.magic wn

(** val armv8a_MOV_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MOV_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let mn = MOV in
  let tin = (Coq_lword opts.opts_size) :: [] in
  let semi = armv8a_MOV_semi opts.opts_size in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in = ((coq_Ea armv8a_decl (S O)) :: []); id_tout =
  ((Coq_lword opts.opts_size) :: []); id_out =
  ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  (cat (ak_reg_reg armv8a_decl) (((CAreg :: []) :: (((CAimm ((Some
    (Obj.magic CAimmC_armv8a_mov_imm)),
    opts.opts_size)) :: []) :: [])) :: []));
  id_nargs = (S (S O)); id_str_jas = (Obj.magic armv8a_mn_str mn); id_safe =
  []; id_doit = DOIT; id_pp_asm = (pp_armv8a_op mn opts) }

(** val mk_movw_instr :
    armv8a_options -> armv8a_mnemonic -> (word -> word -> sem_tuple) ->
    (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_movw_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_r_imm16_shift =
    ((CAreg :: []) :: (((coq_CAimm_sz armv8a_decl U16) :: []) :: (((CAimm
    ((Some (Obj.magic (CAimmC_armv8a_halfword_shift opts.opts_size))),
    U8)) :: []) :: []))) :: []
  in
  (fun mn semi ->
  let tin = (Coq_lword U16) :: ((Coq_lword U8) :: []) in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: []));
  id_tout = ((Coq_lword opts.opts_size) :: []); id_out =
  ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  ak_r_imm16_shift; id_nargs = (S (S (S O))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op mn opts) })

(** val armv8a_MOVZ_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_MOVZ_semi ws imm wsh =
  Obj.magic wshl ws (zero_extend ws U16 imm) (wunsigned U8 wsh)

(** val armv8a_MOVZ_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MOVZ_instr opts =
  mk_movw_instr opts MOVZ (armv8a_MOVZ_semi opts.opts_size)

(** val armv8a_MOVN_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_MOVN_semi ws imm wsh =
  Obj.magic wnot ws (wshl ws (zero_extend ws U16 imm) (wunsigned U8 wsh))

(** val armv8a_MOVN_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MOVN_instr opts =
  mk_movw_instr opts MOVN (armv8a_MOVN_semi opts.opts_size)

(** val armv8a_MOVK_semi : wsize -> word -> word -> word -> sem_tuple **)

let armv8a_MOVK_semi ws old imm wsh =
  let sh = wunsigned U8 wsh in
  let mask = wshl ws (zero_extend ws U16 (wrepr U16 (Zneg Coq_xH))) sh in
  Obj.magic wor ws (wshl ws (zero_extend ws U16 imm) sh)
    (wand ws old (wnot ws mask))

(** val armv8a_MOVK_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_MOVK_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_r_imm16_shift =
    ((CAreg :: []) :: (((coq_CAimm_sz armv8a_decl U16) :: []) :: (((CAimm
    ((Some (Obj.magic (CAimmC_armv8a_halfword_shift opts.opts_size))),
    U8)) :: []) :: []))) :: []
  in
  let mn = MOVK in
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword U16) :: ((Coq_lword
    U8) :: []))
  in
  let semi = armv8a_MOVK_semi opts.opts_size in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl O) :: ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea
                                                               armv8a_decl (S
                                                               (S O))) :: [])));
  id_tout = ((Coq_lword opts.opts_size) :: []); id_out =
  ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  ak_r_imm16_shift; id_nargs = (S (S (S O))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op mn opts) }

(** val armv8a_extend_semi : wsize -> bool -> wsize -> word -> word **)

let armv8a_extend_semi ws sign ws' wn =
  if sign then sign_extend ws' ws wn else zero_extend ws' ws wn

(** val mk_extend_instr :
    armv8a_options -> armv8a_mnemonic -> wsize -> bool -> bool -> (register,
    empty, empty, rflag, condt) instr_desc_t **)

let mk_extend_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  (fun mn in_ws sign valid ->
  let tin = (Coq_lword in_ws) :: [] in
  let semi = armv8a_extend_semi in_ws sign opts.opts_size in
  { id_valid = valid; id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in = ((coq_Ea armv8a_decl (S O)) :: []); id_tout =
  ((Coq_lword opts.opts_size) :: []); id_out =
  ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  (ak_reg_reg armv8a_decl); id_nargs = (S (S O)); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op_szs mn
    ((if sign then opts.opts_size else U32) :: (U32 :: []))) })

(** val armv8a_ADR_semi : word -> sem_tuple **)

let armv8a_ADR_semi wn =
  Obj.magic wn

(** val armv8a_ADR_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_ADR_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let mn = ADR in
  let tin = (lreg armv8a_decl) :: [] in
  { id_valid =
  (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
    (Obj.magic U64));
  id_msb_flag = MSB_MERGE; id_tin = tin; id_in =
  ((coq_Ec armv8a_decl (S O)) :: []); id_tout = ((lreg armv8a_decl) :: []);
  id_out = ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic armv8a_ADR_semi));
  id_args_kinds = (ak_reg_addr armv8a_decl); id_nargs = (S (S O));
  id_str_jas = (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit =
  NOT_DOIT; id_pp_asm = (pp_armv8a_op mn opts) }

(** val armv8a_SXTB_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_SXTB_instr opts =
  mk_extend_instr opts SXTB U8 true
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)))

(** val armv8a_SXTH_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_SXTH_instr opts =
  mk_extend_instr opts SXTH U16 true
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)))

(** val armv8a_SXTW_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_SXTW_instr opts =
  mk_extend_instr opts SXTW U32 true
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64))

(** val armv8a_UXTB_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_UXTB_instr opts =
  mk_extend_instr opts UXTB U8 false
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)))

(** val armv8a_UXTH_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_UXTH_instr opts =
  mk_extend_instr opts UXTH U16 false
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)))

(** val armv8a_UXTW_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_UXTW_instr opts =
  mk_extend_instr opts UXTW U32 false
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64))

(** val mk_cmp_instr :
    armv8a_options -> armv8a_mnemonic -> armv8a_caimm_cond option -> (word ->
    word -> sem_tuple) -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_cmp_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rr_or_imm = fun ick ->
    match ick with
    | Some ic ->
      cat (ak_reg_reg armv8a_decl) (((CAreg :: []) :: (((CAimm ((Some ic),
        opts.opts_size)) :: []) :: [])) :: [])
    | None -> ak_reg_reg armv8a_decl
  in
  (fun mn ick semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword opts.opts_size) :: [])
  in
  let x = { id_valid =
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)));
    id_msb_flag = MSB_MERGE; id_tin = tin; id_in =
    ((coq_Ea armv8a_decl O) :: ((coq_Ea armv8a_decl (S O)) :: [])); id_tout =
    (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: (Coq_lbool :: [])))); id_out =
    ad_nzcv; id_semi = (sem_prod_ok (map eval_ltype tin) (Obj.magic semi));
    id_args_kinds = (Obj.magic ak_rr_or_imm ick); id_nargs = (S (S O));
    id_str_jas = (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT;
    id_pp_asm = (pp_armv8a_op mn opts) }
  in
  (match opts.has_shift with
   | Some sk ->
     mk_shifted opts.opts_size sk mn x
       (mk_semi2_2_shifted (Coq_lword opts.opts_size) opts.opts_size sk
         x.id_semi)
   | None -> x))

(** val armv8a_CMP_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_CMP_semi ws wn wm =
  let wmnot = wnot ws wm in
  nzcv_of_aluop ws (add_word ws (add_word ws wn wmnot) (word1 ws))
    (Z.add (Z.add (wunsigned ws wn) (wunsigned ws wmnot)) (Zpos Coq_xH))
    (Z.add (Z.add (wsigned ws wn) (wsigned ws wmnot)) (Zpos Coq_xH))

(** val armv8a_CMP_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_CMP_instr opts =
  mk_cmp_instr opts CMP (Some CAimmC_armv8a_arith_imm)
    (armv8a_CMP_semi opts.opts_size)

(** val armv8a_TST_semi : wsize -> word -> word -> sem_tuple **)

let armv8a_TST_semi ws wn wm =
  nzcv_of_logop ws (wand ws wn wm)

(** val armv8a_TST_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_TST_instr opts =
  mk_cmp_instr opts TST (Some CAimmC_armv8a_bitmask_imm)
    (armv8a_TST_semi opts.opts_size)

(** val mk_csel_instr :
    armv8a_options -> armv8a_mnemonic -> (word -> word -> bool -> sem_tuple)
    -> (register, empty, empty, rflag, condt) instr_desc_t **)

let mk_csel_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  let ak_rrr_cond =
    ((CAreg :: []) :: ((CAreg :: []) :: ((CAreg :: []) :: ((CAcond :: []) :: [])))) :: []
  in
  (fun mn semi ->
  let tin = (Coq_lword opts.opts_size) :: ((Coq_lword
    opts.opts_size) :: (Coq_lbool :: []))
  in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in =
  ((coq_Ea armv8a_decl (S O)) :: ((coq_Ea armv8a_decl (S (S O))) :: (
  (coq_Ea armv8a_decl (S (S (S O)))) :: []))); id_tout = ((Coq_lword
  opts.opts_size) :: []); id_out = ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  ak_rrr_cond; id_nargs = (S (S (S (S O)))); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op mn opts) })

(** val armv8a_CSEL_semi : wsize -> word -> word -> bool -> sem_tuple **)

let armv8a_CSEL_semi _ wn wm = function
| true -> Obj.magic wn
| false -> Obj.magic wm

(** val armv8a_CSEL_instr :
    armv8a_options -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_CSEL_instr opts =
  mk_csel_instr opts CSEL (armv8a_CSEL_semi opts.opts_size)

(** val armv8a_load_instr :
    armv8a_options -> armv8a_mnemonic -> (register, empty, empty, rflag,
    condt) instr_desc_t **)

let armv8a_load_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  (fun mn ->
  let wacc =
    match wsize_of_narrow_load_mn mn with
    | Some ws' -> ws'
    | None -> opts.opts_size
  in
  let tin = (Coq_lword wacc) :: [] in
  let semi =
    armv8a_extend_semi wacc (isSome (wsize_of_sload_mn mn)) opts.opts_size
  in
  { id_valid =
  ((&&)
    ((||)
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U32))
      (eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)))
    (match mn with
     | LDRSW ->
       eq_op wsize_wsize__canonical__eqtype_Equality
         (Obj.magic opts.opts_size) (Obj.magic U64)
     | _ -> true));
  id_msb_flag =
  (if eq_op wsize_wsize__canonical__eqtype_Equality
        (Obj.magic opts.opts_size) (Obj.magic U64)
   then MSB_MERGE
   else MSB_CLEAR);
  id_tin = tin; id_in = ((coq_Eu armv8a_decl (S O)) :: []); id_tout =
  ((Coq_lword opts.opts_size) :: []); id_out =
  ((coq_Ea armv8a_decl O) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  (ak_reg_addr armv8a_decl); id_nargs = (S (S O)); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op_szs mn
    ((match mn with
      | LDRB -> U32
      | LDRH -> U32
      | _ -> opts.opts_size) :: (opts.opts_size :: []))) })

(** val armv8a_store_instr :
    armv8a_options -> armv8a_mnemonic -> (register, empty, empty, rflag,
    condt) instr_desc_t **)

let armv8a_store_instr opts =
  let armv8a_mn_str = fun mn ->
    if in_mem mn
         (mem (seq_predType armv8a_mnemonic_eqType)
           (Obj.magic sized_mnemonics))
    then pp_sz (Obj.magic string_of_armv8a_mnemonic mn) opts.opts_size
    else pp_s (Obj.magic string_of_armv8a_mnemonic mn)
  in
  (fun mn ->
  let wacc =
    match wsize_of_narrow_store_mn mn with
    | Some ws' -> ws'
    | None -> opts.opts_size
  in
  let tin = (Coq_lword wacc) :: [] in
  let semi = armv8a_extend_semi wacc false wacc in
  { id_valid =
  ((||)
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U32))
    (eq_op wsize_wsize__canonical__eqtype_Equality (Obj.magic opts.opts_size)
      (Obj.magic U64)));
  id_msb_flag = MSB_MERGE; id_tin = tin; id_in =
  ((coq_Ea armv8a_decl O) :: []); id_tout = ((Coq_lword wacc) :: []);
  id_out = ((coq_Eu armv8a_decl (S O)) :: []); id_semi =
  (sem_prod_ok (map eval_ltype tin) (Obj.magic semi)); id_args_kinds =
  (ak_reg_addr armv8a_decl); id_nargs = (S (S O)); id_str_jas =
  (Obj.magic armv8a_mn_str mn); id_safe = []; id_doit = DOIT; id_pp_asm =
  (pp_armv8a_op_szs mn
    ((match mn with
      | STRB -> U32
      | STRH -> U32
      | _ -> opts.opts_size) :: (opts.opts_size :: []))) })

(** val mn_desc :
    armv8a_options -> armv8a_mnemonic -> (register, empty, empty, rflag,
    condt) instr_desc_t **)

let mn_desc opts = function
| ADD -> armv8a_ADD_instr opts
| ADDS -> armv8a_ADDS_instr opts
| ADC -> armv8a_ADC_instr opts
| ADCS -> armv8a_ADCS_instr opts
| SUB -> armv8a_SUB_instr opts
| SUBS -> armv8a_SUBS_instr opts
| NEG -> armv8a_NEG_instr opts
| MUL -> armv8a_MUL_instr opts
| MADD -> armv8a_MADD_instr opts
| MSUB -> armv8a_MSUB_instr opts
| SDIV -> armv8a_SDIV_instr opts
| UDIV -> armv8a_UDIV_instr opts
| AND -> armv8a_AND_instr opts
| ORR -> armv8a_ORR_instr opts
| EOR -> armv8a_EOR_instr opts
| MVN -> armv8a_MVN_instr opts
| ASR -> armv8a_ASR_instr opts
| LSL -> armv8a_LSL_instr opts
| LSR -> armv8a_LSR_instr opts
| ROR -> armv8a_ROR_instr opts
| MOV -> armv8a_MOV_instr opts
| MOVN -> armv8a_MOVN_instr opts
| MOVZ -> armv8a_MOVZ_instr opts
| MOVK -> armv8a_MOVK_instr opts
| ADR -> armv8a_ADR_instr opts
| SXTB -> armv8a_SXTB_instr opts
| SXTH -> armv8a_SXTH_instr opts
| SXTW -> armv8a_SXTW_instr opts
| UXTB -> armv8a_UXTB_instr opts
| UXTH -> armv8a_UXTH_instr opts
| UXTW -> armv8a_UXTW_instr opts
| CMP -> armv8a_CMP_instr opts
| TST -> armv8a_TST_instr opts
| CSEL -> armv8a_CSEL_instr opts
| STR -> armv8a_store_instr opts STR
| STRB -> armv8a_store_instr opts STRB
| STRH -> armv8a_store_instr opts STRH
| x -> armv8a_load_instr opts x

(** val armv8a_instr_desc :
    armv8a_asm_op -> (register, empty, empty, rflag, condt) instr_desc_t **)

let armv8a_instr_desc = function
| ARMv8A_op (mn, opts) -> mn_desc opts mn

(** val armv8a_prim_sized :
    armv8a_mnemonic -> armv8a_asm_op prim_constructor **)

let armv8a_prim_sized mn =
  PrimX86 (((PVp U64) :: ((PVp U32) :: [])), (fun s ->
    match s with
    | PVp sz -> Some (ARMv8A_op (mn, (opts_at sz)))
    | _ -> None))

(** val armv8a_prim_string :
    (string * armv8a_asm_op prim_constructor) list **)

let armv8a_prim_string =
  map (fun mn -> ((string_of_armv8a_mnemonic mn),
    (if in_mem (Obj.magic mn)
          (mem (seq_predType armv8a_mnemonic_eqType)
            (Obj.magic sized_mnemonics))
     then armv8a_prim_sized mn
     else primM (ARMv8A_op (mn, default_opts)))))
    finTC_armv8a_mnemonic.cenum

(** val armv8a_op_decl :
    (register, empty, empty, rflag, condt, armv8a_asm_op) asm_op_decl **)

let armv8a_op_decl =
  { Arch_decl._eqT = eqTC_armv8a_asm_op; instr_desc_op = armv8a_instr_desc;
    Arch_decl.prim_string = armv8a_prim_string }

type armv8a_prog =
  (register, empty, empty, rflag, condt, armv8a_asm_op) asm_prog
