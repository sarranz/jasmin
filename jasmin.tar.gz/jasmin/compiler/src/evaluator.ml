open BinNums
open Utils0
open Type
open Sem_type
open Warray_
open Var0
open Varmap
open Low_memory
open Expr
open Psem_defs
open Values
open Sem_params

exception Eval_error of instr_info * Utils0.error

let pp_error fmt err =
  Format.fprintf fmt "%s" @@
  match err with
  | ErrOob -> "out_of_bound"
  | ErrAddrUndef -> "undefined address"
  | ErrAddrInvalid -> "invalid address"
  | ErrStack -> "stack error"
  | ErrType  -> "type error"
  | ErrArith -> "arithmetic error"
  | ErrSemUndef -> "undefined semantics"
  | ErrAssert _ -> "assertion violation"

let exn_exec (ii:instr_info) (r: 't exec) =
  match r with
  | Ok r -> r
  | Error e -> raise (Eval_error(ii, e))

let of_val_z ii v : coq_Z =
  Obj.magic (exn_exec ii (of_val Coq_cint v))

let of_val_b ii v : bool =
  Obj.magic (exn_exec ii (of_val Coq_cbool v))

(* ----------------------------------------------------------------- *)
type 'asm stack =
  | Sempty of instr_info * 'asm fundef * value list
  | Scall of
      instr_info * 'asm fundef * value list * lval list * Vm.t * 'asm instr list * 'asm stack
  | Sfor of instr_info * var_i option * coq_Z list * 'asm instr list * 'asm instr list * 'asm stack

type ('syscall_state, 'asm) state =
  { s_prog : 'asm prog;
    s_cmd  : 'asm instr list;
    s_estate : 'syscall_state estate;
    s_stk  : 'asm stack;
  }

exception Final of Memory.mem * values

let withassert = Sem_params.withassert

let exec_pre ep spp ii fc gd escs emem (vargs:value list) =
  let s1 = exn_exec ii (write_vars nosubword ep true fc.f_iparams vargs {escs; emem; evm = Vm.init nosubword}) in
  List.iter (fun pa -> exn_exec ii (sem_assert nosubword withassert ep spp gd s1 pa)) fc.f_pre

let exec_post ep spp ii fc gd escs emem (vargs:value list) (vres: value list) =
  let s1 = exn_exec ii (write_vars nosubword ep true fc.f_iparams vargs {escs; emem; evm = Vm.init nosubword}) in
  let s1 = exn_exec ii (write_vars nosubword ep true fc.f_ires vres s1) in
  List.iter (fun pa -> exn_exec ii (sem_assert nosubword withassert ep spp gd s1 pa)) fc.f_post

let init_estate ep spp p ii fn scs0 m vargs =
  let f = BatOption.get (get_fundef p.p_funcs fn) in
  let gd = p.p_globs in
  let vargs = exn_exec ii (mapM2 ErrType truncate_val (List.map eval_atype f.f_tyin) vargs) in
  BatOption.may (fun fc -> exec_pre ep spp ii fc gd scs0 m vargs) f.f_contract;
  let s_estate = { escs = scs0; emem = m; evm = Vm.init nosubword} in
  let s_estate = exn_exec ii (write_vars nosubword ep true f.f_params vargs s_estate) in
  f, vargs, s_estate

let finalize_estate ep spp p ii f vargs (s: _ estate) =
  let gd = p.p_globs in
  let vres = exn_exec ii (mapM (fun (x:var_i) -> get_var nosubword true s.evm x.v_var) f.f_res) in
  let vres = exn_exec ii (mapM2 ErrType truncate_val (List.map Type.eval_atype f.f_tyout) vres) in
  BatOption.may (fun fc -> exec_post ep spp ii fc gd s.escs s.emem vargs vres) f.f_contract;
  s.escs, s.emem, vres

let return ep spp s =
  assert (s.s_cmd = []);
  match s.s_stk with
  | Sempty(ii, f, vargs) ->
    let _, m, vres = finalize_estate ep spp s.s_prog ii f vargs s.s_estate in
    raise (Final(m, vres))

  | Scall(ii,f, vargs, xs,vm1,c,stk) ->
    let escs, emem, vres = finalize_estate ep spp s.s_prog ii f vargs s.s_estate in
    let gd = s.s_prog.p_globs in
    let s1 = exn_exec ii (write_lvals nosubword ep spp true gd {escs; emem; evm = vm1 } xs vres) in
    { s with
      s_cmd = c;
      s_estate = s1;
      s_stk = stk }

  | Sfor(ii,oi,ws,body,c,stk) ->
    match ws with
    | [] -> { s with s_cmd = c; s_stk = stk }
    | w::ws ->
      let s1 = match oi with
        | Some i -> exn_exec ii (write_var nosubword ep true i (Vint w) s.s_estate)
        | None -> s.s_estate
      in
      { s with s_cmd = body;
               s_estate = s1;
               s_stk = Sfor(ii, oi, ws, body, c, stk) }

let small_step1 ep spp sip s =
  match s.s_cmd with
  | [] -> return ep spp s
  | i :: c ->
    let MkI(ii,ir) = i in
    let gd = s.s_prog.p_globs in
    let s1 = s.s_estate in
    match ir with

    | Cassgn(x,_,ty,e) ->
      let v  = exn_exec ii (sem_pexpr nosubword ep spp true gd s1 e) in
      let v' = exn_exec ii (truncate_val (eval_atype ty) v) in
      let s2 = exn_exec ii (write_lval nosubword ep spp true gd x v' s1) in
      { s with s_cmd = c; s_estate = s2 }

    | Copn(xs,_,op,es) ->
      let s2 = exn_exec ii (sem_sopn nosubword ep spp sip._asmop gd op s1 xs es) in
      { s with s_cmd = c; s_estate = s2 }

    | Csyscall(xs,o, es) ->
      let ves = exn_exec ii (sem_pexprs nosubword ep spp true gd s1 es) in
      let ((scs, m), vs) =
        exn_exec ii (syscall_sem__ sip._sc_sem ep._pd s1.escs s1.emem o ves) in
      let s2 = exn_exec ii (write_lvals nosubword ep spp true gd {escs = scs; emem = m; evm = s1.evm} xs vs) in
      { s with s_cmd = c; s_estate = s2 }

    | Cassert (p,a) ->
      let _ = exn_exec ii (sem_assert nosubword withassert ep spp gd s1 (p, a)) in
      { s with s_cmd = c }

    | Cif(e,c1,c2) ->
      let b = of_val_b ii (exn_exec ii (sem_pexpr nosubword ep spp true gd s1 e)) in
      let c = (if b then c1 else c2) @ c in
      { s with s_cmd = c }

    | Cfor (fi, body) ->
      let oi, rng = match fi with
        | FIrange(i, d, lo, hi) ->
            let vlo = of_val_z ii (exn_exec ii (sem_pexpr nosubword ep spp true gd s1 lo)) in
            let vhi = of_val_z ii (exn_exec ii (sem_pexpr nosubword ep spp true gd s1 hi)) in
            Some i, wrange d vlo vhi
        | FIrepeat e ->
            let vn = of_val_z ii (exn_exec ii (sem_pexpr nosubword ep spp true gd s1 e)) in
            None, ziota Z0 vn
      in
      let s =
        {s with s_cmd = []; s_stk = Sfor(ii, oi, rng, body, c, s.s_stk) } in
      return ep spp s

    | Cwhile (_, c1, e, _, c2) ->
      { s with s_cmd = c1 @ MkI(ii, Cif(e, c2@[i],[])) :: c }

    | Ccall(xs,fn,es) ->
      let vargs = exn_exec ii (sem_pexprs nosubword ep spp true gd s1 es) in
      let f, vargs, s_estate = init_estate ep spp s.s_prog ii fn s1.escs s1.emem  vargs in
      let stk = Scall(ii,f, vargs, xs, s1.evm, c, s.s_stk) in
      {s with s_cmd = f.f_body;
              s_estate;
              s_stk = stk }


let rec small_step ep spp sip s =
  small_step ep spp sip (small_step1 ep spp sip s)

let init_state ep spp p ii fn scs0 m vargs =
  let f, vargs, s_estate = init_estate ep spp p ii fn scs0 m vargs in
  { s_prog = p; s_cmd = f.f_body; s_estate; s_stk = Sempty (ii, f, vargs) }


let exec ep spp sip scs0 p ii fn vargs m =
  let s = init_state ep spp p ii fn scs0 m vargs in
  try small_step ep spp sip s
  with Final(m,vs) -> m, vs

(* ----------------------------------------------------------- *)
let initial_memory reg_size rsp alloc =
  let ptr_of_z z = Word0.wrepr reg_size (Conv.cz_of_z z) in
  (Low_memory.Memory.coq_M reg_size).init
    (List.map (fun (ptr, sz) -> (ptr_of_z ptr, Conv.cz_of_z sz)) alloc)
    (ptr_of_z rsp)

(* ----------------------------------------------------------- *)
let run (type asm_op extra_op)
      (module A : Arch_full.Arch
              with type asm_op = asm_op
               and type extra_op = extra_op)
      (p : (asm_op, extra_op) Arch_extra.extended_op_gen Expr.uprog)
      ii fn args m =
  let ep = Sem_params_of_arch_extra.ep_of_asm_e A.asm_e Syscall_ocaml.sc_sem in
  let spp = Sem_params_of_arch_extra.spp_of_asm_e A.asm_e in
  let sip =
    Sem_params_of_arch_extra.sip_of_asm_e A.asm_e Syscall_ocaml.sc_sem
  in
  let scs0 = Syscall_ocaml.initial_state () in
  exec ep spp sip scs0 p ii fn args m

(* ----------------------------------------------------------- *)
let pp_undef fmt cty =
  let pp_ctype fmt cty =
    let open CoreIdent in
    let bty =
      match cty with
      | Coq_cbool -> Bool
      | Coq_cint -> Int
      | Coq_cword U8 -> U U8
      | _ ->
        (* in Vundef, other cases are impossible *)
        assert false
    in
    PrintCommon.pp_btype fmt bty
  in
  Format.fprintf fmt "undef<%a>" pp_ctype cty

let pp_word fmt ws w =
  let z = Word0.wunsigned ws w in
  let z = Conv.z_of_cz z in
  Printer.pp_print_X fmt z

let pp_val fmt v =
  match v with
  | Vbool b -> Format.fprintf fmt "%b" b
  | Vint z  -> Format.fprintf fmt "%a" Z.pp_print (Conv.z_of_cz z)
  | Varr(n,t) ->
    let ni = Conv.int_of_cz n in
    let pp_res fmt = function
      | Ok w               -> pp_word fmt U8 w
      | Error ErrAddrUndef -> pp_undef fmt (Coq_cword U8)
      | Error _            -> assert false in
    Format.fprintf fmt "@[[";
    for i = 0 to ni-2 do
      let i = Conv.cz_of_int i in
      Format.fprintf fmt "%a;@ " pp_res (WArray.get n Aligned AAscale U8 t i);
    done;
    if 0 < ni then
      pp_res fmt (WArray.get n Aligned AAscale U8 t (Conv.cz_of_int (ni-1)));
    Format.fprintf fmt "]@]";
  | Vword(ws, w) -> pp_word fmt ws w
  | Vundef ty -> pp_undef fmt ty
