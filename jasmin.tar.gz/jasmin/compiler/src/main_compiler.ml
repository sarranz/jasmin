open Jasmin
open Jasmin_checksafety
open Utils
open Prog
open Glob_options
open CLI_errors

(* -------------------------------------------------------------------- *)
exception UsageError

let parse () =
  let error () = raise UsageError in
  let infiles = ref [] in
  let set_in s = infiles := s :: !infiles in
  (* Set default option values *)
  if Sys.win32 then set_cc "windows";
  (* Parse command-line arguments *)
  Arg.parse (Arg.align options) set_in usage_msg;
  let c =
    match !color with
    | Auto -> Unix.isatty (Unix.descr_of_out_channel stderr)
    | Always -> true
    | Never -> false
  in
  if c then enable_colors ();
  match !infiles with
  | [] ->
    if !help_intrinsics || !safety_makeconfigdoc <> None || !help_version
    then ""
    else error()
  | [ infile ] ->
    check_options ();
    check_infile infile;
    infile
  | infile :: s :: _ -> raise CLI_errors.(CLIerror (RedundantInputFile (infile, s)))

(* -------------------------------------------------------------------- *)
let check_safety_p pd msf_size asmOp analyze s (p : (_, 'asm) Prog.prog) =
  let () = if SafetyConfig.sc_print_program () then
      let s1,s2 = Glob_options.print_strings s in
      Format.eprintf "@[<v>At compilation pass: %s@;%s@;@;\
                      %a@;@]@."
        s1 s2
        (Printer.pp_prog ~debug:true pd msf_size asmOp) p
  in

  let () = SafetyConfig.pp_current_config_diff () in

  let is_safe =
    List.fold_left (fun res f_decl ->
        if FInfo.is_export f_decl.f_cc then
          let () = Format.eprintf "@[<v>Analyzing function %s@]@."
              f_decl.f_name.fn_name in

          analyze ?fmt:None ~safety_param:!Glob_options.safety_param f_decl p && res
        else res)
      true
      (List.rev (snd p)) in
  if not is_safe then exit(2)

(* -------------------------------------------------------------------- *)
let main () =

  try
    let infile = parse() in

    let (module P) = SafetyMain.get_arch_with_analyze !target_arch !call_conv in
    let module Arch = P.A in

    if !safety_makeconfigdoc <> None
    then (
      let dir = oget !safety_makeconfigdoc in
      SafetyConfig.mk_config_doc dir;
      exit 0);

    if !help_intrinsics
    then (Help.show_intrinsics Arch.asmOp_sopn (); exit 0);

    if !help_version
    then (Format.printf "%s@." version_string; exit 0);

    let () = if !check_safety then
        match !safety_config with
        | Some conf -> SafetyConfig.load_config conf
        | None -> () in

    let env, pprog, _ast =
      try Compile.parse_file Arch.arch_info ~idirs:!Glob_options.idirs infile
      with
      | Annot.AnnotationError (loc, code) -> hierror ~loc:(Lone loc) ~kind:"annotation error" "%t" code
      | Pretyping.TyError (loc, code) -> hierror ~loc:(Lone loc) ~kind:"typing error" "%a" Pretyping.pp_tyerror code
      | Syntax.ParseError (loc, msg) ->
          let msg =
            match msg with
            | None -> "unexpected token" (* default message *)
            | Some msg -> msg
          in
          hierror ~loc:(Lone loc) ~kind:"parse error" "%s" msg
    in

    if !print_dependencies then begin
      Format.printf "%a"
        (pp_list " " (fun fmt p -> Format.fprintf fmt "%s" (BatPathGen.OfString.to_string p)))
        (List.tl (List.rev (Pretyping.Env.dependencies env)));
      exit 0
    end;

    (* Check if generated assembly labels will generate conflicts*)
    let label_errors = Label_check.get_labels_errors pprog in
    List.iter Label_check.warn_duplicate_label label_errors;

    eprint Compiler.Typing (Printer.pp_pprog ~debug:true Arch.pointer_data Arch.msf_size Arch.asmOp) pprog;

    let prog =
      try Compile.preprocess Arch.pointer_data Arch.msf_size Arch.asmOp pprog
      with Typing.TyError(loc, code) ->
        hierror ~loc:(Lmore loc) ~kind:"typing error" "%s" code
    in

    let prog =
      if !slice <> []
      then Slicing.slice !slice prog
      else prog
    in

    if to_warn Linter then begin
      let open Linter in
      let (_globs, funcs) = prog in
      let funcs = List.map RDAnalyser.analyse_function funcs in
      let vi_errors = VariableInitialisation.check_prog ([], funcs) in
      let funcs = List.map LivenessAnalyser.analyse_function funcs in
      let dv_errors = DeadVariables.check_prog ([], funcs) in
      let ir_errors = TaintAnalysis.check_prog ([], funcs) in
      let open CompileError in
      vi_errors @ dv_errors @ ir_errors
      |> List.filter (fun e -> e.level <= !Glob_options.linting_level)
      |> List.iter (fun error ->
          warning Linter (Location.i_loc0 error.location) "%t" error.to_text
        )
    end;

    (* This function is called after each compilation pass.
        - Check program safety (and exit) if the time has come
        - Pretty-print the program
        - Add your own checker here!
    *)
    let visit_prog_after_pass ~debug s p =
      if s = SafetyConfig.sc_comp_pass () && !check_safety then
        check_safety_p
          Arch.pointer_data
          Arch.msf_size
          Arch.asmOp
          P.analyze
          s
          p
        |> fun () -> exit 0
      else
        eprint s (Printer.pp_prog ~debug Arch.pointer_data Arch.msf_size Arch.asmOp) p
    in

    visit_prog_after_pass ~debug:true Compiler.ParamsExpansion prog;

    let prog =
      match !Glob_options.do_auto_spill with
      | None -> prog
      | Some strategy -> AutoSpill.doit strategy prog
    in

    (* Now call the coq compiler *)
    let cprog = Conv.cuprog_of_prog prog in

    if !debug then Printf.eprintf "translated to coq \n%!";

    let to_exec = Pretyping.Env.Exec.get env in
    if to_exec <> [] then begin
        let exec { L.pl_loc = loc ; L.pl_desc = (f, m) } =
          let ii = L.i_loc0 loc, [] in
          try
            let pp_range fmt (ptr, sz) =
              Format.fprintf fmt "%a:%a" Z.pp_print ptr Z.pp_print sz in
            Format.printf "/* Evaluation of %s (@[<h>%a@]):@." f.fn_name
              (pp_list ",@ " pp_range) m;
            let _m, vs =
              (* TODO: allow to configure the initial stack pointer *)
              (match
                 Evaluator.initial_memory Arch.reg_size (Z.of_string "1024") m
               with
               | Utils0.Ok m -> m
               | Utils0.Error err -> raise (Evaluator.Eval_error (ii, err)))
              |> Evaluator.run
                   (module Arch)
                   (Expr.to_uprog Arch.asmOp cprog)
                   ii f []
            in

            Format.printf "@[<v>%a@]@."
              (pp_list "@ " Evaluator.pp_val) vs;
            Format.printf "*/@."
          with Evaluator.Eval_error (ii,err) ->
            let i_loc, _ = ii in
            hierror ~loc:(Lmore i_loc) ~kind:"evaluation error" "%a" Evaluator.pp_error err
        in
        List.iter exec to_exec
      end;

    begin match Compile.compile (module Arch) visit_prog_after_pass prog cprog with
    | Utils0.Error e ->
      let e = Conv.error_of_cerror (Printer.pp_err ~debug:!debug) e in
      raise (HiError e)
    | Utils0.Ok asm ->
      if !Glob_options.print_export_info_json then begin
        Format.printf "%a" (fun fmt ->
          PrintExportInfo.pp_export_info_json
            fmt
            env
            prog)
            asm
      end;
      if !outfile <> "" then begin
        BatFile.with_file_out !outfile (fun out ->
          let fmt = BatFormat.formatter_of_out_channel out in
          Format.fprintf fmt "%a%!" Arch.pp_asm asm);
          if !debug then Format.eprintf "assembly listing written@."
      end else if List.mem Compiler.Assembly !print_list then
          Format.printf "%a%!" Arch.pp_asm asm
    | exception Annot.AnnotationError (loc, code) -> hierror ~loc:(Lone loc) ~kind:"annotation error" "%t" code
    end
  with


  | Utils.HiError e ->
    Format.eprintf "%a@." pp_hierror e;
    exit 1

  | UsageError ->
    Arg.usage (Arg.align options) usage_msg;
    exit 1

  | CLIerror e ->
    Format.eprintf "%a: %s.\n"
      (pp_print_bold_red Format.pp_print_string) "Error"
      (pp_cli_error e);
    exit 1
