module Core_arch_ARM : Arch_full.Core_arch
  with type reg = Arm_decl.register
   and type regx = Arch_utils.empty
   and type xreg = Arch_utils.empty
   and type rflag = Arm_common.rflag
   and type cond = Arm_common.condt
   and type asm_op = Arm_instr_decl.arm_op
   and type extra_op = Arm_extra.arm_extra_op

module Core_arch_RISCV : Arch_full.Core_arch
  with type reg = Riscv_decl.register
   and type regx = Arch_utils.empty
   and type xreg = Arch_utils.empty
   and type rflag = Arch_utils.empty
   and type cond = Riscv_decl.condt
   and type asm_op = Riscv_instr_decl.riscv_op
   and type extra_op = Riscv_extra.riscv_extra_op

module Core_arch_OTBN : Arch_full.Core_arch
  with type reg = Otbn_decl.register
   and type regx = Arch_utils.empty
   and type xreg = Otbn_decl.wide_register
   and type rflag = Otbn_decl.rflag
   and type cond = Otbn_decl.condition
   and type asm_op = Otbn_instr_decl.otbn_op
   and type extra_op = Otbn_extra.extra_op

module Core_arch_ARMV8A : Arch_full.Core_arch
  with type reg = Armv8a_decl.register
   and type regx = Arch_utils.empty
   and type xreg = Arch_utils.empty
   and type rflag = Arm_common.rflag
   and type cond = Arm_common.condt
   and type asm_op = Armv8a_instr_decl.armv8a_asm_op
   and type extra_op = Armv8a_extra.armv8a_extra_op

open X86_decl

val core_arch_x86 :
  Glob_options.call_conv ->
  (module Arch_full.Core_arch
     with type reg = register
      and type regx = register_ext
      and type xreg = xmm_register
      and type rflag = rflag
      and type cond = condt
      and type asm_op = X86_instr_decl.x86_op
      and type extra_op = X86_extra.x86_extra_op)

val get_arch_module :
  Utils.architecture -> Glob_options.call_conv -> (module Arch_full.Arch)
