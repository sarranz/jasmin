open Prog

val pp_warning_msg :  Format.formatter -> Compiler_util.warning_msg -> unit
val pp_err : debug:bool -> Format.formatter -> Compiler_util.pp_error -> unit

val pp_print_X : Format.formatter -> Z.t -> unit

val pp_pvar  : Format.formatter -> pvar -> unit
val pp_ptype : debug:bool -> Format.formatter -> pty -> unit
val pp_eptype : debug:bool -> Format.formatter -> epty -> unit
val pp_plval : debug:bool -> Format.formatter -> plval -> unit
val pp_pexpr : debug:bool -> Format.formatter -> pexpr -> unit
val pp_pprog : debug:bool -> Wsize.wsize -> Wsize.wsize -> ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) pprog -> unit

val pp_var   : debug:bool -> Format.formatter -> var -> unit
val pp_dvar  : debug:bool -> Format.formatter -> var -> unit

val string_of_combine_flags : Operators.combine_flags -> string

val pp_expr  : debug:bool -> Format.formatter -> expr -> unit
val pp_lval  : debug:bool -> Format.formatter -> lval -> unit
val pp_eassert : debug:bool -> Format.formatter -> eassert -> unit

val pp_instr : debug:bool ->
               Wsize.wsize ->
               Wsize.wsize ->
               ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) instr -> unit

val pp_stmt  : debug:bool ->
               Wsize.wsize ->
               Wsize.wsize ->
               ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) stmt  -> unit

val pp_header : debug:bool -> Format.formatter -> ('info, 'asm) func -> unit

val pp_fun :
             debug:bool ->
             ?pp_locals:(Sv.t Utils.pp) ->
             ?pp_info:((Location.i_loc * 'info) Utils.pp) ->
             (('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.sopn) Utils.pp ->
             var Utils.pp ->
             (('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) func) Utils.pp

val pp_ifunc : debug:bool -> (Location.i_loc * 'info) Utils.pp ->
               Wsize.wsize ->
               Wsize.wsize ->
               ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) func -> unit

val pp_func  : debug:bool ->
               Wsize.wsize ->
               Wsize.wsize ->
               ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) func -> unit

val pp_iprog : debug:bool -> (Location.i_loc * 'info) Utils.pp ->
               Wsize.wsize ->
               Wsize.wsize ->
               ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) prog -> unit

val pp_prog  : debug:bool ->
               Wsize.wsize ->
               Wsize.wsize ->
               ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) prog -> unit

val pp_to_save : debug:bool ->
                 Format.formatter -> Var0.Var.var * BinNums.coq_Z -> unit

val pp_saved_stack : debug:bool ->
                     Format.formatter -> Expr.saved_stack -> unit

val pp_return_address : debug:bool ->
                        Format.formatter -> Expr.return_address_location -> unit

val pp_sprog : debug:bool ->
               Wsize.wsize ->
               Wsize.wsize ->
               ('asm_op, 'extra_op) Arch_extra.extended_op_gen Sopn.asmOp ->
               Format.formatter -> ('info, ('asm_op, 'extra_op) Arch_extra.extended_op_gen) sprog -> unit

